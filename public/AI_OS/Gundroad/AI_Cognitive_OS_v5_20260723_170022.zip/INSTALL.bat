﻿@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul

:: ============================================================
:: AI COGNITIVE OS v5 - One-Click Installer
:: Auto-detect Node.js, auto-install dependencies
:: ============================================================

title AI COGNITIVE OS v5 - Installer
set "INSTALL_DIR=%~dp0"
set "INSTALL_DIR=%INSTALL_DIR:~0,-1%"

echo.
echo ============================================
echo    AI COGNITIVE OS v5 - Setup
echo ============================================
echo.
echo Install Path: %INSTALL_DIR%
echo.

:: --- Step 1: Check Node.js ---
echo [1/4] Checking Node.js installation...

node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo   [X] Node.js NOT FOUND
    echo.
    echo   Please install Node.js 18+ first:
    echo   https://nodejs.org/en/download/
    echo.
    echo   After installation, run this installer again.
    echo.
    pause
    exit /b 1
)

for /f "tokens=*" %%a in ('node --version') do set "NODE_VER=%%a"
echo   [OK] Node.js %NODE_VER% found

:: --- Step 2: Check npm ---
echo.
echo [2/4] Checking npm...

npm --version >nul 2>&1
if %errorlevel% neq 0 (
    echo   [X] npm NOT FOUND
    echo   Please reinstall Node.js with npm included.
    pause
    exit /b 1
)

for /f "tokens=*" %%a in ('npm --version') do set "NPM_VER=%%a"
echo   [OK] npm %NPM_VER% found

:: --- Step 3: Install dependencies ---
echo.
echo [3/4] Installing dependencies...
echo   This may take a few minutes...
echo.

cd /d "%INSTALL_DIR%"
npm install

if %errorlevel% neq 0 (
    echo.
    echo   [X] npm install FAILED
    echo   Please check your internet connection and try again.
    pause
    exit /b 1
)

echo   [OK] Dependencies installed

:: --- Step 4: Create start shortcut ---
echo.
echo [4/4] Creating shortcuts...

(
echo @echo off
echo chcp 65001 ^>nul
echo cd /d "%~dp0"
echo node teZ.js
echo pause
) > "%INSTALL_DIR%\START.bat"

echo   [OK] START.bat created

:: --- Step 5: Create desktop shortcut (optional) ---
echo.
echo ============================================
echo    Setup Complete!
echo ============================================
echo.
echo   [OK] All dependencies installed
echo   [OK] START.bat created
echo.
echo   Next steps:
echo   1. Double-click START.bat to launch
echo   2. Enter your license key (or type TRY)
echo.
echo   Need help? Check README.txt
echo.

choice /C YN /M "Create desktop shortcut"
if %errorlevel% equ 1 (
    set "DESKTOP=%USERPROFILE%\Desktop"
    (
        echo [InternetShortcut]
        echo URL=file:///%INSTALL_DIR:\=/%/START.bat
        echo IconFile=%INSTALL_DIR%\teZ.js
        echo IconIndex=0
    ) > "%DESKTOP%\AI Cognitive OS v5.url"
    echo   [OK] Desktop shortcut created
)

echo.
pause
