@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul

:: ============================================================
:: AI COGNITIVE OS v5 - Uninstaller
:: ============================================================

title AI COGNITIVE OS v5 - Uninstall

set "INSTALL_DIR=%~dp0"
set "INSTALL_DIR=%INSTALL_DIR:~0,-1%"

echo.
echo ============================================
echo    AI COGNITIVE OS v5 - Uninstall
echo ============================================
echo.
echo   Install Path: %INSTALL_DIR%
echo.
echo   此操作將移除：
echo   - 程式檔案
echo   - 桌面捷徑
echo   - 啟動項目
echo.
echo   使用者資料將保留：
echo   - Proj/（專案檔案）
echo   - Exports/（匯出報表）
echo   - memory/（對話記憶）
echo.

choice /C YN /M "確認解除安裝"
if %errorlevel% neq 1 (
    echo   已取消
    pause
    exit /b 0
)

echo.
echo [1/4] Stopping processes...

:: 停止 Node.js 程序
taskkill /F /IM node.exe >nul 2>&1
echo   [OK] Node.js processes stopped

:: 停止 Ollama（可選）
taskkill /F /IM ollama.exe >nul 2>&1
echo   [OK] Ollama processes stopped

timeout /t 2 /nobreak >nul

echo.
echo [2/4] Removing shortcuts...

:: 移除桌面捷徑
set "DESKTOP=%USERPROFILE%\Desktop"
if exist "%DESKTOP%\AI Cognitive OS v5.url" (
    del "%DESKTOP%\AI Cognitive OS v5.url"
    echo   [OK] Desktop shortcut removed
)

:: 移除開始功能表（如有）
set "STARTMENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs"
if exist "%STARTMENU%\AI Cognitive OS v5" (
    rmdir /s /q "%STARTMENU%\AI Cognitive OS v5"
    echo   [OK] Start menu entry removed
)

echo.
echo [3/4] Removing program files...

:: 移除 npm 全域安裝（如果在此目錄）
if exist "%INSTALL_DIR%\npm-global" (
    rmdir /s /q "%INSTALL_DIR%\npm-global"
    echo   [OK] npm packages removed
)

:: 移除 node_modules
if exist "%INSTALL_DIR%\node_modules" (
    rmdir /s /q "%INSTALL_DIR%\node_modules"
    echo   [OK] node_modules removed
)

:: 移除啟動腳本
if exist "%INSTALL_DIR%\START.bat" del "%INSTALL_DIR%\START.bat"
if exist "%INSTALL_DIR%\START_WEB.bat" del "%INSTALL_DIR%\START_WEB.bat"
if exist "%INSTALL_DIR%\INSTALL_SUMMARY.txt" del "%INSTALL_DIR%\INSTALL_SUMMARY.txt"

echo   [OK] Program files removed

echo.
echo [4/4] Cleaning registry...

:: 移除環境變數（如有設定）
reg delete "HKCU\Environment" /v "AI_OS_HOME" /f >nul 2>&1

echo   [OK] Registry cleaned

echo.
echo ============================================
echo    Uninstall Complete
echo ============================================
echo.
echo   以下資料夾已保留，請手動備份或刪除：
echo   - %INSTALL_DIR%\Proj
echo   - %INSTALL_DIR%\Novels
echo   - %INSTALL_DIR%\Exports
echo   - %INSTALL_DIR%\memory
echo   - %INSTALL_DIR%\backup
echo.
echo   若要完全移除，請刪除整個資料夾：
echo   %INSTALL_DIR%
echo.

choice /C YN /M "是否立即刪除整個安裝資料夾"
if %errorlevel% equ 1 (
    cd /d "%USERPROFILE%"
    rmdir /s /q "%INSTALL_DIR%"
    echo.
    echo   [OK] 安裝資料夾已刪除
)

echo.
pause