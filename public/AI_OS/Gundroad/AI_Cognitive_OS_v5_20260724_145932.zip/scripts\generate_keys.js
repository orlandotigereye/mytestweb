// scripts/generate_keys.js
const crypto = require('crypto');
const SECRET_SALT = '100127062_ILC_IA_odnalrO';

function validateFormat(key) {
    return /^ACOS5-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(key);
}

function validateKey(key) {
    if (!validateFormat(key)) return false;
    const hmac = crypto.createHmac('sha256', SECRET_SALT);
    hmac.update(key);
    const hash = hmac.digest('hex');
    const nums = key.match(/\d/g) || [];
    const sum = nums.reduce((a, b) => a + parseInt(b), 0);
    const check = parseInt(hash[0], 16);
    return (sum % 16) === (check % 16);
}

function generateKey() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    while (true) {
        const parts = [];
        for (let i = 0; i < 4; i++) {
            let part = '';
            for (let j = 0; j < 4; j++) {
                part += chars[Math.floor(Math.random() * chars.length)];
            }
            parts.push(part);
        }
        const key = 'ACOS5-' + parts.join('-');
        if (validateKey(key)) return key;
    }
}

const keys = [];
for (let i = 0; i < 10000; i++) {
    keys.push(generateKey());
}

const fs = require('fs');
fs.writeFileSync('gumroad_keys.txt', keys.join('\n'));
console.log(`Generated ${keys.length} valid keys`);