﻿@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul

:: ============================================================
:: AI COGNITIVE OS v5 - Enhanced Installer
:: 支援：日誌記錄、重試機制、離線安裝
:: ============================================================

title AI COGNITIVE OS v5 - Installer

:: ========== 初始化日誌 ==========
set "INSTALL_DIR=%~dp0"
set "INSTALL_DIR=%INSTALL_DIR:~0,-1%"
set "LOG_FILE=%INSTALL_DIR%\install.log"
set "LOG_DIR=%INSTALL_DIR%\logs"

if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"
set "LOG_FILE=%LOG_DIR%\install_%date:~-4,4%%date:~-10,2%%date:~-7,2%_%time:~0,2%%time:~3,2%%time:~6,2%.log"
set "LOG_FILE=%LOG_FILE: =0%"

echo ============================================ > "%LOG_FILE%"
echo AI COGNITIVE OS v5 - Install Log >> "%LOG_FILE%"
echo Start: %date% %time% >> "%LOG_FILE%"
echo Install Dir: %INSTALL_DIR% >> "%LOG_FILE%"
echo ============================================ >> "%LOG_FILE%"
echo. >> "%LOG_FILE%"

call :LOG "Installer started"
call :LOG "Install directory: %INSTALL_DIR%"

:: ========== 檢查管理員權限 ==========
net session >nul 2>&1
if %errorlevel% neq 0 (
    call :LOG "Admin rights required, requesting elevation..."
    echo.
    echo   需要管理員權限，正在提升...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

call :LOG "Admin rights confirmed"

:: ========== 顯示歡迎畫面 ==========
cls
echo.
echo ============================================
echo    AI COGNITIVE OS v5 - Setup
echo    Windows 11 Compatible
echo ============================================
echo.
echo   Install Path: %INSTALL_DIR%
echo   Log File: %LOG_FILE%
echo.
echo   [提示] 如果 Windows Defender 提示，
echo          請點「更多資訊」→「仍要執行」
echo.
echo   [提示] 建議暫時關閉防毒軟體即時掃描
echo          以避免安裝過程被中斷
echo.
pause

:: ========== 檢查離線模式 ==========
set "OFFLINE_MODE=0"
if exist "%INSTALL_DIR%\offline\node-v20.15.1-x64.msi" (
    if exist "%INSTALL_DIR%\offline\OllamaSetup.exe" (
        set "OFFLINE_MODE=1"
        call :LOG "Offline mode detected"
        echo.
        echo   [離線模式] 使用本地安裝檔
    )
)

:: ============================================================
:: Step 0: 檢查系統需求
:: ============================================================
echo.
echo [0/6] Checking system requirements...
call :LOG "Step 0: Checking system requirements"

:: 檢查作業系統
for /f "tokens=*" %%a in ('ver') do set "OS_VER=%%a"
call :LOG "OS: %OS_VER%"

:: 檢查磁碟空間
call :CHECK_DISK_SPACE
if %errorlevel% neq 0 goto :INSTALL_FAILED

:: 檢查網路（離線模式跳過）
if %OFFLINE_MODE% equ 0 (
    call :CHECK_NETWORK
    if %errorlevel% neq 0 goto :INSTALL_FAILED
) else (
    echo   [SKIP] Offline mode, skipping network check
    call :LOG "Offline mode: network check skipped"
)

:: 檢查 PowerShell
call :CHECK_POWERSHELL

:: ============================================================
:: Step 1: 安裝 Node.js
:: ============================================================
echo.
echo [1/6] Installing Node.js...
call :LOG "Step 1: Installing Node.js"

call :INSTALL_NODE
if %errorlevel% neq 0 goto :INSTALL_FAILED

:: ============================================================
:: Step 2: 修復 npm
:: ============================================================
echo.
echo [2/6] Configuring npm...
call :LOG "Step 2: Configuring npm"

call :FIX_NPM
if %errorlevel% neq 0 goto :INSTALL_FAILED

:: ============================================================
:: Step 3: 安裝依賴
:: ============================================================
echo.
echo [3/6] Installing dependencies...
call :LOG "Step 3: Installing dependencies"

call :INSTALL_DEPS
if %errorlevel% neq 0 (
    call :LOG "WARN: Some dependencies failed to install"
)

:: ============================================================
:: Step 4: 安裝 Ollama
:: ============================================================
echo.
echo [4/6] Installing Ollama (AI Engine)...
call :LOG "Step 4: Installing Ollama"

call :INSTALL_OLLAMA
if %errorlevel% neq 0 (
    call :LOG "WARN: Ollama installation failed or skipped"
)

:: ============================================================
:: Step 5: 下載 AI 模型
:: ============================================================
echo.
echo [5/6] Downloading AI models...
call :LOG "Step 5: Downloading AI models"

call :DOWNLOAD_MODELS
if %errorlevel% neq 0 (
    call :LOG "WARN: Some models failed to download"
)

:: ============================================================
:: Step 6: 建立啟動檔案
:: ============================================================
echo.
echo [6/6] Creating startup files...
call :LOG "Step 6: Creating startup files"

call :CREATE_STARTUP_FILES
if %errorlevel% neq 0 goto :INSTALL_FAILED

:: ============================================================
:: 安裝完成
:: ============================================================
call :LOG "Installation completed successfully"

echo.
echo ============================================
echo    Setup Complete!
echo ============================================
echo.
echo   [OK] Installation finished
echo   Log: %LOG_FILE%
echo.
echo   Launch Options:
echo   --------------------
echo   1. START.bat       - Console mode
echo   2. START_WEB.bat   - Auto-open browser
echo   3. Desktop shortcut
echo.
echo   Web Portal: http://localhost:3005
echo.

call :SAVE_SUMMARY

pause
exit /b 0

:: ============================================================
:: 安裝失敗處理
:: ============================================================
:INSTALL_FAILED
call :LOG "ERROR: Installation failed"
echo.
echo ============================================
echo    Installation Failed
echo ============================================
echo.
echo   Please check the log file:
echo   %LOG_FILE%
echo.
echo   Common issues:
echo   1. No internet connection (use offline mode)
echo   2. Insufficient disk space
echo   3. Antivirus blocking installation
echo   4. No administrator rights
echo.
echo   For help, contact support or check README.txt
echo.

pause
exit /b 1

:: ============================================================
:: 子程序：記錄日誌
:: ============================================================
:LOG
echo [%date% %time%] %~1 >> "%LOG_FILE%"
exit /b 0

:: ============================================================
:: 子程序：檢查磁碟空間
:: ============================================================
:CHECK_DISK_SPACE
for /f "tokens=3" %%a in ('wmic logicaldisk where "DeviceID='C:'" get FreeSpace /value 2^>nul ^| find "="') do (
    set "FREE_BYTES=%%a"
)
if defined FREE_BYTES (
    set /a "FREE_GB=FREE_BYTES/1024/1024/1024"
    if !FREE_GB! LSS 5 (
        echo   [X] 磁碟空間不足！需要至少 5GB
        echo   目前可用: !FREE_GB! GB
        call :LOG "ERROR: Insufficient disk space: !FREE_GB! GB"
        exit /b 1
    )
    echo   [OK] Disk space: !FREE_GB! GB available
    call :LOG "Disk space: !FREE_GB! GB available"
) else (
    echo   [WARN] 無法檢查磁碟空間，繼續安裝...
    call :LOG "WARN: Could not check disk space"
)
exit /b 0

:: ============================================================
:: 子程序：檢查網路
:: ============================================================
:CHECK_NETWORK
echo   Checking internet connection...
call :LOG "Checking internet connection"

ping -n 1 -w 5000 nodejs.org >nul 2>&1
if %errorlevel% neq 0 (
    echo   [X] 無法連線到網路
    echo   請確認網路連線，或使用離線安裝模式
    call :LOG "ERROR: No internet connection"
    exit /b 1
)
echo   [OK] Internet connection OK
call :LOG "Internet connection OK"
exit /b 0

:: ============================================================
:: 子程序：檢查 PowerShell
:: ============================================================
:CHECK_POWERSHELL
powershell -Command "Get-ExecutionPolicy" >nul 2>&1
if %errorlevel% neq 0 (
    call :LOG "WARN: PowerShell execution policy restricted"
    echo   [WARN] PowerShell 執行受限，嘗試修復...
    powershell -Command "Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser -Force" >nul 2>&1
    if %errorlevel% equ 0 (
        echo   [OK] PowerShell fixed
        call :LOG "PowerShell execution policy fixed"
    ) else (
        echo   [WARN] Could not fix PowerShell, continuing...
        call :LOG "WARN: Could not fix PowerShell"
    )
) else (
    call :LOG "PowerShell OK"
)
exit /b 0

:: ============================================================
:: 子程序：安裝 Node.js（含重試）
:: ============================================================
:INSTALL_NODE
node --version >nul 2>&1
if %errorlevel% equ 0 (
    for /f "tokens=*" %%a in ('node --version') do set "NODE_VER=%%a"
    echo   [OK] Node.js %NODE_VER% already installed
    call :LOG "Node.js already installed: %NODE_VER%"
    exit /b 0
)

echo   [X] Node.js NOT FOUND
echo   Installing Node.js 20 LTS...
call :LOG "Node.js not found, installing..."

set "NODE_INSTALLER=%TEMP%\node-setup.msi"
set "RETRY=0"
set "MAX_RETRY=3"

:NODE_DOWNLOAD_RETRY
if %RETRY% GEQ %MAX_RETRY% (
    echo   [X] 下載失敗，已重試 %MAX_RETRY% 次
    call :LOG "ERROR: Node.js download failed after %MAX_RETRY% retries"
    
    if %OFFLINE_MODE% equ 1 (
        echo   [離線模式] 嘗試使用本地檔案...
        set "NODE_INSTALLER=%INSTALL_DIR%\offline\node-v20.15.1-x64.msi"
        if exist "!NODE_INSTALLER!" (
            call :LOG "Using offline installer: !NODE_INSTALLER!"
            goto :NODE_INSTALL
        )
    )
    
    echo   請手動下載並安裝 Node.js:
    echo   https://nodejs.org/en/download/
    start https://nodejs.org/en/download/
    exit /b 1
)

if %OFFLINE_MODE% equ 1 (
    set "NODE_INSTALLER=%INSTALL_DIR%\offline\node-v20.15.1-x64.msi"
    if exist "!NODE_INSTALLER!" (
        call :LOG "Using offline installer"
        goto :NODE_INSTALL
    )
)

echo   [下載中] 嘗試 %RETRY%/%MAX_RETRY%...
call :LOG "Downloading Node.js (attempt %RETRY%/%MAX_RETRY%)"

powershell -Command "& {$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://nodejs.org/dist/v20.15.1/node-v20.15.1-x64.msi' -OutFile '%NODE_INSTALLER%' -TimeoutSec 60}"

if not exist "%NODE_INSTALLER%" (
    set /a RETRY+=1
    echo   [WARN] 下載失敗，%RETRY% 秒後重試...
    timeout /t %RETRY% /nobreak >nul
    goto :NODE_DOWNLOAD_RETRY
)

:NODE_INSTALL
echo   [安裝中] 執行 Node.js 安裝程式...
call :LOG "Installing Node.js from: %NODE_INSTALLER%"

msiexec /i "%NODE_INSTALLER%" /quiet /norestart ALLUSERS=1
if %errorlevel% neq 0 (
    echo   [WARN] 安裝程式回傳錯誤，可能已安裝或需要重開機
    call :LOG "WARN: msiexec returned %errorlevel%"
)

timeout /t 10 /nobreak >nul

:: 重新載入 PATH
if exist "C:\Program Files\nodejs\node.exe" (
    set "PATH=C:\Program Files\nodejs;%PATH%"
) else if exist "C:\Program Files (x86)\nodejs\node.exe" (
    set "PATH=C:\Program Files (x86)\nodejs;%PATH%"
)

:: 驗證
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo   [X] Node.js 安裝驗證失敗
    call :LOG "ERROR: Node.js installation verification failed"
    exit /b 1
)

for /f "tokens=*" %%a in ('node --version') do set "NODE_VER=%%a"
echo   [OK] Node.js %NODE_VER% installed
call :LOG "Node.js installed: %NODE_VER%"
exit /b 0

:: ============================================================
:: 子程序：修復 npm
:: ============================================================
:FIX_NPM
set "NPM_PREFIX=%INSTALL_DIR%\npm-global"
set "NPM_CACHE=%INSTALL_DIR%\npm-cache"

if not exist "%NPM_PREFIX%" mkdir "%NPM_PREFIX%"
if not exist "%NPM_CACHE%" mkdir "%NPM_CACHE%"
if not exist "%NPM_PREFIX%\node_modules" mkdir "%NPM_PREFIX%\node_modules"

call npm config set prefix "%NPM_PREFIX%" --location=global >nul 2>&1
call npm config set cache "%NPM_CACHE%" --location=global >nul 2>&1

set "PATH=%NPM_PREFIX%;%PATH%"

echo   [OK] npm configured
call :LOG "npm configured: prefix=%NPM_PREFIX%, cache=%NPM_CACHE%"
exit /b 0

:: ============================================================
:: 子程序：安裝依賴（含重試）
:: ============================================================
:INSTALL_DEPS
echo   Installing packages...
call :LOG "Installing npm packages"

cd /d "%INSTALL_DIR%"

set "DEPS=express pptxgenjs xlsx pdf-parse mssql multer nodemailer"

:: 嘗試整體安裝
call npm install --prefix "%INSTALL_DIR%" --cache "%NPM_CACHE%" --no-audit --no-fund >nul 2>&1

if %errorlevel% equ 0 (
    echo   [OK] All packages installed
    call :LOG "All packages installed successfully"
    goto :VERIFY_DEPS
)

echo   [WARN] npm install failed, trying individual packages...
call :LOG "WARN: npm install failed, falling back to individual install"

for %%p in (%DEPS%) do (
    echo   Installing %%p...
    call :LOG "Installing %%p..."
    
    call npm install %%p --prefix "%INSTALL_DIR%" --cache "%NPM_CACHE%" --no-audit --no-fund --save >nul 2>&1
    
    if %errorlevel% neq 0 (
        call :LOG "WARN: %%p failed, retrying with --force"
        call npm install %%p --prefix "%INSTALL_DIR%" --cache "%NPM_CACHE%" --force --no-audit --no-fund --save >nul 2>&1
    )
)

:VERIFY_DEPS
echo   Verifying packages...
call :LOG "Verifying packages"

set "MISSING_DEPS="
for %%p in (%DEPS%) do (
    node -e "require('%%p')" >nul 2>&1
    if !errorlevel! neq 0 (
        echo     [X] %%p - MISSING
        call :LOG "MISSING: %%p"
        set "MISSING_DEPS=!MISSING_DEPS! %%p"
    ) else (
        echo     [OK] %%p
        call :LOG "OK: %%p"
    )
)

if defined MISSING_DEPS (
    echo   [WARN] Missing: %MISSING_DEPS%
    call :LOG "WARN: Missing packages:%MISSING_DEPS%"
    exit /b 1
)

echo   [OK] All packages verified
call :LOG "All packages verified"
exit /b 0

:: ============================================================
:: 子程序：安裝 Ollama
:: ============================================================
:INSTALL_OLLAMA
ollama --version >nul 2>&1
if %errorlevel% equ 0 (
    for /f "tokens=*" %%a in ('ollama --version') do echo   [OK] Ollama: %%a
    call :LOG "Ollama already installed"
    exit /b 0
)

echo   [WARN] Ollama NOT FOUND
echo   Installing Ollama...
call :LOG "Ollama not found, installing..."

set "OLLAMA_INSTALLER=%TEMP%\OllamaSetup.exe"

if %OFFLINE_MODE% equ 1 (
    set "OLLAMA_INSTALLER=%INSTALL_DIR%\offline\OllamaSetup.exe"
    if exist "!OLLAMA_INSTALLER!" (
        call :LOG "Using offline Ollama installer"
        goto :OLLAMA_INSTALL
    )
)

echo   [下載中] Ollama (約 200MB)...
call :LOG "Downloading Ollama"

set "RETRY=0"
:OLLAMA_DOWNLOAD_RETRY
if %RETRY% GEQ 3 (
    echo   [X] Ollama 下載失敗
    call :LOG "ERROR: Ollama download failed"
    echo   請手動安裝: https://ollama.com
    exit /b 1
)

powershell -Command "& {$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://ollama.com/download/OllamaSetup.exe' -OutFile '%OLLAMA_INSTALLER%' -TimeoutSec 120}"

if not exist "%OLLAMA_INSTALLER%" (
    set /a RETRY+=1
    timeout /t %RETRY% /nobreak >nul
    goto :OLLAMA_DOWNLOAD_RETRY
)

:OLLAMA_INSTALL
echo   [安裝中] 執行 Ollama 安裝程式...
call :LOG "Installing Ollama"

start /wait "" "%OLLAMA_INSTALLER%" /S
timeout /t 15 /nobreak >nul

:: 重新載入 PATH
if exist "C:\Users\%USERNAME%\AppData\Local\Programs\Ollama\ollama.exe" (
    set "PATH=C:\Users\%USERNAME%\AppData\Local\Programs\Ollama;%PATH%"
)

ollama --version >nul 2>&1
if %errorlevel% equ 0 (
    echo   [OK] Ollama installed
    call :LOG "Ollama installed successfully"
    exit /b 0
)

echo   [X] Ollama 安裝驗證失敗
call :LOG "ERROR: Ollama installation verification failed"
exit /b 1

:: ============================================================
:: 子程序：下載 AI 模型
:: ============================================================
:DOWNLOAD_MODELS
ollama --version >nul 2>&1
if %errorlevel% neq 0 (
    echo   [SKIP] Ollama not available
    call :LOG "SKIP: Ollama not available, skipping model download"
    exit /b 0
)

echo   Checking models...
call :LOG "Checking AI models"

:: qwen2.5:7b
ollama list 2>nul | findstr "qwen2.5:7b" >nul
if %errorlevel% neq 0 (
    echo   Downloading qwen2.5:7b (約 4GB)...
    call :LOG "Downloading qwen2.5:7b"
    ollama pull qwen2.5:7b
    if %errorlevel% equ 0 (
        echo   [OK] qwen2.5:7b ready
        call :LOG "qwen2.5:7b downloaded"
    ) else (
        echo   [WARN] qwen2.5:7b failed
        call :LOG "WARN: qwen2.5:7b download failed"
    )
) else (
    echo   [OK] qwen2.5:7b already exists
    call :LOG "qwen2.5:7b already exists"
)

:: qwen2.5:14b（可選）
ollama list 2>nul | findstr "qwen2.5:14b" >nul
if %errorlevel% neq 0 (
    echo.
    choice /C YN /M "Download qwen2.5:14b (better quality, ~8GB)"
    if !errorlevel! equ 1 (
        call :LOG "User chose to download qwen2.5:14b"
        echo   Downloading qwen2.5:14b...
        ollama pull qwen2.5:14b
        if !errorlevel! equ 0 (
            echo   [OK] qwen2.5:14b ready
            call :LOG "qwen2.5:14b downloaded"
        ) else (
            echo   [WARN] qwen2.5:14b failed
            call :LOG "WARN: qwen2.5:14b download failed"
        )
    ) else (
        call :LOG "User skipped qwen2.5:14b"
    )
) else (
    echo   [OK] qwen2.5:14b already exists
    call :LOG "qwen2.5:14b already exists"
)

exit /b 0

:: ============================================================
:: 子程序：建立啟動檔案
:: ============================================================
:CREATE_STARTUP_FILES
call :LOG "Creating startup files"

:: 建立資料目錄
if not exist "%INSTALL_DIR%\Proj" mkdir "%INSTALL_DIR%\Proj"
if not exist "%INSTALL_DIR%\Novels" mkdir "%INSTALL_DIR%\Novels"
if not exist "%INSTALL_DIR%\Exports" mkdir "%INSTALL_DIR%\Exports"
if not exist "%INSTALL_DIR%\memory" mkdir "%INSTALL_DIR%\memory"
if not exist "%INSTALL_DIR%\backup" mkdir "%INSTALL_DIR%\backup"

:: START.bat
(
echo @echo off
echo chcp 65001 ^>nul
echo title AI Cognitive OS v5
echo.
echo echo ============================================
echo echo    AI Cognitive OS v5 - Starting...
echo echo ============================================
echo echo.
echo echo Web Portal: http://localhost:3005
echo echo.
echo echo Press Ctrl+C to stop
echo echo.
echo cd /d "%INSTALL_DIR%"
echo node teZ.js
echo if %%errorlevel%% neq 0 pause
) > "%INSTALL_DIR%\START.bat"

call :LOG "START.bat created"

:: START_WEB.bat
(
echo @echo off
echo chcp 65001 ^>nul
echo title AI Cognitive OS v5
echo cd /d "%INSTALL_DIR%"
echo start /min cmd /c "node teZ.js"
echo echo Starting AI Cognitive OS v5...
echo echo Please wait...
echo timeout /t 3 ^>nul
echo start http://localhost:3005
echo echo.
echo echo AI Cognitive OS is running at:
echo echo http://localhost:3005
echo echo.
echo echo Press any key to close this window...
echo pause ^>nul
) > "%INSTALL_DIR%\START_WEB.bat"

call :LOG "START_WEB.bat created"

:: 桌面捷徑
set "DESKTOP=%USERPROFILE%\Desktop"
if exist "%DESKTOP%" (
    (
        echo [InternetShortcut]
        echo URL=file:///%INSTALL_DIR:\=/%/START_WEB.bat
        echo IconIndex=0
    ) > "%DESKTOP%\AI Cognitive OS v5.url"
    echo   [OK] Desktop shortcut created
    call :LOG "Desktop shortcut created"
)

echo   [OK] Startup files created
exit /b 0

:: ============================================================
:: 子程序：儲存安裝摘要
:: ============================================================
:SAVE_SUMMARY
(
echo ============================================
echo AI Cognitive OS v5 - Install Summary
echo ============================================
echo Date: %date% %time%
echo Directory: %INSTALL_DIR%
echo Node.js: %NODE_VER%
echo.
if defined MISSING_DEPS (
    echo Missing Packages: %MISSING_DEPS%
) else (
    echo All Packages: OK
)
echo.
echo Launch:
echo   - START.bat
echo   - START_WEB.bat
echo   - Desktop shortcut
echo.
echo Log: %LOG_FILE%
echo ============================================
) > "%INSTALL_DIR%\INSTALL_SUMMARY.txt"

call :LOG "Summary saved to INSTALL_SUMMARY.txt"
exit /b 0