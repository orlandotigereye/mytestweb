const readline = require("readline");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const MODEL = "qwen2.5:3b";
const URL = "http://127.0.0.1:11434/api/chat";

console.log("🚀 TE OS v6.2 SAFE FILE SYSTEM STARTED");

// =========================
// 📁 LOG
// =========================
const LOG_DIR = path.join(__dirname, "logs");
if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR);

// =========================
// 📦 VERSION (SAFE)
// =========================
const VERSION_DB = path.join(__dirname, ".te_version.json");

function getDateKey() {
    const d = new Date();
    return String(d.getFullYear()).slice(2) +
        String(d.getMonth() + 1).padStart(2, "0") +
        String(d.getDate()).padStart(2, "0");
}

function loadDB() {
    if (!fs.existsSync(VERSION_DB)) return {};
    return JSON.parse(fs.readFileSync(VERSION_DB, "utf8"));
}

function saveDB(db) {
    fs.writeFileSync(VERSION_DB, JSON.stringify(db, null, 2));
}

function nextVersion() {
    const db = loadDB();
    const key = getDateKey();

    db[key] = (db[key] || 0) + 1;
    saveDB(db);

    return `${key}V${String(db[key]).padStart(4, "0")}`;
}

// =========================
// 📦 PROJECT SYSTEM
// =========================
const PROJECT = "default_project";

// =========================
// 🔐 HASH (for conflict avoid)
// =========================
function hashContent(str) {
    return crypto.createHash("md5").update(str).digest("hex").slice(0, 6);
}

// =========================
// 📁 SAFE PATH FIXER
// =========================
function fixFilePath(rawPath, code) {
    let p = rawPath.trim().toLowerCase();

    // ❌ AI亂寫：python / app / index → 修正
    if (!p.includes(".")) {
        if (p.includes("html")) p += ".html";
        else if (p.includes("css")) p += ".css";
        else if (p.includes("js")) p += ".js";
        else if (p.includes("py")) p += ".py";
        else p += ".txt";
    }

    const ext = path.extname(p).replace(".", "") || "txt";

    // folder routing
    let folder =
        ext === "html" ? "html" :
        ext === "css" ? "css" :
        ext === "js" ? "js" :
        ext === "py" ? "python" :
        ext === "md" ? "txt" :
        ext === "pdf" ? "pdf" :
        "other";

    const version = nextVersion();
    const hash = hashContent(code);

    const fileName = `${version}_${hash}_${path.basename(p)}`;

    return path.join(__dirname, "projects", PROJECT, folder, fileName);
}

// =========================
// 🧠 AI ENGINE
// =========================
async function askAI(input) {
    const res = await fetch(URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            model: MODEL,
            messages: [
                {
                    role: "system",
                    content: `
You are TE OS.

CRITICAL RULES:
- ALWAYS output valid file paths with extensions
- NEVER output abstract names like "python" or "app"
- ALWAYS include real filename like index.html, app.js
`
                },
                { role: "user", content: input }
            ],
            stream: true
        })
    });

    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";
    let full = "";

    process.stdout.write("\n🤖 AI: ");

    while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n");
        buffer = lines.pop();

        for (let line of lines) {
            line = line.trim();
            if (!line) continue;

            try {
                const json = JSON.parse(line);
                const text = json?.message?.content || json?.message?.thinking;

                if (text) {
                    process.stdout.write(text);
                    full += text;
                }
            } catch {}
        }
    }

    console.log("\n");
    return full;
}

// =========================
// 📁 SAFE FILE WRITER
// =========================
function writeFileSafe(filePath, content) {
    fs.mkdirSync(path.dirname(filePath), { recursive: true });

    // ❗ no overwrite protection
    if (fs.existsSync(filePath)) {
        const backup = filePath + ".bak";
        fs.copyFileSync(filePath, backup);
    }

    fs.writeFileSync(filePath, content, "utf8");

    console.log("✔ FILE CREATED:", filePath);
}

// =========================
// 📁 PARSER FIXED
// =========================
function parseAndWriteFiles(output) {
    if (!output) return;

    const fileRegex = /FILE:\s*(.+)\nCODE:\n([\s\S]*?)(?=\nFILE:|$)/g;
    const mdRegex = /```([a-zA-Z0-9_.\-\/]+)\n([\s\S]*?)```/g;

    let files = [];
    let match;

    while ((match = fileRegex.exec(output)) !== null) {
        files.push({ path: match[1], code: match[2] });
    }

    while ((match = mdRegex.exec(output)) !== null) {
        files.push({ path: match[1], code: match[2] });
    }

    for (const f of files) {
        const fixedPath = fixFilePath(f.path, f.code);
        writeFileSafe(fixedPath, f.code);
    }
}

// =========================
// 🧠 CLI
// =========================
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function loop() {
    rl.question("TE > ", async (input) => {

        if (input.toLowerCase() === "exit") {
            rl.close();
            return;
        }

        if (input === "/version") {
            console.log("📦 VERSION:", nextVersion());
            return loop();
        }

        if (!input) return loop();

        console.log("⚡ thinking...");

        const result = await askAI(input);

        parseAndWriteFiles(result);

        loop();
    });
}

loop();

rl.on("close", () => process.exit(0));