const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

async function loop() {
    rl.question('TE > ', async (input) => {
        if (input.toLowerCase() === 'exit') {
            console.log('Goodbye!');
            rl.close();
            return;
        }

        try {
            // 在此處處理您的邏輯
            console.log(`AI: Processing: ${input}`);
        } catch (err) {
            console.error('Error:', err.message);
        }

        // 遞迴呼叫前檢查是否已關閉
        if (!rl.closed) {
            loop();
        }
    });
}

// 初始化
loop();

// 確保程式結束時處理
rl.on('close', () => {
    process.exit(0);
});