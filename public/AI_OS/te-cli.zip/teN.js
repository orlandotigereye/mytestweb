const readline = require("readline");
const fs = require("fs");
const path = require("path");

// ======================================================
// 🤖 MODEL CONFIG
// ======================================================
const URL = "http://127.0.0.1:11434/api/chat";

const MODEL_FAST = "qwen2.5:3b";
const MODEL_SMART = "qwen2.5:7b";
let ACTIVE_MODEL = MODEL_FAST;

console.log("🚀 TE OS v6.7 FULL CONTROL SYSTEM STARTED");

// ======================================================
// 📦 VERSION SYSTEM
// ======================================================
const VERSION_FILE = path.join(__dirname, "version.json");

function getToday() {
    const d = new Date();
    const y = String(d.getFullYear()).slice(2);
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}${m}${day}`;
}

let versionData = fs.existsSync(VERSION_FILE)
    ? JSON.parse(fs.readFileSync(VERSION_FILE, "utf8"))
    : { version: `${getToday()}V0001` };

function saveVersion() {
    fs.writeFileSync(VERSION_FILE, JSON.stringify(versionData, null, 2));
}

function nextVersion() {
    const match = versionData.version.match(/V(\d+)/);
    let num = match ? parseInt(match[1]) + 1 : 1;

    versionData.version = `${getToday()}V${String(num).padStart(4, "0")}`;
    saveVersion();
    return versionData.version;
}

// ======================================================
// ⚙️ RUNTIME STATE
// ======================================================
const runtime = {
    start: Date.now(),
    requests: 0,
    files: 0,
    errors: 0,
    lastInput: null
};

// ======================================================
// 📋 FEATURES
// ======================================================
const FEATURES = {
    ai_chat: true,
    streaming: true,
    file_writer: true,
    file_parser: true,
    version_system: true,
    runtime_monitor: true,
    regression_test: true,
    model_router: true,
    cli_commands: true
};

// ======================================================
// 🧠 FEATURE CHECKLIST
// ======================================================
function featureChecklist() {
    console.log("\n📋 FEATURE CHECKLIST");
    console.log("────────────────────");

    let ok = 0;
    const total = Object.keys(FEATURES).length;

    for (const [k, v] of Object.entries(FEATURES)) {
        console.log(v ? "✅" : "❌", k);
        if (v) ok++;
    }

    console.log("────────────────────");
    console.log(`📦 STATUS: ${ok}/${total} ACTIVE`);

    const health = (ok / total) * 100;

    if (health >= 90) console.log("🟢 SYSTEM HEALTH: EXCELLENT");
    else if (health >= 70) console.log("🟡 SYSTEM HEALTH: GOOD");
    else console.log("🔴 SYSTEM HEALTH: DEGRADED");

    console.log("");
}

// ======================================================
// ⚙️ RUNTIME BEHAVIOR
// ======================================================
function runtimeBehavior() {
    const uptime = ((Date.now() - runtime.start) / 1000).toFixed(2);

    console.log("\n⚙️ RUNTIME BEHAVIOR");
    console.log("────────────────────");
    console.log("⏱ uptime:", uptime + "s");
    console.log("📨 requests:", runtime.requests);
    console.log("📁 files:", runtime.files);
    console.log("❌ errors:", runtime.errors);
    console.log("🧠 last input:", runtime.lastInput);
    console.log("🤖 active model:", ACTIVE_MODEL);
    console.log("────────────────────\n");
}

// ======================================================
// 🧪 REGRESSION TEST
// ======================================================
function regressionTest() {
    console.log("\n🧪 REGRESSION TEST");
    console.log("────────────────────");

    const tests = [
        { name: "feature_system", fn: () => Object.keys(FEATURES).length > 0 },
        { name: "runtime_object", fn: () => typeof runtime === "object" },
        { name: "filesystem_access", fn: () => fs.existsSync(__dirname) },
        { name: "version_system", fn: () => typeof versionData.version === "string" },
        { name: "model_router", fn: () => ACTIVE_MODEL !== null }
    ];

    let pass = 0;

    for (const t of tests) {
        try {
            const ok = t.fn();
            console.log(ok ? "✅" : "❌", t.name);
            if (ok) pass++;
        } catch {
            runtime.errors++;
            console.log("❌", t.name);
        }
    }

    console.log("────────────────────");
    console.log(`📊 RESULT: ${pass}/${tests.length} PASSED`);

    if (pass === tests.length) {
        console.log("🟢 SYSTEM STATUS: STABLE");
    } else {
        console.log("🟡 SYSTEM STATUS: WARNING");
    }

    console.log("");
}

// ======================================================
// 🤖 MODEL ROUTER
// ======================================================
function chooseModel(input) {
    const t = input.toLowerCase();

    if (input.length > 60) return MODEL_SMART;

    const smartKeywords = ["code", "fix", "debug", "build", "system", "project", "architecture"];

    for (const k of smartKeywords) {
        if (t.includes(k)) return MODEL_SMART;
    }

    return MODEL_FAST;
}

// ======================================================
// 🤖 AI ENGINE
// ======================================================
async function askAI(input) {
    runtime.requests++;
    runtime.lastInput = input;

    ACTIVE_MODEL = chooseModel(input);

    const res = await fetch(URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            model: ACTIVE_MODEL,
            messages: [
                { role: "system", content: "You are TE OS AI assistant." },
                { role: "user", content: input }
            ],
            stream: true
        })
    });

    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";
    let full = "";

    process.stdout.write(`\n🤖 [${ACTIVE_MODEL}] `);

    while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n");
        buffer = lines.pop();

        for (let line of lines) {
            line = line.trim();
            if (!line) continue;

            try {
                const json = JSON.parse(line);
                const text = json?.message?.content || json?.message?.thinking;

                if (text) {
                    process.stdout.write(text);
                    full += text;
                }
            } catch {}
        }
    }

    console.log("\n");
    return full;
}

// ======================================================
// 📁 FILE SYSTEM
// ======================================================
function writeFileSafe(filePath, content) {
    fs.mkdirSync(path.dirname(filePath), { recursive: true });

    if (fs.existsSync(filePath)) {
        fs.copyFileSync(filePath, filePath + ".bak");
    }

    fs.writeFileSync(filePath, content, "utf8");

    runtime.files++;
    console.log("✔ FILE CREATED:", filePath);
}

// ======================================================
// 📁 FILE PARSER
// ======================================================
function parseAndWriteFiles(output) {
    if (!output) return;

    const fileRegex = /FILE:\s*(.+)\nCODE:\n([\s\S]*?)(?=\nFILE:|$)/g;
    const mdRegex = /```([a-zA-Z0-9_.\-\/]+)\n([\s\S]*?)```/g;

    let match;

    while ((match = fileRegex.exec(output)) !== null) {
        writeFileSafe(path.join(process.cwd(), match[1].trim()), match[2]);
    }

    while ((match = mdRegex.exec(output)) !== null) {
        writeFileSafe(path.join(process.cwd(), match[1].trim()), match[2]);
    }
}

// ======================================================
// 🧠 CLI
// ======================================================
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function loop() {
    rl.question("TE > ", async (input) => {

        if (!input) return loop();

        // =========================
        // COMMAND SYSTEM
        // =========================
        if (input === "/check") return (featureChecklist(), loop());

        if (input === "/runtime") return (runtimeBehavior(), loop());

        if (input === "/test") return (regressionTest(), loop());

        if (input === "/version") {
            console.log("📌 VERSION:", versionData.version);
            return loop();
        }

        if (input === "/next-version") {
            console.log("🚀 VERSION:", nextVersion());
            return loop();
        }

        if (input === "/model") {
            console.log("\n🤖 MODEL STATUS");
            console.log("────────────────────");
            console.log("FAST :", MODEL_FAST);
            console.log("SMART:", MODEL_SMART);
            console.log("ACTIVE:", ACTIVE_MODEL);
            console.log("────────────────────\n");
            return loop();
        }

        if (input.toLowerCase() === "exit") {
            rl.close();
            return;
        }

        console.log("⚡ thinking...");

        const result = await askAI(input);

        parseAndWriteFiles(result);

        loop();
    });
}

loop();

rl.on("close", () => process.exit(0));