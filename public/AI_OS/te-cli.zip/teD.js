const readline = require("readline");
const fs = require("fs");
const path = require("path");

const MODEL = "qwen2.5:3b";
const URL = "http://127.0.0.1:11434/api/chat";

console.log("🚀 TE CLI v2.5 TOOL MODE STARTED");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// =========================
// 🧠 MODE PARSER
// =========================
function parseInput(input) {
    const parts = input.trim().split(" ");
    const mode = parts[0].toLowerCase();
    const content = parts.slice(1).join(" ");

    if (["chat", "code", "fix"].includes(mode)) {
        return { mode, content };
    }

    return { mode: "chat", content: input };
}

// =========================
// 🧠 PROMPT ENGINE
// =========================
function buildPrompt(mode, input) {

    if (mode === "code") {
        return `
You are a senior software engineer.

Return ONLY files.

FORMAT:
FILE: path
CODE:
content

NO explanation.
TASK:
${input}
`;
    }

    if (mode === "fix") {
        return `
You are a debugging expert.
Return ONLY corrected code.

TASK:
${input}
`;
    }

    return input;
}

// =========================
// 🧠 STREAM ENGINE
// =========================
async function askAI(prompt) {
    const res = await fetch(URL, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            model: MODEL,
            messages: [
                { role: "user", content: prompt }
            ],
            stream: true,
            options: {
                temperature: 0.2,
                num_predict: 300
            }
        })
    });

    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";
    let fullText = "";

    process.stdout.write("\n🤖 AI: ");

    while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n");
        buffer = lines.pop();

        for (let line of lines) {
            line = line.trim();
            if (!line) continue;

            try {
                const json = JSON.parse(line);

                const text =
                    json?.message?.content ||
                    json?.message?.thinking;

                if (text) {
                    process.stdout.write(text);
                    fullText += text;
                }

            } catch (e) {
                // ignore
            }
        }
    }

    console.log("\n");

    return fullText;
}

// =========================
// 📁 FILE SYSTEM ENGINE
// =========================
function parseAndWriteFiles(output) {
    if (!output) return;

    const lines = output.split("\n");

    let state = "idle";
    let filePath = null;
    let codeBuffer = [];

    function flush() {
        if (!filePath || codeBuffer.length === 0) return;

        const fullPath = path.resolve(filePath);
        fs.mkdirSync(path.dirname(fullPath), { recursive: true });
        fs.writeFileSync(fullPath, codeBuffer.join("\n"), "utf8");

        console.log("✔ FILE CREATED:", filePath);

        filePath = null;
        codeBuffer = [];
        state = "idle";
    }

    for (let line of lines) {
        line = line.trim();

        if (line.startsWith("FILE:")) {
            flush();
            filePath = line.replace("FILE:", "").trim();
            state = "file";
            continue;
        }

        if (line.startsWith("CODE:")) {
            state = "code";
            continue;
        }

        if (state === "code") {
            codeBuffer.push(line);
        }
    }

    flush();
}

// =========================
// CLI LOOP
// =========================
function loop() {
    rl.question("TE > ", async (input) => {

        if (!input) return loop();

        if (input.toLowerCase() === "exit") {
            console.log("Goodbye!");
            rl.close();
            return;
        }

        const { mode, content } = parseInput(input);

        console.log(`⚡ mode: ${mode}`);
        console.log("⚡ thinking...");

        const prompt = buildPrompt(mode, content);

        const result = await askAI(prompt);

        parseAndWriteFiles(result);

        loop();
    });
}

loop();

rl.on("close", () => {
    process.exit(0);
});