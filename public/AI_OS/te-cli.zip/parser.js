const { writeFile } = require("./fs");

function parse(output) {
    const parts = output.split("FILE:");

    for (const chunk of parts) {
        const p = chunk.split("CODE:");
        if (p.length < 2) continue;

        const file = p[0].trim();
        const code = p[1].trim();

        if (file && code) {
            writeFile(file, code);
        }
    }
}

module.exports = { parse };