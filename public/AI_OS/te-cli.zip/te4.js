const readline = require('readline');

const MODEL = "qwen3:8b";
const OLLAMA_URL = "http://127.0.0.1:11434/api/chat";

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

async function askAI(input) {
    try {
        const res = await fetch(OLLAMA_URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                model: MODEL,
                messages: [
                    { role: "user", content: input }
                ],
                stream: false
            })
        });

        const text = await res.text();

        try {
            const json = JSON.parse(text);
            return json.message?.content || json.response || text;
        } catch {
            return text;
        }

    } catch (err) {
        return "ERROR: " + err.message;
    }
}

function loop() {
    rl.question('TE > ', async (input) => {

        if (input.toLowerCase() === 'exit') {
            console.log('Goodbye!');
            rl.close();
            return;
        }

        console.log("thinking...");

        const ai = await askAI(input);

        console.log("\nAI:\n", ai);

        loop();
    });
}

loop();

rl.on('close', () => {
    process.exit(0);
});