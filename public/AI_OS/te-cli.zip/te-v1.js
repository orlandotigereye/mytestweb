const axios = require("axios");

(async () => {
    console.log("Start...");

    try {
        const res = await axios.post(
            "http://127.0.0.1:11434/api/generate",
            {
                model: "qwen3:8b",
                prompt: "Say hello",
                stream: false
            },
            {
                timeout: 30000
            }
        );

        console.log("SUCCESS");
        console.log(res.data);

    } catch (e) {
        console.log("FAILED");
        console.log("status:", e.response?.status);
        console.log("data:", e.response?.data);
        console.log("message:", e.message);
    }

    console.log("Done");
})();