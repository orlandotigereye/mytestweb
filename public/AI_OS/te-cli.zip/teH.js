const readline = require("readline");
const fs = require("fs");
const path = require("path");

// =========================
// ⚙ CONFIG
// =========================
const MODEL = "qwen2.5:3b";
const URL = "http://127.0.0.1:11434/api/chat";

console.log("🚀 TE CLI v6.5 STABLE FULL STARTED");

// =========================
// 📁 PATH
// =========================
const VERSION_FILE = path.join(__dirname, ".te_versions.json");

// =========================
// 📁 VERSION SYSTEM (SAFE)
// =========================
function loadVersions() {
    try {
        if (!fs.existsSync(VERSION_FILE)) return {};
        return JSON.parse(fs.readFileSync(VERSION_FILE, "utf8"));
    } catch {
        return {};
    }
}

function saveVersions(v) {
    fs.writeFileSync(VERSION_FILE, JSON.stringify(v, null, 2), "utf8");
}

// A-Z → AA-ZZ
function nextVersion(v) {
    if (!v) return "A";

    if (v.length === 1) {
        if (v === "Z") return "AA";
        return String.fromCharCode(v.charCodeAt(0) + 1);
    }

    let arr = v.split("");
    let i = arr.length - 1;

    while (i >= 0) {
        if (arr[i] !== "Z") {
            arr[i] = String.fromCharCode(arr[i].charCodeAt(0) + 1);
            break;
        } else {
            arr[i] = "A";
            i--;
        }
    }

    if (i < 0) arr.unshift("A");

    return arr.join("");
}

// =========================
// 📁 FILE ROUTER
// =========================
function getFolderByExt(ext) {
    const map = {
        ".html": "html",
        ".css": "css",
        ".js": "js",
        ".txt": "txt",
        ".md": "txt",
        ".pdf": "pdf"
    };

    return map[ext] || "other";
}

// =========================
// 🧠 MEMORY SYSTEM
// =========================
let history = [];

// =========================
// 🤖 AI ENGINE (STABLE STREAM)
// =========================
async function askAI(input) {
    const res = await fetch(URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            model: MODEL,
            messages: [
                {
                    role: "system",
                    content: "You are TE AI coding agent. Output file structures when needed."
                },
                ...history,
                { role: "user", content: input }
            ],
            stream: true
        })
    });

    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";
    let output = "";

    process.stdout.write("\n🤖 AI: ");

    while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n");
        buffer = lines.pop();

        for (const line of lines) {
            const clean = line.trim();
            if (!clean) continue;

            try {
                const json = JSON.parse(clean);

                const text =
                    json?.message?.content ||
                    json?.message?.thinking;

                if (text) {
                    process.stdout.write(text);
                    output += text;
                }
            } catch {
                // ignore broken json
            }
        }
    }

    console.log("\n");
    return output;
}

// =========================
// 📁 FILE WRITER (ROBUST)
// =========================
function writeFileSmart(filePath, code) {
    const versions = loadVersions();

    const ext = path.extname(filePath).toLowerCase();
    const folder = getFolderByExt(ext);

    const now = new Date();
    const date =
        now.getFullYear().toString() +
        String(now.getMonth() + 1).padStart(2, "0") +
        String(now.getDate()).padStart(2, "0") +
        String(now.getHours()).padStart(2, "0") +
        String(now.getMinutes()).padStart(2, "0");

    const key = filePath;
    const version = nextVersion(versions[key]);

    versions[key] = version;
    saveVersions(versions);

    const finalName = `${date}_${version}${ext}`;

    const dir = path.join(__dirname, folder);
    const fullPath = path.join(dir, finalName);

    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(fullPath, code, "utf8");

    console.log(`✔ FILE CREATED: ${folder}/${finalName}`);
}

// =========================
// 📁 PARSER (SAFE & COMPLETE)
// =========================
function parseAndWriteFiles(output) {
    if (!output || typeof output !== "string") return;

    let files = [];

    const regex1 = /FILE:\s*(.+)\nCODE:\n([\s\S]*?)(?=\nFILE:|$)/g;
    const regex2 = /```([a-zA-Z0-9_.\-\/]+)\n([\s\S]*?)```/g;

    let match;

    while ((match = regex1.exec(output)) !== null) {
        files.push({ path: match[1].trim(), code: match[2] });
    }

    while ((match = regex2.exec(output)) !== null) {
        files.push({ path: match[1].trim(), code: match[2] });
    }

    if (files.length === 0) return;

    for (const f of files) {
        writeFileSmart(f.path, f.code);
    }
}

// =========================
// 🧠 CLI
// =========================
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function loop() {
    rl.question("TE > ", async (input) => {

        if (!input) return loop();

        if (input === "exit") {
            rl.close();
            return;
        }

        if (input === "/reset") {
            history = [];
            console.log("🧠 memory cleared");
            return loop();
        }

        console.log("⚡ thinking...");

        history.push({ role: "user", content: input });

        const result = await askAI(input);

        history.push({ role: "assistant", content: result });

        if (history.length > 30) {
            history = history.slice(-30);
        }

        parseAndWriteFiles(result);

        loop();
    });
}

loop();

rl.on("close", () => {
    process.exit(0);
});