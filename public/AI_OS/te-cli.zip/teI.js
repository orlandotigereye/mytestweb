const readline = require("readline");
const fs = require("fs");
const path = require("path");

const MODEL = "qwen2.5:3b";
const URL = "http://127.0.0.1:11434/api/chat";

console.log("🚀 TE CLI v6 FULL SYSTEM STARTED");

// =========================
// 📁 LOG SYSTEM
// =========================
const LOG_DIR = path.join(__dirname, "logs");
if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR);

// =========================
// 📦 VERSION SYSTEM (260629V0001)
// =========================
const VERSION_DB = path.join(__dirname, ".te_version.json");

function getDateKey() {
    const d = new Date();
    return String(d.getFullYear()).slice(2) +
        String(d.getMonth() + 1).padStart(2, "0") +
        String(d.getDate()).padStart(2, "0");
}

function loadVersionDB() {
    if (!fs.existsSync(VERSION_DB)) return {};
    return JSON.parse(fs.readFileSync(VERSION_DB, "utf8"));
}

function saveVersionDB(db) {
    fs.writeFileSync(VERSION_DB, JSON.stringify(db, null, 2));
}

function getNextVersion() {
    const db = loadVersionDB();
    const key = getDateKey();

    if (!db[key]) db[key] = 1;
    else db[key]++;

    saveVersionDB(db);

    const num = String(db[key]).padStart(4, "0");
    return `${key}V${num}`;
}

function getCurrentVersion() {
    const db = loadVersionDB();
    const key = getDateKey();

    if (!db[key]) return null;
    return `${key}V${String(db[key]).padStart(4, "0")}`;
}

// =========================
// 📄 SESSION LOG
// =========================
function getSessionFile() {
    const date = getDateKey();

    const files = fs.readdirSync(LOG_DIR)
        .filter(f => f.startsWith(`LLM${date}`))
        .sort();

    let num = 1;
    if (files.length > 0) {
        const last = files[files.length - 1];
        const m = last.match(/(\d+)\.json$/);
        if (m) num = parseInt(m[1]) + 1;
    }

    const id = String(num).padStart(3, "0");

    return {
        fileName: `LLM${date}${id}.json`,
        filePath: path.join(LOG_DIR, `LLM${date}${id}.json`)
    };
}

const session = getSessionFile();

let history = [];

let logData = {
    session: session.fileName.replace(".json", ""),
    date: new Date().toISOString().slice(0, 10),
    messages: []
};

function saveLog() {
    fs.writeFileSync(session.filePath, JSON.stringify(logData, null, 2), "utf8");
}

// =========================
// 🧠 AI ENGINE
// =========================
async function askAI(input) {
    const messages = [
        {
            role: "system",
            content: `
You are TE AI OS.

You are a coding + assistant agent.

RULES:
- output code when needed
- FILE: path + CODE format allowed
- be concise
`
        },
        ...history,
        { role: "user", content: input }
    ];

    const res = await fetch(URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            model: MODEL,
            messages,
            stream: true
        })
    });

    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";
    let fullText = "";

    process.stdout.write("\n🤖 AI: ");

    while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n");
        buffer = lines.pop();

        for (let line of lines) {
            line = line.trim();
            if (!line) continue;

            try {
                const json = JSON.parse(line);
                const text = json?.message?.content || json?.message?.thinking;

                if (text) {
                    process.stdout.write(text);
                    fullText += text;
                }
            } catch {}
        }
    }

    console.log("\n");
    return fullText;
}

// =========================
// 📁 FILE SYSTEM ENGINE
// =========================
function parseAndWriteFiles(output) {
    if (!output) return;

    const fileRegex = /FILE:\s*(.+)\nCODE:\n([\s\S]*?)(?=\nFILE:|$)/g;
    const mdRegex = /```([a-zA-Z0-9_.\-\/]+)\n([\s\S]*?)```/g;

    let files = [];
    let match;

    while ((match = fileRegex.exec(output)) !== null) {
        files.push({ path: match[1], code: match[2] });
    }

    while ((match = mdRegex.exec(output)) !== null) {
        files.push({ path: match[1], code: match[2] });
    }

    if (files.length === 0) return;

    for (const f of files) {
        const fullPath = path.join(process.cwd(), f.path);

        fs.mkdirSync(path.dirname(fullPath), { recursive: true });
        fs.writeFileSync(fullPath, f.code, "utf8");

        console.log("✔ FILE CREATED:", f.path);
    }
}

// =========================
// 🧠 CLI
// =========================
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function loop() {
    rl.question("TE > ", async (input) => {

        // =========================
        // 📦 VERSION COMMANDS
        // =========================
        if (input === "/version") {
            console.log("📌 VERSION:", getCurrentVersion() || "NONE");
            return loop();
        }

        if (input === "/next-version") {
            console.log("🚀 NEW VERSION:", getNextVersion());
            return loop();
        }

        // =========================
        // 🧠 MEMORY RESET
        // =========================
        if (input === "/reset") {
            history = [];
            console.log("🧠 memory cleared");
            return loop();
        }

        // =========================
        // EXIT
        // =========================
        if (input.toLowerCase() === "exit") {
            saveLog();
            rl.close();
            return;
        }

        if (!input) return loop();

        console.log("⚡ thinking...");

        logData.messages.push({ role: "user", content: input });

        const result = await askAI(input);

        logData.messages.push({ role: "assistant", content: result });

        history.push({ role: "user", content: input });
        history.push({ role: "assistant", content: result });

        if (history.length > 20) history = history.slice(-20);

        saveLog();

        parseAndWriteFiles(result);

        loop();
    });
}

loop();

rl.on("close", () => process.exit(0));