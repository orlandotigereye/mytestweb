const readline = require("readline");
const fs = require("fs");
const path = require("path");

// ======================================================
// 🤖 MODEL
// ======================================================
const URL = "http://127.0.0.1:11434/api/chat";
const MODEL = "qwen2.5:3b";

// ======================================================
// 🚀 SYSTEM START
// ======================================================
console.log("🚀 TE OS v6.6 CONTROL CORE STARTED");

// ======================================================
// 📦 VERSION SYSTEM
// ======================================================
const VERSION_DIR = path.join(__dirname, "version.json");

function getTodayVersion() {
    const d = new Date();
    const y = String(d.getFullYear()).slice(2);
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}${m}${day}`;
}

let versionData = {
    version: `${getTodayVersion()}V0001`
};

if (fs.existsSync(VERSION_DIR)) {
    versionData = JSON.parse(fs.readFileSync(VERSION_DIR, "utf8"));
}

function saveVersion() {
    fs.writeFileSync(VERSION_DIR, JSON.stringify(versionData, null, 2));
}

function nextVersion() {
    const match = versionData.version.match(/V(\d+)/);
    let num = match ? parseInt(match[1]) + 1 : 1;
    const v = `${getTodayVersion()}V${String(num).padStart(4, "0")}`;
    versionData.version = v;
    saveVersion();
    return v;
}

// ======================================================
// 📊 RUNTIME
// ======================================================
const runtime = {
    start: Date.now(),
    requests: 0,
    files: 0,
    errors: 0,
    lastInput: null
};

// ======================================================
// 🧠 FEATURES
// ======================================================
const FEATURES = {
    ai_chat: true,
    streaming: true,
    file_writer: true,
    file_parser: true,
    runtime: true,
    regression_test: true,
    version_system: true,
    cli_commands: true
};

// ======================================================
// 📋 FEATURE CHECKLIST
// ======================================================
function featureChecklist() {
    console.log("\n📋 FEATURE CHECKLIST");

    let ok = 0;
    const total = Object.keys(FEATURES).length;

    for (const [k, v] of Object.entries(FEATURES)) {
        console.log(v ? "✅" : "❌", k);
        if (v) ok++;
    }

    console.log(`\n📦 STATUS: ${ok}/${total} ACTIVE\n`);
}

// ======================================================
// ⚙️ RUNTIME REPORT
// ======================================================
function runtimeBehavior() {
    const uptime = ((Date.now() - runtime.start) / 1000).toFixed(2);

    console.log("\n⚙️ RUNTIME BEHAVIOR");
    console.log("────────────────────");
    console.log("⏱ uptime:", uptime + "s");
    console.log("📨 requests:", runtime.requests);
    console.log("📁 files:", runtime.files);
    console.log("❌ errors:", runtime.errors);
    console.log("🧠 last input:", runtime.lastInput);
    console.log("────────────────────\n");
}

// ======================================================
// 🧪 REGRESSION TEST
// ======================================================
function regressionTest() {
    console.log("\n🧪 REGRESSION TEST");

    const tests = [
        { name: "feature_check", fn: () => Object.values(FEATURES).every(Boolean) },
        { name: "runtime_object", fn: () => typeof runtime === "object" },
        { name: "fs_access", fn: () => fs.existsSync(__dirname) },
        { name: "version_system", fn: () => typeof versionData.version === "string" }
    ];

    let pass = 0;

    for (const t of tests) {
        try {
            const ok = t.fn();
            console.log(ok ? "✅" : "❌", t.name);
            if (ok) pass++;
        } catch (e) {
            runtime.errors++;
            console.log("❌", t.name);
        }
    }

    console.log(`\n🧪 RESULT: ${pass}/${tests.length} PASSED\n`);
}

// ======================================================
// 🤖 AI ENGINE
// ======================================================
async function askAI(input) {
    runtime.requests++;
    runtime.lastInput = input;

    const res = await fetch(URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            model: MODEL,
            messages: [
                { role: "system", content: "You are TE OS AI assistant." },
                { role: "user", content: input }
            ],
            stream: true
        })
    });

    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";
    let full = "";

    process.stdout.write("\n🤖 AI: ");

    while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n");
        buffer = lines.pop();

        for (let line of lines) {
            line = line.trim();
            if (!line) continue;

            try {
                const json = JSON.parse(line);
                const text = json?.message?.content || json?.message?.thinking;

                if (text) {
                    process.stdout.write(text);
                    full += text;
                }
            } catch {}
        }
    }

    console.log("\n");
    return full;
}

// ======================================================
// 📁 FILE SYSTEM
// ======================================================
function writeFileSafe(filePath, content) {
    fs.mkdirSync(path.dirname(filePath), { recursive: true });

    if (fs.existsSync(filePath)) {
        fs.copyFileSync(filePath, filePath + ".bak");
    }

    fs.writeFileSync(filePath, content, "utf8");

    runtime.files++;
    console.log("✔ FILE CREATED:", filePath);
}

// ======================================================
// 📁 FILE PARSER
// ======================================================
function parseAndWriteFiles(output) {
    if (!output) return;

    const fileRegex = /FILE:\s*(.+)\nCODE:\n([\s\S]*?)(?=\nFILE:|$)/g;
    const mdRegex = /```([a-zA-Z0-9_.\-\/]+)\n([\s\S]*?)```/g;

    let match;

    while ((match = fileRegex.exec(output)) !== null) {
        const filePath = path.join(process.cwd(), match[1].trim());
        writeFileSafe(filePath, match[2]);
    }

    while ((match = mdRegex.exec(output)) !== null) {
        const filePath = path.join(process.cwd(), match[1].trim());
        writeFileSafe(filePath, match[2]);
    }
}

// ======================================================
// 🧠 CLI
// ======================================================
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function loop() {
    rl.question("TE > ", async (input) => {

        if (!input) return loop();

        // =========================
        // COMMANDS
        // =========================
        if (input === "/check") return (featureChecklist(), loop());
        if (input === "/runtime") return (runtimeBehavior(), loop());
        if (input === "/test") return (regressionTest(), loop());

        if (input === "/version") {
            console.log("📌 VERSION:", versionData.version);
            return loop();
        }

        if (input === "/next-version") {
            console.log("🚀 NEW VERSION:", nextVersion());
            return loop();
        }

        if (input.toLowerCase() === "exit") {
            rl.close();
            return;
        }

        console.log("⚡ thinking...");

        const result = await askAI(input);

        parseAndWriteFiles(result);

        loop();
    });
}

loop();

rl.on("close", () => process.exit(0));