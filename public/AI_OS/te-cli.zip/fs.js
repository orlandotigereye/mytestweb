const fs = require("fs");
const path = require("path");

function writeFile(filePath, content) {
    const full = path.resolve(filePath);
    fs.mkdirSync(path.dirname(full), { recursive: true });
    fs.writeFileSync(full, content, "utf8");
    console.log("✔ FILE:", filePath);
}

module.exports = { writeFile };