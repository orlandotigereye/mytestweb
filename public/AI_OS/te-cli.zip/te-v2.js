const fs = require("fs");
const readline = require("readline");
const axios = require("axios");

const MODEL = "qwen3:8b";

console.log("🚀 TE CLI v2 STARTED");

async function askOllama(prompt) {
    try {
        const res = await axios.post(
            "http://127.0.0.1:11434/api/chat",
            {
                model: MODEL,
                messages: [
                    {
                        role: "user",
                        content: prompt
                    }
                ],
                stream: false
            },
            {
                timeout: 120000
            }
        );

        return res.data?.message?.content || "[EMPTY]";
    } catch (err) {
        console.log("ERROR STATUS:", err.response?.status);
        console.log("ERROR DATA:", err.response?.data);
        console.log("ERROR MSG:", err.message);
        return "ERROR";
    }
}
// 📁 write file helper
function writeFileSafe(filePath, content) {
    try {
        fs.mkdirSync(require("path").dirname(filePath), { recursive: true });
        fs.writeFileSync(filePath, content, "utf8");
        console.log("✔ FILE WRITTEN:", filePath);
    } catch (e) {
        console.log("WRITE ERROR:", e.message);
    }
}

// 🧠 強制 Agent Prompt（核心）
function buildPrompt(input) {
    return `
You are an AUTONOMOUS SOFTWARE ENGINEERING AGENT.

RULES (STRICT):
- NEVER ask questions
- NEVER chat or explain
- ALWAYS produce complete working solutions
- ALWAYS assume full requirements
- If coding → output FULL CODE
- If multi-file → format like:
  FILE: path
  CODE:
  ...
- NEVER say "as an AI model"
- NEVER refuse task
- NEVER be vague

TASK:
${input}
`;
}

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

async function handle(input) {
    console.log("thinking...");

    const prompt = buildPrompt(input);
    const res = await askOllama(prompt);

    console.log("\nAI:\n", res);

    // 🧠 自動抓 multi-file
    const files = res.split("FILE:");

    if (files.length > 1) {
        files.forEach(chunk => {
            const parts = chunk.split("CODE:");
            if (parts.length < 2) return;

            const filePath = parts[0].trim();
            const code = parts[1].trim();

            if (filePath && code) {
                writeFileSafe(filePath, code);
            }
        });
    }
}

function loop() {
    rl.question("TE v2 > ", async (input) => {
        if (!input) return loop();

        if (input === "exit") {
            rl.close();
            return;
        }

        try {
            await handle(input);
        } catch (e) {
            console.log("ERROR:", e.message);
        }

        loop();
    });
}

loop();