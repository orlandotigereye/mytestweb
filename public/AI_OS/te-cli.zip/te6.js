const readline = require("readline");

const MODEL = "qwen3:8b";
const URL = "http://127.0.0.1:11434/api/chat";

console.log("🚀 TE CLI CLEAN MODE STARTED");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

async function askAI(input) {
    try {
        const res = await fetch(URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                model: MODEL,
                messages: [
                    { role: "user", content: input }
                ],
                stream: true
            })
        });

        const reader = res.body.getReader();
        const decoder = new TextDecoder();

        let buffer = "";

        process.stdout.write("\n🤖 AI: ");

        while (true) {
            const { value, done } = await reader.read();
            if (done) break;

            buffer += decoder.decode(value, { stream: true });

            // 🔥 Ollama stream 修正：用 newline + fallback chunk parse
            const chunks = buffer.split("\n");
            buffer = chunks.pop();

            for (let chunk of chunks) {
                chunk = chunk.trim();

                if (!chunk) continue;

                // 🧨 Ollama 有時會有 data: 前綴
                if (chunk.startsWith("data: ")) {
                    chunk = chunk.replace("data: ", "");
                }

                try {
                    const json = JSON.parse(chunk);

                    const text = json.message?.content;

                    if (text) {
                        process.stdout.write(text);
                    }

                } catch (e) {
                    // 🧠 如果不是 JSON → 當純文字
                    if (chunk.length < 200) {
                        process.stdout.write(chunk);
                    }
                }
            }
        }

        console.log("\n");

    } catch (err) {
        console.log("\n❌ ERROR:", err.message);
    }
}

function loop() {
    rl.question("TE > ", async (input) => {

        if (input.toLowerCase() === "exit") {
            console.log("Goodbye!");
            rl.close();
            return;
        }

        console.log("⚡ thinking...");

        await askAI(input);

        loop();
    });
}

loop();

rl.on("close", () => {
    process.exit(0);
});