const readline = require("readline");
const fs = require("fs");
const path = require("path");

const MODEL = "qwen3:8b";
const URL = "http://127.0.0.1:11434/api/chat";

console.log("🚀 TE CLI PRODUCT MODE STARTED");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// =========================
// 🧠 AI CALL (STREAM CLEAN)
// =========================
async function askAI(input) {
    const res = await fetch(URL, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            model: MODEL,
            messages: [
                {
                    role: "system",
                    content: `
You are a software engineering agent.

RULES:
- Output ONLY files if needed
- Format:
FILE: path
CODE:
...
- No explanations unless asked
`
                },
                { role: "user", content: input }
            ],
            stream: true
        })
    });

    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";
    let fullText = "";

    process.stdout.write("\n🤖 AI: ");

    while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n");
        buffer = lines.pop();

        for (let line of lines) {
            line = line.trim();
            if (!line) continue;

            try {
                const json = JSON.parse(line);
                const text = json.message?.content;

                if (text) {
                    process.stdout.write(text);
                    fullText += text;
                }
            } catch {}
        }
    }

    console.log("\n");

    return fullText;
}

// =========================
// 📁 FILE PARSER
// =========================
function parseAndWriteFiles(output) {
    const parts = output.split("FILE:");

    if (parts.length < 2) return;

    parts.forEach(chunk => {
        const p = chunk.split("CODE:");
        if (p.length < 2) return;

        const filePath = p[0].trim();
        const code = p[1].trim();

        if (!filePath || !code) return;

        const fullPath = path.resolve(filePath);

        fs.mkdirSync(path.dirname(fullPath), { recursive: true });
        fs.writeFileSync(fullPath, code, "utf8");

        console.log("✔ FILE CREATED:", filePath);
    });
}

// =========================
// CLI LOOP
// =========================
function loop() {
    rl.question("TE > ", async (input) => {

        if (input.toLowerCase() === "exit") {
            rl.close();
            return;
        }

        console.log("⚡ thinking...");

        const result = await askAI(input);

        parseAndWriteFiles(result);

        loop();
    });
}

loop();

rl.on("close", () => {
    process.exit(0);
});