module.exports = {
    MODEL: "qwen3:8b",
    URL: "http://127.0.0.1:11434/api/chat"
};