const readline = require("readline");

const MODEL = "qwen3:8b";
const URL = "http://127.0.0.1:11434/api/chat";

console.log("🚀 TE CLI CLEAN MODE STARTED");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

async function askAI(input) {
    try {
        const res = await fetch(URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                model: MODEL,
                messages: [
                    { role: "user", content: input }
                ],
                stream: true
            })
        });

        const reader = res.body.getReader();
        const decoder = new TextDecoder();

        let buffer = "";

        process.stdout.write("\n🤖 AI: ");

        while (true) {
            const { value, done } = await reader.read();
            if (done) break;

            buffer += decoder.decode(value, { stream: true });

            // 🔥 正解：用 line 分割（Ollama NDJSON）
            const lines = buffer.split("\n");
            buffer = lines.pop();

            for (let line of lines) {
                line = line.trim();
                if (!line) continue;

                try {
                    const json = JSON.parse(line);

                    const text = json.message?.content;

                    if (text) {
                        process.stdout.write(text);
                    }

                } catch (e) {
                    // ignore broken line
                }
            }
        }

        console.log("\n");

    } catch (err) {
        console.log("\n❌ ERROR:", err.message);
    }
}

function loop() {
    rl.question("TE > ", async (input) => {

        if (input.toLowerCase() === "exit") {
            console.log("Goodbye!");
            rl.close();
            return;
        }

        console.log("⚡ thinking...");

        await askAI(input);

        loop();
    });
}

loop();

rl.on("close", () => {
    process.exit(0);
});