const readline = require("readline");
const fs = require("fs");
const path = require("path");

const MODEL = "qwen3:8b";
const URL = "http://127.0.0.1:11434/api/chat";

console.log("🚀 TE CLI STREAM ENGINE v2.0 STARTED");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// =========================
// 🧠 STREAM AI ENGINE
// =========================

async function askAI(input) {
    const res = await fetch(URL, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            model: MODEL,
            messages: [
                { role: "user", content: input }
            ],
            stream: true
        })
    });

    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";
    let fullText = "";

    process.stdout.write("\n🤖 AI: ");

    while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        while (true) {
            const start = buffer.indexOf("{");
            if (start === -1) break;

            let open = 0;
            let end = -1;

            for (let i = start; i < buffer.length; i++) {
                if (buffer[i] === "{") open++;
                if (buffer[i] === "}") open--;

                if (open === 0) {
                    end = i;
                    break;
                }
            }

            if (end === -1) break;

            const jsonStr = buffer.slice(start, end + 1);
            buffer = buffer.slice(end + 1);

            try {
                const json = JSON.parse(jsonStr);
                const text = json?.message?.content;

                if (text) {
                    process.stdout.write(text);
                    fullText += text;
                }

            } catch (e) {}
        }
    }

    console.log("\n");

    return fullText;
}

// =========================
// 📁 STREAM-SAFE PARSER v2
// =========================
function parseAndWriteFiles(output) {
    const lines = output.split("\n");

    let state = "idle";
    let filePath = null;
    let codeBuffer = [];

    function flush() {
        if (!filePath || codeBuffer.length === 0) return;

        const fullPath = path.resolve(filePath);
        fs.mkdirSync(path.dirname(fullPath), { recursive: true });
        fs.writeFileSync(fullPath, codeBuffer.join("\n"), "utf8");

        console.log("✔ FILE CREATED:", filePath);

        filePath = null;
        codeBuffer = [];
        state = "idle";
    }

    for (let line of lines) {
        line = line.trim();

        if (line.startsWith("FILE:")) {
            flush();
            filePath = line.replace("FILE:", "").trim();
            state = "file";
            continue;
        }

        if (line.startsWith("CODE:")) {
            state = "code";
            continue;
        }

        if (state === "code") {
            codeBuffer.push(line);
        }
    }

    flush();
}

// =========================
// CLI LOOP
// =========================
function loop() {
    rl.question("TE > ", async (input) => {

        if (input.toLowerCase() === "exit") {
            rl.close();
            return;
        }

        console.log("⚡ thinking...");

        const result = await askAI(input);

        parseAndWriteFiles(result);

        loop();
    });
}

loop();

rl.on("close", () => {
    process.exit(0);
});