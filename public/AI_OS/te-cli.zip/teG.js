const readline = require("readline");
const fs = require("fs");
const path = require("path");

const MODEL = "qwen2.5:3b";
const URL = "http://127.0.0.1:11434/api/chat";

console.log("🚀 TE CLI v6 IDE CORE STARTED");

// =========================
// 📁 PROJECT SCAN SYSTEM
// =========================
function scanProject(dir = process.cwd()) {
    const files = [];

    function walk(d) {
        const items = fs.readdirSync(d);

        for (const item of items) {
            const full = path.join(d, item);

            if (fs.statSync(full).isDirectory()) {
                if (!["node_modules", "logs"].includes(item)) {
                    walk(full);
                }
            } else {
                files.push(full);
            }
        }
    }

    walk(dir);
    return files;
}

// =========================
// 📁 FILE TOOL
// =========================
function readFileTool(filePath) {
    try {
        return fs.readFileSync(filePath, "utf8");
    } catch (e) {
        return "ERROR: " + e.message;
    }
}

function applyFileEdit(filePath, content) {
    const full = path.join(process.cwd(), filePath);
    fs.mkdirSync(path.dirname(full), { recursive: true });
    fs.writeFileSync(full, content, "utf8");
    console.log("✏️ FILE UPDATED:", filePath);
}

// =========================
// 🧠 MEMORY (simple history)
// =========================
let history = [];

// =========================
// 🤖 AI ENGINE
// =========================
async function askAI(input) {

    const projectFiles = scanProject().slice(0, 30).join("\n");

    const messages = [
        {
            role: "system",
            content: `
You are TE AI IDE.

You can:
- read project files
- modify files
- debug code

PROJECT FILES:
${projectFiles}
`
        },
        ...history,
        { role: "user", content: input }
    ];

    const res = await fetch(URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            model: MODEL,
            messages,
            stream: true
        })
    });

    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";
    let fullText = "";

    process.stdout.write("\n🤖 AI: ");

    while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n");
        buffer = lines.pop();

        for (let line of lines) {
            line = line.trim();
            if (!line) continue;

            try {
                const json = JSON.parse(line);

                const text =
                    json?.message?.content ||
                    json?.message?.thinking;

                if (text) {
                    process.stdout.write(text);
                    fullText += text;
                }

            } catch {}
        }
    }

    console.log("\n");
    return fullText;
}

// =========================
// 📁 FILE PARSER (SAFE)
// =========================
function parseAndWriteFiles(output) {
    if (!output) return;

    const fileRegex = /FILE:\s*(.+)\nCODE:\n([\s\S]*?)(?=\nFILE:|$)/g;
    const mdRegex = /```([a-zA-Z0-9_.\-\/]+)\n([\s\S]*?)```/g;

    let match;
    let files = [];

    while ((match = fileRegex.exec(output)) !== null) {
        files.push({ path: match[1], code: match[2] });
    }

    while ((match = mdRegex.exec(output)) !== null) {
        files.push({ path: match[1], code: match[2] });
    }

    for (const f of files) {
        const full = path.join(process.cwd(), f.path);
        fs.mkdirSync(path.dirname(full), { recursive: true });
        fs.writeFileSync(full, f.code, "utf8");
        console.log("✔ FILE CREATED:", f.path);
    }
}

// =========================
// 🧠 CLI
// =========================
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function loop() {
    rl.question("TE > ", async (input) => {

        if (!input) return loop();

        // =========================
        // 🧠 COMMANDS
        // =========================

        // 📁 EDIT FILE
        if (input.startsWith("/edit ")) {
            const [, filePath, ...content] = input.split(" ");
            applyFileEdit(filePath, content.join(" "));
            return loop();
        }

        // 🐛 DEBUG PROJECT
        if (input === "/debug") {
            const files = scanProject();

            let issues = [];

            for (const f of files.slice(0, 20)) {
                const code = readFileTool(f);

                if (
                    code.includes("undefined") ||
                    code.includes("Exception") ||
                    code.includes("Error")
                ) {
                    issues.push({ file: f, preview: code.slice(0, 200) });
                }
            }

            console.log("🐛 DEBUG REPORT:");
            console.log(issues);

            return loop();
        }

        // 📁 SHOW PROJECT
        if (input === "/project") {
            console.log(scanProject().slice(0, 50));
            return loop();
        }

        if (input === "exit") {
            rl.close();
            return;
        }

        console.log("⚡ thinking...");

        history.push({ role: "user", content: input });

        const result = await askAI(input);

        history.push({ role: "assistant", content: result });

        if (history.length > 20) {
            history = history.slice(-20);
        }

        parseAndWriteFiles(result);

        loop();
    });
}

loop();

rl.on("close", () => {
    process.exit(0);
});