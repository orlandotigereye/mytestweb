const readline = require("readline");
const fs = require("fs");
const path = require("path");

const MODEL = "qwen2.5:3b";
const URL = "http://127.0.0.1:11434/api/chat";

console.log("🚀 TE CLI v5 CHATGPT CLONE STARTED");

// =========================
// 📁 LOG SYSTEM
// =========================
const LOG_DIR = path.join(__dirname, "logs");

function getDateStr() {
    const d = new Date();
    const y = String(d.getFullYear()).slice(2);
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}${m}${day}`;
}

function getSessionFile() {
    if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR);

    const date = getDateStr();

    const files = fs.readdirSync(LOG_DIR)
        .filter(f => f.startsWith(`LLM${date}`))
        .sort();

    let num = 1;
    if (files.length > 0) {
        const last = files[files.length - 1];
        const match = last.match(/(\d+)\.json$/);
        if (match) num = parseInt(match[1]) + 1;
    }

    const id = String(num).padStart(3, "0");

    return {
        fileName: `LLM${date}${id}.json`,
        filePath: path.join(LOG_DIR, `LLM${date}${id}.json`)
    };
}

const session = getSessionFile();

let history = [];

let logData = {
    session: session.fileName.replace(".json", ""),
    date: new Date().toISOString().slice(0, 10),
    messages: []
};

function saveLog() {
    fs.writeFileSync(
        session.filePath,
        JSON.stringify(logData, null, 2),
        "utf8"
    );
}

// =========================
// 🧠 AI STREAM ENGINE
// =========================
async function askAI(input) {
    const messages = [
        {
            role: "system",
            content: "You are a helpful AI assistant and coding agent."
        },
        ...history,
        { role: "user", content: input }
    ];

    const res = await fetch(URL, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            model: MODEL,
            messages,
            stream: true
        })
    });

    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";
    let fullText = "";

    process.stdout.write("\n🤖 AI: ");

    while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n");
        buffer = lines.pop();

        for (let line of lines) {
            line = line.trim();
            if (!line) continue;

            try {
                const json = JSON.parse(line);
                const text =
                    json?.message?.content ||
                    json?.message?.thinking;

                if (text) {
                    process.stdout.write(text);
                    fullText += text;
                }
            } catch {}
        }
    }

    console.log("\n");

    return fullText;
}

// =========================
// 📁 FILE EXTRACTOR (ROBUST)
// =========================
function parseAndWriteFiles(output) {
    if (!output) return;

    let files = [];

    // FILE: CODE:
    const fileRegex = /FILE:\s*(.+)\nCODE:\n([\s\S]*?)(?=\nFILE:|$)/g;
    let match;

    while ((match = fileRegex.exec(output)) !== null) {
        files.push({
            path: match[1].trim(),
            code: match[2].trim()
        });
    }

    // markdown ```file
    const mdRegex = /```([a-zA-Z0-9_.\-\/]+)\n([\s\S]*?)```/g;

    while ((match = mdRegex.exec(output)) !== null) {
        files.push({
            path: match[1].trim(),
            code: match[2].trim()
        });
    }

    if (files.length === 0) return;

    for (const f of files) {
        const safePath = path.join(process.cwd(), f.path);

        fs.mkdirSync(path.dirname(safePath), { recursive: true });
        fs.writeFileSync(safePath, f.code, "utf8");

        console.log("✔ FILE CREATED:", f.path);
    }
}

// =========================
// 🧠 CLI LOOP
// =========================
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function loop() {
    rl.question("TE > ", async (input) => {

        if (!input) return loop();

        if (input.toLowerCase() === "exit") {
            saveLog();
            rl.close();
            return;
        }

        if (input === "/reset") {
            history = [];
            console.log("🧠 memory cleared");
            return loop();
        }

        console.log("⚡ thinking...");

        logData.messages.push({
            role: "user",
            content: input
        });

        const result = await askAI(input);

        logData.messages.push({
            role: "assistant",
            content: result
        });

        history.push({ role: "user", content: input });
        history.push({ role: "assistant", content: result });

        if (history.length > 20) {
            history = history.slice(-20);
        }

        saveLog();

        parseAndWriteFiles(result);

        loop();
    });
}

loop();

rl.on("close", () => {
    process.exit(0);
});