const readline = require("readline");

const MODEL = "qwen3:8b";
const URL = "http://127.0.0.1:11434/api/chat";

console.log("🚀 TE CLI CLEAN MODE v4 STARTED");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

async function askAI(input) {
    try {
        const res = await fetch(URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                model: MODEL,
                messages: [
                    { role: "user", content: input }
                ],
                stream: true
            })
        });

        const reader = res.body.getReader();
        const decoder = new TextDecoder();

        let buffer = "";

        process.stdout.write("\n🤖 AI: ");

        while (true) {
            const { value, done } = await reader.read();
            if (done) break;

            buffer += decoder.decode(value, { stream: true });

            // 🔥 安全 JSON extractor（穩定版核心）
            while (true) {
                const start = buffer.indexOf("{");
                const end = buffer.indexOf("}", start + 1);

                if (start === -1 || end === -1) break;

                const jsonStr = buffer.slice(start, end + 1);
                buffer = buffer.slice(end + 1);

                try {
                    const json = JSON.parse(jsonStr);

                    const text = json?.message?.content;

                    // ❌ 忽略 thinking
                    if (text) {
                        process.stdout.write(text);
                    }

                } catch (e) {
                    // ignore broken json
                }
            }
        }

        console.log("\n");

    } catch (err) {
        console.log("\n❌ ERROR:", err.message);
    }
}

function loop() {
    rl.question("TE > ", async (input) => {

        if (input.toLowerCase() === "exit") {
            console.log("Goodbye!");
            rl.close();
            return;
        }

        console.log("⚡ thinking...");

        await askAI(input);

        loop();
    });
}

loop();

rl.on("close", () => {
    process.exit(0);
});