const readline = require("readline");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const MODEL = "qwen2.5:3b";
const URL = "http://127.0.0.1:11434/api/chat";

console.log("🚀 TE OS v6.3 STABLE VERIFIED STARTED");

// ======================================================
// 📦 FEATURE CHECKLIST (不准功能消失)
// ======================================================
const FEATURES = {
    ai_chat: true,
    streaming: true,
    memory: true,
    file_generation: true,
    file_parser: true,
    markdown_parser: true,
    version_system: true,
    project_system: true,
    file_backup: true,
    safe_writer: true
};

function featureCheck() {
    const missing = Object.entries(FEATURES)
        .filter(([k, v]) => !v)
        .map(([k]) => k);

    if (missing.length > 0) {
        console.log("❌ FEATURE MISSING:", missing);
    } else {
        console.log("✅ ALL FEATURES OK");
    }
}

// ======================================================
// 📊 RUNTIME BEHAVIOR MONITOR
// ======================================================
const runtime = {
    startTime: Date.now(),
    requestCount: 0,
    fileCreated: 0,
    lastInput: null
};

function runtimeReport() {
    const uptime = ((Date.now() - runtime.startTime) / 1000).toFixed(2);

    console.log("\n📊 RUNTIME REPORT");
    console.log("────────────────────");
    console.log("⏱ uptime:", uptime + "s");
    console.log("💬 requests:", runtime.requestCount);
    console.log("📁 files:", runtime.fileCreated);
    console.log("🧠 last input:", runtime.lastInput);
    console.log("────────────────────\n");
}

// ======================================================
// 📦 VERSION SYSTEM
// ======================================================
const VERSION_DB = path.join(__dirname, ".te_version.json");

function getDateKey() {
    const d = new Date();
    return String(d.getFullYear()).slice(2) +
        String(d.getMonth() + 1).padStart(2, "0") +
        String(d.getDate()).padStart(2, "0");
}

function loadDB() {
    if (!fs.existsSync(VERSION_DB)) return {};
    return JSON.parse(fs.readFileSync(VERSION_DB, "utf8"));
}

function saveDB(db) {
    fs.writeFileSync(VERSION_DB, JSON.stringify(db, null, 2));
}

function nextVersion() {
    const db = loadDB();
    const key = getDateKey();

    db[key] = (db[key] || 0) + 1;
    saveDB(db);

    return `${key}V${String(db[key]).padStart(4, "0")}`;
}

// ======================================================
// 🧠 REGRESSION TEST ENGINE
// ======================================================
function regressionTest() {
    console.log("\n🧪 RUNNING REGRESSION TESTS...");

    const tests = [
        { name: "feature_check", fn: () => Object.keys(FEATURES).length >= 9 },
        { name: "version_system", fn: () => typeof nextVersion() === "string" },
        { name: "fs_access", fn: () => fs.existsSync(__dirname) },
        { name: "crypto_hash", fn: () => crypto.createHash("md5").update("test").digest("hex").length > 0 }
    ];

    let pass = 0;

    for (const t of tests) {
        try {
            const ok = t.fn();
            console.log(ok ? "✅" : "❌", t.name);
            if (ok) pass++;
        } catch (e) {
            console.log("❌", t.name, "ERROR");
        }
    }

    console.log(`\n🧪 RESULT: ${pass}/${tests.length} PASSED\n`);

    return pass === tests.length;
}

// ======================================================
// 📁 FILE SYSTEM (SAFE)
// ======================================================
function writeFileSafe(filePath, content) {
    fs.mkdirSync(path.dirname(filePath), { recursive: true });

    if (fs.existsSync(filePath)) {
        const backup = filePath + ".bak";
        fs.copyFileSync(filePath, backup);
    }

    fs.writeFileSync(filePath, content, "utf8");

    runtime.fileCreated++;

    console.log("✔ FILE CREATED:", filePath);
}

// ======================================================
// 📁 FILE PARSER
// ======================================================
function parseAndWriteFiles(output) {
    if (!output) return;

    const fileRegex = /FILE:\s*(.+)\nCODE:\n([\s\S]*?)(?=\nFILE:|$)/g;
    const mdRegex = /```([a-zA-Z0-9_.\-\/]+)\n([\s\S]*?)```/g;

    let match;
    let files = [];

    while ((match = fileRegex.exec(output)) !== null) {
        files.push({ path: match[1], code: match[2] });
    }

    while ((match = mdRegex.exec(output)) !== null) {
        files.push({ path: match[1], code: match[2] });
    }

    for (const f of files) {
        const safePath = path.join(process.cwd(), f.path);
        writeFileSafe(safePath, f.code);
    }
}

// ======================================================
// 🧠 AI ENGINE
// ======================================================
async function askAI(input) {
    runtime.requestCount++;
    runtime.lastInput = input;

    const res = await fetch(URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            model: MODEL,
            messages: [
                {
                    role: "system",
                    content: "You are TE OS AI agent."
                },
                { role: "user", content: input }
            ],
            stream: true
        })
    });

    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";
    let full = "";

    process.stdout.write("\n🤖 AI: ");

    while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n");
        buffer = lines.pop();

        for (let line of lines) {
            line = line.trim();
            if (!line) continue;

            try {
                const json = JSON.parse(line);
                const text = json?.message?.content || json?.message?.thinking;

                if (text) {
                    process.stdout.write(text);
                    full += text;
                }
            } catch {}
        }
    }

    console.log("\n");

    return full;
}

// ======================================================
// 🧠 CLI
// ======================================================
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function loop() {
    rl.question("TE > ", async (input) => {

        if (!input) return loop();

        if (input === "/check") {
            featureCheck();
            return loop();
        }

        if (input === "/runtime") {
            runtimeReport();
            return loop();
        }

        if (input === "/test") {
            regressionTest();
            return loop();
        }

        if (input === "/version") {
            console.log("📦 VERSION:", nextVersion());
            return loop();
        }

        if (input.toLowerCase() === "exit") {
            rl.close();
            return;
        }

        console.log("⚡ thinking...");

        const result = await askAI(input);

        parseAndWriteFiles(result);

        loop();
    });
}

loop();

rl.on("close", () => process.exit(0));