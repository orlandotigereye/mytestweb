const fs = require("fs");
const path = require("path");
const readline = require("readline");

const MODEL = "qwen3:8b";

console.log("🚀 TE CLI v3.1 STABLE FIXED STARTED");

// =========================
// 🧠 SAFE OLLAMA CALL
// =========================
async function askOllama(prompt) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 120000);

    try {
        const res = await fetch("http://127.0.0.1:11434/api/chat", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            signal: controller.signal,
            body: JSON.stringify({
                model: MODEL,
                messages: [
                    { role: "user", content: prompt }
                ],
                stream: false
            })
        });

        clearTimeout(timeout);

        const text = await res.text();   // 🔥 重要：不用 json()

        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            console.log("⚠ RAW RESPONSE:");
            console.log(text);
            return text;
        }

        return data.message?.content || data.response || JSON.stringify(data);

    } catch (err) {
        clearTimeout(timeout);

        console.log("========== OLLAMA ERROR ==========");
        console.log(err.name);
        console.log(err.message);
        console.log("==================================");

        return "ERROR";
    }
}

// =========================
// 📁 FILE WRITER
// =========================
function writeFileSafe(filePath, content) {
    try {
        const full = path.resolve(filePath);
        fs.mkdirSync(path.dirname(full), { recursive: true });
        fs.writeFileSync(full, content, "utf8");
        console.log("✔ FILE:", filePath);
    } catch (e) {
        console.log("WRITE ERROR:", e.message);
    }
}

// =========================
// 🧠 PROMPT
// =========================
function buildPrompt(input) {
    return `
You are an AUTONOMOUS SOFTWARE ENGINEERING AGENT.

RULES:
- Output ONLY code
- No explanations
- Multi-file format:
FILE: path
CODE:
...
TASK:
${input}
`;
}

// =========================
// 📦 PARSER
// =========================
function parseFiles(output) {
    const parts = output.split("FILE:");

    for (const chunk of parts) {
        const p = chunk.split("CODE:");
        if (p.length < 2) continue;

        const file = p[0].trim();
        const code = p[1].trim();

        if (file && code) {
            writeFileSafe(file, code);
        }
    }
}

// =========================
// CLI
// =========================
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

async function handle(input) {
    console.log("thinking...");

    const prompt = buildPrompt(input);
    const res = await askOllama(prompt);

    console.log("\nAI:\n", res);

    parseFiles(res);
}

function loop() {
    rl.question("TE v3.1 > ", async (input) => {
        if (input === "exit") process.exit(0);

        try {
            await handle(input);
        } catch (e) {
            console.log("ERROR:", e.message);
        }

        loop();
    });
}

loop();