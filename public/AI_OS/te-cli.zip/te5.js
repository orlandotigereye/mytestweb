const readline = require("readline");

const MODEL = "qwen3:8b";
const URL = "http://127.0.0.1:11434/api/chat";

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

async function askAI(input) {
    const res = await fetch(URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            model: MODEL,
            messages: [
                { role: "user", content: input }
            ],
            stream: true
        })
    });

    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let full = "";

    process.stdout.write("\nAI: ");

    while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value);
        full += chunk;

        // ⚡ 即時輸出
        process.stdout.write(chunk);
    }

    console.log("\n");
    return full;
}

function loop() {
    rl.question("TE > ", async (input) => {

        if (input === "exit") process.exit(0);

        console.log("thinking...");

        await askAI(input);

        loop();
    });
}

loop();