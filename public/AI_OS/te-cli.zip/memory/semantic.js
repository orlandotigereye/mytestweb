const fs = require("fs");
const path = require("path");

const EMBED_URL = "http://127.0.0.1:11434/api/embeddings";

const DB_FILE = path.join(__dirname, "vector.json");

function loadDB() {
    if (!fs.existsSync(DB_FILE)) return [];
    return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
}

function saveDB(db) {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

// 👉 取得 embedding
async function embed(text) {
    const res = await fetch(EMBED_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            model: "nomic-embed-text",
            prompt: text
        })
    });

    const data = await res.json();
    return data.embedding;
}

// 👉 cosine similarity
function cosine(a, b) {
    let dot = 0, magA = 0, magB = 0;

    for (let i = 0; i < a.length; i++) {
        dot += a[i] * b[i];
        magA += a[i] * a[i];
        magB += b[i] * b[i];
    }

    return dot / (Math.sqrt(magA) * Math.sqrt(magB));
}

// 👉 add memory
async function addMemory(text) {
    const db = loadDB();
    const vector = await embed(text);

    db.push({ text, vector });
    saveDB(db);
}

// 👉 search memory
async function searchMemory(query, topK = 5) {
    const db = loadDB();
    const qVec = await embed(query);

    const scored = db.map(item => ({
        text: item.text,
        score: cosine(qVec, item.vector)
    }));

    return scored
        .sort((a, b) => b.score - a.score)
        .slice(0, topK);
}

module.exports = {
    addMemory,
    searchMemory
};