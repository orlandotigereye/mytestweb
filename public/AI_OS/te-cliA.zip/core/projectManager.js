const fs = require("fs");
const path = require("path");

class ProjectManager {

    constructor(config, versionManager) {

        this.config = config;
        this.version = versionManager;

        this.root = config.PROJ_DIR;

        this.ensureFolders();

        this.projectFile = config.PROJECT_JSON;

        this.manifestFile = config.MANIFEST_FILE;

        this.indexFile = config.PROJECT_INDEX;

        this.loadProject();

    }

    // ==================================================
    // 建立資料夾
    // ==================================================

    ensureFolders() {

        const folders = [

            "",

            "html",

            "css",

            "js",

            "json",

            "txt",

            "pdf",

            "image",

            "other"

        ];

        for (const f of folders) {

            fs.mkdirSync(
                path.join(this.root, f),
                { recursive: true }
            );

        }

    }

    // ==================================================
    // load
    // ==================================================

    loadProject() {

        if (fs.existsSync(this.projectFile)) {

            try {

                this.project =
                    JSON.parse(
                        fs.readFileSync(
                            this.projectFile,
                            "utf8"
                        )
                    );

                return;

            } catch {}

        }

        this.project = {

            version: this.version.current(),

            created: new Date().toISOString(),

            files: []

        };

        this.saveProject();

    }

    // ==================================================
    // save
    // ==================================================

    saveProject() {

        fs.writeFileSync(

            this.projectFile,

            JSON.stringify(
                this.project,
                null,
                2
            )

        );

    }

    // ==================================================
    // 副檔名分類
    // ==================================================

    folder(ext) {

        ext = ext.toLowerCase();

        return this.config.OUTPUT_FOLDER[ext]
            || this.config.DEFAULT_OUTPUT_FOLDER;

    }

    // ==================================================
    // 前四字
    // ==================================================

    prefix(filename) {

        const name =
            path.parse(filename).name
                .replace(/[^a-z0-9]/ig, "");

        return (name || "file")
            .substring(
                0,
                this.config.FILE_PREFIX_LENGTH
            )
            .padEnd(
                this.config.FILE_PREFIX_LENGTH,
                "_"
            );

    }

    // ==================================================
    // 流水號
    // ==================================================

    nextNumber(folder, prefix, ext) {

        const dir =
            path.join(
                this.root,
                folder
            );

        const files =
            fs.readdirSync(dir);

        let max = 0;

        for (const f of files) {

            const m =
                f.match(
                    new RegExp(
                        "^" +
                        prefix +
                        "(\\d+)\\." +
                        ext +
                        "$",
                        "i"
                    )
                );

            if (m) {

                max =
                    Math.max(
                        max,
                        parseInt(m[1])
                    );

            }

        }

        return String(max + 1)
            .padStart(
                this.config.FILE_COUNTER_DIGITS,
                "0"
            );

    }

    // ==================================================
    // 建立完整路徑
    // ==================================================

    buildPath(originalName) {

        const ext =
            path.extname(originalName)
                .replace(".", "")
                .toLowerCase();

        const folder =
            this.folder(ext);

        const prefix =
            this.prefix(originalName);

        const num =
            this.nextNumber(
                folder,
                prefix,
                ext
            );

        const filename =
            `${prefix}${num}.${ext}`;

        return {

            folder,

            filename,

            fullPath:
                path.join(
                    this.root,
                    folder,
                    filename
                )

        };

    }

    // ==================================================
    // 寫檔
    // ==================================================

    write(originalName, content) {

        const file =
            this.buildPath(originalName);

        fs.writeFileSync(

            file.fullPath,

            content,

            "utf8"

        );

        this.project.files.push({

            original: originalName,

            saved: file.filename,

            folder: file.folder,

            version: this.version.current(),

            created: new Date().toISOString()

        });

        this.saveProject();

        this.saveManifest();

        console.log(
            "✔ FILE CREATED:",
            file.filename
        );

        return file.fullPath;

    }

    // ==================================================
    // Manifest
    // ==================================================

    saveManifest() {

        fs.writeFileSync(

            this.manifestFile,

            JSON.stringify(

                this.project.files,

                null,

                2

            )

        );

    }

    // ==================================================
    // list
    // ==================================================

    list() {

        return this.project.files;

    }

}

module.exports = ProjectManager;