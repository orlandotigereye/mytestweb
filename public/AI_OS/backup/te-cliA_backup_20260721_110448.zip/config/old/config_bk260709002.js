const path = require("path");

// 修正安全沙箱範圍：在 Windows 系統下放寬至磁碟機根目錄，允許跨資料夾寫入 C:\tmp2
const ROOT = process.platform === "win32" ? "C:/" : "/";

module.exports = {

    // =====================================
    // AI
    // =====================================
	//MODEL_SMART: "qwen2.5:14b" 會死掉

    URL: "http://127.0.0.1:11434/api/chat",
	
    MODEL_FAST: "qwen2.5:3b",

    MODEL_SMART: "qwen2.5:7b",

    DEFAULT_MODEL: "qwen2.5:7b",

    TEMPERATURE: 0.2,

    NUM_PREDICT: 500,

    STREAM: true,

    // =====================================
    // PATH
    // =====================================

    ROOT,

    VERSION_FILE: path.join(process.platform === "win32" ? "C:/tmp2" : __dirname, "version.json"),

    LOG_DIR: path.join(process.platform === "win32" ? "C:/tmp2" : __dirname, "logs"),

    OUTPUT_DIR: path.join(process.platform === "win32" ? "C:/tmp2" : __dirname, "output"),

    PROJECT_DIR: path.join(process.platform === "win32" ? "C:/tmp2" : __dirname, "projects"),

    MEMORY_DIR: path.join(process.platform === "win32" ? "C:/tmp2" : __dirname, "memory"),

    BACKUP_DIR: path.join(process.platform === "win32" ? "C:/tmp2" : __dirname, "backup"),

    // ========= TE OS v7 新增 =========

    PROJ_DIR: path.join(process.platform === "win32" ? "C:/tmp2" : __dirname, "Proj"),

    PROJECT_JSON: path.join(process.platform === "win32" ? "C:/tmp2" : __dirname, "Proj", "project.json"),

    PROJECT_INDEX: path.join(process.platform === "win32" ? "C:/tmp2" : __dirname, "Proj", "project.index.json"),

    MANIFEST_FILE: path.join(process.platform === "win32" ? "C:/tmp2" : __dirname, "Proj", "manifest.json"),

    SESSION_DIR: path.join(process.platform === "win32" ? "C:/tmp2" : __dirname, "sessions"),

    CACHE_DIR: path.join(process.platform === "win32" ? "C:/tmp2" : __dirname, "cache"),

    TEMP_DIR: path.join(process.platform === "win32" ? "C:/tmp2" : __dirname, "temp"),
    
    WIKI_FILE: path.join(process.platform === "win32" ? "C:/tmp2" : __dirname, "memory", "company_facts.json"),
    
    SCHEDULE_FILE: path.join(process.platform === "win32" ? "C:/tmp2" : __dirname, "memory", "schedules.json"),

    DB_SCHEMA_DIR: "C:/tmp2/web/25060301/public/cfoc",

    DB_CONFIG: {
        server: "localhost",
        database: "CFOCT",
        user: "sa",
        password: "your_password",
        options: { encrypt: false, trustServerCertificate: true }
    },

    // =====================================
    // FILE
    // =====================================

    BACKUP_EXTENSION: ".bak",

    AUTO_BACKUP: false,

    AUTO_CREATE_FOLDER: true,

    // ========= 自動分類 =========

    OUTPUT_FOLDER: {

        html: "html",

        htm: "html",

        css: "css",

        js: "js",

        mjs: "js",

        cjs: "js",

        ts: "js",

        jsx: "js",

        tsx: "js",

        json: "json",

        txt: "txt",

        md: "txt",

        csv: "txt",

        log: "txt",

        pdf: "pdf",

        png: "image",

        jpg: "image",

        jpeg: "image",

        gif: "image",

        webp: "image",

        svg: "image",

        bmp: "image",

        ico: "image"

    },

    DEFAULT_OUTPUT_FOLDER: "other",

    // =====================================
    // 自動命名
    // =====================================

    FILE_PREFIX_LENGTH: 4,

    FILE_COUNTER_DIGITS: 4,

    AUTO_RENAME_FILE: true,

    AUTO_FIX_FILENAME: true,

    AUTO_FIX_EXTENSION: true,

    AUTO_FIX_PATH: true,

    // =====================================
    // PROJECT
    // =====================================

    CREATE_PROJECT_JSON: true,

    CREATE_MANIFEST: true,

    CREATE_INDEX: true,

    SAVE_HISTORY: true,

    SAVE_SESSION: true,

    SAVE_MEMORY: true,

    PROJECT_HISTORY_LIMIT: 1000,

    // =====================================
    // RUNTIME
    // =====================================

    MAX_HISTORY: 20,

    MAX_OUTPUT_FILE: 20,

    MAX_MEMORY_SEARCH: 10,

    MAX_PROJECT_FILE: 5000,

    // =====================================
    // VERSION
    // =====================================

    VERSION_PREFIX: "V",

    VERSION_DIGITS: 4,

    // =====================================
    // MODEL ROUTER
    // =====================================

    LONG_PROMPT_LENGTH: 80,

    SMART_KEYWORDS: [

        "code",

        "project",

        "architecture",

        "design",

        "debug",

        "bug",

        "fix",

        "review",

        "refactor",

        "performance",

        "security",

        "database",

        "server",

        "node",

        "javascript",

        "python",

        "html",

        "css",

        "api",

        "sql",

        "json"

    ],

    // =====================================
    // FEATURE FLAGS
    // =====================================

    FEATURES: {

        ai_chat: true,

        streaming: true,

        model_router: true,

        runtime_monitor: true,

        version_system: true,

        regression_test: true,

        feature_checklist: true,

        file_writer: true,

        file_parser: true,

        auto_backup: true,

        auto_project: true,

        auto_manifest: true,

        auto_index: true,

        auto_folder: true,

        auto_filename: true,

        conflict_resolver: true,

        semantic_memory: true,

        continue_project: true,

        debug_project: true,

        modify_project: true,

        installer_mode: false

    }

};