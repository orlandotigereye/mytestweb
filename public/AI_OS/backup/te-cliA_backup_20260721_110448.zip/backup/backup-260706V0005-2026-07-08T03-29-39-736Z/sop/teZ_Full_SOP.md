# 🧠 AI COGNITIVE OS v5 (teZ.js) - 全功能標準作業程序 (SOP)

本文件提供 **AI COGNITIVE OS v5** (`teZ.js`) 的完整功能說明、部署流程及操作範例。本系統整合了多代理協作 (Multi-Agent Collaboration)、語意記憶 (Semantic Memory) 與專案管理 (Project Management) 功能，旨在提供高效的自動化開發體驗。

---

## 🏗️ 系統架構簡述

`teZ.js` 作為核心調度器，整合了以下模組：
- **VersionManager**: 處理版本控制與系統演進。
- **MemorySystem**: 基於圖結構的對話與語意記憶。
- **FileSystemManager**: 處理沙盒安全讀寫、搜尋取代 (Search & Replace) 邏輯。
- **AIEngine**: 處理 Planner, Executor, Reward 等認知流程。
- **ProjectManager**: 專責專案初始化、任務路徑 (Roadmap) 與 Express 看板整合。
- **UI Renderer**: 處理終端機格式化輸出、進度條與顏色。

---

## 📦 系統移載與自由移動指南 (Portability Guide)

本系統設計為「環境感知」，支援在不同目錄或電腦間自由移動：

### 1. 本地移動 (同一台電腦)
- 您可以直接對整個 `te-cliA` 資料夾進行「剪下」與「貼上」。
- 系統會自動根據當前位置重新設定安全邊界 (Sandbox Root) 與資料路徑。

### 2. 異地移動 (搬移至新電腦)
- **完整複製**: 連同 `node_modules` 資料夾一起複製，可確保即插即用。
- **輕量複製**: 僅複製程式碼與 `package.json`。在新環境中執行：
  ```bash
  npm install
  ```
  系統會自動補齊 `pdf-parse`, `xlsx`, `express` 等必要功能組件。

### 3. 必備檔案清單
確保移動時包含以下核心結構：
- `teZ.js` (主程式)
- `config/`, `core/`, `lib/` (功能模組)
- `memory/`, `Novels/` (您的對話與創作數據)
- `package.json` (環境配置清單)

---

## 🚀 部署與啟動流程

### 1. 環境需求
- **Node.js**: v18.0.0 或更高版本。
- **AI 推理後端**: Ollama (預設連接埠 11434)。
- **預設模型**: `qwen2.5:3b` (Fast) 與 `qwen2.5:7b` (Smart)。

### 2. 安裝步驟
1. 確保目錄中包含 `teZ.js` 及其相依目錄：`config/`, `core/`, `lib/`, `memory/`。
2. 啟動 Ollama 服務並確保模型已下載：
   ```bash
   ollama pull qwen2.5:3b
   ollama pull qwen2.5:7b
   ```
3. 在終端機執行：
   ```bash
   node teZ.js
   ```

---

## ⌨️ CLI 全功能指令指南

系統啟動後，在 `You ➔` 提示符下輸入指令。

### 1. 系統診斷與狀態
- **`/check`**
  - **功能**: 檢查核心模組 (Memory, UI, FS, AI Engine) 是否加載成功。
  - **範例**: `You ➔ /check`
- **`/runtime`**
  - **功能**: 顯示當前運行指標，包括啟動時間、請求次數、獎勵歷史、流式塊數等。
  - **範例**: `You ➔ /runtime`

### 2. 模型管理
- **`/model [fast|smart|dynamic]`**
  - **功能**: 切換當前活動模型。
    - `fast`: 使用輕量模型（預設為 config 中的 `MODEL_FAST`）。
    - `smart`: 使用強推理模型（預設為 config 中的 `MODEL_SMART`）。
    - `dynamic`: 系統根據輸入長度自動選擇（預設行為）。
  - **範例**: `You ➔ /model smart`

### 3. 檔案與資料夾操作
- **`/file <path> <instruction>`**
  - **功能**: 載入特定檔案內容並執行指令。支援帶引號的路徑。
  - **範例**: `You ➔ /file "src/main.js" 幫我把這個函數重構為非同步模式`
- **`/folder <dir> <instruction>`**
  - **功能**: 遞迴讀取資料夾內所有檔案。大型檔案會自動觸發並行摘要 (Concurrent Summarization) 以節省 Context 空間。
  - **範例**: `You ➔ /folder "./lib" 分析這些模組的依賴關係`

### 4. 專案管理系統 (`/project`)
- **`/project init [dir]`**
  - **功能**: 在指定目錄初始化 Phase5 專案管理器，生成 `package.json` 與 `p5_kanban.json`。
  - **範例**: `You ➔ /project init ./web-dashboard`
- **`/project open [dir]`**
  - **功能**: 啟動指定專案的 Express 儀表板服務（需先生成 `p5_web_server.js`）。
  - **範例**: `You ➔ /project open ./web-dashboard`
- **`/project analyze [dir]`**
  - **功能**: 掃描專案目錄，分析整體結構與代碼品質。
  - **範例**: `You ➔ /project analyze ./src`
- **`/project roadmap`**
  - **功能**: 以表格形式顯示當前專案的任務清單與狀態。
  - **範例**: `You ➔ /project roadmap`
- **`/project risk`**
  - **功能**: 查看最近一次開發流程的風險評估報告。
  - **範例**: `You ➔ /project risk`

### 5. 連續小說創作系統 (`/novel`)
- **`/novel init <title>`**
  - **功能**: 初始化一部新小說，自動生成大綱與章節規劃。
  - **範例**: `You ➔ /novel init "時空裂縫的守望者"`
- **`/novel load <title>`**
  - **功能**: 載入已存在的小說專案。
  - **範例**: `You ➔ /novel load "時空裂縫的守望者"`
- **`/novel next [prompt]`**
  - **功能**: 根據大綱與前文背景，自動撰寫下一章節。可加入特定劇情提示。
  - **範例**: `You ➔ /novel next "主角在這一章發現了古老的符文"`
- **`/novel status`**
  - **功能**: 顯示目前小說的進度、章節數及儲存路徑。
  - **範例**: `You ➔ /novel status`
- **`/novel list`**
  - **功能**: 列出所有已建立的小說專案。
  - **範例**: `You ➔ /novel list`

### 6. 企業級進階工具 (`/schedule`, `/wiki`, `/analyze`, `/export`, `/portal`)
- **`/schedule <time> <cmd>`**
  - **功能**: 設定定時任務（如 `17:00`）或倒數計時器（如 `in 10m`）。
  - **範例**: `You ➔ /schedule "in 5m" 提醒我檢查郵件`
- **`/wiki`**
  - **功能**: 顯示從對話中自動提取的「企業知識百科」。
  - **範例**: `You ➔ /wiki`
- **`/analyze <file>`**
  - **功能**: 針對 PDF、Excel 等非文字檔進行內容分析與摘要。
  - **範例**: `You ➔ /analyze "reports/sales.xlsx"`
- **`/export [novel|report]`**
  - **功能**: 將產出內容（小說或系統報告）匯出為排版精美的 HTML 檔案。
  - **範例**: `You ➔ /export novel`
- **`/portal`**
  - **功能**: 啟動 Web 互動門戶，讓您在瀏覽器介面中與 AI 進行全功能互動。
  - **範例**: `You ➔ /portal`

### 7. 其他指令
- **`/help`**: 顯示簡易指令清單。
- **`/clear`**: 清除當前對話記憶。
- **`exit`**: 安全退出系統。

---

## 🧠 核心開發流程：PlanA (Cognition Pipeline)

當您直接輸入開發相關需求時，系統會啟動 **PlanA** 自動化工作流：

1. **規劃 (Planner)**: AI 分析需求並生成分步執行計劃。
2. **實作 (Multi-Agent Workflow)**: 
   - 系統會根據 Context 自動切換模型。
   - 支援 **Search & Replace 區塊** 修改模式，精準編輯現有檔案。
   - 若無區塊標籤，則自動識別代碼塊進行全檔案覆蓋寫入。
3. **安全檢查 (Sandbox)**:
   - 修改後的 `.js` 檔案會自動觸發沙盒執行測試 (4000ms 逾時控制)。
   - 確保代碼邏輯正確且無執行期錯誤。
4. **版本控制 (Versioning)**:
   - 所有異動會透過 `RegressionCenter` 進行版本追蹤，確保可回溯性。
5. **獎勵機制 (Reward)**:
   - 系統根據輸出品質自動評分 (Reward Score)，並記錄於 Runtime。

---

## 💡 使用小技巧
- **引號支援**: 指令中的路徑若包含空白，請務必使用雙引號封裝，如 `"/my folder/test.js"`。
- **摘要機制**: 當使用 `/folder` 處理大型專案時，系統會自動對超過 10000 字元的檔案進行摘要，以確保不超出 LLM 的 Context Limit。
- **即時回饋**: 系統在執行耗時操作時會顯示 Spinner 或進度百分比，請耐心等待 AI 完成思考。

---

## 🎬 具體案例演示

### 範例 1：自動化功能開發 (PlanA)
**場景**: 您想在目前的專案中新增一個密碼強度檢查工具。
**操作**: 
```text
You ➔ 幫我寫一個密碼強度檢查的 Node.js 工具，包含正則表達式，並將其存為 passwordUtils.js
```
**系統反應**:
1. 啟動 `Standardized Dev Flow`。
2. `Roadmap` 生成步驟：1. 定義規則 2. 寫入檔案 3. 測試執行。
3. `Impact Analysis` 評估風險（低）。
4. `AI Executor` 生成代碼並存入 `./Proj/js/passwordUtils.js`。
5. `Sandbox` 自動運行 `node passwordUtils.js` 確保無誤。
6. 完成後，任務標記為 `done` 並提升專案版本。

### 範例 2：跨檔案分析與重構
**場景**: 您不確定 `lib` 資料夾下的模組是如何互相呼叫的。
**操作**: 
```text
You ➔ /folder "./lib" 總結這些模組的導出介面，並畫出一個簡單的依賴關係圖。
```
**系統反應**:
1. 系統掃描 `./lib` 並讀取所有 `.js` 文件。
2. 大型文件自動摘要。
3. AI 整合所有 Context 並給出模組導出清單與 Mermaid 格式的關係圖。

### 範例 3：啟動專案管理看板
**場景**: 您想在網頁介面查看目前的開發進度。
**操作**: 
1. `You ➔ /project init` (初始化設定)
2. `You ➔ 幫我寫一個 Express 伺服器命名為 p5_web_server.js，用來讀取 p5_kanban.json 並展示成看板`
3. `You ➔ /project open` (啟動服務)
**系統反應**: 系統會開啟 Express 服務，您可以在瀏覽器訪問對應端口查看 Glassmorphism 風格的看板。

### 範例 4：撰寫長篇連載小說
**場景**: 您想創作一部科幻小說。
**操作**: 
1. `You ➔ /novel init "星際遺產"` (系統生成 10 章大綱)
2. `You ➔ /novel next` (系統撰寫第一章)
3. `You ➔ /novel next "在這一章引入一名神秘的賞金獵人"` (撰寫第二章並加入特定要素)
**系統反應**: 系統會維護「前文摘要」，確保故事邏輯連貫，並將每一章存為獨立的 `.txt` 檔案。

---

## 🛠️ 常見問題與排除 (Troubleshooting)

| 現象 | 可能原因 | 解決方法 |
| :--- | :--- | :--- |
| 指令無反應 | Ollama 服務未啟動 | 確保 `ollama serve` 正在執行 |
| 檔案讀取失敗 | 路徑包含空白但未加引號 | 使用 `/file "path with space" 指令` |
| 模型回應過慢 | 硬體資源不足 | 使用 `/model fast` 切換到輕量模型 |
| 沙盒測試失敗 | 代碼語法錯誤或環境缺漏 | 根據 AI 的 Critic 回饋修正需求，再次執行 |

---
*文件更新於: 2026-07-07*
*版本: v5.0.0*
