@echo off
TITLE OrlandoGPT Cognitive OS
echo Checking for Node.js...
node -v >nul 2>&1
if %errorlevel% neq 0 (
    echo Error: Node.js is not installed. Please install Node.js v18 or later.
    pause
    exit /b
)
echo Starting OrlandoGPT...
node teZ.js
pause
