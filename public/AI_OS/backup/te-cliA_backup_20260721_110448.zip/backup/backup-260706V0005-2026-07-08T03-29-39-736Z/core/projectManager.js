const fs = require("fs");
const path = require("path");
const RoadmapEngine = require("./roadmap");
const ArchitectureAnalyzer = require("./analyzer");
const RegressionCenter = require("./regression");

class ProjectManager {
    constructor(config, versionManager) {
        this.config = config;
        this.version = versionManager;
        this.root = config.PROJ_DIR;

        this.ensureFolders();
        this.projectFile = config.PROJECT_JSON;
        this.manifestFile = config.MANIFEST_FILE;
        this.indexFile = config.PROJECT_INDEX;

        this.roadmap = new RoadmapEngine(config);
        this.analyzer = new ArchitectureAnalyzer(config);
        this.regression = new RegressionCenter(config, versionManager);

        this.loadProject();
    }

    ensureFolders() {
        const folders = ["", "html", "css", "js", "json", "txt", "pdf", "image", "other"];
        for (const f of folders) {
            fs.mkdirSync(path.join(this.root, f), { recursive: true });
        }
    }

    loadProject() {
        if (fs.existsSync(this.projectFile)) {
            try {
                this.project = JSON.parse(fs.readFileSync(this.projectFile, "utf8"));
                return;
            } catch (e) {}
        }
        this.project = {
            version: this.version.current(),
            created: new Date().toISOString(),
            files: []
        };
        this.saveProject();
    }

    saveProject() {
        fs.writeFileSync(this.projectFile, JSON.stringify(this.project, null, 2), "utf8");
    }

    async runStandardFlow(input, ai, fsManager, UI, cognitionCallback) {
        console.log(`\n${UI.colors.magenta}${UI.colors.bold}🔄 STARTING STANDARDIZED DEV FLOW${UI.colors.reset}`);

        // 1. Roadmap Engine: Get current context or generate new one
        let currentTask = this.roadmap.getNextTask();
        if (!currentTask || input.toLowerCase().includes("plan") || input.toLowerCase().includes("roadmap")) {
            UI.updateStatus("Generating/Updating Roadmap...", 20);
            await this.roadmap.generatePlan(input, ai);
            currentTask = this.roadmap.getNextTask();
        }

        const roadmapSummary = this.roadmap.getSummary();
        console.log(`${UI.colors.cyan}📍 Roadmap Status:\n${roadmapSummary}${UI.colors.reset}`);

        // 2. Architecture Analyzer: Impact Analysis
        UI.updateStatus("Analyzing Architecture Impact...", 40);
        // Include roadmap in impact analysis
        const analysis = await this.analyzer.analyzeImpact(`${input}\n\n${roadmapSummary}`, ai, fsManager);
        console.log(`${UI.colors.yellow}⚠️ Impact Analysis:\n${analysis}${UI.colors.reset}`);
        
        const risk = await this.analyzer.assessRisk(analysis, ai);
        console.log(`${UI.colors.red}⚖️ Risk Score: ${risk.score}/10. Mitigation: ${risk.mitigation}${UI.colors.reset}`);

        // 3. Implementation (The existing cognition/AI work)
        UI.updateStatus("Implementing Changes...", 60);
        // Pass the roadmap summary to ensure AI follows the plan
        const result = await cognitionCallback(input, analysis, roadmapSummary);

        // 4. Regression Center: Verify & Release
        UI.updateStatus("Verifying & Finalizing...", 80);
        const verification = await this.regression.runVerification(fsManager, UI);
        
        if (verification.success) {
            // 自動推進任務狀態
            if (currentTask) {
                this.roadmap.updateTask(currentTask.id, "done");
                console.log(`${UI.colors.green}🏁 Task "${currentTask.name}" marked as DONE.${UI.colors.reset}`);
            }
            
            await this.regression.backup(UI);
            const newVer = await this.regression.release(UI);
            console.log(`${UI.colors.green}✅ Flow Complete. Project advanced to ${newVer}${UI.colors.reset}`);
        } else {
            console.log(`${UI.colors.red}❌ Verification failed: ${verification.report}${UI.colors.reset}`);
        }

        return result;
    }


    folder(ext) {
        ext = ext.toLowerCase();
        return this.config.OUTPUT_FOLDER[ext] || this.config.DEFAULT_OUTPUT_FOLDER;
    }

    prefix(filename) {
        const name = path.parse(filename).name.replace(/[^a-z0-9]/ig, "");
        return (name || "file").substring(0, this.config.FILE_PREFIX_LENGTH).padEnd(this.config.FILE_PREFIX_LENGTH, "_");
    }

    nextNumber(folder, prefix, ext) {
        const dir = path.join(this.root, folder);
        const files = fs.readdirSync(dir);
        let max = 0;
        for (const f of files) {
            const m = f.match(new RegExp("^" + prefix + "(\\d+)\\." + ext + "$", "i"));
            if (m) {
                max = Math.max(max, parseInt(m[1]));
            }
        }
        return String(max + 1).padStart(this.config.FILE_COUNTER_DIGITS, "0");
    }

    buildPath(originalName) {
        const ext = path.extname(originalName).replace(".", "").toLowerCase();
        const folder = this.folder(ext);
        const prefix = this.prefix(originalName);
        const num = this.nextNumber(folder, prefix, ext);
        const filename = `${prefix}${num}.${ext}`;
        return {
            folder,
            filename,
            fullPath: path.join(this.root, folder, filename)
        };
    }

    write(originalName, content) {
        const file = this.buildPath(originalName);
        fs.writeFileSync(file.fullPath, content, "utf8");
        this.project.files.push({
            original: originalName,
            saved: file.filename,
            folder: file.folder,
            version: this.version.current(),
            created: new Date().toISOString()
        });
        this.saveProject();
        this.saveManifest();
        console.log("✔ FILE CREATED:", file.filename);
        return file.fullPath;
    }

    saveManifest() {
        fs.writeFileSync(this.manifestFile, JSON.stringify(this.project.files, null, 2), "utf8");
    }

    list() {
        return this.project.files;
    }
}

module.exports = ProjectManager;