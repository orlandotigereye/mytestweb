const path = require("path");
const fs = require("fs");

class Orchestrator {
    constructor(context) {
        this.config = context.config;
        this.ai = context.ai;
        this.memory = context.memory;
        this.fsManager = context.fsManager;
        this.projectManager = context.projectManager;
        this.wikiEngine = context.wikiEngine;
        this.ui = context.ui;
        this.runtime = context.runtime;
        this.activeModel = null;
        
        // Suggestion 3: Thinking Log
        this.thinkingLog = [];
    }

    logThinking(step) {
        const entry = `[${new Date().toLocaleTimeString()}] ${step}`;
        this.thinkingLog.push(entry);
        console.log(`${this.ui.colors.gray}${entry}${this.ui.colors.reset}`);
        // Limit log size
        if (this.thinkingLog.length > 20) this.thinkingLog.shift();
    }

    async cognition(input) {
        this.thinkingLog = []; // Clear for new run
        this.logThinking("Initializing cognition pipeline...");

        // Suggestion 1: Active Wiki Retrieval (RAG-lite)
        const relevantFacts = this.wikiEngine.findRelevantFacts(input);
        let contextPrefix = "";
        if (relevantFacts.length > 0) {
            this.logThinking(`Found ${relevantFacts.length} relevant facts in Wiki.`);
            contextPrefix = `[KNOWLEDGE CONTEXT]\n${relevantFacts.join("\n")}\n\n`;
        }

        const enrichedInput = await this.fsManager.detectAndLoadFiles(input, this.ai);
        const isCode = this.ai.isCodeRequest(enrichedInput);

        if (!isCode) {
            this.logThinking("Identified as Chat/Reasoning request.");
            const graph = this.ai.planner(enrichedInput);
            this.logThinking("Plan generated. Executing reasoning graph...");
            
            const finalInput = contextPrefix + enrichedInput;
            const output = await this.ai.executeGraph(finalInput, graph, this.runtime, this.activeModel);
            
            this.logThinking("Reasoning complete. Recording to memory.");
            const score = this.ai.reward(output, this.runtime);
            
            this.runtime.lastInput = input;
            this.runtime.lastOutput = output;
            this.runtime.lastScore = score;

            const a = await this.memory.add("user", input, this.activeModel);
            const b = await this.memory.add("assistant", output, this.activeModel);
            this.memory.link(a, b);
            
            await this.wikiEngine.extractFacts(input, output);
            return output;
        }

        this.logThinking("Identified as Development/PlanA request.");
        return await this.projectManager.runStandardFlow(enrichedInput, this.ai, this.fsManager, this.ui, async (inp, analysis, roadmap) => {
            this.logThinking("Executing Multi-Agent Development Workflow...");
            const model = this.activeModel || (inp.length > 100 ? this.config.MODEL_SMART : this.config.MODEL_FAST);
            const contextualInput = `${contextPrefix}[Roadmap]\n${roadmap}\n\n[Analysis]\n${analysis}\n\n[Request]\n${inp}`;
            
            let code = await this.ai.executeMultiAgentWorkflow(contextualInput, model, this.runtime, this.fsManager);

            this.logThinking("Applying code edits to filesystem...");
            const blocks = this.fsManager.applySearchReplaceBlocks(code);
            if (blocks.length > 0) {
                this.fsManager.applyEdits(blocks);
            } else {
                const blocksRegex = /```[a-zA-Z0-9\s]*\r?\n([\s\S]*?)```/g;
                let m;
                while ((m = blocksRegex.exec(code)) !== null) {
                    this.fsManager.writeSmartFile(m[1]);
                }
            }

            this.logThinking("Updating memory and wiki...");
            const score = this.ai.reward(code, this.runtime);
            this.runtime.lastInput = inp;
            this.runtime.lastOutput = code;
            this.runtime.lastScore = score;
            await this.memory.add("user", inp, this.activeModel);
            await this.memory.add("assistant", code, this.activeModel);
            await this.wikiEngine.extractFacts(inp, code);
            
            return code;
        }, (step) => this.logThinking(step));
    }
}

module.exports = Orchestrator;
