const fs = require("fs");
const path = require("path");

class RoadmapEngine {
    constructor(config) {
        this.config = config;
        this.roadmapFile = path.join(config.PROJ_DIR, "roadmap.json");
        this.load();
    }

    load() {
        if (fs.existsSync(this.roadmapFile)) {
            try {
                this.data = JSON.parse(fs.readFileSync(this.roadmapFile, "utf8"));
            } catch (e) {
                this.data = { project: "Default", tasks: [], dependencies: [] };
            }
        } else {
            this.data = { project: "Default", tasks: [], dependencies: [] };
        }
    }

    save() {
        if (!fs.existsSync(path.dirname(this.roadmapFile))) {
            fs.mkdirSync(path.dirname(this.roadmapFile), { recursive: true });
        }
        fs.writeFileSync(this.roadmapFile, JSON.stringify(this.data, null, 2), "utf8");
    }

    async generatePlan(input, ai) {
        const messages = [
            { role: "system", content: "You are a professional project manager. Generate a development roadmap in JSON format." },
            { role: "user", content: `Based on the following request, generate a development roadmap with tasks and dependencies:
Request: ${input}
Return only JSON: { "tasks": [{ "id": 1, "name": "...", "desc": "...", "status": "todo" }], "dependencies": [] }` }
        ];
        
        try {
            const response = await ai.getAIResponse(this.config.MODEL_FAST, messages, "Generating Roadmap");
            const jsonMatch = response.match(/\{[\s\S]*\}/);

            if (jsonMatch) {
                const plan = JSON.parse(jsonMatch[0]);
                this.data.tasks = plan.tasks || [];
                this.data.dependencies = plan.dependencies || [];
                this.save();
                return this.data;
            }
        } catch (e) {
            console.error("Roadmap Generation Failed:", e.message);
        }
        return this.data;
    }

    getSummary() {
        const done = this.data.tasks.filter(t => t.status === "done").map(t => t.name);
        const todo = this.data.tasks.filter(t => t.status === "todo").map(t => t.name);
        const next = this.getNextTask();

        return `
[ROADMAP STATUS]
- Project: ${this.data.project}
- Completed: ${done.length > 0 ? done.join(", ") : "None"}
- Remaining: ${todo.length > 0 ? todo.join(", ") : "None"}
- Current Focus: ${next ? next.name : "None - All tasks completed"}
- Dependencies: ${JSON.stringify(this.data.dependencies)}
        `.trim();
    }

    getNextTask() {
        return this.data.tasks.find(t => t.status === "todo");
    }


    updateTask(taskId, status) {
        const task = this.data.tasks.find(t => t.id === taskId);
        if (task) {
            task.status = status;
            this.save();
        }
    }
}

module.exports = RoadmapEngine;
