const fs = require("fs");
const path = require("path");
const cp = require("child_process");

class RegressionCenter {
    constructor(config, versionManager) {
        this.config = config;
        this.version = versionManager;
    }

    async runVerification(fsManager, UI) {
        console.log(`${UI.colors.yellow}🔍 Starting Regression Verification...${UI.colors.reset}`);
        
        const projDir = this.config.PROJ_DIR;
        if (!fs.existsSync(projDir)) return { success: true, report: "No project directory to verify." };

        const getJsFiles = (dir) => {
            let results = [];
            const list = fs.readdirSync(dir);
            list.forEach(file => {
                const fullPath = path.join(dir, file);
                const stat = fs.statSync(fullPath);
                if (stat && stat.isDirectory()) results = results.concat(getJsFiles(fullPath));
                else if (file.endsWith(".js")) results.push(fullPath);
            });
            return results;
        };

        const jsFiles = getJsFiles(projDir);
        let errors = [];

        for (const filePath of jsFiles) {
            try {
                cp.execSync(`node -c "${filePath}"`, { stdio: "ignore" });
            } catch (e) {
                errors.push(`${path.basename(filePath)}: Syntax Error`);
            }
        }

        if (errors.length > 0) {
            return { success: false, report: errors.join(", ") };
        }
        
        return { success: true, report: `All ${jsFiles.length} JS syntax checks passed.` };
    }



    async backup(UI) {
        const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
        const backupName = `backup-${this.version.current()}-${timestamp}`;
        const backupPath = path.join(this.config.BACKUP_DIR, backupName);
        
        if (!fs.existsSync(this.config.BACKUP_DIR)) {
            fs.mkdirSync(this.config.BACKUP_DIR, { recursive: true });
        }
        
        console.log(`${UI.colors.blue}📦 Creating physical backup at: ${backupPath}${UI.colors.reset}`);
        
        const ignore = ["node_modules", ".git", ".gemini", "backup", "cache", "temp", "sessions"];
        
        const copyRecursive = (src, dest) => {
            if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
            const entries = fs.readdirSync(src, { withFileTypes: true });
            for (let entry of entries) {
                if (ignore.includes(entry.name)) continue;
                const srcPath = path.join(src, entry.name);
                const destPath = path.join(dest, entry.name);
                if (entry.isDirectory()) copyRecursive(srcPath, destPath);
                else fs.copyFileSync(srcPath, destPath);
            }
        };

        try {
            copyRecursive(this.config.ROOT, backupPath);
            return backupPath;

        } catch (e) {
            console.error("Backup failed:", e.message);
            return null;
        }
    }


    async release(UI) {
        const newVersion = this.version.next();
        console.log(`${UI.colors.green}🚀 Released version: ${newVersion}${UI.colors.reset}`);
        return newVersion;
    }
}

module.exports = RegressionCenter;
