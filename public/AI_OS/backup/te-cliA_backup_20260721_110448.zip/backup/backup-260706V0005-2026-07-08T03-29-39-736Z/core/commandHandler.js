const fs = require("fs");
const path = require("path");

class CommandHandler {
    constructor(context) {
        this.context = context; // Contains ai, memory, fsManager, etc.
        this.commands = new Map();
        this.loadCommands();
    }

    loadCommands() {
        const cmdDir = path.join(__dirname, "..", "commands");
        if (!fs.existsSync(cmdDir)) fs.mkdirSync(cmdDir);

        // Define core commands structure
        const coreCommands = [
            { name: "check", file: "check.js" },
            { name: "runtime", file: "runtime.js" },
            { name: "model", file: "model.js" },
            { name: "file", file: "file.js" },
            { name: "folder", file: "folder.js" },
            { name: "project", file: "project.js" },
            { name: "novel", file: "novel.js" },
            { name: "schedule", file: "schedule.js" },
            { name: "wiki", file: "wiki.js" },
            { name: "export", file: "export.js" },
            { name: "analyze", file: "analyze.js" },
            { name: "portal", file: "portal.js" },
            { name: "help", file: "help.js" },
            { name: "clear", file: "clear.js" }
        ];

        // Register commands (In a real scenario, these would be separate files)
        // For this refactor, I will create the base command files first.
    }

    async execute(input) {
        const parts = input.trim().split(" ");
        const cmdName = parts[0].substring(1).toLowerCase();
        const args = parts.slice(1).join(" ");

        if (this.commands.has(cmdName)) {
            return await this.commands.get(cmdName)(args, this.context);
        }
        return null; // Not a command or not found
    }

    register(name, fn) {
        this.commands.set(name, fn);
    }
}

module.exports = CommandHandler;
