const fs = require("fs");
const path = require("path");

class ArchitectureAnalyzer {
    constructor(config) {
        this.config = config;
    }

    async analyzeImpact(input, ai, fsManager) {
        const files = fsManager.listAllFiles().map(f => f.relPath);
        const messages = [
            { role: "system", content: "You are an expert software architect performing impact analysis." },
            { role: "user", content: `Perform an architecture impact analysis for the following request:
Request: ${input}
Available Files: ${files.join(", ")}
Identify:
1. Which files will likely be modified?
2. Potential risks or breaking changes.
3. Suggestions for implementation.
4. GENERATE A MERMAID DIAGRAM showing the relationship between affected files (using graph TD).

Format as a technical report with the Mermaid diagram inside a \`\`\`mermaid code block.` }
        ];

        try {
            const report = await ai.getAIResponse(this.config.MODEL_SMART, messages, "Impact Analysis");
            return report;
        } catch (e) {
            return "Impact analysis failed: " + e.message;
        }
    }

    async assessRisk(analysisReport, ai) {
        const messages = [
            { role: "system", content: "You are a risk assessment specialist." },
            { role: "user", content: `Based on this impact analysis, provide a risk score (1-10) and a brief mitigation plan:
${analysisReport}
Return only JSON: { "score": 5, "mitigation": "..." }` }
        ];

        try {
            const response = await ai.getAIResponse(this.config.MODEL_FAST, messages, "Risk Assessment");
            const jsonMatch = response.match(/\{[\s\S]*\}/);

            if (jsonMatch) {
                return JSON.parse(jsonMatch[0]);
            }
        } catch (e) {
            return { score: 0, mitigation: "Unknown" };
        }
        return { score: 0, mitigation: "Unknown" };
    }
}

module.exports = ArchitectureAnalyzer;
