const fs = require("fs");

class VersionManager {

    constructor(config) {

        this.config = config;

        this.versionFile = config.VERSION_FILE;

        this.versionData = this.load();

    }

    // ===========================
    // 今日日期
    // ===========================
    getToday() {

        const d = new Date();

        const y = String(d.getFullYear()).slice(2);

        const m = String(d.getMonth() + 1).padStart(2, "0");

        const day = String(d.getDate()).padStart(2, "0");

        return `${y}${m}${day}`;

    }

    // ===========================
    // 讀取 Version
    // ===========================
    load() {

        if (fs.existsSync(this.versionFile)) {

            try {

                return JSON.parse(

                    fs.readFileSync(this.versionFile, "utf8")

                );

            }

            catch {

                return {

                    version:
                        `${this.getToday()}${this.config.VERSION_PREFIX}0001`

                };

            }

        }

        return {

            version:
                `${this.getToday()}${this.config.VERSION_PREFIX}0001`

        };

    }

    // ===========================
    // Save
    // ===========================
    save() {

        fs.writeFileSync(

            this.versionFile,

            JSON.stringify(this.versionData, null, 2),

            "utf8"

        );

    }

    // ===========================
    // Current
    // ===========================
    current() {

        return this.versionData.version;

    }

    // ===========================
    // Next Version
    // ===========================
    next() {

        const match = this.versionData.version.match(/V(\d+)/);

        let number = 1;

        if (match) {

            number = parseInt(match[1]) + 1;

        }

        this.versionData.version =

            `${this.getToday()}${this.config.VERSION_PREFIX}${String(number).padStart(this.config.VERSION_DIGITS, "0")}`;

        this.save();

        return this.versionData.version;

    }

}

module.exports = VersionManager;