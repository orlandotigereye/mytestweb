const readline = require("readline");
const fs = require("fs");
const path = require("path");
const cp = require("child_process");

// 匯入配置與核心管理類別
const config = require("./config/config");
const VersionManager = require("./core/version");

// 匯入拆分後的模組
const UI = require("./lib/ui_renderer");
const MemorySystem = require("./lib/memory");
const FileSystemManager = require("./lib/file_system");
const AIEngine = require("./lib/ai_engine");
const ProjectManager = require("./core/projectManager");
const NovelEngine = require("./lib/novel_engine");
const WikiEngine = require("./lib/wiki_engine");
const Scheduler = require("./lib/scheduler");
const ExportEngine = require("./lib/export_engine");
const WebPortal = require("./lib/web_portal");
const Orchestrator = require("./core/orchestrator");
const CommandHandler = require("./core/commandHandler");
const DBEngine = require("./lib/db_engine");


// ======================================================
// 🚀 初始化系統元件
// ======================================================
let ACTIVE_MODEL = null;
const runtime = {
    start: Date.now(),
    requests: 0,
    rewardTotal: 0,
    rewardHistory: [],
    streamChunks: 0,
    cliQueue: 0,
    lastScore: 0,
    lastInput: "",
    lastOutput: ""
};

const version = new VersionManager(config);
const memory = new MemorySystem(config);
memory.load();

const fsManager = new FileSystemManager(config, version, UI.colors, UI);
const ai = new AIEngine(config, memory, UI, version);
const projectManager = new ProjectManager(config, version);
const novelEngine = new NovelEngine(config, ai, fsManager, UI);
const wikiEngine = new WikiEngine(config, ai, UI);
const exportEngine = new ExportEngine(config, UI);
const dbEngine = new DBEngine(config, ai, UI);
const scheduler = new Scheduler(config, UI, async (cmd) => {
    // Background execution wrapper
    const output = await orchestrator.cognition(cmd);
    console.log(`\n${UI.colors.gray}[Scheduled Task Complete] Result summarized in memory.${UI.colors.reset}`);
});

const orchestrator = new Orchestrator({ config, ai, memory, fsManager, projectManager, wikiEngine, ui: UI, runtime });
const commandHandler = new CommandHandler({ config, ai, memory, fsManager, projectManager, wikiEngine, ui: UI, runtime, orchestrator, novelEngine, scheduler, version });

UI.setTerminalTitle("Idle", version.current(), ACTIVE_MODEL, config);
console.log(`${UI.colors.cyan}${UI.colors.bold}🧠 AI COGNITIVE OS v5 STARTED (Version: ${version.current()})${UI.colors.reset}`);

// ======================================================
// 🛠️ 輔助工具函數 (留在主程式以利調度)
// ======================================================
function parseQuotedArgs(str) {
    str = (str || "").trim();
    if (!str) return { path: "", rest: "" };
    let p = "", r = "";
    if (str.startsWith('"') || str.startsWith("'")) {
        const q = str[0];
        const next = str.indexOf(q, 1);
        if (next !== -1) { p = str.substring(1, next); r = str.substring(next + 1).trim(); }
        else p = str.substring(1);
    } else {
        const space = str.indexOf(" ");
        if (space !== -1) { p = str.substring(0, space); r = str.substring(space + 1).trim(); }
        else p = str;
    }
    return { path: p, rest: r };
}

function runSandbox(filePath) {
    return new Promise((resolve) => {
        if (!fsManager.isPathSafe(filePath)) {
            console.log(`${UI.colors.red}Failed: Sandbox path traversal blocked.${UI.colors.reset}`);
            return resolve({ success: false, error: "Security Exception: Sandbox traversal blocked." });
        }
        if (path.extname(filePath) !== ".js") return resolve({ success: true, stdout: "Not a JS file." });
        process.stdout.write(`${UI.colors.yellow}⏳ [planA] Running execution test... ${UI.colors.reset}`);
        cp.exec(`node "${filePath}"`, { timeout: 4000 }, (error, stdout, stderr) => {
            if (error) {
                console.log(`${UI.colors.red}Failed!${UI.colors.reset}`);
                resolve({ success: false, error: error.message, stderr, stdout });
            } else {
                console.log(`${UI.colors.green}Success!${UI.colors.reset}`);
                resolve({ success: true, stdout });
            }
        });
    });
}

// ======================================================
// 🧠 主認知流程已移至 core/orchestrator.js
// ======================================================


// ======================================================
// ⌨️ CLI 指令處理
// ======================================================
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    completer: (line) => {
        const com = ["/check", "/runtime", "/test", "/model", "/file", "/folder", "/project", "/novel", "/schedule", "/wiki", "/export", "/analyze", "/db", "/portal", "/config", "/clear", "/help", "exit"];
        const hits = com.filter(c => c.startsWith(line.trim()));
        return [hits.length ? hits : com, line];
    }

});

const promptUser = () => {
    UI.setTerminalTitle("Idle", version.current(), ACTIVE_MODEL, config);
    rl.setPrompt(`\n${UI.colors.cyan}${UI.colors.bold}You ➔ ${UI.colors.reset}`);
    rl.prompt();
};

rl.on("line", async (line) => {
    const input = line.trim();
    if (!input) return;
    runtime.cliQueue++;

    try {
        if (input === "/check") {
            console.log("📋 System Modules: Memory, UI, FS, AI Engine Loaded.");
        } else if (input === "/runtime") {
            console.log("\n🧠 RUNTIME:", { ...runtime, activeModel: ACTIVE_MODEL || "Dynamic" });
        } else if (input.startsWith("/file ")) {
            const { path: f, rest: p } = parseQuotedArgs(input.substring(6));
            const content = fsManager.read_file(f);
            await orchestrator.cognition(`[File: ${f}]\n${content}\n\n${p}`);
            await UI.streamFormattedOutput(runtime.lastOutput, runtime.lastScore);
        } else if (input.startsWith("/folder ")) {
            const { path: dir, rest: p } = parseQuotedArgs(input.substring(8));
            const files = fsManager.readFolderRecursive(dir);
            if (files.length === 0) {
                console.log(`${UI.colors.yellow}⚠️ No match files found in directory: ${dir}${UI.colors.reset}`);
            } else {
                UI.startSpinner(version.current(), ACTIVE_MODEL, config, "Processing folder files...", 10);
                
                // Concurrent summarization using Promise.all
                const processedFiles = await Promise.all(files.map(async (file) => {
                    let fileContent = file.content;
                    if (fileContent.length > 10000 && ai) {
                        console.log(`\n${UI.colors.yellow}⚠️ File ${file.relPath} is large (${fileContent.length} chars). Summarizing concurrently...${UI.colors.reset}`);
                        try {
                            const summary = await ai.summarizeContent(fileContent.substring(0, 15000), config.MODEL_FAST);
                            fileContent = `[SUMMARY: ${summary}]`;
                        } catch (e) {
                            fileContent = fileContent.substring(0, 5000) + "\n... (Truncated due to summary failure) ...";
                        }
                    }
                    return { relPath: file.relPath, content: fileContent };
                }));

                UI.stopSpinner();

                let folderContext = `[Loaded Directory: ${dir}]\n`;
                for (const file of processedFiles) {
                    folderContext += `\n--- File: ${file.relPath} ---\n${file.content}\n`;
                }

                console.log(`${UI.colors.green}ℹ️ Loaded ${files.length} files from directory: ${dir}${UI.colors.reset}`);
                await orchestrator.cognition(`${folderContext}\n\nUser Request: ${p}`);
                await UI.streamFormattedOutput(runtime.lastOutput, runtime.lastScore);
            }
        } else if (input.startsWith("/project ")) {
            const cmd = input.substring(9).trim();
            if (cmd.startsWith("init")) {
                const targetDir = cmd.substring(4).trim() || "./phase5-manager";
                const absTarget = path.resolve(config.ROOT, targetDir);

                if (!fsManager.isPathSafe(absTarget)) {
                    throw new Error("Cannot initialize project outside workspace sandbox.");
                }
                console.log(`\n${UI.colors.cyan}${UI.colors.bold}🚀 Initializing Phase5 Project Manager in: ${absTarget}...${UI.colors.reset}`);
                if (!fs.existsSync(absTarget)) fs.mkdirSync(absTarget, { recursive: true });
                
                // Write baseline files
                const pkg = {
                    name: "phase5-project-manager",
                    version: "1.0.0",
                    description: "Advanced Glassmorphism Web Kanban & Weekly Report Analyzer",
                    main: "p5_web_server.js",
                    dependencies: { express: "^4.18.2" }
                };
                fs.writeFileSync(path.join(absTarget, "package.json"), JSON.stringify(pkg, null, 2), "utf8");
                
                // Create skeleton files
                fs.writeFileSync(path.join(absTarget, "p5_kanban.json"), JSON.stringify({
                    projectName: "Phase5 Project Workspace",
                    tasks: [
                        { id: "task-1", title: "Setup Glassmorphism Board", status: "Todo", desc: "Build standard web dashboard" },
                        { id: "task-2", title: "Link AI Orchestrator", status: "In Progress", desc: "Bind with OrlandoGPT QA Critic" }
                    ]
                }, null, 2), "utf8");

                console.log(`${UI.colors.green}✅ Created package.json & p5_kanban.json databases!${UI.colors.reset}`);
                console.log(`${UI.colors.cyan}👉 Run 'npm install' in ${targetDir} to pull express dashboard server dependencies.${UI.colors.reset}`);
            } else if (cmd.startsWith("open")) {
                const targetDir = cmd.substring(4).trim() || "./phase5-manager";
                const absTarget = path.resolve(config.ROOT, targetDir);

                const serverFile = path.join(absTarget, "p5_web_server.js");
                if (fs.existsSync(serverFile)) {
                    console.log(`\n${UI.colors.green}🌐 Starting Phase5 Express Dashboard Server...${UI.colors.reset}`);
                    const proc = cp.exec(`node "${serverFile}"`, { cwd: absTarget });
                    proc.stdout.on("data", data => console.log(`${UI.colors.gray}[Web Dashboard] ${data.trim()}${UI.colors.reset}`));
                    proc.stderr.on("data", data => console.log(`${UI.colors.red}[Web Error] ${data.trim()}${UI.colors.reset}`));
                } else {
                    console.log(`${UI.colors.yellow}⚠️ p5_web_server.js not found in ${targetDir}. Please generate/init first.${UI.colors.reset}`);
                }
            } else if (cmd.startsWith("analyze")) {
                const targetDir = cmd.substring(7).trim() || "./phase5-manager";
                const files = fsManager.readFolderRecursive(path.resolve(config.ROOT, targetDir));

                if (files.length === 0) {
                    console.log(`${UI.colors.yellow}⚠️ No code files found to analyze in ${targetDir}.${UI.colors.reset}`);
                } else {
                    console.log(`\n${UI.colors.cyan}🕵️‍♂️ Scanning and analyzing project files in ${targetDir}...${UI.colors.reset}`);
                    await orchestrator.cognition(`Please analyze this directory's overall structure and code quality. Summarize files dynamically:\n\n` + 
                        files.map(f => `File [${f.relPath}]:\n${f.content.substring(0, 1000)}`).join("\n---\n"));
                    await UI.streamFormattedOutput(runtime.lastOutput, runtime.lastScore);
                }
            } else if (cmd.startsWith("roadmap")) {
                console.log(`\n${UI.colors.cyan}📍 CURRENT ROADMAP:${UI.colors.reset}`);
                console.table(projectManager.roadmap.data.tasks);
            } else if (cmd.startsWith("risk")) {
                console.log(`\n${UI.colors.red}⚖️ LAST RISK ASSESSMENT:${UI.colors.reset}`);
                // Since risk isn't persisted yet, we just show a placeholder or the last known value
                console.log("Risk analysis is performed per-request during the Standard Flow.");
            } else {
                console.log(`${UI.colors.yellow}Unknown project command. Try: /project init, /project roadmap, /project analyze, /project open${UI.colors.reset}`);
            }

        } else if (input.startsWith("/novel ")) {
            const cmd = input.substring(7).trim();
            if (cmd.startsWith("init ")) {
                const title = cmd.substring(5).trim();
                const novel = await novelEngine.init(title);
                console.log(`\n${UI.colors.green}📖 Novel "${title}" Initialized!${UI.colors.reset}`);
                console.log(novelEngine.getStatus());
            } else if (cmd.startsWith("load ")) {
                const title = cmd.substring(5).trim();
                const novel = await novelEngine.load(title);
                if (novel) {
                    console.log(`\n${UI.colors.green}📖 Novel "${title}" Loaded!${UI.colors.reset}`);
                    console.log(novelEngine.getStatus());
                } else {
                    console.log(`${UI.colors.red}Novel "${title}" not found.${UI.colors.reset}`);
                }
            } else if (cmd.startsWith("next")) {
                const prompt = cmd.substring(4).trim();
                const result = await novelEngine.writeNextChapter(prompt);
                console.log(`\n${UI.colors.green}✅ Chapter ${result.chapterNum} written to ${result.path}${UI.colors.reset}`);
                await UI.streamFormattedOutput(result.content, 5);
            } else if (cmd === "status") {
                console.log(novelEngine.getStatus());
            } else if (cmd === "list") {
                const novels = novelEngine.listNovels();
                console.log(`\n${UI.colors.cyan}📚 Available Novels:${UI.colors.reset}`);
                novels.forEach(n => console.log(` - ${n}`));
            } else {
                console.log(`${UI.colors.yellow}Unknown novel command. Try: /novel init <title>, /novel load <title>, /novel next [prompt], /novel status, /novel list${UI.colors.reset}`);
            }

        } else if (input.startsWith("/schedule ")) {
            const cmd = input.substring(10).trim();
            const space = cmd.indexOf(" ");
            if (space !== -1) {
                const time = cmd.substring(0, space);
                const taskCmd = cmd.substring(space + 1);
                scheduler.add(time, taskCmd);
                console.log(`${UI.colors.green}⏰ Task scheduled for ${time}: ${taskCmd}${UI.colors.reset}`);
            } else {
                console.log(`${UI.colors.yellow}Usage: /schedule <HH:mm | in Xm> <command>${UI.colors.reset}`);
            }
        } else if (input === "/wiki") {
            console.log(wikiEngine.getWikiSummary());
        } else if (input.startsWith("/analyze ")) {
            const file = input.substring(9).trim();
            const content = await fsManager.analyzeDocument(file, ai);
            await orchestrator.cognition(`[Document Context: ${file}]\n${content}\n\nPlease analyze this document.`);
            await UI.streamFormattedOutput(runtime.lastOutput, 5);
        } else if (input.startsWith("/export ")) {
            const cmd = input.substring(8).trim();
            if (cmd === "novel") {
                if (novelEngine.activeNovel) {
                    const path = await exportEngine.exportNovel(novelEngine.activeNovel);
                    console.log(`${UI.colors.green}📄 Novel exported to HTML: ${path}${UI.colors.reset}`);
                } else console.log(`${UI.colors.red}No active novel to export.${UI.colors.reset}`);
            } else {
                const path = await exportEngine.exportReport("System Report", runtime.lastOutput);
                console.log(`${UI.colors.green}📄 Report exported to HTML: ${path}${UI.colors.reset}`);
            }

        } else if (input.startsWith("/config ")) {
            const parts = input.substring(8).trim().split(" ");
            if (parts.length === 2) {
                config[parts[0]] = parts[1];
                console.log(`${UI.colors.green}⚙️ Config updated: ${parts[0]} = ${parts[1]}${UI.colors.reset}`);
            } else {
                console.log(`${UI.colors.yellow}Usage: /config <KEY> <VALUE>${UI.colors.reset}`);
            }

        } else if (input.startsWith("/db ")) {
            const question = input.substring(4).trim();
            const result = await dbEngine.ask(question);
            if (result.error) {
                console.log(`${UI.colors.red}❌ DB Error: ${result.error}${UI.colors.reset}`);
            } else {
                console.table(result.slice(0, 20)); // Show top 20 rows
                console.log(`${UI.colors.green}✅ Found ${result.length} rows.${UI.colors.reset}`);
                runtime.lastOutput = JSON.stringify(result); // Pass to portal
            }

        } else if (input === "/portal") {
            WebPortal.startPortal(config, orchestrator, UI);

        } else if (input.startsWith("/model ")) {
            const m = input.substring(7).trim().toLowerCase();
            ACTIVE_MODEL = m === "smart" ? config.MODEL_SMART : (m === "fast" ? config.MODEL_FAST : null);
            orchestrator.activeModel = ACTIVE_MODEL;
            console.log(`🤖 Model set to: ${ACTIVE_MODEL || "Dynamic"}`);
        } else if (input === "/help") {
            const c = UI.colors;
            console.log(`\n${c.cyan}${c.bold}🧠 AI COGNITIVE OS v5 - FULL COMMAND GUIDE${c.reset}`);
            
            console.log(`\n${c.magenta}${c.bold}[ 🛠️ SYSTEM & STATUS ]${c.reset}`);
            console.log(`  ${c.yellow}/check${c.reset}              - 檢查系統模組加載狀態`);
            console.log(`  ${c.yellow}/runtime${c.reset}            - 顯示運行指標、請求次數與獎勵積分`);
            console.log(`  ${c.yellow}/model <type>${c.reset}       - 切換模型 (${c.gray}fast | smart | dynamic${c.reset})`);
            console.log(`  ${c.yellow}/config <key> <val>${c.reset} - 動態調整系統參數`);
            console.log(`  ${c.yellow}/clear${c.reset}              - 清除當前對話記憶`);
            console.log(`  ${c.yellow}exit${c.reset}                - 安全退出系統`);

            console.log(`\n${c.magenta}${c.bold}[ 📂 FILE & DATA ]${c.reset}`);
            console.log(`  ${c.yellow}/file <path> <cmd>${c.reset}  - 讀取特定檔案並執行 AI 指令`);
            console.log(`  ${c.yellow}/folder <dir> <cmd>${c.reset} - 遞迴讀取資料夾內容 (支援大型檔案摘要)`);
            console.log(`  ${c.yellow}/analyze <file>${c.reset}     - 針對 PDF/Excel 等非文字檔進行深度分析`);

            console.log(`\n${c.magenta}${c.bold}[ 🚀 DEVELOPMENT & PROJECT ]${c.reset}`);
            console.log(`  ${c.yellow}/project init${c.reset}       - 初始化專案管理環境與看板`);
            console.log(`  ${c.yellow}/project roadmap${c.reset}    - 顯示當前開發任務進度表`);
            console.log(`  ${c.yellow}/project analyze${c.reset}    - 掃描專案結構與代碼品質`);
            console.log(`  ${c.yellow}/project open${c.reset}       - 啟動 Express Web 任務看板`);
            console.log(`  ${c.yellow}/project risk${c.reset}       - 查看最近一次改動的風險評估`);

            console.log(`\n${c.magenta}${c.bold}[ 🖋️ NOVEL CREATION ]${c.reset}`);
            console.log(`  ${c.yellow}/novel init <title>${c.reset} - 開始一部新小說，生成大綱與設定`);
            console.log(`  ${c.yellow}/novel next [prompt]${c.reset}- 撰寫下一章節 (自動參考前文背景)`);
            console.log(`  ${c.yellow}/novel status${c.reset}       - 查看寫作進度與章節清單`);
            console.log(`  ${c.yellow}/novel list${c.reset}         - 列出本地所有小說作品`);

            console.log(`\n${c.magenta}${c.bold}[ 💼 BUSINESS & AUTOMATION ]${c.reset}`);
            console.log(`  ${c.yellow}/schedule <time> <cmd>${c.reset}- 設定定時任務 (${c.gray}HH:mm${c.reset}) 或計時器 (${c.gray}in Xm${c.reset})`);
            console.log(`  ${c.yellow}/wiki${c.reset}                - 檢視自動提取的企業知識百科 (Facts)`);
            console.log(`  ${c.yellow}/export <type>${c.reset}        - 匯出排版精美的 HTML (${c.gray}novel | report${c.reset})`);
            console.log(`  ${c.yellow}/portal${c.reset}              - 啟動瀏覽器全功能互動門戶 (Port 3005)`);

            console.log(`\n${c.cyan}💡 提示: 直接輸入問題即可進行 AI 對話或啟動自動化編碼工作流 (PlanA)。${c.reset}\n`);

        } else if (input === "exit") {
            process.exit(0);
        } else {
            await orchestrator.cognition(input);
            await UI.streamFormattedOutput(runtime.lastOutput, runtime.lastScore);
        }
    } catch (e) {
        console.error(`${UI.colors.red}Error: ${e.message}${UI.colors.reset}`);
    }
    promptUser();
});

promptUser();