const fs = require("fs");
const path = require("path");
const assert = require("assert");

// 匯入我們的模組與主配接
const config = require("../config/config");
const VersionManager = require("../core/version");
const UI = require("../lib/ui_renderer");
const MemorySystem = require("../lib/memory");
const FileSystemManager = require("../lib/file_system");
const AIEngine = require("../lib/ai_engine");

async function runSelfTest() {
    console.log("🕵️‍♂️ STARTING SYSTEM INTEGRATION SELF-TEST...");
    
    const version = new VersionManager(config);
    const memory = new MemorySystem(config);
    memory.load();
    const fsManager = new FileSystemManager(config, version, UI.colors, UI);
    const ai = new AIEngine(config, memory, UI, version);

    // 1. 測試安全防護機制 (Safety Verification)
    console.log("\n🔒 1. Verifying Path Safety Guard...");
    const safePath = path.join(process.cwd(), "Proj", "test.js");
    const unsafePath = path.resolve(process.cwd(), "../../unauthorized.txt");
    
    assert.strictEqual(fsManager.isPathSafe(safePath), true, "Proj directory should be safe.");
    assert.strictEqual(fsManager.isPathSafe(unsafePath), false, "Outside paths must be blocked.");
    console.log("✅ Safety verification passed!");

    // 2. 測試遞迴資料夾讀取 (Folder Scan Verification)
    console.log("\n📁 2. Verifying Recursive Folder Scan...");
    const testDir = path.join(process.cwd(), "AI", "te-cliA", "lib");
    const files = fsManager.readFolderRecursive(testDir);
    assert.ok(files.length > 0, "Should find files in lib folder.");
    console.log(`✅ Folder scan passed! Successfully scanned ${files.length} modules from lib.`);

    // 3. 測試並發摘要邏輯 (Concurrent Summary Verification)
    console.log("\n⚡ 3. Verifying Concurrent Summarization Logic...");
    const mockFiles = [
        { relPath: "large1.js", content: "const a = 1; ".repeat(1500) }, // ~15000 chars (Large)
        { relPath: "large2.js", content: "const b = 2; ".repeat(1200) }  // ~12000 chars (Large)
    ];

    console.log("⏳ Running concurrent mock summarizations...");
    const startTime = Date.now();
    const processed = await Promise.all(mockFiles.map(async (file) => {
        let fileContent = file.content;
        if (fileContent.length > 10000) {
            // 利用 AIEngine 的快速摘要模型
            const summary = await ai.summarizeContent(fileContent.substring(0, 15000), config.MODEL_FAST);
            fileContent = `[SUMMARY: ${summary}]`;
        }
        return { relPath: file.relPath, content: fileContent };
    }));
    const duration = Date.now() - startTime;

    assert.strictEqual(processed.length, 2, "Both files should be processed.");
    assert.ok(processed[0].content.includes("[SUMMARY:"), "First file should be summarized.");
    assert.ok(processed[1].content.includes("[SUMMARY:"), "Second file should be summarized.");
    console.log(`✅ Concurrent summarization passed! (Processed in ${duration}ms)`);

    // 4. 測試 API 的錯誤重試機制 (Exponential Backoff Retry Verification)
    console.log("\n🔄 4. Verifying Exponential Backoff Retry logic...");
    let attemptCount = 0;
    const mockFetchWithFailure = async (url, options) => {
        attemptCount++;
        if (attemptCount < 3) {
            throw new Error("Temporary Network Timeout Simulation");
        }
        return {
            ok: true,
            status: 200,
            json: async () => ({ message: { content: "Refined output from resilient endpoint" } })
        };
    };

    // 暫時替換全域 fetch 進行注入測試
    const originalFetch = global.fetch;
    global.fetch = mockFetchWithFailure;

    try {
        console.log("⏳ Triggering resilient request...");
        const res = await ai.getAIResponse(config.MODEL_FAST, [{ role: "user", content: "Hello" }], "Resiliency Test", 3, 100);
        assert.strictEqual(res, "Refined output from resilient endpoint", "Should succeed on 3rd attempt.");
        assert.strictEqual(attemptCount, 3, "Should have retried exactly 3 times.");
        console.log("✅ API retry logic with exponential backoff verified successfully!");
    } finally {
        global.fetch = originalFetch; // 還原
    }

    // 5. 測試多代理人協調流程 (Multi-Agent Team Orchestration Verification)
    console.log("\n👥 5. Verifying Multi-Agent Team Orchestration...");
    let agentCallCount = 0;
    const mockMultiAgentFetch = async (url, options) => {
        agentCallCount++;
        let content = "Default Agent response";
        if (agentCallCount === 1) {
            content = "File Scout Report: modified file.js to support new logic.";
        } else if (agentCallCount === 2) {
            content = "Chief Coder roadmap design complete.";
        } else if (agentCallCount === 3) {
            content = "const test = 'Chief Coder perfect code output'; // TODO: placeholder"; // QA should reject this
        } else if (agentCallCount === 4) {
            content = "Feedback: remove the placeholder";
        } else if (agentCallCount === 5) {
            content = "const test = 'Chief Coder perfect code output without placeholders';"; // QA should approve
        }
        
        return {
            ok: true,
            status: 200,
            json: async () => ({ message: { content } })
        };
    };

    const originalFetchAgain = global.fetch;
    global.fetch = mockMultiAgentFetch;

    try {
        console.log("⏳ Running Multi-Agent Collaboration Test...");
        const codeResult = await ai.executeMultiAgentWorkflow("Please write standard logic.", config.MODEL_FAST, { requests: 0 }, fsManager);
        assert.ok(codeResult.includes("without placeholders"), "Should refine code to pass QA Critic.");
        assert.strictEqual(agentCallCount, 5, "Multi-Agent loop should fetch precisely 5 steps (Scout -> Roadmap -> Code -> Critic -> Revision).");
        console.log("✅ Multi-Agent collaborative pipeline verified successfully!");
    } finally {
        global.fetch = originalFetchAgain;
    }

    console.log("\n🎉 ALL INTEGRATION SELF-TESTS COMPLETED SUCCESSFULLY!");
}

runSelfTest().catch(err => {
    console.error("❌ Test Failed:", err);
    process.exit(1);
});
