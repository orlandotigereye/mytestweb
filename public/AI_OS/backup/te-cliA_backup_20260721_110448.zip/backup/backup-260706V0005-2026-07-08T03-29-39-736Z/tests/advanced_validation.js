const path = require("path");
const fs = require("fs");

const config = require("../config/config");
const WikiEngine = require("../lib/wiki_engine");
const Scheduler = require("../lib/scheduler");
const ExportEngine = require("../lib/export_engine");
const FileSystemManager = require("../lib/file_system");

async function runValidation() {
    console.log("🚀 Starting Advanced Feature Self-Validation...");

    const uiMock = {
        updateStatus: (s) => console.log(`[Status] ${s}`),
        colors: { green: "", red: "", cyan: "", yellow: "", magenta: "", reset: "" }
    };

    const aiMock = {
        getAIResponse: async (m, p) => {
            if (p[0].content.includes("Fact Extractor")) {
                return JSON.stringify({ "TestCategory": { "TestFact": "Verified" } });
            }
            return "Mock AI Response";
        },
        MODEL_FAST: "fast",
        MODEL_SMART: "smart"
    };

    // 1. Wiki Validation
    console.log("\n1️⃣ Testing Wiki Engine...");
    const wiki = new WikiEngine(config, aiMock, uiMock);
    await wiki.extractFacts("這是一個重要的測試事實，折扣是 50%。", "收到，已經記錄折扣為 50%。");
    if (wiki.facts.categories.TestCategory && wiki.facts.categories.TestCategory.TestFact === "Verified") {
        console.log("✅ Wiki Extraction Passed.");
    } else {
        console.error("❌ Wiki Extraction Failed.");
    }

    // 2. Scheduler Validation
    console.log("\n2️⃣ Testing Scheduler...");
    let taskExecuted = false;
    const scheduler = new Scheduler(config, uiMock, async (cmd) => {
        if (cmd === "test_cmd") taskExecuted = true;
    });
    scheduler.add("in 0.001m", "test_cmd"); // Execute almost immediately
    console.log("Wait for 15s to check scheduler loop...");
    await new Promise(r => setTimeout(r, 15000));
    if (taskExecuted) console.log("✅ Scheduler Task Execution Passed.");
    else console.error("❌ Scheduler Task Execution Failed or Timed Out.");

    // 3. Export Validation
    console.log("\n3️⃣ Testing Export Engine...");
    const exporter = new ExportEngine(config, uiMock);
    const reportPath = await exporter.exportReport("Validation Report", "Content verified.");
    if (fs.existsSync(reportPath)) {
        console.log(`✅ Export Passed: ${reportPath}`);
    } else {
        console.error("❌ Export Failed.");
    }

    // 4. FileSystem Document Support Validation
    console.log("\n4️⃣ Testing Document Support...");
    const fsm = new FileSystemManager(config, null, uiMock.colors, uiMock);
    const docResult = fsm.readDocument("test.pdf");
    if (docResult.includes("Binary format detected")) {
        console.log("✅ Document Detection Passed.");
    } else {
        console.error("❌ Document Detection Failed.");
    }

    console.log("\n🏁 Validation Finished.");
    process.exit(0);
}

runValidation().catch(e => {
    console.error(e);
    process.exit(1);
});
