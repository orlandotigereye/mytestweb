const path = require("path");
const fs = require("fs");

const config = require("../config/config");
const ArchitectureAnalyzer = require("../core/analyzer");
const ExportEngine = require("../lib/export_engine");

async function runValidation() {
    console.log("\x1b[36m%s\x1b[0m", "🚀 Starting Premium Feature Validation (UI, Analyzer, Export)...");

    const uiMock = {
        updateStatus: (s) => console.log(`[Status] ${s}`),
        colors: { green: "\x1b[32m", red: "\x1b[31m", cyan: "\x1b[36m", yellow: "\x1b[33m", magenta: "\x1b[35m", bold: "\x1b[1m", reset: "\x1b[0m" }
    };

    const aiMock = {
        getAIResponse: async (model, messages, type) => {
            if (type === "Impact Analysis") {
                return "### Impact Analysis Report\n1. Modify: test.js\n\n```mermaid\ngraph TD\nA[User Request] --> B[test.js]\n```";
            }
            return "Mock Response";
        },
        MODEL_SMART: "smart",
        MODEL_FAST: "fast"
    };

    const fsManagerMock = {
        listAllFiles: () => [{ relPath: "test.js" }]
    };

    // 1. Visual Impact Analysis Validation
    console.log("\n1️⃣ Testing Visual Impact Analysis (Mermaid Generation)...");
    const analyzer = new ArchitectureAnalyzer(config);
    const report = await analyzer.analyzeImpact("Change login logic", aiMock, fsManagerMock);
    
    if (report.includes("```mermaid") && report.includes("graph TD")) {
        console.log("\x1b[32m%s\x1b[0m", "✅ Mermaid Diagram Generation Verified.");
    } else {
        console.error("\x1b[31m%s\x1b[0m", "❌ Mermaid Diagram Generation Failed.");
    }

    // 2. Premium Export Validation
    console.log("\n2️⃣ Testing Premium HTML Export (Glassmorphism & Style)...");
    const exporter = new ExportEngine(config, uiMock);
    
    // Test Novel Export
    const novelConfig = {
        title: "Validation_Novel",
        genre: "Sci-Fi",
        tone: "Dark",
        outline: "A test story.",
        chapters: []
    };
    const novelPath = await exporter.exportNovel(novelConfig);
    const novelHtml = fs.readFileSync(novelPath, "utf8");
    
    if (novelHtml.includes("backdrop-filter: blur(10px)") && novelHtml.includes("linear-gradient")) {
        console.log("\x1b[32m%s\x1b[0m", "✅ Premium Novel Export Style Verified (Glassmorphism found).");
    } else {
        console.error("\x1b[31m%s\x1b[0m", "❌ Premium Novel Export Style Missing.");
    }

    // 3. Web Portal Loadability Validation
    console.log("\n3️⃣ Testing Web Portal Module Integrity...");
    try {
        const WebPortal = require("../lib/web_portal");
        if (typeof WebPortal.startPortal === "function") {
            console.log("\x1b[32m%s\x1b[0m", "✅ Web Portal Module Integrity Verified.");
        }
    } catch (e) {
        console.error("\x1b[31m%s\x1b[0m", "❌ Web Portal Module Loading Failed: " + e.message);
    }

    console.log("\n\x1b[36m%s\x1b[0m", "🏁 Premium Features Validation Finished.");
    process.exit(0);
}

runValidation().catch(e => {
    console.error(e);
    process.exit(1);
});
