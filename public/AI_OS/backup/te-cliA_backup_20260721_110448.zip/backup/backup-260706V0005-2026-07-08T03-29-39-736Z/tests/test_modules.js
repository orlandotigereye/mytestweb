const path = require("path");
const config = require("../config/config");
const UI = require("../lib/ui_renderer");
const MemorySystem = require("../lib/memory");
const FileSystemManager = require("../lib/file_system");
const AIEngine = require("../lib/ai_engine");

async function runTests() {
    console.log(`${UI.colors.cyan}🧪 STARTING MODULE UNIT TESTS...${UI.colors.reset}\n`);

    // 1. UI Test
    console.log("1. Testing UI Renderer...");
    UI.startSpinner("VTest", null, config, "UI Test Phase", 5);
    await new Promise(r => setTimeout(r, 2000));
    UI.updateStatus("Updating UI State...", 3);
    await new Promise(r => setTimeout(r, 1000));
    UI.stopSpinner();
    console.log("✅ UI Test Passed\n");

    // 2. Memory Test
    console.log("2. Testing Memory System...");
    const memory = new MemorySystem(config);
    const id1 = await memory.add("user", "Hello, how are you?", null);
    const id2 = await memory.add("assistant", "I am doing well, thank you!", null);
    memory.link(id1, id2);
    const history = memory.retrieve(2);
    if (history.length === 2) {
        console.log("✅ Memory Add/Link/Retrieve Passed");
    } else {
        console.error("❌ Memory Test Failed");
    }

    // 3. File System Test
    console.log("\n3. Testing File System...");
    const fsManager = new FileSystemManager(config, { current: () => "VTest" }, UI.colors, UI);
    const testContent = "console.log('test');";
    const testFile = fsManager.writeSmartFile(testContent, "test_unit.js");
    const read = fsManager.read_file(testFile);
    if (read.trim() === testContent.trim()) {
        console.log("✅ File Write/Read Passed");
    } else {
        console.error("❌ File System Test Failed");
    }

    // 4. AI Engine Logic Test
    console.log("\n4. Testing AI Engine Logic...");
    const ai = new AIEngine(config, memory, UI, { current: () => "VTest" });
    const isCode = ai.isCodeRequest("Write a javascript function to sort an array");
    const isChat = ai.isGreetingOrChat("Hi there, how is the weather?");
    if (isCode && isChat) {
        console.log("✅ AI Logic Detection Passed");
    } else {
        console.error("❌ AI Logic Detection Failed");
    }

    console.log(`\n${UI.colors.green}🎉 ALL UNIT TESTS COMPLETED!${UI.colors.reset}`);
}

runTests().catch(e => console.error("Test Suite Error:", e));
