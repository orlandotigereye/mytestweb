const path = require("path");
const fs = require("fs");

const config = require("../config/config");
const WikiEngine = require("../lib/wiki_engine");
const FileSystemManager = require("../lib/file_system");

async function runValidation() {
    console.log("🚀 Starting Advanced Validation for Wiki & Document Parsing...");

    const uiMock = {
        updateStatus: (s) => console.log(`[Status] ${s}`),
        colors: { green: "\x1b[32m", red: "\x1b[31m", cyan: "\x1b[36m", yellow: "\x1b[33m", magenta: "\x1b[35m", bold: "\x1b[1m", reset: "\x1b[0m" }
    };

    const aiMock = {
        getAIResponse: async (m, messages) => {
            const systemPrompt = messages[0].content;
            if (systemPrompt.includes("Strategic Fact Extractor")) {
                // Mocking the NEW AI response format
                return JSON.stringify({
                    "ValidationCategory": {
                        "TestFact": { "value": "Enhanced_Verified", "action": "NEW" }
                    }
                });
            }
            return "Mock Summary Response";
        },
        summarizeContent: async (content) => "This is a verified document summary.",
        MODEL_FAST: "fast",
        MODEL_SMART: "smart"
    };

    // 1. Upgraded Wiki Validation
    console.log("\n1️⃣ Testing Upgraded Wiki Engine (Deduplication & Action Logic)...");
    const wiki = new WikiEngine(config, aiMock, uiMock);
    
    // Clear old test facts if any
    delete wiki.facts.categories["ValidationCategory"];
    
    await wiki.extractFacts("新的折扣政策是 30%。", "好的，我已經記錄了。");
    
    if (wiki.facts.categories.ValidationCategory && wiki.facts.categories.ValidationCategory.TestFact === "Enhanced_Verified") {
        console.log(`${uiMock.colors.green}✅ Wiki Enhanced Extraction Passed (JSON Action logic verified).${uiMock.colors.reset}`);
    } else {
        console.error(`${uiMock.colors.red}❌ Wiki Enhanced Extraction Failed.${uiMock.colors.reset}`);
    }

    // 2. Document Parser Validation (Dependency Check)
    console.log("\n2️⃣ Testing Real Document Parsers (Dependency Check)...");
    const fsm = new FileSystemManager(config, { current: () => "V1" }, uiMock.colors, uiMock);
    
    // Create a dummy text file to test the flow (since we can't easily generate binary PDF/XLSX here)
    const dummyPath = path.join(config.ROOT, "temp_test.txt");
    fs.writeFileSync(dummyPath, "This is a test document content.");
    
    try {
        const result = await fsm.analyzeDocument("temp_test.txt", aiMock);
        if (result.includes("Summary:") && result.includes("verified document summary")) {
            console.log(`${uiMock.colors.green}✅ Document Analysis Flow Passed.${uiMock.colors.reset}`);
        } else {
            console.error(`${uiMock.colors.red}❌ Document Analysis Flow Failed.${uiMock.colors.reset}`);
        }
    } catch (e) {
        console.error(`${uiMock.colors.red}❌ Document Analysis Error: ${e.message}${uiMock.colors.reset}`);
    } finally {
        if (fs.existsSync(dummyPath)) fs.unlinkSync(dummyPath);
    }

    // Check if libraries are actually loadable
    try {
        require("pdf-parse");
        require("xlsx");
        console.log(`${uiMock.colors.green}✅ External Libraries (pdf-parse, xlsx) are successfully installed and loadable.${uiMock.colors.reset}`);
    } catch (e) {
        console.error(`${uiMock.colors.red}❌ External Libraries Loading Failed: ${e.message}${uiMock.colors.reset}`);
    }

    console.log("\n🏁 Advanced Validation Finished.");
    process.exit(0);
}

runValidation().catch(e => {
    console.error(e);
    process.exit(1);
});
