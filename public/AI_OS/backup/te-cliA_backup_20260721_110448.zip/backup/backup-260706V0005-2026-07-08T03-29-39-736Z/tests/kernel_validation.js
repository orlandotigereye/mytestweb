const path = require("path");
const fs = require("fs");

const config = require("../config/config");
const WikiEngine = require("../lib/wiki_engine");
const Orchestrator = require("../core/orchestrator");

async function runValidation() {
    console.log("\x1b[36m%s\x1b[0m", "🚀 Starting Advanced Kernel & RAG-lite Validation...");

    const uiMock = {
        updateStatus: (s) => console.log(`[Status] ${s}`),
        colors: { green: "\x1b[32m", red: "\x1b[31m", cyan: "\x1b[36m", yellow: "\x1b[33m", magenta: "\x1b[35m", bold: "\x1b[1m", reset: "\x1b[0m", gray: "\x1b[90m" }
    };

    const aiMock = {
        getAIResponse: async () => "Mock AI Response",
        planner: () => ({ nodes: [] }),
        executeGraph: async () => "Mock Reasoning Output",
        isCodeRequest: () => false,
        reward: () => 10,
        MODEL_SMART: "smart",
        MODEL_FAST: "fast"
    };

    const memoryMock = {
        add: async () => "msg-id",
        link: () => {}
    };

    const fsManagerMock = {
        detectAndLoadFiles: async (i) => i
    };

    // 1. RAG-lite & Fact Retrieval Validation
    console.log("\n1️⃣ Testing Active Knowledge Retrieval (RAG-lite)...");
    const wiki = new WikiEngine(config, aiMock, uiMock);
    wiki.facts.categories = { "Policy": { "Discount": "50% off for testing" } };
    
    const orchestrator = new Orchestrator({ 
        config, ai: aiMock, memory: memoryMock, fsManager: fsManagerMock, 
        projectManager: {}, wikiEngine: wiki, ui: uiMock, runtime: {} 
    });

    await orchestrator.cognition("What is the Discount policy?");
    
    if (orchestrator.thinkingLog.some(log => log.includes("Found 1 relevant facts"))) {
        console.log("\x1b[32m%s\x1b[0m", "✅ RAG-lite Fact Retrieval Verified.");
    } else {
        console.error("\x1b[31m%s\x1b[0m", "❌ RAG-lite Fact Retrieval Failed.");
    }

    // 2. Kernelization & Thinking Log Validation
    console.log("\n2️⃣ Testing Kernelization (Thinking Log visibility)...");
    if (orchestrator.thinkingLog.length > 0) {
        console.log("\x1b[32m%s\x1b[0m", `✅ Orchestrator Thinking Log Verified (${orchestrator.thinkingLog.length} steps recorded).`);
    } else {
        console.error("\x1b[31m%s\x1b[0m", "❌ Orchestrator Thinking Log Empty.");
    }

    // 3. Web Portal Interactivity Integrity
    console.log("\n3️⃣ Testing Web Portal Interactivity Endpoints...");
    const WebPortal = require("../lib/web_portal");
    // We check if the module exports correctly with the new signature
    if (typeof WebPortal.startPortal === "function") {
        console.log("\x1b[32m%s\x1b[0m", "✅ Web Portal API Logic Verified.");
    }

    console.log("\n\x1b[36m%s\x1b[0m", "🏁 Advanced Kernel Validation Finished.");
    process.exit(0);
}

runValidation().catch(e => {
    console.error(e);
    process.exit(1);
});
