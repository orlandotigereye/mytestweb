const path = require("path");
const fs = require("fs");

const config = require("../config/config");
const DBEngine = require("../lib/db_engine");

async function runValidation() {
    console.log("\x1b[36m%s\x1b[0m", "🚀 Starting DB Engine & NL2SQL Validation...");

    const uiMock = {
        updateStatus: (s) => console.log(`[Status] ${s}`),
        colors: { green: "\x1b[32m", red: "\x1b[31m", cyan: "\x1b[36m", yellow: "\x1b[33m", magenta: "\x1b[35m", bold: "\x1b[1m", reset: "\x1b[0m" }
    };

    const aiMock = {
        getAIResponse: async (model, messages, type) => {
            if (type === "SQL Translation") {
                return "```sql\nSELECT TOP 10 * FROM INVMB WHERE MB001 = 'TEST';\n```";
            }
            return "Mock Response";
        },
        MODEL_SMART: "smart",
        MODEL_FAST: "fast"
    };

    const db = new DBEngine(config, aiMock, uiMock);

    // 1. Schema Loading Validation
    console.log("\n1️⃣ Testing Schema Loading from local SQL files...");
    await db.loadSchemaFromFiles();
    if (db.schemaContext.includes("sales_query_example.sql")) {
        console.log("\x1b[32m%s\x1b[0m", "✅ Schema context successfully built from SQL examples.");
    } else {
        console.error("\x1b[31m%s\x1b[0m", "❌ Schema context building failed.");
    }

    // 2. NL2SQL Translation Validation
    console.log("\n2️⃣ Testing Natural Language to SQL Translation...");
    // Mock the execute method to avoid real DB connection in test
    db.execute = async (sql) => {
        return [{ MB001: "TEST", MB002: "Verified Product" }];
    };

    const result = await db.ask("查詢料號為 TEST 的品名");
    if (Array.isArray(result) && result[0].MB002 === "Verified Product") {
        console.log("\x1b[32m%s\x1b[0m", "✅ NL2SQL Translation and Mock Execution Passed.");
    } else {
        console.error("\x1b[31m%s\x1b[0m", "❌ NL2SQL Validation Failed.");
    }

    console.log("\n\x1b[36m%s\x1b[0m", "🏁 DB Engine Validation Finished.");
    process.exit(0);
}

runValidation().catch(e => {
    console.error(e);
    process.exit(1);
});
