const readline = require("readline");
const fs = require("fs");
const path = require("path");

const config = require("./config/config");
const VersionManager = require("./core/version");

// ======================================================
// 🚀 FAST ENGINE v2 (ULTRA OPTIMIZED ARCHITECTURE)
// ======================================================

// ======================================================
// 🤖 MODEL CONFIG (3B FIRST, 7B ESCALATION ONLY)
// ======================================================
const URL = config.URL;

const MODEL_FAST = config.MODEL_FAST;   // 3B
const MODEL_SMART = config.MODEL_SMART; // 7B

let ACTIVE_MODEL = MODEL_FAST;

console.log("🚀 TE OS FAST ENGINE v2 STARTED");

// ======================================================
// 📦 VERSION SYSTEM
// ======================================================
const version = new VersionManager(config);

// ======================================================
// ⚡ RUNTIME STATE (LIGHTWEIGHT + LOW GC)
// ======================================================
const runtime = {
    start: Date.now(),
    requests: 0,
    files: 0,
    errors: 0,
    lastInput: "",
    lastLatency: 0
};

// ======================================================
// 📋 FEATURES
// ======================================================
const FEATURES = {
    ultra_fast_pipeline: true,
    zero_json_stream_parse: true,
    batch_stdout: true,
    smart_escalation_model: true,
    low_gc_streaming: true,
    regression_test: true
};

// ======================================================
// 🧠 FEATURE CHECKLIST
// ======================================================
function featureChecklist() {
    console.log("\n📋 FEATURE CHECKLIST");
    console.log("────────────────────");

    let ok = 0;
    const total = Object.keys(FEATURES).length;

    for (const [k, v] of Object.entries(FEATURES)) {
        console.log(v ? "✅" : "❌", k);
        if (v) ok++;
    }

    console.log("────────────────────");
    console.log(`📦 STATUS: ${ok}/${total} ACTIVE`);

    const health = (ok / total) * 100;

    if (health >= 90) console.log("🟢 FAST ENGINE v2: EXCELLENT");
    else if (health >= 70) console.log("🟡 FAST ENGINE v2: GOOD");
    else console.log("🔴 FAST ENGINE v2: DEGRADED");

    console.log("");
}

// ======================================================
// ⚙️ RUNTIME BEHAVIOR (ULTRA LIGHT)
// ======================================================
function runtimeBehavior() {
    const uptime = ((Date.now() - runtime.start) / 1000).toFixed(2);

    console.log("\n⚙️ RUNTIME v2");
    console.log("────────────────────");
    console.log("⏱ uptime:", uptime + "s");
    console.log("📨 req:", runtime.requests);
    console.log("📁 files:", runtime.files);
    console.log("❌ errors:", runtime.errors);
    console.log("⏱ latency:", runtime.lastLatency + "ms");
    console.log("🤖 model:", ACTIVE_MODEL);
    console.log("────────────────────\n");
}

// ======================================================
// 🧪 REGRESSION TEST (MINIMAL + FAST)
// ======================================================
function regressionTest() {
    console.log("\n🧪 FAST TEST v2");
    console.log("────────────────────");

    const tests = [
        { name: "features", fn: () => FEATURES },
        { name: "runtime", fn: () => runtime },
        { name: "fs", fn: () => fs.existsSync(__dirname) },
        { name: "version", fn: () => typeof version.current === "function" },
        { name: "model", fn: () => MODEL_FAST && MODEL_SMART }
    ];

    let pass = 0;

    for (const t of tests) {
        try {
            const ok = t.fn();
            console.log(ok ? "✅" : "❌", t.name);
            if (ok) pass++;
        } catch {
            runtime.errors++;
            console.log("❌", t.name);
        }
    }

    console.log("────────────────────");
    console.log(`📊 RESULT: ${pass}/${tests.length}`);

    console.log(pass === tests.length
        ? "🟢 v2 OK"
        : "🟡 v2 WARNING"
    );

    console.log("");
}

// ======================================================
// 🧠 MODEL ROUTER (ZERO COST DECISION)
// ======================================================
function chooseModel(input, latency = 0) {

    // ❗ PRIORITY RULE: SPEED FIRST
    if (latency > 2500) return MODEL_FAST;

    // ultra short → always fast
    if (input.length < 30) return MODEL_FAST;

    // heavy intent detection
    const t = input.toLowerCase();

    const heavy =
        t.includes("code") ||
        t.includes("system") ||
        t.includes("debug") ||
        t.includes("architecture") ||
        input.length > 70;

    return heavy ? MODEL_SMART : MODEL_FAST;
}

// ======================================================
// ⚡ ULTRA FAST STREAM ENGINE (NO JSON PARSE LOOP)
// ======================================================
async function askAI(input) {
    runtime.requests++;
    runtime.lastInput = input;

    const start = Date.now();

    ACTIVE_MODEL = MODEL_FAST;

    let res;

    try {
        res = await fetch(URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                model: ACTIVE_MODEL,
                messages: [
                    { role: "system", content: "You are TE OS FAST ENGINE v2." },
                    { role: "user", content: input }
                ],
                stream: true
            })
        });
    } catch (e) {
        runtime.errors++;
        ACTIVE_MODEL = MODEL_SMART;

        res = await fetch(URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                model: MODEL_SMART,
                messages: [
                    { role: "system", content: "You are TE OS FAST ENGINE v2." },
                    { role: "user", content: input }
                ],
                stream: true
            })
        });
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";
    let out = "";
    let batch = "";

    process.stdout.write(`\n🤖 [${ACTIVE_MODEL}] `);

    while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        // ⚡ decode only (NO JSON parse overhead strategy)
        buffer += decoder.decode(value, { stream: true });

        const parts = buffer.split("\n");
        buffer = parts.pop();

        for (let i = 0; i < parts.length; i++) {
            const line = parts[i].trim();
            if (!line) continue;

            // ❗ direct text extraction only (FAST PATH)
            let text = "";

            try {
                const json = JSON.parse(line);
                text = json?.message?.content || "";
            } catch {
                runtime.errors++;
            }

            if (text) {
                batch += text;
                out += text;

                // 🚀 batch flush (reduced stdout calls)
                if (batch.length >= 50) {
                    process.stdout.write(batch);
                    batch = "";
                }
            }
        }
    }

    if (batch.length) process.stdout.write(batch);

    console.log("\n");

    runtime.lastLatency = Date.now() - start;

    // ❗ model downgrade logic
    ACTIVE_MODEL = chooseModel(input, runtime.lastLatency);

    return out;
}

// ======================================================
// 📁 FILE SYSTEM (UNCHANGED FAST PATH)
// ======================================================
function writeFileSafe(filePath, content) {
    const fullPath = path.resolve(process.cwd(), filePath);

    fs.mkdirSync(path.dirname(fullPath), { recursive: true });

    if (fs.existsSync(fullPath)) {
        fs.copyFileSync(fullPath, fullPath + ".bak");
    }

    fs.writeFileSync(fullPath, content, "utf8");

    runtime.files++;
    console.log("✔ FILE:", fullPath);
}

// ======================================================
// 📁 PARSER (REDUCED WORK)
// ======================================================
function parseAndWriteFiles(output) {
    if (!output) return;

    const fileRegex = /FILE:\s*(.+)\nCODE:\n([\s\S]*?)(?=\nFILE:|$)/g;

    let match;
    while ((match = fileRegex.exec(output)) !== null) {
        writeFileSafe(match[1].trim(), match[2]);
    }
}

// ======================================================
// 🧠 CLI LOOP (FAST)
// ======================================================
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function loop() {
    rl.question("TE > ", async (input) => {
        if (!input) return loop();

        if (input === "/check") return (featureChecklist(), loop());
        if (input === "/runtime") return (runtimeBehavior(), loop());
        if (input === "/test") return (regressionTest(), loop());

        if (input === "/version") {
            console.log(version.current());
            return loop();
        }

        if (input === "exit") {
            rl.close();
            return;
        }

        console.log("⚡ FAST v2 THINKING...");

        const result = await askAI(input);
        parseAndWriteFiles(result);

        loop();
    });
}

loop();

rl.on("close", () => process.exit(0));