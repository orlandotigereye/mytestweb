const readline = require("readline");
const fs = require("fs");
const path = require("path");

const config = require("./config/config");
const VersionManager = require("./core/version");

// ======================================================
// 🤖 MODEL CONFIG
// ======================================================
const URL = config.URL;

const MODEL_FAST = config.MODEL_FAST;
const MODEL_SMART = config.MODEL_SMART;
let ACTIVE_MODEL = config.DEFAULT_MODEL;

console.log("🚀 TE OS v6.7 FULL CONTROL SYSTEM STARTED");

// ======================================================
// 📦 VERSION SYSTEM
// ======================================================
const VERSION_FILE = config.VERSION_FILE;
const version = new VersionManager(config);

// ⚙️ RUNTIME STATE
// ======================================================
const runtime = {
    start: Date.now(),
    requests: 0,
    files: 0,
    errors: 0,
    lastInput: null
};

// ======================================================
// 📋 FEATURES
// ======================================================
const FEATURES = {
    ai_chat: true,
    streaming: true,
    file_writer: true,
    file_parser: true,
    version_system: true,
    runtime_monitor: true,
    regression_test: true,
    model_router: true,
    cli_commands: true
};

// ======================================================
// 🧠 FEATURE CHECKLIST
// ======================================================
function featureChecklist() {
    console.log("\n📋 FEATURE CHECKLIST");
    console.log("────────────────────");

    let ok = 0;
    const total = Object.keys(FEATURES).length;

    for (const [k, v] of Object.entries(FEATURES)) {
        console.log(v ? "✅" : "❌", k);
        if (v) ok++;
    }

    console.log("────────────────────");
    console.log(`📦 STATUS: ${ok}/${total} ACTIVE`);

    const health = (ok / total) * 100;

    if (health >= 90) console.log("🟢 SYSTEM HEALTH: EXCELLENT");
    else if (health >= 70) console.log("🟡 SYSTEM HEALTH: GOOD");
    else console.log("🔴 SYSTEM HEALTH: DEGRADED");

    console.log("");
}

// ======================================================
// ⚙️ RUNTIME BEHAVIOR
// ======================================================
function runtimeBehavior() {
    const uptime = ((Date.now() - runtime.start) / 1000).toFixed(2);

    console.log("\n⚙️ RUNTIME BEHAVIOR");
    console.log("────────────────────");
    console.log("⏱ uptime:", uptime + "s");
    console.log("📨 requests:", runtime.requests);
    console.log("📁 files:", runtime.files);
    console.log("❌ errors:", runtime.errors);
    console.log("🧠 last input:", runtime.lastInput);
    console.log("🤖 active model:", ACTIVE_MODEL);
    console.log("────────────────────\n");
}

// ======================================================
// 🧪 REGRESSION TEST
// ======================================================
function regressionTest() {
    console.log("\n🧪 REGRESSION TEST");
    console.log("────────────────────");

    const tests = [
        {
            name: "feature_system",
            fn: () => FEATURES && Object.keys(FEATURES).length > 0
        },
        {
            name: "runtime_object",
            fn: () => typeof runtime === "object" && runtime !== null
        },
        {
            name: "filesystem_access",
            fn: () => fs.existsSync(__dirname)
        },
        {
            name: "version_system",
            fn: () => {
                try {
                    const v = version.current();
                    return v !== undefined && v !== null;
                } catch (e) {
                    runtime.errors++;
                    return false;
                }
            }
        },
        {
            name: "model_router",
            fn: () => typeof ACTIVE_MODEL === "string"
        },
        {
            name: "cli_functional",
            fn: () => typeof chooseModel === "function"
        }
    ];

    let pass = 0;

    for (const t of tests) {
        try {
            const ok = t.fn();
            console.log(ok ? "✅" : "❌", t.name);
            if (ok) pass++;
        } catch (err) {
            runtime.errors++;
            console.log("❌", t.name);
        }
    }

    console.log("────────────────────");
    console.log(`📊 RESULT: ${pass}/${tests.length} PASSED`);

    if (pass === tests.length) {
        console.log("🟢 SYSTEM STATUS: STABLE");
    } else if (pass >= tests.length / 2) {
        console.log("🟡 SYSTEM STATUS: WARNING");
    } else {
        console.log("🔴 SYSTEM STATUS: FAILING");
    }

    console.log("");
}

// ======================================================
// 🤖 MODEL ROUTER
// ======================================================
function chooseModel(input) {
    const t = input.toLowerCase();

    if (input.length > 60) return MODEL_SMART;

    const smartKeywords = [
        "code",
        "fix",
        "debug",
        "build",
        "system",
        "project",
        "architecture"
    ];

    for (const k of smartKeywords) {
        if (t.includes(k)) return MODEL_SMART;
    }

    return MODEL_FAST;
}

// ======================================================
// 🤖 AI ENGINE
// ======================================================
async function askAI(input) {
    runtime.requests++;
    runtime.lastInput = input;

    ACTIVE_MODEL = chooseModel(input);

    const res = await fetch(URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            model: ACTIVE_MODEL,
            messages: [
                { role: "system", content: "You are TE OS AI assistant." },
                { role: "user", content: input }
            ],
            stream: true
        })
    });

    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";
    let full = "";

    process.stdout.write(`\n🤖 [${ACTIVE_MODEL}] `);

    while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n");
        buffer = lines.pop();

        for (let line of lines) {
            line = line.trim();
            if (!line) continue;

            try {
                const json = JSON.parse(line);
                const text =
                    json?.message?.content ||
                    json?.message?.thinking ||
                    "";

                if (text) {
                    process.stdout.write(text);
                    full += text;
                }
            } catch (e) {
                runtime.errors++;
            }
        }
    }

    console.log("\n");
    return full;
}

// ======================================================
// 📁 FILE SYSTEM
// ======================================================
function writeFileSafe(filePath, content) {
    const fullPath = path.resolve(process.cwd(), filePath);

    fs.mkdirSync(path.dirname(fullPath), { recursive: true });

    if (fs.existsSync(fullPath)) {
        fs.copyFileSync(fullPath, fullPath + ".bak");
    }

    fs.writeFileSync(fullPath, content, "utf8");

    runtime.files++;
    console.log("✔ FILE CREATED:", fullPath);
}

// ======================================================
// 📁 FILE PARSER
// ======================================================
function parseAndWriteFiles(output) {
    if (!output) return;

    const fileRegex = /FILE:\s*(.+)\nCODE:\n([\s\S]*?)(?=\nFILE:|$)/g;
    const mdRegex = /```([a-zA-Z0-9_.\-\/]+)\n([\s\S]*?)```/g;

    let match;

    while ((match = fileRegex.exec(output)) !== null) {
        writeFileSafe(match[1].trim(), match[2]);
    }

    while ((match = mdRegex.exec(output)) !== null) {
        writeFileSafe(match[1].trim(), match[2]);
    }
}

// ======================================================
// 🧠 CLI
// ======================================================
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function loop() {
    rl.question("TE > ", async (input) => {
        if (!input) return loop();

        // =========================
        // COMMAND SYSTEM
        // =========================
        if (input === "/check") {
            featureChecklist();
            return loop();
        }

        if (input === "/runtime") {
            runtimeBehavior();
            return loop();
        }

        if (input === "/test") {
            regressionTest();
            return loop();
        }

        if (input === "/version") {
            console.log("📌 VERSION:", version.current());
            return loop();
        }

        if (input === "/next-version") {
            console.log("🚀 VERSION:", version.next());
            return loop();
        }

        if (input === "/model") {
            console.log("\n🤖 MODEL STATUS");
            console.log("────────────────────");
            console.log("FAST :", MODEL_FAST);
            console.log("SMART:", MODEL_SMART);
            console.log("ACTIVE:", ACTIVE_MODEL);
            console.log("────────────────────\n");
            return loop();
        }

        if (input.toLowerCase() === "exit") {
            rl.close();
            return;
        }

        console.log("⚡ thinking...");

        const result = await askAI(input);
        parseAndWriteFiles(result);

        loop();
    });
}

loop();

rl.on("close", () => process.exit(0));