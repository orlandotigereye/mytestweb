const readline = require("readline");
const fs = require("fs");
const path = require("path");

const config = require("./config/config");
const VersionManager = require("./core/version");

// ======================================================
// 🧠 AI COGNITIVE OS v1 (RUNTIME → COGNITION SHIFT)
// ======================================================

console.log("🧠 AI COGNITIVE OS v1 STARTED");

// ======================================================
// 🤖 MODEL CONFIG
// ======================================================
const URL = config.URL;
const MODEL_FAST = config.MODEL_FAST;
const MODEL_SMART = config.MODEL_SMART;

let ACTIVE_MODEL = MODEL_FAST;

// ======================================================
// 📦 VERSION SYSTEM
// ======================================================
const version = new VersionManager(config);

// ======================================================
// 🧠 MEMORY SYSTEM (SHORT + LONG + SUMMARY)
// ======================================================
const Memory = {
    shortTerm: [],
    longTerm: [],
    summary: [],

    maxShort: 20,

    add(role, content) {
        if (!content) return;

        const entry = { role, content, time: Date.now() };

        this.shortTerm.push(entry);
        this.longTerm.push(entry);

        if (this.shortTerm.length > this.maxShort) {
            this.shortTerm.shift();
        }
    },

    summarize() {
        // lightweight compression (cognition layer simulation)
        if (this.longTerm.length > 30) {
            const chunk = this.longTerm.splice(0, 10);
            const summary = chunk.map(x => x.content).join(" | ");
            this.summary.push(summary);
        }
    },

    retrieve() {
        return [
            ...this.summary.map(s => ({ role: "system", content: "SUMMARY: " + s })),
            ...this.shortTerm
        ];
    }
};

// ======================================================
// 📊 RUNTIME + COGNITION STATE
// ======================================================
const runtime = {
    start: Date.now(),
    requests: 0,
    success: 0,
    fail: 0,
    errors: 0,
    toolCalls: 0,
    cognitionLoops: 0,
    lastInput: "",
    lastLatency: 0,
    lastModel: "",
    lastCritique: ""
};

// ======================================================
// 📋 FEATURES (COGNITIVE EXPANSION)
// ======================================================
const FEATURES = {
    memory_short_long_summary: true,
    planner_tree: true,
    cognition_loop: true,
    self_critique: true,
    tool_system: true,
    streaming: true,
    fallback_model: true,
    file_intelligence: true,
    event_trace: true,
    regression_test: true,
    runtime_monitor: true
};

// ======================================================
// 🧠 FEATURE CHECKLIST
// ======================================================
function featureChecklist() {
    console.log("\n📋 FEATURE CHECKLIST");

    let ok = 0;
    for (const [k, v] of Object.entries(FEATURES)) {
        console.log(v ? "✅" : "❌", k);
        if (v) ok++;
    }

    console.log("────────────────────");
    console.log(`STATUS: ${ok}/${Object.keys(FEATURES).length}`);
}

// ======================================================
// ⚙️ RUNTIME SNAPSHOT
// ======================================================
function runtimeBehavior() {
    const uptime = ((Date.now() - runtime.start) / 1000).toFixed(2);

    console.log("\n🧠 COGNITIVE SNAPSHOT");
    console.log({
        uptime: uptime + "s",
        requests: runtime.requests,
        success: runtime.success,
        fail: runtime.fail,
        errors: runtime.errors,
        toolCalls: runtime.toolCalls,
        cognitionLoops: runtime.cognitionLoops,
        model: runtime.lastModel,
        lastCritique: runtime.lastCritique
    });
}

// ======================================================
// 🧠 PLANNER TREE (REAL COGNITIVE STRUCTURE)
// ======================================================
function planner(input) {
    const t = input.toLowerCase();

    const tree = {
        intent: "chat",
        steps: []
    };

    if (t.includes("code") || t.includes("file")) {
        tree.intent = "generation";
        tree.steps.push("analyze_requirements");
        tree.steps.push("generate_output");
    }

    if (t.includes("debug")) {
        tree.intent = "debugging";
        tree.steps.push("analyze_error");
        tree.steps.push("propose_fix");
    }

    if (t.includes("system") || t.includes("architecture")) {
        tree.intent = "architecture";
        tree.steps.push("decompose_system");
        tree.steps.push("design_structure");
    }

    if (tree.steps.length === 0) {
        tree.steps.push("respond_directly");
    }

    return tree;
}

// ======================================================
// 🧠 SELF CRITIC (COGNITION LAYER)
// ======================================================
function critic(output) {
    if (!output) return "EMPTY_OUTPUT";

    let score = 0;

    if (output.length > 50) score++;
    if (output.includes("error") === false) score++;
    if (output.includes("undefined") === false) score++;

    const result =
        score >= 2 ? "GOOD" :
        score === 1 ? "OK" : "BAD";

    runtime.lastCritique = result;

    return result;
}

// ======================================================
// 🤖 TOOL SYSTEM
// ======================================================
const Tools = {
    write(content) {
        const dir = path.join(process.cwd(), "Proj");
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

        const file = path.join(dir, `Proj_${Date.now()}.txt`);
        fs.writeFileSync(file, content, "utf8");

        runtime.toolCalls++;
        return file;
    }
};

// ======================================================
// 🌐 SAFE FETCH
// ======================================================
async function safeFetch(model, messages) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 20000);

    try {
        const res = await fetch(URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            signal: controller.signal,
            body: JSON.stringify({
                model,
                messages,
                stream: true
            })
        });

        clearTimeout(timer);

        if (!res.ok) throw new Error("HTTP_FAIL");

        return res;
    } catch (e) {
        clearTimeout(timer);
        throw e;
    }
}

// ======================================================
// 🌊 STREAM ENGINE
// ======================================================
async function streamRead(res) {
    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";
    let output = "";
    let chunk = "";

    while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n");
        buffer = lines.pop();

        for (const line of lines) {
            const clean = line.trim();
            if (!clean) continue;

            try {
                const json = JSON.parse(clean);
                const text = json?.message?.content || "";

                if (text) {
                    chunk += text;
                    output += text;

                    if (chunk.length > 70) {
                        process.stdout.write(chunk);
                        chunk = "";
                    }
                }
            } catch {
                runtime.errors++;
            }
        }
    }

    if (chunk) process.stdout.write(chunk);
    console.log("\n");

    return output;
}

// ======================================================
// 🧠 COGNITION ENGINE (MAIN LOOP)
// ======================================================
async function cognition(input) {
    runtime.requests++;
    runtime.lastInput = input;

    const plan = planner(input);

    let model = plan.intent === "architecture" ? MODEL_SMART : MODEL_FAST;

    runtime.lastModel = model;

    const messages = Memory.retrieve();
    messages.push({ role: "user", content: input });

    let res;

    try {
        res = await safeFetch(model, messages);
    } catch (e) {
        runtime.fail++;
        model = MODEL_SMART;

        try {
            res = await safeFetch(model, messages);
        } catch (e2) {
            runtime.errors++;
            return "";
        }
    }

    const output = await streamRead(res);

    runtime.success++;

    Memory.add("user", input);
    Memory.add("assistant", output);

    Memory.summarize();

    const score = critic(output);

    runtime.cognitionLoops++;

    return output + `\n\n[COGNITION:${score}]`;
}

// ======================================================
// 📄 OUTPUT PARSER
// ======================================================
function parseOutput(output) {
    if (!output) return;

    const regex = /```[\s\S]*?\n([\s\S]*?)```/g;

    let match;
    while ((match = regex.exec(output)) !== null) {
        Tools.write(match[1]);
    }
}

// ======================================================
// 🧪 REGRESSION TEST
// ======================================================
async function regressionTest() {
    console.log("\n🧪 COGNITIVE TEST");

    const tests = [
        { name: "memory", fn: () => Memory.shortTerm !== undefined },
        { name: "planner", fn: () => typeof planner === "function" },
        { name: "critic", fn: () => typeof critic === "function" },
        { name: "tools", fn: () => typeof Tools.write === "function" },
        { name: "cognition", fn: () => typeof cognition === "function" }
    ];

    let pass = 0;

    for (const t of tests) {
        try {
            const ok = t.fn();
            console.log(ok ? "✅" : "❌", t.name);
            if (ok) pass++;
        } catch {}

    }

    console.log(`RESULT: ${pass}/${tests.length}`);

    await cognition("system cognition test");
}

// ======================================================
// 🧠 CLI
// ======================================================
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function loop() {
    rl.question("AI-COG-v1 > ", async (input) => {
        try {
            if (!input) return loop();

            if (input === "/check") return (featureChecklist(), loop());
            if (input === "/runtime") return (runtimeBehavior(), loop());
            if (input === "/test") return (await regressionTest(), loop());

            if (input === "exit") {
                rl.close();
                return;
            }

            const output = await cognition(input);

            parseOutput(output);

        } catch (err) {
            runtime.errors++;
            console.log("❌ ERROR:", err.message);
        }

        loop();
    });
}

loop();

rl.on("close", () => process.exit(0));