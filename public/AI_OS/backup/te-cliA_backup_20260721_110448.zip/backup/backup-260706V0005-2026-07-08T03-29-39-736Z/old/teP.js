const readline = require("readline");
const fs = require("fs");
const path = require("path");

const config = require("./config/config");
const VersionManager = require("./core/version");

// ======================================================
// 🚀 AI AGENT RUNTIME KERNEL v6 (EXPANDED SYSTEM)
// ======================================================

console.log("🚀 AI AGENT RUNTIME KERNEL v6 STARTED");

// ======================================================
// 🤖 MODEL CONFIG
// ======================================================
const URL = config.URL;
const MODEL_FAST = config.MODEL_FAST;
const MODEL_SMART = config.MODEL_SMART;

let ACTIVE_MODEL = MODEL_FAST;

// ======================================================
// 📦 VERSION SYSTEM
// ======================================================
const version = new VersionManager(config);

// ======================================================
// 🧠 MEMORY LAYER (ENHANCED)
// ======================================================
const Memory = {
    shortTerm: [],
    eventLog: [],
    max: 25,

    add(role, content) {
        if (!content) return;

        const entry = {
            time: Date.now(),
            role,
            content
        };

        this.shortTerm.push(entry);
        this.eventLog.push(entry);

        if (this.shortTerm.length > this.max) {
            this.shortTerm.shift();
        }
    },

    retrieveContext() {
        return this.shortTerm.map(x => ({
            role: x.role,
            content: x.content
        }));
    }
};

// ======================================================
// 📊 RUNTIME STATE
// ======================================================
const runtime = {
    start: Date.now(),
    requests: 0,
    success: 0,
    fail: 0,
    files: 0,
    errors: 0,
    toolCalls: 0,
    lastInput: "",
    lastLatency: 0,
    lastModel: "",
    lastEvent: null
};

// ======================================================
// 📋 FEATURE FLAGS
// ======================================================
const FEATURES = {
    planner: true,
    executor: true,
    tool_layer: true,
    memory_layer: true,
    event_kernel: true,
    streaming: true,
    fallback_model: true,
    file_intelligence: true,
    safe_execution: true,
    regression_test: true,
    runtime_monitor: true
};

// ======================================================
// 🧠 FEATURE CHECKLIST
// ======================================================
function featureChecklist() {
    console.log("\n📋 FEATURE CHECKLIST");
    let ok = 0;

    for (const [k, v] of Object.entries(FEATURES)) {
        console.log(v ? "✅" : "❌", k);
        if (v) ok++;
    }

    console.log("────────────────────");
    console.log(`STATUS: ${ok}/${Object.keys(FEATURES).length}`);
}

// ======================================================
// ⚙️ RUNTIME SNAPSHOT
// ======================================================
function runtimeBehavior() {
    const uptime = ((Date.now() - runtime.start) / 1000).toFixed(2);

    console.log("\n⚙️ RUNTIME KERNEL SNAPSHOT");
    console.log({
        uptime: uptime + "s",
        requests: runtime.requests,
        success: runtime.success,
        fail: runtime.fail,
        files: runtime.files,
        errors: runtime.errors,
        toolCalls: runtime.toolCalls,
        model: runtime.lastModel
    });
}

// ======================================================
// 🧠 PLANNER (NEW CORE)
// ======================================================
function planner(input) {
    const t = input.toLowerCase();

    const plan = {
        tasks: [],
        mode: "simple"
    };

    if (t.includes("file") || t.includes("code")) {
        plan.tasks.push("generate_code");
    }

    if (t.includes("analyze")) {
        plan.tasks.push("analysis");
    }

    if (t.includes("project") || t.includes("system")) {
        plan.tasks.push("architecture");
        plan.mode = "complex";
    }

    if (plan.tasks.length === 0) {
        plan.tasks.push("chat");
    }

    return plan;
}

// ======================================================
// 🤖 TOOL SYSTEM (SAFE EXECUTOR)
// ======================================================
const Tools = {
    writeFile(content) {
        const dir = path.join(process.cwd(), "Proj");
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

        const file = path.join(dir, `Proj_${Date.now()}.txt`);
        fs.writeFileSync(file, content, "utf8");

        runtime.files++;
        return file;
    },

    logEvent(event) {
        runtime.lastEvent = event;
        Memory.eventLog.push({
            time: Date.now(),
            type: "event",
            event
        });
    }
};

// ======================================================
// 🧠 MODEL ROUTER (IMPROVED)
// ======================================================
function chooseModel(input, plan) {
    const t = input.toLowerCase();

    if (plan.mode === "complex") return MODEL_SMART;

    if (input.length > 120) return MODEL_SMART;

    if (
        t.includes("system") ||
        t.includes("architecture") ||
        t.includes("debug")
    ) return MODEL_SMART;

    return MODEL_FAST;
}

// ======================================================
// 🌐 SAFE FETCH
// ======================================================
async function safeFetch(model, messages) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 20000);

    try {
        const res = await fetch(URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            signal: controller.signal,
            body: JSON.stringify({
                model,
                messages,
                stream: true
            })
        });

        clearTimeout(timeout);

        if (!res.ok) throw new Error("HTTP_ERROR");

        return res;
    } catch (e) {
        clearTimeout(timeout);
        throw e;
    }
}

// ======================================================
// 🌊 STREAM ENGINE
// ======================================================
async function streamRead(res) {
    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";
    let output = "";
    let chunk = "";

    runtime.toolCalls++;

    while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n");
        buffer = lines.pop();

        for (const line of lines) {
            const clean = line.trim();
            if (!clean) continue;

            try {
                const json = JSON.parse(clean);
                const text = json?.message?.content || "";

                if (text) {
                    chunk += text;
                    output += text;

                    if (chunk.length > 70) {
                        process.stdout.write(chunk);
                        chunk = "";
                    }
                }
            } catch {
                runtime.errors++;
            }
        }
    }

    if (chunk) process.stdout.write(chunk);
    console.log("\n");

    return output;
}

// ======================================================
// 🧠 EXECUTOR (CORE ORCHESTRATION)
// ======================================================
async function executor(input, plan) {
    runtime.requests++;
    runtime.lastInput = input;

    const model = chooseModel(input, plan);
    runtime.lastModel = model;

    const messages = [
        { role: "system", content: "AI Agent Runtime Kernel v6" },
        ...Memory.retrieveContext(),
        { role: "user", content: input }
    ];

    let res;

    try {
        res = await safeFetch(model, messages);
    } catch (e) {
        runtime.fail++;
        const fallback = model === MODEL_FAST ? MODEL_SMART : MODEL_FAST;

        try {
            res = await safeFetch(fallback, messages);
        } catch (e2) {
            runtime.errors++;
            console.log("❌ EXECUTION FAILED");
            return "";
        }
    }

    const output = await streamRead(res);

    runtime.success++;

    Memory.add("user", input);
    Memory.add("assistant", output);

    Tools.logEvent({ input, output, model });

    return output;
}

// ======================================================
// 📄 FILE INTELLIGENCE
// ======================================================
function parseOutput(output) {
    if (!output) return;

    const fileRegex = /FILE:\s*(.+)\nCODE:\n([\s\S]*?)(?=\nFILE:|$)/g;
    const mdRegex = /```[\s\S]*?\n([\s\S]*?)```/g;

    let match;

    while ((match = fileRegex.exec(output)) !== null) {
        Tools.writeFile(match[2]);
    }

    while ((match = mdRegex.exec(output)) !== null) {
        Tools.writeFile(match[1]);
    }
}

// ======================================================
// 🧪 REGRESSION TEST (FULL FLOW)
// ======================================================
async function regressionTest() {
    console.log("\n🧪 REGRESSION TEST");

    const tests = [
        { name: "memory", fn: () => Memory.shortTerm.length >= 0 },
        { name: "planner", fn: () => typeof planner === "function" },
        { name: "executor", fn: () => typeof executor === "function" },
        { name: "tools", fn: () => typeof Tools.writeFile === "function" },
        { name: "router", fn: () => typeof chooseModel === "function" }
    ];

    let pass = 0;

    for (const t of tests) {
        try {
            const ok = t.fn();
            console.log(ok ? "✅" : "❌", t.name);
            if (ok) pass++;
        } catch {}

    }

    console.log(`RESULT: ${pass}/${tests.length}`);

    await executor("system check", planner("system check"));
}

// ======================================================
// 🧠 CLI LOOP
// ======================================================
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function loop() {
    rl.question("AI-Kernel-v6 > ", async (input) => {
        try {
            if (!input) return loop();

            if (input === "/check") return (featureChecklist(), loop());
            if (input === "/runtime") return (runtimeBehavior(), loop());
            if (input === "/test") return (await regressionTest(), loop());

            if (input === "exit") {
                rl.close();
                return;
            }

            const plan = planner(input);

            const output = await executor(input, plan);

            parseOutput(output);

        } catch (err) {
            runtime.errors++;
            console.log("❌ CLI ERROR:", err.message);
        }

        loop();
    });
}

loop();

rl.on("close", () => process.exit(0));