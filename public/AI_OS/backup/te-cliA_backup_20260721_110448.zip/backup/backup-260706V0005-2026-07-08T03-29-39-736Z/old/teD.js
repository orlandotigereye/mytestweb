const readline = require("readline");
const fs = require("fs");
const path = require("path");

const config = require("./config/config");
const VersionManager = require("./core/version");

// ======================================================
// 🤖 MODEL CONFIG
// ======================================================
const URL = config.URL;

const MODEL_FAST = config.MODEL_FAST;   // 3B
const MODEL_SMART = config.MODEL_SMART; // 7B

let ACTIVE_MODEL = MODEL_SMART;

console.log("🚀 TE OS v6.7 FULL CONTROL SYSTEM STARTED");

// ======================================================
// 📦 VERSION SYSTEM
// ======================================================
const version = new VersionManager(config);

// ======================================================
// ⚙️ RUNTIME STATE
// ======================================================
const runtime = {
    start: Date.now(),
    requests: 0,
    files: 0,
    errors: 0,
    lastInput: null,
    lastLatency: 0
};

// ======================================================
// 📋 FEATURES
// ======================================================
const FEATURES = {
    ai_chat: true,
    streaming: true,
    file_writer: true,
    file_parser: true,
    version_system: true,
    runtime_monitor: true,
    regression_test: true,
    model_router: true,
    auto_fallback_model: true
};

// ======================================================
// 🧠 FEATURE CHECKLIST
// ======================================================
function featureChecklist() {
    console.log("\n📋 FEATURE CHECKLIST");
    console.log("────────────────────");

    let ok = 0;
    const total = Object.keys(FEATURES).length;

    for (const [k, v] of Object.entries(FEATURES)) {
        console.log(v ? "✅" : "❌", k);
        if (v) ok++;
    }

    console.log("────────────────────");
    console.log(`📦 STATUS: ${ok}/${total} ACTIVE`);

    const health = (ok / total) * 100;

    if (health >= 90) console.log("🟢 SYSTEM HEALTH: EXCELLENT");
    else if (health >= 70) console.log("🟡 SYSTEM HEALTH: GOOD");
    else console.log("🔴 SYSTEM HEALTH: DEGRADED");

    console.log("");
}

// ======================================================
// ⚙️ RUNTIME BEHAVIOR
// ======================================================
function runtimeBehavior() {
    const uptime = ((Date.now() - runtime.start) / 1000).toFixed(2);

    console.log("\n⚙️ RUNTIME BEHAVIOR");
    console.log("────────────────────");
    console.log("⏱ uptime:", uptime + "s");
    console.log("📨 requests:", runtime.requests);
    console.log("📁 files:", runtime.files);
    console.log("❌ errors:", runtime.errors);
    console.log("⏱ last latency:", runtime.lastLatency + "ms");
    console.log("🧠 last input:", runtime.lastInput);
    console.log("🤖 active model:", ACTIVE_MODEL);
    console.log("────────────────────\n");
}

// ======================================================
// 🧪 REGRESSION TEST
// ======================================================
function regressionTest() {
    console.log("\n🧪 REGRESSION TEST");
    console.log("────────────────────");

    const tests = [
        { name: "feature_system", fn: () => FEATURES && Object.keys(FEATURES).length > 0 },
        { name: "runtime_object", fn: () => typeof runtime === "object" },
        { name: "filesystem_access", fn: () => fs.existsSync(__dirname) },
        { name: "version_system", fn: () => typeof version.current === "function" },
        { name: "model_router", fn: () => typeof chooseModel === "function" },
        { name: "auto_fallback", fn: () => MODEL_FAST && MODEL_SMART }
    ];

    let pass = 0;

    for (const t of tests) {
        try {
            const ok = t.fn();
            console.log(ok ? "✅" : "❌", t.name);
            if (ok) pass++;
        } catch (e) {
            runtime.errors++;
            console.log("❌", t.name);
        }
    }

    console.log("────────────────────");
    console.log(`📊 RESULT: ${pass}/${tests.length} PASSED`);

    if (pass === tests.length) {
        console.log("🟢 SYSTEM STATUS: STABLE");
    } else {
        console.log("🟡 SYSTEM STATUS: WARNING");
    }

    console.log("");
}

// ======================================================
// 🤖 MODEL ROUTER + AUTO FALLBACK (7B → 3B)
// ======================================================
function chooseModel(input, latency = 0) {
    const text = input.toLowerCase();

    const heavyKeywords = [
        "code", "fix", "debug", "system", "architecture",
        "project", "design", "optimize", "refactor"
    ];

    const isComplex = input.length > 60 ||
        heavyKeywords.some(k => text.includes(k));

    // ❗ PERFORMANCE FALLBACK LOGIC
    // 如果模型反應太慢 → 自動降級
    if (latency > 4000) {
        return MODEL_FAST; // 3B
    }

    // 複雜任務用 7B
    if (isComplex) {
        return MODEL_SMART; // 7B
    }

    // 一般任務用 3B
    return MODEL_FAST;
}

// ======================================================
// 🤖 AI ENGINE (WITH LATENCY AUTO SWITCH)
// ======================================================
async function askAI(input) {
    runtime.requests++;
    runtime.lastInput = input;

    const startTime = Date.now();

    // 初始先用 7B
    ACTIVE_MODEL = MODEL_SMART;

    let res;

    try {
        res = await fetch(URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                model: ACTIVE_MODEL,
                messages: [
                    { role: "system", content: "You are TE OS AI assistant." },
                    { role: "user", content: input }
                ],
                stream: true
            })
        });
    } catch (e) {
        runtime.errors++;
        console.log("❌ MODEL ERROR → fallback to 3B");

        ACTIVE_MODEL = MODEL_FAST;

        res = await fetch(URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                model: ACTIVE_MODEL,
                messages: [
                    { role: "system", content: "You are TE OS AI assistant." },
                    { role: "user", content: input }
                ],
                stream: true
            })
        });
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";
    let full = "";

    process.stdout.write(`\n🤖 [${ACTIVE_MODEL}] `);

    while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n");
        buffer = lines.pop();

        for (let line of lines) {
            line = line.trim();
            if (!line) continue;

            try {
                const json = JSON.parse(line);
                const text =
                    json?.message?.content ||
                    json?.message?.thinking ||
                    "";

                if (text) {
                    process.stdout.write(text);
                    full += text;
                }
            } catch (e) {
                runtime.errors++;
            }
        }
    }

    console.log("\n");

    runtime.lastLatency = Date.now() - startTime;

    // ❗ AUTO DOWNGRADE LOGIC
    if (ACTIVE_MODEL === MODEL_SMART && runtime.lastLatency > 4000) {
        console.log("⚠️ SLOW MODEL DETECTED → switching to 3B next run");
        ACTIVE_MODEL = MODEL_FAST;
    }

    return full;
}

// ======================================================
// 📁 FILE SYSTEM
// ======================================================
function writeFileSafe(filePath, content) {
    const fullPath = path.resolve(process.cwd(), filePath);

    fs.mkdirSync(path.dirname(fullPath), { recursive: true });

    if (fs.existsSync(fullPath)) {
        fs.copyFileSync(fullPath, fullPath + ".bak");
    }

    fs.writeFileSync(fullPath, content, "utf8");

    runtime.files++;
    console.log("✔ FILE CREATED:", fullPath);
}

// ======================================================
// 📁 FILE PARSER
// ======================================================
function parseAndWriteFiles(output) {
    if (!output) return;

    const fileRegex = /FILE:\s*(.+)\nCODE:\n([\s\S]*?)(?=\nFILE:|$)/g;
    const mdRegex = /```([a-zA-Z0-9_.\-\/]+)\n([\s\S]*?)```/g;

    let match;

    while ((match = fileRegex.exec(output)) !== null) {
        writeFileSafe(match[1].trim(), match[2]);
    }

    while ((match = mdRegex.exec(output)) !== null) {
        writeFileSafe(match[1].trim(), match[2]);
    }
}

// ======================================================
// 🧠 CLI
// ======================================================
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function loop() {
    rl.question("TE > ", async (input) => {
        if (!input) return loop();

        if (input === "/check") return (featureChecklist(), loop());
        if (input === "/runtime") return (runtimeBehavior(), loop());
        if (input === "/test") return (regressionTest(), loop());

        if (input === "/version") {
            console.log("📌 VERSION:", version.current());
            return loop();
        }

        if (input === "/next-version") {
            console.log("🚀 VERSION:", version.next());
            return loop();
        }

        if (input === "exit") {
            rl.close();
            return;
        }

        console.log("⚡ thinking...");

        const result = await askAI(input);

        parseAndWriteFiles(result);

        loop();
    });
}

loop();

rl.on("close", () => process.exit(0));