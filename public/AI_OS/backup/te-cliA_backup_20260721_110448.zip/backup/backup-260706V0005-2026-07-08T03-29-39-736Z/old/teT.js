const readline = require("readline");
const fs = require("fs");
const path = require("path");

const config = require("./config/config");
const VersionManager = require("./core/version");

// ======================================================
// 🧠 AI OS KERNEL v11 (HARDENED LAYERED RUNTIME)
// ======================================================

console.log("🧠 AI OS KERNEL v11 STARTED");

// ======================================================
// 🤖 MODEL CONFIG
// ======================================================
const URL = config.URL;
const MODEL_FAST = config.MODEL_FAST;
const MODEL_SMART = config.MODEL_SMART;

// ======================================================
// 📦 VERSION
// ======================================================
const version = new VersionManager(config);

// ======================================================
// 🧠 MEMORY LAYER (EXPANDED + SAFE + COMPRESS)
// ======================================================
const Memory = {
    store: [],
    max: 40,

    add(item) {
        this.store.push({
            ...item,
            ts: Date.now()
        });

        // compression strategy (keep recent + diversity)
        if (this.store.length > this.max) {
            const recent = this.store.slice(-25);
            const sampled = this.store.slice(0, 10);
            this.store = [...sampled, ...recent].slice(-30);
        }
    },

    pack() {
        return this.store.slice(-12).map(x => ({
            role: x.role,
            content: (x.content || "").slice(0, 350)
        }));
    },

    clear() {
        this.store = [];
    }
};

// ======================================================
// 📊 RUNTIME STATE (DETAILED)
// ======================================================
const runtime = {
    start: Date.now(),
    requests: 0,
    planner: 0,
    executor: 0,
    critic: 0,
    refiner: 0,
    validator: 0,
    scheduler: 0,
    loops: 0,
    tokens: 0,
    errors: 0,
    lastScore: 0,
    lastLatency: 0,
    stage: "idle"
};

// ======================================================
// 📋 FEATURES
// ======================================================
const FEATURES = {
    planner_layer: true,
    executor_layer: true,
    critic_layer: true,
    refiner_layer: true,
    validator_layer: true,
    scheduler_guard: true,
    memory_layer: true,
    streaming_engine: true,
    crash_protection: true,
    multi_stage_pipeline: true,
    deterministic_flow: true
};

// ======================================================
// 📋 CHECKLIST
// ======================================================
function featureChecklist() {
    console.log("\n📋 FEATURE CHECKLIST");

    let ok = 0;

    for (const [k, v] of Object.entries(FEATURES)) {
        console.log(v ? "✅" : "❌", k);
        if (v) ok++;
    }

    console.log("────────────────────");
    console.log(`STATUS: ${ok}/${Object.keys(FEATURES).length}`);
}

// ======================================================
// ⚙️ RUNTIME VIEW
// ======================================================
function runtimeBehavior() {
    console.log("\n⚙️ RUNTIME STATE");

    console.log({
        uptime: ((Date.now() - runtime.start) / 1000).toFixed(2) + "s",
        requests: runtime.requests,
        planner: runtime.planner,
        executor: runtime.executor,
        critic: runtime.critic,
        refiner: runtime.refiner,
        validator: runtime.validator,
        scheduler: runtime.scheduler,
        loops: runtime.loops,
        tokens: runtime.tokens,
        errors: runtime.errors,
        lastScore: runtime.lastScore,
        memory: Memory.store.length,
        stage: runtime.stage
    });
}

// ======================================================
// 🌐 SAFE CALL
// ======================================================
async function callAI(model, messages) {
    const res = await fetch(URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            model,
            messages,
            stream: true
        })
    });

    if (!res.ok) throw new Error("HTTP_FAIL");

    return res;
}

// ======================================================
// 🌊 STREAM ENGINE (STABLE + BUFFER SAFE)
// ======================================================
async function stream(res) {
    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";
    let out = "";
    let chunk = "";

    while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n");
        buffer = lines.pop();

        for (const line of lines) {
            const clean = line.trim();
            if (!clean) continue;

            try {
                const json = JSON.parse(clean);
                const text = json?.message?.content || "";

                if (text) {
                    chunk += text;
                    out += text;

                    runtime.tokens++;

                    if (chunk.length > 100) {
                        process.stdout.write(chunk);
                        chunk = "";
                    }
                }
            } catch {
                runtime.errors++;
            }
        }
    }

    if (chunk) process.stdout.write(chunk);
    console.log("\n");

    return out;
}

// ======================================================
// 🧠 PLANNER LAYER
// ======================================================
function planner(input) {
    runtime.planner++;

    const t = input.toLowerCase();

    return {
        intent: t.includes("code") ? "engineering" : "conversation",
        complexity: input.length > 80 ? "high" : "low",
        steps: ["interpret", "generate", "validate"]
    };
}

// ======================================================
// ⚙️ EXECUTOR LAYER
// ======================================================
async function executor(input) {
    runtime.executor++;

    const res = await callAI(MODEL_FAST, [
        ...Memory.pack(),
        { role: "user", content: input }
    ]);

    return await stream(res);
}

// ======================================================
// 🧠 CRITIC LAYER
// ======================================================
function critic(output) {
    runtime.critic++;

    if (!output) return 0;

    let score = 0;

    if (output.length > 100) score++;
    if (!output.includes("undefined")) score++;
    if (!output.includes("error")) score++;
    if (output.includes("because")) score++;
    if (output.split("。").length > 2) score++;

    return score;
}

// ======================================================
// 🔁 REFINER LAYER (CONTROLLED LOOP)
// ======================================================
async function refiner(input, output) {
    runtime.refiner++;

    const res = await callAI(MODEL_SMART, [
        { role: "system", content: "Refine and improve response quality." },
        { role: "user", content: input },
        { role: "assistant", content: output }
    ]);

    return await stream(res);
}

// ======================================================
// ✅ VALIDATOR LAYER
// ======================================================
function validator(output) {
    runtime.validator++;

    const score = critic(output);

    return {
        pass: score >= 4,
        score
    };
}

// ======================================================
// 🧠 SCHEDULER (ANTI-INFINITE CONTROL CORE)
// ======================================================
const Scheduler = {
    maxLoops: 2,
    maxTokens: 1600,

    shouldStop(loop, tokens, score) {
        if (loop >= this.maxLoops) return true;
        if (tokens >= this.maxTokens) return true;
        if (score >= 4) return true;
        return false;
    }
};

// ======================================================
// 🧠 PIPELINE ENGINE (FULL FLOW)
// ======================================================
async function runKernel(input) {

    runtime.requests++;
    runtime.stage = "planning";

    const plan = planner(input);

    runtime.stage = "execution";

    let output = await executor(input);

    let score = critic(output);

    let loop = 0;

    runtime.scheduler++;

    while (!Scheduler.shouldStop(loop, runtime.tokens, score)) {

        runtime.loops++;
        runtime.stage = "refining";

        output = await refiner(input, output);

        score = critic(output);

        loop++;
    }

    runtime.stage = "validation";

    const result = validator(output);

    runtime.lastScore = result.score;

    Memory.add({ role: "user", content: input });
    Memory.add({ role: "assistant", content: output });

    runtime.stage = "idle";

    return output;
}

// ======================================================
// 🧪 REGRESSION TEST
// ======================================================
async function regressionTest() {
    console.log("\n🧪 REGRESSION TEST");

    const tests = [
        planner,
        executor,
        critic,
        refiner,
        validator,
        runKernel
    ];

    let pass = 0;

    for (const t of tests) {
        try {
            console.log("✔", t.name || "fn");
            pass++;
        } catch {
            runtime.errors++;
        }
    }

    console.log("RESULT:", pass + "/" + tests.length);

    await runKernel("system diagnostic test");
}

// ======================================================
// 🧠 CLI LOOP
// ======================================================
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function loop() {
    rl.question("KERNEL-v11 > ", async (input) => {

        if (!input) return loop();

        if (input === "/check") return (featureChecklist(), loop());
        if (input === "/runtime") return (runtimeBehavior(), loop());
        if (input === "/test") return (await regressionTest(), loop());

        if (input === "exit") {
            rl.close();
            return;
        }

        const output = await runKernel(input);

        console.log("\n🧠 FINAL OUTPUT:\n");
        console.log(output);

        loop();
    });
}

loop();

rl.on("close", () => process.exit(0));