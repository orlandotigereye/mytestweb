const readline = require("readline");
const fs = require("fs");
const path = require("path");

const config = require("./config/config");
const VersionManager = require("./core/version");

// ======================================================
// 🧠 AI SELF-IMPROVING COGNITIVE AGENT v6
// ======================================================

console.log("🧠 AI SELF-IMPROVING COGNITIVE AGENT v6 STARTED");

// ======================================================
// 🤖 MODEL CONFIG
// ======================================================
const URL = config.URL;
const MODEL_FAST = config.MODEL_FAST;
const MODEL_SMART = config.MODEL_SMART;

let ACTIVE_MODEL = MODEL_FAST;

// ======================================================
// 📦 VERSION SYSTEM
// ======================================================
const version = new VersionManager(config);

// ======================================================
// 🧠 ADVANCED MEMORY SYSTEM (EXPANDED)
// ======================================================
const Memory = {
    shortTerm: [],
    longTerm: [],
    episodic: [],
    summary: [],

    maxShort: 25,

    add(role, content) {
        if (!content) return;

        const entry = {
            role,
            content,
            time: Date.now()
        };

        this.shortTerm.push(entry);
        this.longTerm.push(entry);

        if (role === "assistant") {
            this.episodic.push(content);
        }

        if (this.shortTerm.length > this.maxShort) {
            this.shortTerm.shift();
        }
    },

    summarize() {
        if (this.longTerm.length > 40) {
            const chunk = this.longTerm.splice(0, 12);
            const summary = chunk.map(x => x.content).join(" | ");
            this.summary.push(summary);
        }
    },

    retrieve() {
        return [
            ...this.summary.map(s => ({ role: "system", content: "MEMORY_SUMMARY: " + s })),
            ...this.shortTerm
        ];
    }
};

// ======================================================
// 📊 RUNTIME STATE
// ======================================================
const runtime = {
    start: Date.now(),
    requests: 0,
    success: 0,
    fail: 0,
    errors: 0,
    selfChecks: 0,
    reflections: 0,
    improvements: 0,
    lastInput: "",
    lastOutput: "",
    lastScore: 0,
    lastModel: "",
    loopDepth: 0
};

// ======================================================
// 📋 FEATURES
// ======================================================
const FEATURES = {
    memory_system: true,
    episodic_memory: true,
    summarization: true,
    planner: true,
    reward_system: true,
    self_check: true,
    reflection_loop: true,
    improvement_loop: true,
    fallback_model: true,
    streaming: true,
    file_writer: true,
    regression_test: true,
    runtime_monitor: true
};

// ======================================================
// 📋 FEATURE CHECKLIST
// ======================================================
function featureChecklist() {
    console.log("\n📋 FEATURE CHECKLIST");

    let ok = 0;
    for (const [k, v] of Object.entries(FEATURES)) {
        console.log(v ? "✅" : "❌", k);
        if (v) ok++;
    }

    console.log("────────────────────");
    console.log(`STATUS: ${ok}/${Object.keys(FEATURES).length}`);
}

// ======================================================
// ⚙️ RUNTIME SNAPSHOT
// ======================================================
function runtimeBehavior() {
    const uptime = ((Date.now() - runtime.start) / 1000).toFixed(2);

    console.log("\n🧠 COGNITIVE RUNTIME SNAPSHOT");
    console.log({
        uptime: uptime + "s",
        requests: runtime.requests,
        success: runtime.success,
        fail: runtime.fail,
        errors: runtime.errors,
        selfChecks: runtime.selfChecks,
        reflections: runtime.reflections,
        improvements: runtime.improvements,
        loopDepth: runtime.loopDepth,
        model: runtime.lastModel
    });
}

// ======================================================
// 🧠 PLANNER (EXPANDED)
// ======================================================
function planner(input) {
    const t = input.toLowerCase();

    const plan = {
        intent: "chat",
        steps: []
    };

    if (t.includes("code") || t.includes("file")) {
        plan.intent = "generation";
        plan.steps.push("analyze_requirements", "generate_code", "validate_output");
    }

    if (t.includes("debug")) {
        plan.intent = "debugging";
        plan.steps.push("error_analysis", "fix_generation", "verification");
    }

    if (t.includes("system") || t.includes("architecture")) {
        plan.intent = "architecture";
        plan.steps.push("decompose", "design", "optimize");
    }

    if (plan.steps.length === 0) {
        plan.steps.push("direct_response");
    }

    return plan;
}

// ======================================================
// 🧠 REWARD SYSTEM (IMPROVED)
// ======================================================
function rewardScore(text) {
    let score = 0;

    if (!text) return 0;

    if (text.length > 120) score++;
    if (!text.includes("undefined")) score++;
    if (!text.includes("error")) score++;
    if (!text.includes("null")) score++;
    if (text.includes("because")) score++;
    if (text.split("。").length > 2) score++;

    return score;
}

// ======================================================
// 🧠 SELF CHECK
// ======================================================
function selfCheck(output) {
    runtime.selfChecks++;

    const score = rewardScore(output);
    runtime.lastScore = score;

    return score;
}

// ======================================================
// 🧠 IMPROVEMENT LOOP (CORE DIFFERENCE v6)
// ======================================================
async function improveLoop(input, output) {
    let score = rewardScore(output);

    if (score >= 5) return output;

    runtime.reflections++;
    runtime.loopDepth++;

    const messages = [
        { role: "system", content: "You are an expert AI improving your previous answer." },
        { role: "user", content: input },
        { role: "assistant", content: output },
        { role: "user", content: "Improve correctness, structure, clarity, and completeness." }
    ];

    try {
        const res = await safeFetch(MODEL_SMART, messages);
        const improved = await streamRead(res);

        runtime.improvements++;

        const newScore = rewardScore(improved);

        if (newScore > score) {
            return improved;
        }

        return output;
    } catch (e) {
        runtime.errors++;
        return output;
    }
}

// ======================================================
// 🌐 SAFE FETCH
// ======================================================
async function safeFetch(model, messages) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 20000);

    const res = await fetch(URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: controller.signal,
        body: JSON.stringify({
            model,
            messages,
            stream: true
        })
    });

    clearTimeout(timer);

    if (!res.ok) throw new Error("HTTP_FAIL");

    return res;
}

// ======================================================
// 🌊 STREAM ENGINE
// ======================================================
async function streamRead(res) {
    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";
    let output = "";
    let chunk = "";

    while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n");
        buffer = lines.pop();

        for (const line of lines) {
            const clean = line.trim();
            if (!clean) continue;

            try {
                const json = JSON.parse(clean);
                const text = json?.message?.content || "";

                if (text) {
                    chunk += text;
                    output += text;

                    if (chunk.length > 80) {
                        process.stdout.write(chunk);
                        chunk = "";
                    }
                }
            } catch {
                runtime.errors++;
            }
        }
    }

    if (chunk) process.stdout.write(chunk);
    console.log("\n");

    return output;
}

// ======================================================
// 🤖 MAIN AI ENGINE (FULL COGNITIVE LOOP)
// ======================================================
async function askAI(input) {
    runtime.requests++;
    runtime.lastInput = input;

    const plan = planner(input);

    let model = plan.intent === "architecture" ? MODEL_SMART : MODEL_FAST;

    runtime.lastModel = model;

    const messages = Memory.retrieve();
    messages.push({ role: "user", content: input });

    let res;

    try {
        res = await safeFetch(model, messages);
    } catch (e) {
        runtime.fail++;
        res = await safeFetch(MODEL_SMART, messages);
    }

    let output = await streamRead(res);

    runtime.success++;

    Memory.add("user", input);
    Memory.add("assistant", output);

    Memory.summarize();

    selfCheck(output);

    output = await improveLoop(input, output);

    runtime.lastOutput = output;

    return output;
}

// ======================================================
// 📁 FILE SYSTEM
// ======================================================
function writeFile(content) {
    const dir = path.join(process.cwd(), "Proj");
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    const file = path.join(dir, `Proj_${Date.now()}.txt`);
    fs.writeFileSync(file, content, "utf8");

    console.log("📁 FILE CREATED:", file);
}

// ======================================================
// 📄 OUTPUT PARSER
// ======================================================
function parseOutput(output) {
    if (!output) return;

    const regex = /```[\s\S]*?\n([\s\S]*?)```/g;

    let match;
    while ((match = regex.exec(output)) !== null) {
        writeFile(match[1]);
    }
}

// ======================================================
// 🧪 REGRESSION TEST
// ======================================================
async function regressionTest() {
    console.log("\n🧪 REGRESSION TEST v6");

    const tests = [
        { name: "memory", fn: () => Memory.shortTerm !== undefined },
        { name: "planner", fn: () => typeof planner === "function" },
        { name: "reward", fn: () => rewardScore("test") >= 0 },
        { name: "selfCheck", fn: () => typeof selfCheck === "function" },
        { name: "improveLoop", fn: () => typeof improveLoop === "function" }
    ];

    let pass = 0;

    for (const t of tests) {
        try {
            const ok = t.fn();
            console.log(ok ? "✅" : "❌", t.name);
            if (ok) pass++;
        } catch {
            runtime.errors++;
        }
    }

    console.log(`RESULT: ${pass}/${tests.length}`);

    await askAI("system regression test v6");
}

// ======================================================
// 🧠 CLI
// ======================================================
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function loop() {
    rl.question("AI-v6 > ", async (input) => {
        try {
            if (!input) return loop();

            if (input === "/check") return (featureChecklist(), loop());
            if (input === "/runtime") return (runtimeBehavior(), loop());
            if (input === "/test") return (await regressionTest(), loop());

            if (input === "exit") {
                rl.close();
                return;
            }

            const output = await askAI(input);

            parseOutput(output);

        } catch (err) {
            runtime.errors++;
            console.log("❌ ERROR:", err.message);
        }

        loop();
    });
}

loop();

rl.on("close", () => process.exit(0));