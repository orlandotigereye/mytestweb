const readline = require("readline");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const config = require("./config/config");
const VersionManager = require("./core/version");

// ======================================================
// 🧠 Agent Runtime v1 (EVENT DRIVEN COGNITIVE ENGINE)
// ======================================================

console.log("🧠 Agent Runtime v1 STARTED");

// ======================================================
// 🤖 MODEL CONFIG
// ======================================================
const URL = config.URL;
const MODEL_FAST = config.MODEL_FAST;
const MODEL_SMART = config.MODEL_SMART;

let ACTIVE_MODEL = MODEL_FAST;

// ======================================================
// 📦 VERSION
// ======================================================
const version = new VersionManager(config);

// ======================================================
// 🧠 EVENT BUS (NEW)
// ======================================================
const EventBus = {
    events: [],

    emit(type, payload) {
        this.events.push({ type, payload, time: Date.now() });
    },

    recent() {
        return this.events.slice(-20);
    }
};

// ======================================================
// 🧠 MEMORY SYSTEM (ENHANCED, NO REMOVAL)
// ======================================================
const Memory = {
    short: [],
    long: [],
    summary: [],
    maxShort: 25,

    add(role, content) {
        if (!content) return;

        const entry = { role, content, time: Date.now() };

        this.short.push(entry);
        this.long.push(entry);

        if (this.short.length > this.maxShort) {
            this.short.shift();
        }

        EventBus.emit("memory:add", entry);
    },

    scoreMatch(a, b) {
        const A = (a || "").toLowerCase();
        const B = (b || "").toLowerCase();
        let score = 0;
        for (const w of A.split(" ")) {
            if (B.includes(w)) score++;
        }
        return score;
    },

    retrieve(input) {
        const ranked = this.long
            .map(x => ({
                role: x.role,
                content: x.content,
                score: this.scoreMatch(input, x.content)
            }))
            .sort((a, b) => b.score - a.score)
            .slice(0, 8);

        return [
            ...this.summary.map(s => ({ role: "system", content: "SUMMARY: " + s })),
            ...this.short,
            ...ranked
        ];
    },

    summarize() {
        if (this.long.length > 40) {
            const chunk = this.long.splice(0, 10);
            const summary = chunk.map(x => x.content).join(" | ");
            this.summary.push(summary);
        }
    }
};

// ======================================================
// 📊 RUNTIME STATE
// ======================================================
const runtime = {
    start: Date.now(),
    requests: 0,
    planner: 0,
    executor: 0,
    critic: 0,
    refiner: 0,
    validator: 0,
    errors: 0,
    loops: 0,

    queue: 0,
    dropped: 0,

    lastInput: "",
    lastOutput: "",
    lastScore: 0,
    lastModel: "",

    tokens: 0,
    streamChunks: 0,

    traces: []
};

// ======================================================
// 📋 FEATURES
// ======================================================
const FEATURES = {
    planner: true,
    executor: true,
    critic: true,
    refiner: true,
    validator: true,
    memory: true,
    streaming: true,
    event_bus: true,
    queue_scheduler: true,
    regression_test: true,
    file_writer: true,
    runtime_trace: true,
    fallback_model: true
};

// ======================================================
// 📋 FEATURE CHECKLIST
// ======================================================
function featureChecklist() {
    console.log("\n📋 FEATURE CHECKLIST");

    let ok = 0;

    for (const [k, v] of Object.entries(FEATURES)) {
        console.log(v ? "✅" : "❌", k);
        if (v) ok++;
    }

    console.log("────────────────────");
    console.log(`STATUS: ${ok}/${Object.keys(FEATURES).length}`);
}

// ======================================================
// ⚙️ RUNTIME BEHAVIOR
// ======================================================
function runtimeBehavior() {
    const uptime = ((Date.now() - runtime.start) / 1000).toFixed(2);

    console.log("\n🧠 RUNTIME SNAPSHOT");
    console.log({
        uptime: uptime + "s",
        requests: runtime.requests,
        planner: runtime.planner,
        executor: runtime.executor,
        critic: runtime.critic,
        refiner: runtime.refiner,
        validator: runtime.validator,
        loops: runtime.loops,
        errors: runtime.errors,
        queue: runtime.queue,
        dropped: runtime.dropped,
        tokens: runtime.tokens,
        chunks: runtime.streamChunks,
        model: runtime.lastModel,
        score: runtime.lastScore
    });
}

// ======================================================
// 🧠 MODEL ROUTER
// ======================================================
function chooseModel(input) {
    const t = input.toLowerCase();

    if (input.length > 120) return MODEL_SMART;
    if (t.includes("system") || t.includes("architecture")) return MODEL_SMART;

    return MODEL_FAST;
}

// ======================================================
// 🌐 SAFE FETCH
// ======================================================
async function safeFetch(model, messages) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 20000);

    const res = await fetch(URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: controller.signal,
        body: JSON.stringify({
            model,
            messages,
            stream: true
        })
    });

    clearTimeout(timer);

    if (!res.ok) throw new Error("HTTP_FAIL");
    return res;
}

// ======================================================
// 🌊 STREAM ENGINE (FIXED NON-BLOCK)
// ======================================================
async function streamRead(res) {
    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";
    let output = "";
    let chunk = "";

    runtime.streamChunks = 0;

    while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n");
        buffer = lines.pop();

        for (const line of lines) {
            const clean = line.trim();
            if (!clean) continue;

            try {
                const json = JSON.parse(clean);
                const text = json?.message?.content || "";

                if (text) {
                    chunk += text;
                    output += text;

                    runtime.tokens++;
                    runtime.streamChunks++;

                    if (chunk.length > 60) {
                        process.stdout.write(chunk);
                        chunk = "";
                    }
                }
            } catch {
                runtime.errors++;
            }
        }
    }

    if (chunk) process.stdout.write(chunk);
    process.stdout.write("\n");

    return output;
}

// ======================================================
// 🧠 PLANNER (AGENT STYLE)
// ======================================================
function planner(input) {
    runtime.planner++;

    const t = input.toLowerCase();

    const plan = {
        id: crypto.randomUUID(),
        intent: "chat",
        steps: []
    };

    if (t.includes("code")) plan.intent = "code";
    if (t.includes("system")) plan.intent = "architecture";
    if (t.includes("debug")) plan.intent = "debug";

    plan.steps = [
        "interpret",
        "generate",
        "validate"
    ];

    runtime.traces.push({ type: "plan", plan });

    return plan;
}

// ======================================================
// ⚙️ EXECUTOR
// ======================================================
async function executor(input, plan) {
    runtime.executor++;

    const messages = Memory.retrieve(input);

    messages.push({ role: "system", content: JSON.stringify(plan) });
    messages.push({ role: "user", content: input });

    const model = chooseModel(input);

    runtime.lastModel = model;

    const res = await safeFetch(model, messages);

    return await streamRead(res);
}

// ======================================================
// 🧠 CRITIC
// ======================================================
function critic(output) {
    runtime.critic++;

    let score = 0;

    if (!output) return 0;
    if (output.length > 80) score++;
    if (!output.includes("error")) score++;
    if (!output.includes("undefined")) score++;
    if (output.includes(".")) score++;
    if (output.split("\n").length > 2) score++;

    return score;
}

// ======================================================
// 🔁 REFINER LOOP
// ======================================================
async function refiner(input, output, plan) {
    runtime.refiner++;

    const oldScore = critic(output);

    const res = await safeFetch(MODEL_SMART, [
        { role: "system", content: "Improve response quality." },
        { role: "system", content: JSON.stringify(plan) },
        { role: "user", content: input },
        { role: "assistant", content: output }
    ]);

    const improved = await streamRead(res);

    const newScore = critic(improved);

    return newScore > oldScore ? improved : output;
}

// ======================================================
// ✅ VALIDATOR
// ======================================================
function validator(output) {
    runtime.validator++;

    const score = critic(output);

    return {
        pass: score >= 4,
        score
    };
}

// ======================================================
// 🧠 AGENT PIPELINE (CORE)
// ======================================================
async function runAgent(input) {
    runtime.requests++;
    runtime.lastInput = input;

    const plan = planner(input);

    let output = await executor(input, plan);

    let score = critic(output);

    let loop = 0;

    while (score < 4 && loop < 3) {
        output = await refiner(input, output, plan);
        score = critic(output);
        loop++;
        runtime.loops++;
    }

    const result = validator(output);

    runtime.lastScore = result.score;
    runtime.lastOutput = output;

    Memory.add("user", input);
    Memory.add("assistant", output);
    Memory.summarize();

    return output;
}

// ======================================================
// 📁 PROJ SYSTEM (UNCHANGED)
// ======================================================
function writeProj(content) {
    const dir = path.join(process.cwd(), "Proj");
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    const file = path.join(dir, `Proj_${Date.now()}.txt`);
    fs.writeFileSync(file, content, "utf8");

    EventBus.emit("file:write", file);
    return file;
}

// ======================================================
// 🧪 REGRESSION TEST
// ======================================================
async function regressionTest() {
    console.log("\n🧪 REGRESSION TEST");

    const tests = [
        () => planner("test"),
        () => typeof executor === "function",
        () => typeof critic === "function",
        () => typeof validator === "function",
        () => typeof runAgent === "function",
        () => Memory.short !== undefined,
        () => EventBus.events.length >= 0
    ];

    let pass = 0;

    for (const t of tests) {
        try {
            if (t()) pass++;
        } catch {
            runtime.errors++;
        }
    }

    console.log(`RESULT: ${pass}/${tests.length}`);

    await runAgent("system test");
}

// ======================================================
// 🧠 CLI (FIXED QUEUE + NO LAG)
// ======================================================
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

let queue = [];
let running = false;

async function tick() {
    if (running) return;
    const input = queue.shift();
    if (!input) return;

    running = true;

    try {
        if (input === "/check") featureChecklist();
        else if (input === "/runtime") runtimeBehavior();
        else if (input === "/test") await regressionTest();
        else if (input === "exit") rl.close();
        else {
            const out = await runAgent(input);
            console.log("\n🧠 FINAL OUTPUT:\n");
            console.log(out);
        }
    } catch (e) {
        runtime.errors++;
        console.log("❌ ERROR:", e.message);
    }

    running = false;
    setImmediate(tick);
}

rl.on("line", (input) => {
    input = (input || "").trim();

    if (!input) {
        runtime.dropped++;
        return;
    }

    runtime.queue++;
    queue.push(input);
    tick();
});

rl.on("close", () => process.exit(0));