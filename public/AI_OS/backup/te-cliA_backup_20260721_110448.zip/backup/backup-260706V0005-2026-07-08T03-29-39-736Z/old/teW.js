const readline = require("readline");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const config = require("./config/config");
const VersionManager = require("./core/version");

// ======================================================
// 🧠 AI COGNITIVE KERNEL v8 S+ (STABLE FIXED VERSION)
// ======================================================

console.log("🧠 AI COGNITIVE KERNEL v8 S+ STARTED");

// ======================================================
// 🤖 MODEL CONFIG
// ======================================================
const URL = config.URL;
const MODEL_FAST = config.MODEL_FAST;
const MODEL_SMART = config.MODEL_SMART;

let ACTIVE_MODEL = MODEL_FAST;

// ======================================================
// 📦 VERSION SYSTEM
// ======================================================
const version = new VersionManager(config);

// ======================================================
// 🧠 MEMORY SYSTEM
// ======================================================
const Memory = {
    store: [],
    max: 50,

    add(entry) {
        this.store.push({
            ...entry,
            time: Date.now()
        });

        if (this.store.length > this.max) {
            this.store.shift();
        }
    },

    score(a, b) {
        const A = a.toLowerCase();
        const B = b.toLowerCase();
        let s = 0;
        for (const w of A.split(" ")) {
            if (B.includes(w)) s++;
        }
        return s;
    },

    retrieve(query) {
        return this.store
            .map(x => ({
                role: x.role,
                content: x.content,
                score: this.score(query, x.content || "")
            }))
            .sort((a, b) => b.score - a.score)
            .slice(0, 8)
            .map(x => ({ role: x.role, content: x.content }));
    },

    export() {
        return this.store.map(x => ({
            role: x.role,
            content: x.content
        }));
    }
};

// ======================================================
// 📊 RUNTIME STATE
// ======================================================
const runtime = {
    start: Date.now(),
    requests: 0,
    planner: 0,
    executor: 0,
    critic: 0,
    refiner: 0,
    validator: 0,
    errors: 0,
    loops: 0,
    lastScore: 0,
    lastInput: "",
    lastOutput: "",
    tokens: 0
};

// ======================================================
// 📋 FEATURES
// ======================================================
const FEATURES = {
    planner: true,
    executor: true,
    critic: true,
    refiner_loop: true,
    validator: true,
    memory_system: true,
    stream_engine: true,
    file_writer: true,
    regression_test: true,
    runtime_monitor: true,
    self_correction: true,
    memory_retrieval: true,
    plan_enforcement: true,
    cli_stability_fix: true
};

// ======================================================
// 📋 FEATURE CHECKLIST
// ======================================================
function featureChecklist() {
    console.log("\n📋 FEATURE CHECKLIST");

    let ok = 0;

    for (const [k, v] of Object.entries(FEATURES)) {
        console.log(v ? "✅" : "❌", k);
        if (v) ok++;
    }

    console.log("────────────────────");
    console.log(`STATUS: ${ok}/${Object.keys(FEATURES).length}`);
}

// ======================================================
// ⚙️ RUNTIME BEHAVIOR
// ======================================================
function runtimeBehavior() {
    const uptime = ((Date.now() - runtime.start) / 1000).toFixed(2);

    console.log("\n🧠 RUNTIME SNAPSHOT");
    console.log({
        uptime: uptime + "s",
        requests: runtime.requests,
        planner: runtime.planner,
        executor: runtime.executor,
        critic: runtime.critic,
        refiner: runtime.refiner,
        validator: runtime.validator,
        loops: runtime.loops,
        errors: runtime.errors,
        lastScore: runtime.lastScore,
        memory_size: Memory.store.length
    });
}

// ======================================================
// 🧠 MODEL ROUTER
// ======================================================
function chooseModel(input) {
    const t = input.toLowerCase();

    if (input.length > 120) return MODEL_SMART;
    if (t.includes("debug") || t.includes("system") || t.includes("architecture")) return MODEL_SMART;

    return MODEL_FAST;
}

// ======================================================
// 🌐 SAFE FETCH
// ======================================================
async function safeFetch(model, messages) {
    const res = await fetch(URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            model,
            messages,
            stream: true
        })
    });

    if (!res.ok) throw new Error("HTTP_FAIL");

    return res;
}

// ======================================================
// 🌊 STREAM ENGINE
// ======================================================
async function streamRead(res) {
    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";
    let output = "";
    let chunk = "";

    while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n");
        buffer = lines.pop();

        for (const line of lines) {
            const clean = line.trim();
            if (!clean) continue;

            try {
                const json = JSON.parse(clean);
                const text = json?.message?.content || "";

                if (text) {
                    chunk += text;
                    output += text;
                    runtime.tokens++;

                    if (chunk.length > 100) {
                        process.stdout.write(chunk);
                        chunk = "";
                    }
                }
            } catch {
                runtime.errors++;
            }
        }
    }

    if (chunk) process.stdout.write(chunk);
    console.log("\n");

    return output;
}

// ======================================================
// 🧠 PIPELINE FUNCTIONS (UNCHANGED LOGIC)
// ======================================================
function planner(input) {
    runtime.planner++;

    const t = input.toLowerCase();

    const plan = {
        intent: "chat",
        complexity: "low",
        steps: []
    };

    if (t.includes("code")) plan.intent = "code";
    if (t.includes("system") || t.includes("architecture")) plan.intent = "architecture";

    plan.steps = ["understand", "generate", "validate"];

    return plan;
}

async function executor(input, plan) {
    runtime.executor++;

    const messages = Memory.export();
    messages.push({ role: "system", content: JSON.stringify(plan) });
    messages.push({ role: "user", content: input });

    const res = await safeFetch(MODEL_FAST, messages);
    return await streamRead(res);
}

function critic(output) {
    runtime.critic++;

    let score = 0;
    if (!output) return 0;

    if (output.length > 100) score++;
    if (!output.includes("undefined")) score++;
    if (!output.includes("error")) score++;
    if (output.includes(".")) score++;
    if (output.split("\n").length > 2) score++;

    return score;
}

async function refiner(input, output, plan) {
    runtime.refiner++;

    const oldScore = critic(output);

    const messages = [
        { role: "system", content: "Improve response quality." },
        { role: "system", content: JSON.stringify(plan) },
        { role: "user", content: input },
        { role: "assistant", content: output }
    ];

    const res = await safeFetch(MODEL_SMART, messages);
    const improved = await streamRead(res);

    const newScore = critic(improved);

    return newScore > oldScore ? improved : output;
}

function validator(output) {
    runtime.validator++;
    return { pass: critic(output) >= 4, score: critic(output) };
}

async function runKernel(input) {
    runtime.requests++;
    runtime.lastInput = input;

    const plan = planner(input);

    let output = await executor(input, plan);

    let score = critic(output);

    let guard = 0;

    while (score < 4 && guard < 2) {
        const newOut = await refiner(input, output, plan);
        const newScore = critic(newOut);

        if (newScore > score) {
            output = newOut;
            score = newScore;
        }

        guard++;
        runtime.loops++;
    }

    runtime.lastScore = score;
    runtime.lastOutput = output;

    return output;
}

// ======================================================
// 📁 FILE WRITER
// ======================================================
function writeFile(content) {
    const dir = path.join(process.cwd(), "Proj");
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    const file = path.join(dir, `Proj_${Date.now()}.txt`);
    fs.writeFileSync(file, content, "utf8");

    console.log("📁 FILE CREATED:", file);
}

// ======================================================
// 🧪 REGRESSION TEST
// ======================================================
async function regressionTest() {
    console.log("\n🧪 REGRESSION TEST");

    const tests = [
        () => planner("test"),
        () => typeof executor === "function",
        () => critic("ok"),
        () => validator("ok"),
        () => Memory.store.length >= 0
    ];

    let pass = 0;

    for (const t of tests) {
        try {
            if (t()) pass++;
        } catch {
            runtime.errors++;
        }
    }

    console.log(`RESULT: ${pass}/${tests.length}`);

    await runKernel("system test");
}

// ======================================================
// 🧠 CLI (FIXED - NO MORE LOOP FLOOD)
// ======================================================
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

let isRunning = false; // 🔥 FIX: prevent double execution

function loop() {
    rl.question("KERNEL-v8-S+ > ", async (input) => {

        input = (input || "").trim();

        // ✅ FIX 1: ignore empty input safely
        if (input.length === 0) {
            return setImmediate(loop);
        }

        // ✅ FIX 2: prevent re-entry
        if (isRunning) {
            console.log("⏳ processing...");
            return setImmediate(loop);
        }

        isRunning = true;

        try {
            if (input === "/check") {
                featureChecklist();
                return setImmediate(loop);
            }

            if (input === "/runtime") {
                runtimeBehavior();
                return setImmediate(loop);
            }

            if (input === "/test") {
                await regressionTest();
                return setImmediate(loop);
            }

            if (input === "exit") {
                rl.close();
                return;
            }

            const output = await runKernel(input);

            console.log("\n🧠 FINAL OUTPUT:\n");
            console.log(output);

        } catch (err) {
            runtime.errors++;
            console.log("❌ ERROR:", err.message);
        }

        isRunning = false;

        setImmediate(loop);
    });
}

loop();

rl.on("close", () => process.exit(0));