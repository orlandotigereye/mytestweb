const readline = require("readline");
const fs = require("fs");
const path = require("path");

const config = require("./config/config");
const VersionManager = require("./core/version");

// ======================================================
// 🤖 MODEL CONFIG (FAST ENGINE OPTIMIZED)
// ======================================================
const URL = config.URL;

const MODEL_FAST = config.MODEL_FAST;   // 3B
const MODEL_SMART = config.MODEL_SMART; // 7B

let ACTIVE_MODEL = MODEL_SMART;

console.log("🚀 TE OS FAST ENGINE v1 STARTED");

// ======================================================
// 📦 VERSION SYSTEM
// ======================================================
const version = new VersionManager(config);

// ======================================================
// ⚙️ RUNTIME STATE (FAST OPTIMIZED)
// ======================================================
const runtime = {
    start: Date.now(),
    requests: 0,
    files: 0,
    errors: 0,
    lastInput: "",
    lastLatency: 0
};

// ======================================================
// 📋 FEATURES
// ======================================================
const FEATURES = {
    ai_stream_fast: true,
    zero_copy_parser: true,
    batch_output: true,
    auto_model_fallback: true,
    runtime_monitor: true,
    regression_test: true
};

// ======================================================
// 🧠 FEATURE CHECKLIST
// ======================================================
function featureChecklist() {
    console.log("\n📋 FEATURE CHECKLIST");
    console.log("────────────────────");

    let ok = 0;
    const total = Object.keys(FEATURES).length;

    for (const [k, v] of Object.entries(FEATURES)) {
        console.log(v ? "✅" : "❌", k);
        if (v) ok++;
    }

    console.log("────────────────────");
    console.log(`📦 STATUS: ${ok}/${total} ACTIVE`);

    const health = (ok / total) * 100;

    if (health >= 90) console.log("🟢 FAST ENGINE: EXCELLENT");
    else if (health >= 70) console.log("🟡 FAST ENGINE: GOOD");
    else console.log("🔴 FAST ENGINE: DEGRADED");

    console.log("");
}

// ======================================================
// ⚙️ RUNTIME BEHAVIOR (LIGHTWEIGHT)
// ======================================================
function runtimeBehavior() {
    const uptime = ((Date.now() - runtime.start) / 1000).toFixed(2);

    console.log("\n⚙️ RUNTIME (FAST)");
    console.log("────────────────────");
    console.log("⏱ uptime:", uptime + "s");
    console.log("📨 req:", runtime.requests);
    console.log("📁 files:", runtime.files);
    console.log("❌ errors:", runtime.errors);
    console.log("⏱ latency:", runtime.lastLatency + "ms");
    console.log("🤖 model:", ACTIVE_MODEL);
    console.log("────────────────────\n");
}

// ======================================================
// 🧪 REGRESSION TEST (LIGHTWEIGHT)
// ======================================================
function regressionTest() {
    console.log("\n🧪 FAST TEST");
    console.log("────────────────────");

    const tests = [
        { name: "features", fn: () => FEATURES },
        { name: "runtime", fn: () => runtime },
        { name: "fs", fn: () => fs.existsSync(__dirname) },
        { name: "version", fn: () => typeof version.current === "function" },
        { name: "model", fn: () => typeof ACTIVE_MODEL === "string" }
    ];

    let pass = 0;

    for (const t of tests) {
        try {
            const ok = t.fn();
            console.log(ok ? "✅" : "❌", t.name);
            if (ok) pass++;
        } catch {
            runtime.errors++;
            console.log("❌", t.name);
        }
    }

    console.log("────────────────────");
    console.log(`📊 RESULT: ${pass}/${tests.length}`);

    console.log(pass === tests.length
        ? "🟢 FAST ENGINE OK"
        : "🟡 FAST ENGINE WARNING"
    );

    console.log("");
}

// ======================================================
// 🤖 ULTRA FAST MODEL ROUTER
// ======================================================
function chooseModel(input, latency = 0) {
    const len = input.length;

    // ❗ HARD RULE: SPEED FIRST
    if (latency > 3000) return MODEL_FAST;

    // short query → always fast model
    if (len < 40) return MODEL_FAST;

    // long or complex → smart model
    return MODEL_SMART;
}

// ======================================================
// ⚡ ULTRA FAST AI STREAM ENGINE
// ======================================================
async function askAI(input) {
    runtime.requests++;
    runtime.lastInput = input;

    const start = Date.now();

    ACTIVE_MODEL = MODEL_SMART;

    let res;

    try {
        res = await fetch(URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                model: ACTIVE_MODEL,
                messages: [
                    { role: "system", content: "You are TE OS FAST ENGINE." },
                    { role: "user", content: input }
                ],
                stream: true
            })
        });
    } catch (e) {
        runtime.errors++;
        ACTIVE_MODEL = MODEL_FAST;

        res = await fetch(URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                model: MODEL_FAST,
                messages: [
                    { role: "system", content: "You are TE OS FAST ENGINE." },
                    { role: "user", content: input }
                ],
                stream: true
            })
        });
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";
    let outputBuffer = "";
    let full = "";

    process.stdout.write(`\n🤖 [${ACTIVE_MODEL}] `);

    while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n");
        buffer = lines.pop();

        for (let i = 0; i < lines.length; i++) {
            const line = lines[i].trim();
            if (!line) continue;

            try {
                const json = JSON.parse(line);

                const text =
                    json?.message?.content || "";

                if (text) {
                    outputBuffer += text;
                    full += text;

                    // 🚀 batch output (FAST BOOST)
                    if (outputBuffer.length >= 20) {
                        process.stdout.write(outputBuffer);
                        outputBuffer = "";
                    }
                }
            } catch {
                runtime.errors++;
            }
        }
    }

    if (outputBuffer.length) {
        process.stdout.write(outputBuffer);
    }

    console.log("\n");

    runtime.lastLatency = Date.now() - start;

    ACTIVE_MODEL = chooseModel(input, runtime.lastLatency);

    return full;
}

// ======================================================
// 📁 FAST FILE SYSTEM
// ======================================================
function writeFileSafe(filePath, content) {
    const fullPath = path.resolve(process.cwd(), filePath);

    fs.mkdirSync(path.dirname(fullPath), { recursive: true });

    if (fs.existsSync(fullPath)) {
        fs.copyFileSync(fullPath, fullPath + ".bak");
    }

    fs.writeFileSync(fullPath, content, "utf8");

    runtime.files++;
    console.log("✔ FILE:", fullPath);
}

// ======================================================
// 📁 FAST PARSER (LESS REGEX COST)
// ======================================================
function parseAndWriteFiles(output) {
    if (!output) return;

    const fileRegex = /FILE:\s*(.+)\nCODE:\n([\s\S]*?)(?=\nFILE:|$)/g;

    let match;
    while ((match = fileRegex.exec(output)) !== null) {
        writeFileSafe(match[1].trim(), match[2]);
    }
}

// ======================================================
// 🧠 CLI (FAST LOOP)
// ======================================================
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function loop() {
    rl.question("TE > ", async (input) => {
        if (!input) return loop();

        if (input === "/check") {
            featureChecklist();
            return loop();
        }

        if (input === "/runtime") {
            runtimeBehavior();
            return loop();
        }

        if (input === "/test") {
            regressionTest();
            return loop();
        }

        if (input === "/version") {
            console.log(version.current());
            return loop();
        }

        if (input === "exit") {
            rl.close();
            return;
        }

        console.log("⚡ FAST THINKING...");

        const result = await askAI(input);

        parseAndWriteFiles(result);

        loop();
    });
}

loop();

rl.on("close", () => process.exit(0));