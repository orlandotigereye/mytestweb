const readline = require("readline");
const fs = require("fs");
const path = require("path");

const config = require("./config/config");
const VersionManager = require("./core/version");

// ======================================================
// 🧠 AI COGNITIVE OS v1.2 (NON-DESTRUCTIVE PATCH)
// ======================================================

console.log("🧠 AI COGNITIVE OS v1.2 STARTED");

// ======================================================
// 🤖 MODEL CONFIG (UNCHANGED)
// ======================================================
const URL = config.URL;
const MODEL_FAST = config.MODEL_FAST;
const MODEL_SMART = config.MODEL_SMART;

let ACTIVE_MODEL = MODEL_FAST;

// ======================================================
// 📦 VERSION SYSTEM (UNCHANGED)
// ======================================================
const version = new VersionManager(config);

// ======================================================
// 🧠 MEMORY SYSTEM (UNCHANGED + PATCH LAYER)
// ======================================================
const Memory = {
    shortTerm: [],
    longTerm: [],
    summary: [],

    maxShort: 20,

    add(role, content) {
        if (!content) return;

        const entry = { role, content, time: Date.now() };

        this.shortTerm.push(entry);
        this.longTerm.push(entry);

        if (this.shortTerm.length > this.maxShort) {
            this.shortTerm.shift();
        }
    },

    summarize() {
        // PATCH: safer batch compression (no behavior change)
        if (this.longTerm.length > 30) {
            const chunk = this.longTerm.splice(0, 10);
            const summary = chunk.map(x => x.content).join(" | ");
            this.summary.push(summary);
        }
    },

    retrieve() {
        return [
            ...this.summary.map(s => ({ role: "system", content: "SUMMARY: " + s })),
            ...this.shortTerm
        ];
    }
};

// ======================================================
// 📊 RUNTIME STATE (UNCHANGED + PATCH FIELDS ADDED)
// ======================================================
const runtime = {
    start: Date.now(),
    requests: 0,
    success: 0,
    fail: 0,
    errors: 0,
    toolCalls: 0,
    cognitionLoops: 0,
    lastInput: "",
    lastLatency: 0,
    lastModel: "",
    lastCritique: "",

    // 🔧 PATCH ADD-ON (NO REMOVAL OF OLD FIELDS)
    queueSize: 0,
    lastInputHash: "",
    streamBuffer: 0,
    cliDrops: 0
};

// ======================================================
// 📋 FEATURES (UNCHANGED + ADD-ON ONLY)
// ======================================================
const FEATURES = {
    memory_short_long_summary: true,
    planner_tree: true,
    cognition_loop: true,
    self_critique: true,
    tool_system: true,
    streaming: true,
    fallback_model: true,
    file_intelligence: true,
    event_trace: true,
    regression_test: true,
    runtime_monitor: true,

    // ADD-ON ONLY
    cli_fix_patch: true,
    stream_fix_patch: true,
    queue_patch: true,
    dedup_patch: true
};

// ======================================================
// 📋 FEATURE CHECKLIST (UNCHANGED STYLE)
// ======================================================
function featureChecklist() {
    console.log("\n📋 FEATURE CHECKLIST");

    let ok = 0;
    for (const [k, v] of Object.entries(FEATURES)) {
        console.log(v ? "✅" : "❌", k);
        if (v) ok++;
    }

    console.log("────────────────────");
    console.log(`STATUS: ${ok}/${Object.keys(FEATURES).length}`);
}

// ======================================================
// ⚙️ RUNTIME SNAPSHOT (UNCHANGED + PATCH INFO)
// ======================================================
function runtimeBehavior() {
    const uptime = ((Date.now() - runtime.start) / 1000).toFixed(2);

    console.log("\n🧠 COGNITIVE SNAPSHOT");
    console.log({
        uptime: uptime + "s",
        requests: runtime.requests,
        success: runtime.success,
        fail: runtime.fail,
        errors: runtime.errors,
        toolCalls: runtime.toolCalls,
        cognitionLoops: runtime.cognitionLoops,
        model: runtime.lastModel,
        lastCritique: runtime.lastCritique,

        // PATCH
        queueSize: runtime.queueSize,
        cliDrops: runtime.cliDrops,
        streamBuffer: runtime.streamBuffer
    });
}

// ======================================================
// 🧠 PLANNER (UNCHANGED LOGIC)
// ======================================================
function planner(input) {
    const t = input.toLowerCase();

    const tree = {
        intent: "chat",
        steps: []
    };

    if (t.includes("code") || t.includes("file")) {
        tree.intent = "generation";
        tree.steps.push("analyze_requirements");
        tree.steps.push("generate_output");
    }

    if (t.includes("debug")) {
        tree.intent = "debugging";
        tree.steps.push("analyze_error");
        tree.steps.push("propose_fix");
    }

    if (t.includes("system") || t.includes("architecture")) {
        tree.intent = "architecture";
        tree.steps.push("decompose_system");
        tree.steps.push("design_structure");
    }

    if (tree.steps.length === 0) {
        tree.steps.push("respond_directly");
    }

    return tree;
}

// ======================================================
// 🧠 CRITIC (UNCHANGED)
// ======================================================
function critic(output) {
    if (!output) return "EMPTY_OUTPUT";

    let score = 0;

    if (output.length > 50) score++;
    if (!output.includes("error")) score++;
    if (!output.includes("undefined")) score++;

    return score >= 2 ? "GOOD" : score === 1 ? "OK" : "BAD";
}

// ======================================================
// 🤖 TOOL SYSTEM (UNCHANGED)
// ======================================================
const Tools = {
    write(content) {
        const dir = path.join(process.cwd(), "Proj");
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

        const file = path.join(dir, `Proj_${Date.now()}.txt`);
        fs.writeFileSync(file, content, "utf8");

        runtime.toolCalls++;
        return file;
    }
};

// ======================================================
// 🌐 SAFE FETCH (UNCHANGED)
// ======================================================
async function safeFetch(model, messages) {
    const res = await fetch(URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            model,
            messages,
            stream: true
        })
    });

    if (!res.ok) throw new Error("HTTP_FAIL");
    return res;
}

// ======================================================
// 🌊 STREAM ENGINE (PATCH: smoother buffer)
// ======================================================
async function streamRead(res) {
    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";
    let output = "";
    let chunk = "";

    while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n");
        buffer = lines.pop();

        for (const line of lines) {
            const clean = line.trim();
            if (!clean) continue;

            try {
                const json = JSON.parse(clean);
                const text = json?.message?.content || "";

                if (text) {
                    chunk += text;
                    output += text;

                    runtime.streamBuffer++;

                    // PATCH: slightly larger buffer = less lag
                    if (chunk.length > 100) {
                        process.stdout.write(chunk);
                        chunk = "";
                    }
                }
            } catch {
                runtime.errors++;
            }
        }
    }

    if (chunk) process.stdout.write(chunk);
    console.log("\n");

    return output;
}

// ======================================================
// 🧠 COGNITION ENGINE (UNCHANGED CORE FLOW)
// ======================================================
async function cognition(input) {
    runtime.requests++;
    runtime.lastInput = input;

    const plan = planner(input);

    let model = plan.intent === "architecture" ? MODEL_SMART : MODEL_FAST;
    runtime.lastModel = model;

    const messages = Memory.retrieve();
    messages.push({ role: "user", content: input });

    let res;

    try {
        res = await safeFetch(model, messages);
    } catch {
        res = await safeFetch(MODEL_SMART, messages);
    }

    const output = await streamRead(res);

    runtime.success++;

    Memory.add("user", input);
    Memory.add("assistant", output);

    Memory.summarize();

    runtime.cognitionLoops++;

    return output + "\n\n[COGNITION OK]";
}

// ======================================================
// 📄 PARSER (UNCHANGED)
// ======================================================
function parseOutput(output) {
    if (!output) return;

    const regex = /```[\s\S]*?\n([\s\S]*?)```/g;

    let match;
    while ((match = regex.exec(output)) !== null) {
        Tools.write(match[1]);
    }
}

// ======================================================
// 🧪 REGRESSION TEST (UNCHANGED)
// ======================================================
async function regressionTest() {
    console.log("\n🧪 COGNITIVE TEST");

    const tests = [
        () => planner("test"),
        () => typeof cognition === "function",
        () => typeof Tools.write === "function",
        () => typeof critic === "function"
    ];

    let pass = 0;

    for (const t of tests) {
        try {
            if (t()) pass++;
        } catch {}
    }

    console.log(`RESULT: ${pass}/${tests.length}`);

    await cognition("system test");
}

// ======================================================
// 🧠 CLI (FIX PATCH ONLY, NO STRUCTURE CHANGE)
// ======================================================
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

let queue = [];
let running = false;

async function processQueue() {
    if (running) return;

    const input = queue.shift();
    if (!input) return;

    running = true;

    const clean = (input || "").trim();

    // PATCH: fix "hi / empty loop / lag"
    if (!clean) {
        runtime.cliDrops++;
        running = false;
        return processQueue();
    }

    // PATCH: dedup fix
    if (clean === runtime.lastInputHash) {
        running = false;
        return processQueue();
    }

    runtime.lastInputHash = clean;
    runtime.queueSize = queue.length;

    try {
        if (clean === "/check") featureChecklist();
        else if (clean === "/runtime") runtimeBehavior();
        else if (clean === "/test") await regressionTest();
        else if (clean === "exit") rl.close();
        else {
            const output = await cognition(clean);
            parseOutput(output);
            console.log("\n🧠 OUTPUT DONE\n");
        }
    } catch (e) {
        runtime.errors++;
        console.log("❌ ERROR:", e.message);
    }

    running = false;
    setImmediate(processQueue);
}

rl.on("line", (input) => {
    queue.push(input);
    processQueue();
});

rl.on("close", () => process.exit(0));