const readline = require("readline");
const fs = require("fs");
const path = require("path");

const config = require("./config/config");
const VersionManager = require("./core/version");

// ======================================================
// 🚀 Production AI CLI Engine v4.5 FULL HARDENED
// ======================================================

console.log("🚀 Production AI CLI Engine v4.5 STARTED");

// ======================================================
// 🤖 MODEL CONFIG
// ======================================================
const URL = config.URL;
const MODEL_FAST = config.MODEL_FAST;
const MODEL_SMART = config.MODEL_SMART;

let ACTIVE_MODEL = MODEL_FAST;

// ======================================================
// 📦 VERSION
// ======================================================
const version = new VersionManager(config);

// ======================================================
// 🧠 RUNTIME STATE (DEEP MONITOR)
// ======================================================
const runtime = {
    start: Date.now(),
    requests: 0,
    success: 0,
    fail: 0,
    files: 0,
    errors: 0,
    lastInput: "",
    lastLatency: 0,
    lastModel: "",
    lastError: null,
    streamChunks: 0
};

// ======================================================
// 📋 FEATURES
// ======================================================
const FEATURES = {
    streaming: true,
    fallback_model: true,
    retry_system: true,
    file_intelligence: true,
    response_parser: true,
    runtime_monitor: true,
    crash_guard: true,
    buffer_safety: true,
    dual_mode_ai: true
};

// ======================================================
// 📋 FEATURE CHECKLIST
// ======================================================
function featureChecklist() {
    console.log("\n📋 FEATURE CHECKLIST");
    console.log("────────────────────");

    let ok = 0;
    for (const [k, v] of Object.entries(FEATURES)) {
        console.log(v ? "✅" : "❌", k);
        if (v) ok++;
    }

    console.log("────────────────────");
    console.log(`STATUS: ${ok}/${Object.keys(FEATURES).length}`);
}

// ======================================================
// ⚙️ RUNTIME SNAPSHOT
// ======================================================
function runtimeBehavior() {
    const uptime = ((Date.now() - runtime.start) / 1000).toFixed(2);

    console.log("\n⚙️ RUNTIME SNAPSHOT");
    console.log({
        uptime: uptime + "s",
        requests: runtime.requests,
        success: runtime.success,
        fail: runtime.fail,
        files: runtime.files,
        errors: runtime.errors,
        lastLatency: runtime.lastLatency + "ms",
        model: runtime.lastModel,
        chunks: runtime.streamChunks
    });
}

// ======================================================
// 🧠 MODEL ROUTER (SMART + FAST HYBRID)
// ======================================================
function chooseModel(input, latency = 0) {
    const t = input.toLowerCase();

    if (latency > 2500) return MODEL_FAST;

    const heavy =
        input.length > 80 ||
        t.includes("system") ||
        t.includes("debug") ||
        t.includes("architecture") ||
        t.includes("build");

    return heavy ? MODEL_SMART : MODEL_FAST;
}

// ======================================================
// ⏱ TIMEOUT WRAPPER
// ======================================================
function timeout(ms) {
    return new Promise((_, reject) =>
        setTimeout(() => reject(new Error("TIMEOUT")), ms)
    );
}

// ======================================================
// 🌐 SAFE FETCH (STREAM + FALLBACK READY)
// ======================================================
async function safeFetch(model, input) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 20000);

    try {
        const res = await fetch(URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            signal: controller.signal,
            body: JSON.stringify({
                model,
                messages: [
                    { role: "system", content: "Production AI CLI Engine v4.5" },
                    { role: "user", content: input }
                ],
                stream: true
            })
        });

        clearTimeout(timer);

        if (!res.ok) throw new Error("HTTP_FAIL");

        return res;

    } catch (err) {
        clearTimeout(timer);
        throw err;
    }
}

// ======================================================
// 🤖 STREAM ENGINE (SAFE BUFFER)
// ======================================================
async function streamRead(res) {
    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";
    let output = "";
    let chunk = "";

    runtime.streamChunks = 0;

    while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n");
        buffer = lines.pop();

        for (const line of lines) {
            const clean = line.trim();
            if (!clean) continue;

            try {
                const json = JSON.parse(clean);
                const text = json?.message?.content || "";

                if (text) {
                    chunk += text;
                    output += text;
                    runtime.streamChunks++;

                    if (chunk.length > 80) {
                        process.stdout.write(chunk);
                        chunk = "";
                    }
                }

            } catch {
                runtime.errors++;
            }
        }
    }

    if (chunk) process.stdout.write(chunk);
    console.log("\n");

    return output;
}

// ======================================================
// 🤖 AI ENGINE (FULL FALLBACK CHAIN)
// ======================================================
async function askAI(input) {
    runtime.requests++;
    runtime.lastInput = input;

    const start = Date.now();

    let model = chooseModel(input);

    runtime.lastModel = model;

    let res;

    try {
        res = await safeFetch(model, input);
    } catch (err) {
        runtime.errors++;
        runtime.fail++;

        // fallback model
        model = MODEL_SMART === ACTIVE_MODEL ? MODEL_FAST : MODEL_SMART;

        try {
            res = await safeFetch(model, input);
        } catch (err2) {
            runtime.errors++;
            runtime.lastError = err2.message;
            console.log("❌ AI FAILED COMPLETELY");
            return "";
        }
    }

    let output = await streamRead(res);

    runtime.lastLatency = Date.now() - start;
    runtime.success++;

    ACTIVE_MODEL = model;

    return output;
}

// ======================================================
// 📁 FILE INTELLIGENCE LAYER
// ======================================================
function writeSmartFile(content) {
    const dir = path.join(process.cwd(), "Proj");
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    let type = "txt";

    if (content.includes("<html")) type = "html";
    else if (content.includes("function")) type = "js";
    else if (content.includes("{") && content.includes(":")) type = "json";

    const file = `Proj_${Date.now()}.${type}`;
    const filePath = path.join(dir, file);

    fs.writeFileSync(filePath, content, "utf8");

    runtime.files++;

    console.log("📁 SAVED:", filePath);

    return filePath;
}

// ======================================================
// 📄 RESPONSE PARSER (FILE + CODE BLOCKS)
// ======================================================
function parseOutput(output) {
    if (!output) return;

    // FILE: name / CODE:
    const fileRegex = /FILE:\s*(.+)\nCODE:\n([\s\S]*?)(?=\nFILE:|$)/g;

    let match;

    while ((match = fileRegex.exec(output)) !== null) {
        writeSmartFile(match[2]);
    }

    // markdown code blocks
    const mdRegex = /```[\w]*\n([\s\S]*?)```/g;

    while ((match = mdRegex.exec(output)) !== null) {
        writeSmartFile(match[1]);
    }
}

// ======================================================
// 🧪 REGRESSION TEST (FULL FLOW)
// ======================================================
function regressionTest() {
    console.log("\n🧪 REGRESSION TEST");

    const tests = [
        { name: "runtime", fn: () => typeof runtime === "object" },
        { name: "model_router", fn: () => typeof chooseModel === "function" },
        { name: "fetch", fn: () => typeof safeFetch === "function" },
        { name: "stream", fn: () => typeof streamRead === "function" },
        { name: "file_writer", fn: () => typeof writeSmartFile === "function" }
    ];

    let pass = 0;

    for (const t of tests) {
        try {
            const ok = t.fn();
            console.log(ok ? "✅" : "❌", t.name);
            if (ok) pass++;
        } catch {
            runtime.errors++;
        }
    }

    console.log(`RESULT: ${pass}/${tests.length}`);

    // real flow test
    askAI("test system flow");
}

// ======================================================
// 🧠 CLI LOOP (CRASH SAFE)
// ======================================================
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function loop() {
    rl.question("AI-v4.5 > ", async (input) => {
        try {
            if (!input) return loop();

            if (input === "/check") return (featureChecklist(), loop());
            if (input === "/runtime") return (runtimeBehavior(), loop());
            if (input === "/test") return (regressionTest(), loop());

            if (input === "exit") {
                rl.close();
                return;
            }

            const output = await askAI(input);

            parseOutput(output);

        } catch (err) {
            runtime.errors++;
            runtime.lastError = err.message;
            console.log("❌ CLI ERROR:", err.message);
        }

        loop();
    });
}

loop();

rl.on("close", () => process.exit(0));