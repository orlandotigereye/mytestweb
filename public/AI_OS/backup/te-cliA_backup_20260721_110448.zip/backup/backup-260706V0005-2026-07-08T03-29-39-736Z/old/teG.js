const readline = require("readline");
const fs = require("fs");
const path = require("path");

const config = require("./config/config");
const VersionManager = require("./core/version");

// ======================================================
// 🚀 FAST ENGINE v3 (PROJ OUTPUT SYSTEM)
// ======================================================

// ======================================================
// 🤖 MODEL CONFIG
// ======================================================
const URL = config.URL;

const MODEL_FAST = config.MODEL_FAST;
const MODEL_SMART = config.MODEL_SMART;

let ACTIVE_MODEL = MODEL_FAST;

console.log("🚀 TE OS FAST ENGINE v3 STARTED");

// ======================================================
// 📦 VERSION SYSTEM
// ======================================================
const version = new VersionManager(config);

// ======================================================
// 📁 PROJ OUTPUT SYSTEM
// ======================================================
const PROJ_DIR = path.join(process.cwd(), "Proj");

function getProjFileName(ext = "html") {
    const d = new Date();

    const yy = String(d.getFullYear()).slice(2);
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");

    const datePart = `${yy}${mm}${dd}`;

    if (!fs.existsSync(PROJ_DIR)) {
        fs.mkdirSync(PROJ_DIR, { recursive: true });
    }

    const files = fs.readdirSync(PROJ_DIR)
        .filter(f => f.startsWith(`Proj${datePart}`))
        .sort();

    let seq = 1;

    if (files.length > 0) {
        const last = files[files.length - 1];
        const match = last.match(/Proj\d{6}(\d{3})/);
        if (match) seq = parseInt(match[1], 10) + 1;
    }

    const seqStr = String(seq).padStart(3, "0");

    return path.join(PROJ_DIR, `Proj${datePart}${seqStr}.${ext}`);
}

// ======================================================
// ⚙️ RUNTIME STATE
// ======================================================
const runtime = {
    start: Date.now(),
    requests: 0,
    files: 0,
    errors: 0,
    lastInput: "",
    lastLatency: 0
};

// ======================================================
// 📋 FEATURES
// ======================================================
const FEATURES = {
    proj_file_system: true,
    auto_naming: true,
    batch_output: true,
    ultra_fast_stream: true,
    model_router: true,
    regression_test: true
};

// ======================================================
// 🧠 FEATURE CHECKLIST
// ======================================================
function featureChecklist() {
    console.log("\n📋 FEATURE CHECKLIST");
    console.log("────────────────────");

    let ok = 0;
    const total = Object.keys(FEATURES).length;

    for (const [k, v] of Object.entries(FEATURES)) {
        console.log(v ? "✅" : "❌", k);
        if (v) ok++;
    }

    console.log("────────────────────");
    console.log(`📦 STATUS: ${ok}/${total} ACTIVE`);

    const health = (ok / total) * 100;

    if (health >= 90) console.log("🟢 FAST ENGINE v3: EXCELLENT");
    else if (health >= 70) console.log("🟡 FAST ENGINE v3: GOOD");
    else console.log("🔴 FAST ENGINE v3: DEGRADED");

    console.log("");
}

// ======================================================
// ⚙️ RUNTIME BEHAVIOR
// ======================================================
function runtimeBehavior() {
    const uptime = ((Date.now() - runtime.start) / 1000).toFixed(2);

    console.log("\n⚙️ RUNTIME v3");
    console.log("────────────────────");
    console.log("⏱ uptime:", uptime + "s");
    console.log("📨 req:", runtime.requests);
    console.log("📁 files:", runtime.files);
    console.log("❌ errors:", runtime.errors);
    console.log("⏱ latency:", runtime.lastLatency + "ms");
    console.log("🤖 model:", ACTIVE_MODEL);
    console.log("────────────────────\n");
}

// ======================================================
// 🧪 REGRESSION TEST
// ======================================================
function regressionTest() {
    console.log("\n🧪 FAST TEST v3");
    console.log("────────────────────");

    const tests = [
        { name: "proj_system", fn: () => fs.existsSync(process.cwd()) },
        { name: "runtime", fn: () => typeof runtime === "object" },
        { name: "fs", fn: () => fs },
        { name: "model", fn: () => MODEL_FAST && MODEL_SMART },
        { name: "naming", fn: () => typeof getProjFileName === "function" }
    ];

    let pass = 0;

    for (const t of tests) {
        try {
            const ok = t.fn();
            console.log(ok ? "✅" : "❌", t.name);
            if (ok) pass++;
        } catch {
            runtime.errors++;
            console.log("❌", t.name);
        }
    }

    console.log("────────────────────");
    console.log(`📊 RESULT: ${pass}/${tests.length}`);

    console.log(pass === tests.length
        ? "🟢 v3 OK"
        : "🟡 v3 WARNING"
    );

    console.log("");
}

// ======================================================
// 🤖 MODEL ROUTER
// ======================================================
function chooseModel(input, latency = 0) {
    if (latency > 2500) return MODEL_FAST;

    const t = input.toLowerCase();

    const heavy =
        input.length > 70 ||
        t.includes("code") ||
        t.includes("system") ||
        t.includes("debug");

    return heavy ? MODEL_SMART : MODEL_FAST;
}

// ======================================================
// ⚡ ULTRA FAST STREAM ENGINE
// ======================================================
async function askAI(input) {
    runtime.requests++;
    runtime.lastInput = input;

    const start = Date.now();

    ACTIVE_MODEL = MODEL_FAST;

    let res;

    try {
        res = await fetch(URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                model: ACTIVE_MODEL,
                messages: [
                    { role: "system", content: "You are TE OS FAST ENGINE v3." },
                    { role: "user", content: input }
                ],
                stream: true
            })
        });
    } catch (e) {
        runtime.errors++;
        ACTIVE_MODEL = MODEL_SMART;

        res = await fetch(URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                model: MODEL_SMART,
                messages: [
                    { role: "system", content: "You are TE OS FAST ENGINE v3." },
                    { role: "user", content: input }
                ],
                stream: true
            })
        });
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";
    let output = "";
    let batch = "";

    process.stdout.write(`\n🤖 [${ACTIVE_MODEL}] `);

    while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n");
        buffer = lines.pop();

        for (let i = 0; i < lines.length; i++) {
            const line = lines[i].trim();
            if (!line) continue;

            let text = "";
            try {
                const json = JSON.parse(line);
                text = json?.message?.content || "";
            } catch {
                runtime.errors++;
            }

            if (text) {
                batch += text;
                output += text;

                if (batch.length >= 60) {
                    process.stdout.write(batch);
                    batch = "";
                }
            }
        }
    }

    if (batch.length) process.stdout.write(batch);

    console.log("\n");

    runtime.lastLatency = Date.now() - start;

    ACTIVE_MODEL = chooseModel(input, runtime.lastLatency);

    return output;
}

// ======================================================
// 📁 PROJ FILE WRITER (NEW REQUIREMENT)
// ======================================================
function writeProjFile(content, ext = "html") {
    const filePath = getProjFileName(ext);

    fs.writeFileSync(filePath, content, "utf8");

    runtime.files++;
    console.log("📁 PROJ CREATED:", filePath);

    return filePath;
}

// ======================================================
// 📁 PARSER → PROJ OUTPUT ONLY
// ======================================================
function parseAndWriteFiles(output) {
    if (!output) return;

    const fileRegex = /FILE:\s*(.+)\nCODE:\n([\s\S]*?)(?=\nFILE:|$)/g;

    let match;
    while ((match = fileRegex.exec(output)) !== null) {
        const fileName = match[1].trim();
        const code = match[2];

        // ❗ NEW RULE:
        // ALL OUTPUT GOES TO PROJ SYSTEM
        if (fileName.endsWith(".html")) {
            writeProjFile(code, "html");
        } else if (fileName.endsWith(".js")) {
            writeProjFile(code, "js");
        } else if (fileName.endsWith(".css")) {
            writeProjFile(code, "css");
        } else {
            writeProjFile(code, "txt");
        }
    }
}

// ======================================================
// 🧠 CLI
// ======================================================
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function loop() {
    rl.question("TE > ", async (input) => {
        if (!input) return loop();

        if (input === "/check") return (featureChecklist(), loop());
        if (input === "/runtime") return (runtimeBehavior(), loop());
        if (input === "/test") return (regressionTest(), loop());

        if (input === "/version") {
            console.log(version.current());
            return loop();
        }

        if (input === "exit") {
            rl.close();
            return;
        }

        console.log("⚡ FAST v3 THINKING...");

        const result = await askAI(input);

        parseAndWriteFiles(result);

        loop();
    });
}

loop();

rl.on("close", () => process.exit(0));