const path = require("path");
const fs = require("fs");

class Orchestrator {
    constructor(context) {
        this.config = context.config;
        this.ai = context.ai;
        this.memory = context.memory;
        this.fsManager = context.fsManager;
        this.projectManager = context.projectManager;
        this.wikiEngine = context.wikiEngine;
        this.ui = context.ui;
        this.runtime = context.runtime;
        this.activeModel = null;
        this.thinkingLog = [];
        
        // 進程守護安全機制 - 註冊全域退出事件，防止極端狀況下記憶與狀態流失
        this.setupProcessGuard();
    }

    /**
     * 掛載系統訊號監聽器，確保強制關閉時完成記憶體落盤
     */
    setupProcessGuard() {
        const safeShutdown = () => {
            console.log('\n💾 [System Guard] 偵測到中斷訊號，正在強制執行系統狀態與記憶圖譜存盤...');
            try {
                if (this.memory && typeof this.memory.save === 'function') {
                    this.memory.save();
                }
                if (this.projectManager && typeof this.projectManager.saveState === 'function') {
                    this.projectManager.saveState();
                }
                console.log('✅ [System Guard] 所有運行核心存盤完畢，安全退出系統。');
            } catch (e) {
                console.error('❌ [System Guard] 強制緊急存盤失敗:', e.message);
            }
            process.exit(0);
        };
        process.on('SIGINT', safeShutdown);
        process.on('SIGTERM', safeShutdown);
    }

    logThinking(step) {
        const entry = `[${new Date().toLocaleTimeString()}] ${step}`;
        this.thinkingLog.push(entry);
        console.log(`${this.ui.colors.gray}${entry}${this.ui.colors.reset}`);
        if (this.thinkingLog.length > 20) this.thinkingLog.shift();
    }

    /**
     * B案自動化核心：具備安全沙箱隔離與自適應副檔名偵測機制
     */
    executeAutoFileDrop(outputContent, allowFallback = true) {
        this.logThinking("B-Scheme: 啟動智慧文本掃描，檢索自動建檔標記...");
        let writeCount = 0;
        
        // 取得安全沙箱邊界根路徑
        const workspaceRoot = path.resolve(this.config.WORKSPACE_ROOT || process.cwd());

        // 1. 優先處理標準的 Search / Replace 結構區塊
        const blocks = this.fsManager.applySearchReplaceBlocks(outputContent);
        if (blocks.length > 0) {
            const edits = this.fsManager.applyEdits(blocks);
            this.logThinking(`B-Scheme: 已成功套用 ${edits} 個 Search-Replace 區塊修改。`);
            writeCount += edits;
        }

        // 2. 智慧掃描：捕獲帶有明示路徑標籤的代碼區塊
        const explicitFileRegex = /(?:File|檔案|Path|Filename)[:\s]*["']?([a-zA-Z0-9_\-\.\/\\:]+)["']?\s*\r?\n```[a-zA-Z0-9\s]*\r?\n([\s\S]*?)```/gi;
        let match;
        while ((match = explicitFileRegex.exec(outputContent)) !== null) {
            const targetPath = match[1].trim();
            const fileContent = match[2];
            
            // 安全沙箱路徑隔離驗證 (Workspace Sandboxing)
            const resolvedTarget = path.resolve(workspaceRoot, targetPath);
            if (!resolvedTarget.startsWith(workspaceRoot)) {
                console.error(`${this.ui.colors.red}[B案安全攔截] 偵測到越權路徑嘗試，已拒絕寫入沙箱外部：${targetPath}${this.ui.colors.reset}`);
                continue;
            }

            try {
                if (this.config.ATOMIC_WRITE_ENABLED) {
                    const dir = path.dirname(resolvedTarget);
                    if (!fs.existsSync(dir)) {
                        fs.mkdirSync(dir, { recursive: true });
                    }
                    const tmpPath = resolvedTarget + ".tmp";
                    fs.writeFileSync(tmpPath, fileContent, "utf8");
                    fs.renameSync(tmpPath, resolvedTarget);
                    this.logThinking(`B-Scheme [Atomic]: 自動感應並安全無損寫入沙箱區 -> ${resolvedTarget}`);
                } else {
                    this.fsManager.writeSmartFile(fileContent, resolvedTarget);
                    this.logThinking(`B-Scheme [Standard]: 自動感應並寫入至沙箱區 -> ${resolvedTarget}`);
                }
                writeCount++;
            } catch (e) {
                console.error(`${this.ui.colors.red}[B案寫入失敗] 無法安全寫入 ${resolvedTarget}: ${e.message}${this.ui.colors.reset}`);
            }
        }

        // 3. 安全後備方案：退化為自動歸類 + 智慧副檔名偵測
        if (writeCount === 0 && allowFallback) {
            const genericRegex = /```([a-zA-Z0-9_\-+]*)\r?\n([\s\S]*?)```/g;
            let m;
            while ((m = genericRegex.exec(outputContent)) !== null) {
                const langTag = m[1].toLowerCase().trim();
                const fallbackContent = m[2];
                
                // 智慧自適應副檔名對照
                let ext = "txt";
                if (["js", "javascript", "node"].includes(langTag)) ext = "js";
                else if (["html", "htm"].includes(langTag)) ext = "html";
                else if (["css"].includes(langTag)) ext = "css";
                else if (["json"].includes(langTag)) ext = "json";
                else if (["sh", "bash", "shell"].includes(langTag)) ext = "sh";
                else if (["py", "python"].includes(langTag)) ext = "py";
                else if (["md", "markdown"].includes(langTag)) ext = "md";
                else if (["ts", "typescript"].includes(langTag)) ext = "ts";

                try {
                    const fallbackDir = path.join(workspaceRoot, "Proj");
                    if (!fs.existsSync(fallbackDir)) {
                        fs.mkdirSync(fallbackDir, { recursive: true });
                    }
                    
                    const timestamp = Date.now();
                    const randId = Math.floor(Math.random() * 1000);
                    const fallbackName = `Proj_Fallback_${timestamp}_${randId}.${ext}`;
                    const fallbackPath = path.join(fallbackDir, fallbackName);
                    
                    this.fsManager.writeSmartFile(fallbackContent, fallbackPath);
                    this.logThinking(`B-Scheme [Fallback]: 偵測代碼語系 [${langTag || "plain"}]，智慧落盤至沙箱安全區 -> ${fallbackPath}`);
                } catch (e) {
                    console.error(`${this.ui.colors.red}[B案後備失敗] 寫入匿名塊發生錯誤: ${e.message}${this.ui.colors.reset}`);
                }
            }
        }
    }

    async cognition(input) {
        this.thinkingLog = []; 
        this.logThinking("Initializing cognition pipeline with advanced expansions...");

        // 優先處理 /c, /chat, /f, /file 強控制令前綴
        let cleanInput = input.trim();
        let forceChat = false;
        let forceCode = false;

        if (/^\/(c|chat)(\s+|$)/i.test(cleanInput)) {
            forceChat = true;
            input = cleanInput.replace(/^\/(c|chat)\s*/i, "");
        } else if (/^\/(f|file)(\s+|$)/i.test(cleanInput)) {
            forceCode = true;
            input = cleanInput.replace(/^\/(f|file)\s*/i, "");
        }

        const relevantFacts = this.wikiEngine.findRelevantFacts(input);
        let contextPrefix = "";
        if (relevantFacts.length > 0) {
            this.logThinking(`Found ${relevantFacts.length} relevant facts in Wiki.`);
            contextPrefix = `[KNOWLEDGE CONTEXT]\n${relevantFacts.join("\n")}\n\n`;
        }

        // 超大檔案動態分頁載入核心
        let bigFileContext = "";
        const pathRegex = /(?:[a-zA-Z]:)?[/\\a-zA-Z0-9_\-.]+\.[a-zA-Z0-9]+/g;
        let pathMatch;
        const scanPaths = new Set();
        while ((pathMatch = pathRegex.exec(input)) !== null) {
            scanPaths.add(pathMatch[0]);
        }
        for (const filePath of scanPaths) {
            try {
                if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
                    const fileLines = fs.readFileSync(filePath, "utf8").split(/\r?\n/);
                    const offsetLimit = this.config.LARGE_FILE_OFFSET_LINE || 3000;
                    if (fileLines.length > offsetLimit) {
                        this.logThinking(`偵測到超大檔案 ${filePath} (${fileLines.length} 行)，啟動 ${offsetLimit} 行分頁載入引擎...`);
                        const slicedContent = fileLines.slice(offsetLimit).join("\n");
                        bigFileContext += `\n\n[LARGE FILE ADDITIONAL CONTEXT (From Line ${offsetLimit} to End)][${filePath}]\n${slicedContent}\n`;
                    }
                }
            } catch (err) {
                // 忽略雜訊
            }
        }

        const enrichedInput = await this.fsManager.detectAndLoadFiles(input, this.ai) + bigFileContext;
        let isCode = this.ai.isCodeRequest(enrichedInput);

        // 前綴與智慧意圖路由分流核心
        if (forceChat) {
            this.logThinking("Command Prefix Override: Forced Chat/Reasoning request.");
            isCode = false;
        } else if (forceCode) {
            this.logThinking("Command Prefix Override: Forced Development/PlanA request.");
            isCode = true;
        } else {
            // 若沒有寫就用智慧意圖正則表達式
            const fileIntentRegex = /(建立|新增|修改|產生|生成|寫個|寫一個|create|write|generate|output).*(檔|檔案|file)/i;
            if (!isCode && (fileIntentRegex.test(input) || fileIntentRegex.test(enrichedInput))) {
                this.logThinking("Intent Override: Detected file operation request. Elevating to Development flow.");
                isCode = true;
            }
        }

        // 分流處理。非程式請求（純聊天）絕不注入建檔提示詞，還原純淨對話
        if (!isCode) {
            this.logThinking("Identified as Chat/Reasoning request.");
            const graph = this.ai.planner(enrichedInput);
            this.logThinking("Plan generated. Executing reasoning graph...");
            
            const finalInput = contextPrefix + enrichedInput;
            const output = await this.ai.executeGraph(finalInput, graph, this.runtime, this.activeModel);
            
            // 純聊天分流：不允許進行未標註路徑的後備匿名建檔落盤
            this.executeAutoFileDrop(output, false);

            this.logThinking("Reasoning complete. Recording to memory.");
            const score = this.ai.reward(output, this.runtime);
            
            this.runtime.lastInput = input;
            this.runtime.lastOutput = output;
            this.runtime.lastScore = score;

            const a = await this.memory.add("user", input, this.activeModel);
            const b = await this.memory.add("assistant", output, this.activeModel);
            this.memory.link(a, b);
            
            await this.wikiEngine.extractFacts(input, output);
            return output;
        }

        // 只有確定是寫碼/開發請求時，才注入 B 案落盤規則提示詞
        this.logThinking("Identified as Development/PlanA request.");
        let finalInputForPrompt = enrichedInput;
        if (this.config.ENFORCE_B_SCHEME_PROMPT) {
            const bSchemePrompt = `\n\n【B案格式指令規則】\n當你需要建立、修改或覆寫任何檔案程式碼時，請務必在該代碼塊的正上方標註「File: 檔案完整路徑」。\n範例：\nFile: C:\\tmp2\\web\\public\\app.js\n\`\`\`javascript\nconsole.log("hello");\n\`\`\`\n嚴禁使用任何省略號或「其餘相同省略」等縮減字眼，必須完整輸出每一行程式碼以供自動落盤系統辨識。`;
            finalInputForPrompt += bSchemePrompt;
        }

        return await this.projectManager.runStandardFlow(finalInputForPrompt, this.ai, this.fsManager, this.ui, async (inp, analysis, roadmap) => {
            this.logThinking("Executing Multi-Agent Development Workflow...");
            const model = this.activeModel || (inp.length > 100 ? this.config.MODEL_SMART : this.config.MODEL_FAST);
            const contextualInput = `${contextPrefix}[Roadmap]\n${roadmap}\n\n[Analysis]\n${analysis}\n\n[Request]\n${inp}`;
            
            let code = await this.ai.executeMultiAgentWorkflow(contextualInput, model, this.runtime, this.fsManager);
            
            this.logThinking("Applying code edits to filesystem via B-Scheme...");
            this.executeAutoFileDrop(code, true);

            this.logThinking("Updating memory and wiki...");
            const score = this.ai.reward(code, this.runtime);
            this.runtime.lastInput = inp;
            this.runtime.lastOutput = code;
            this.runtime.lastScore = score;
            await this.memory.add("user", inp, this.activeModel);
            await this.memory.add("assistant", code, this.activeModel);
            await this.wikiEngine.extractFacts(inp, code);
            
            return code;
        }, (step) => this.logThinking(step));
    }
}

module.exports = Orchestrator;