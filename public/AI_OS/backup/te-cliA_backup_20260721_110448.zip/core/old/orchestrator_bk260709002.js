const path = require("path");
const fs = require("fs");

class Orchestrator {
    constructor(context) {
        this.config = context.config;
        this.ai = context.ai;
        this.memory = context.memory;
        this.fsManager = context.fsManager;
        this.projectManager = context.projectManager;
        this.wikiEngine = context.wikiEngine;
        this.ui = context.ui;
        this.runtime = context.runtime;
        this.activeModel = null;
        this.thinkingLog = [];
    }

    logThinking(step) {
        const entry = `[${new Date().toLocaleTimeString()}] ${step}`;
        this.thinkingLog.push(entry);
        console.log(`${this.ui.colors.gray}${entry}${this.ui.colors.reset}`);
        if (this.thinkingLog.length > 20) this.thinkingLog.shift();
    }

    /**
     * 🚀 B案自動化核心：解析 AI 輸出的任何文本，自動識別包含路徑的代碼塊並精準落盤
     */
    executeAutoFileDrop(outputContent) {
        this.logThinking("B-Scheme: 啟動智慧文本掃描，檢索自動建檔標記...");
        let writeCount = 0;
        
        // 1. 優先處理標準的 Search / Replace 結構區塊
        const blocks = this.fsManager.applySearchReplaceBlocks(outputContent);
        if (blocks.length > 0) {
            const edits = this.fsManager.applyEdits(blocks);
            this.logThinking(`B-Scheme: 已成功套用 ${edits} 個 Search-Replace 區塊修改。`);
            writeCount += edits;
        }

        // 2. 智慧掃描：捕獲帶有明示路徑標籤的代碼區塊，例如 "File: C:\path\to\file.md\n\`\`\`"
        const explicitFileRegex = /(?:File|檔案|Path|Filename)[:\s]*["']?([a-zA-Z0-9_\-\.\/\\:]+)["']?\s*\r?\n```[a-zA-Z0-9\s]*\r?\n([\s\S]*?)```/gi;
        let match;
        while ((match = explicitFileRegex.exec(outputContent)) !== null) {
            const targetPath = match[1].trim();
            const fileContent = match[2];
            try {
                this.fsManager.writeSmartFile(fileContent, targetPath);
                this.logThinking(`B-Scheme: 自動感應成功！檔案已安全寫入至 -> ${targetPath}`);
                writeCount++;
            } catch (e) {
                console.error(`${this.ui.colors.red}[B案自動建檔失敗] 無法寫入 ${targetPath}: ${e.message}${this.ui.colors.reset}`);
            }
        }

        // 3. 安全後備方案：如果完全沒有找到任何帶路徑標記的區塊，但有代碼塊，則退化為自動分配
        if (writeCount === 0) {
            const genericRegex = /```[a-zA-Z0-9\s]*\r?\n([\s\S]*?)```/g;
            let m;
            while ((m = genericRegex.exec(outputContent)) !== null) {
                try {
                    const fallbackPath = this.fsManager.writeSmartFile(m[1]);
                    this.logThinking(`B-Scheme: 已將未指定路徑的代碼塊寫入至緩衝區 -> ${fallbackPath}`);
                } catch (e) {
                    console.error(`${this.ui.colors.red}[B案後備失敗] 寫入匿名塊發生錯誤: ${e.message}${this.ui.colors.reset}`);
                }
            }
        }
    }

    async cognition(input) {
        this.thinkingLog = []; 
        this.logThinking("Initializing cognition pipeline...");

        const relevantFacts = this.wikiEngine.findRelevantFacts(input);
        let contextPrefix = "";
        if (relevantFacts.length > 0) {
            this.logThinking(`Found ${relevantFacts.length} relevant facts in Wiki.`);
            contextPrefix = `[KNOWLEDGE CONTEXT]\n${relevantFacts.join("\n")}\n\n`;
        }

        const enrichedInput = await this.fsManager.detectAndLoadFiles(input, this.ai);
        const isCode = this.ai.isCodeRequest(enrichedInput);

        if (!isCode) {
            this.logThinking("Identified as Chat/Reasoning request.");
            const graph = this.ai.planner(enrichedInput);
            this.logThinking("Plan generated. Executing reasoning graph...");
            
            const finalInput = contextPrefix + enrichedInput;
            const output = await this.ai.executeGraph(finalInput, graph, this.runtime, this.activeModel);
            
            // 💡 修正點：即使在 Chat 模式下，也要攔截並自動執行 B案 建檔程序
            this.executeAutoFileDrop(output);

            this.logThinking("Reasoning complete. Recording to memory.");
            const score = this.ai.reward(output, this.runtime);
            
            this.runtime.lastInput = input;
            this.runtime.lastOutput = output;
            this.runtime.lastScore = score;

            const a = await this.memory.add("user", input, this.activeModel);
            const b = await this.memory.add("assistant", output, this.activeModel);
            this.memory.link(a, b);
            
            await this.wikiEngine.extractFacts(input, output);
            return output;
        }

        this.logThinking("Identified as Development/PlanA request.");
        return await this.projectManager.runStandardFlow(enrichedInput, this.ai, this.fsManager, this.ui, async (inp, analysis, roadmap) => {
            this.logThinking("Executing Multi-Agent Development Workflow...");
            const model = this.activeModel || (inp.length > 100 ? this.config.MODEL_SMART : this.config.MODEL_FAST);
            const contextualInput = `${contextPrefix}[Roadmap]\n${roadmap}\n\n[Analysis]\n${analysis}\n\n[Request]\n${inp}`;
            
            let code = await this.ai.executeMultiAgentWorkflow(contextualInput, model, this.runtime, this.fsManager);

            this.logThinking("Applying code edits to filesystem via B-Scheme...");
            
            // 💡 修正點：調用統一的 B案 檔案解構落盤引擎
            this.executeAutoFileDrop(code);

            this.logThinking("Updating memory and wiki...");
            const score = this.ai.reward(code, this.runtime);
            this.runtime.lastInput = inp;
            this.runtime.lastOutput = code;
            this.runtime.lastScore = score;
            await this.memory.add("user", inp, this.activeModel);
            await this.memory.add("assistant", code, this.activeModel);
            await this.wikiEngine.extractFacts(inp, code);
            
            return code;
        }, (step) => this.logThinking(step));
    }
}

module.exports = Orchestrator;