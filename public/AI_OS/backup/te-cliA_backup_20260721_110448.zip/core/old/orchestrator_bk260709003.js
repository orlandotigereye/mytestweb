const path = require("path");
const fs = require("fs");

class Orchestrator {
    constructor(context) {
        this.config = context.config;
        this.ai = context.ai;
        this.memory = context.memory;
        this.fsManager = context.fsManager;
        this.projectManager = context.projectManager;
        this.wikiEngine = context.wikiEngine;
        this.ui = context.ui;
        this.runtime = context.runtime;
        this.activeModel = null;
        this.thinkingLog = [];
        
        // 進程守護安全機制 - 註冊全域退出事件，防止極端狀況下記憶與狀態流失
        this.setupProcessGuard();
    }

    /**
     * 掛載系統訊號監聽器，確保強制關閉時完成記憶體落盤
     */
    setupProcessGuard() {
        const safeShutdown = () => {
            console.log('\n💾 [System Guard] 偵測到中斷訊號，正在強制執行系統狀態與記憶圖譜存盤...');
            try {
                if (this.memory && typeof this.memory.save === 'function') {
                    this.memory.save();
                }
                if (this.projectManager && typeof this.projectManager.saveState === 'function') {
                    this.projectManager.saveState();
                }
                console.log('✅ [System Guard] 所有運行核心存盤完畢，安全退出系統。');
            } catch (e) {
                console.error('❌ [System Guard] 強制緊急存盤失敗:', e.message);
            }
            process.exit(0);
        };
        process.on('SIGINT', safeShutdown);
        process.on('SIGTERM', safeShutdown);
    }

    logThinking(step) {
        const entry = `[${new Date().toLocaleTimeString()}] ${step}`;
        this.thinkingLog.push(entry);
        console.log(`${this.ui.colors.gray}${entry}${this.ui.colors.reset}`);
        if (this.thinkingLog.length > 20) this.thinkingLog.shift();
    }

    /**
     * B案自動化核心：具備原子化安全無損寫入機制
     */
    executeAutoFileDrop(outputContent) {
        this.logThinking("B-Scheme: 啟動智慧文本掃描，檢索自動建檔標記...");
        let writeCount = 0;
        
        // 1. 優先處理標準的 Search / Replace 結構區塊
        const blocks = this.fsManager.applySearchReplaceBlocks(outputContent);
        if (blocks.length > 0) {
            const edits = this.fsManager.applyEdits(blocks);
            this.logThinking(`B-Scheme: 已成功套用 ${edits} 個 Search-Replace 區塊修改。`);
            writeCount += edits;
        }

        // 2. 智慧掃描：捕獲帶有明示路徑標籤的代碼區塊
        const explicitFileRegex = /(?:File|檔案|Path|Filename)[:\s]*["']?([a-zA-Z0-9_\-\.\/\\:]+)["']?\s*\r?\n```[a-zA-Z0-9\s]*\r?\n([\s\S]*?)```/gi;
        let match;
        while ((match = explicitFileRegex.exec(outputContent)) !== null) {
            const targetPath = match[1].trim();
            const fileContent = match[2];
            try {
                if (this.config.ATOMIC_WRITE_ENABLED) {
                    const dir = path.dirname(targetPath);
                    if (!fs.existsSync(dir)) {
                        fs.mkdirSync(dir, { recursive: true });
                    }
                    const tmpPath = targetPath + ".tmp";
                    fs.writeFileSync(tmpPath, fileContent, "utf8");
                    fs.renameSync(tmpPath, targetPath);
                    this.logThinking(`B-Scheme [Atomic]: 自動感應並安全無損寫入 -> ${targetPath}`);
                } else {
                    this.fsManager.writeSmartFile(fileContent, targetPath);
                    this.logThinking(`B-Scheme [Standard]: 自動感應並寫入至 -> ${targetPath}`);
                }
                writeCount++;
            } catch (e) {
                console.error(`${this.ui.colors.red}[B案寫入失敗] 無法安全寫入 ${targetPath}: ${e.message}${this.ui.colors.reset}`);
            }
        }

        // 3. 安全後備方案：如果完全沒有找到任何帶路徑標記的區塊，但有代碼塊，則退化為自動歸類
        if (writeCount === 0) {
            const genericRegex = /```[a-zA-Z0-9\s]*\r?\n([\s\S]*?)```/g;
            let m;
            while ((m = genericRegex.exec(outputContent)) !== null) {
                try {
                    const fallbackPath = this.fsManager.writeSmartFile(m[1]);
                    this.logThinking(`B-Scheme [Fallback]: 已將未指定路徑的代碼塊寫入至專案緩衝區 -> ${fallbackPath}`);
                } catch (e) {
                    console.error(`${this.ui.colors.red}[B案後備失敗] 寫入匿名塊發生錯誤: ${e.message}${this.ui.colors.reset}`);
                }
            }
        }
    }

    async cognition(input) {
        this.thinkingLog = []; 
        this.logThinking("Initializing cognition pipeline with advanced expansions...");

        const relevantFacts = this.wikiEngine.findRelevantFacts(input);
        let contextPrefix = "";
        if (relevantFacts.length > 0) {
            this.logThinking(`Found ${relevantFacts.length} relevant facts in Wiki.`);
            contextPrefix = `[KNOWLEDGE CONTEXT]\n${relevantFacts.join("\n")}\n\n`;
        }

        // 超大檔案動態分頁載入核心
        let bigFileContext = "";
        const pathRegex = /(?:[a-zA-Z]:)?[/\\a-zA-Z0-9_\-.]+\.[a-zA-Z0-9]+/g;
        let pathMatch;
        const scanPaths = new Set();
        while ((pathMatch = pathRegex.exec(input)) !== null) {
            scanPaths.add(pathMatch[0]);
        }
        for (const filePath of scanPaths) {
            try {
                if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
                    const fileLines = fs.readFileSync(filePath, "utf8").split(/\r?\n/);
                    const offsetLimit = this.config.LARGE_FILE_OFFSET_LINE || 3000;
                    if (fileLines.length > offsetLimit) {
                        this.logThinking(`偵測到超大檔案 ${filePath} (${fileLines.length} 行)，啟動 ${offsetLimit} 行分頁載入引擎...`);
                        const slicedContent = fileLines.slice(offsetLimit).join("\n");
                        bigFileContext += `\n\n[LARGE FILE ADDITIONAL CONTEXT (From Line ${offsetLimit} to End)][${filePath}]\n${slicedContent}\n`;
                    }
                }
            } catch (err) {
                // 忽略雜訊
            }
        }

        const enrichedInput = await this.fsManager.detectAndLoadFiles(input, this.ai) + bigFileContext;
        const isCode = this.ai.isCodeRequest(enrichedInput);

        // 分流處理。非程式請求（純聊天）絕不注入建檔提示詞，還原純淨對話
        if (!isCode) {
            this.logThinking("Identified as Chat/Reasoning request.");
            const graph = this.ai.planner(enrichedInput);
            this.logThinking("Plan generated. Executing reasoning graph...");
            
            const finalInput = contextPrefix + enrichedInput;
            const output = await this.ai.executeGraph(finalInput, graph, this.runtime, this.activeModel);
            
            this.executeAutoFileDrop(output);

            this.logThinking("Reasoning complete. Recording to memory.");
            const score = this.ai.reward(output, this.runtime);
            
            this.runtime.lastInput = input;
            this.runtime.lastOutput = output;
            this.runtime.lastScore = score;

            const a = await this.memory.add("user", input, this.activeModel);
            const b = await this.memory.add("assistant", output, this.activeModel);
            this.memory.link(a, b);
            
            await this.wikiEngine.extractFacts(input, output);
            return output;
        }

        // 只有確定是寫碼/開發請求時，才注入 B 案落盤規則提示詞
        this.logThinking("Identified as Development/PlanA request.");
        let finalInputForPrompt = enrichedInput;
        if (this.config.ENFORCE_B_SCHEME_PROMPT) {
            const bSchemePrompt = `\n\n【B案格式指令規則】\n當你需要建立、修改或覆寫任何檔案程式碼時，請務必在該代碼塊的正上方標註「File: 檔案完整路徑」。\n範例：\nFile: C:\\tmp2\\web\\public\\app.js\n\`\`\`javascript\nconsole.log("hello");\n\`\`\`\n嚴禁使用任何省略號或「其餘相同省略」等縮減字眼，必須完整輸出每一行程式碼以供自動落盤系統辨識。`;
            finalInputForPrompt += bSchemePrompt;
        }

        return await this.projectManager.runStandardFlow(finalInputForPrompt, this.ai, this.fsManager, this.ui, async (inp, analysis, roadmap) => {
            this.logThinking("Executing Multi-Agent Development Workflow...");
            const model = this.activeModel || (inp.length > 100 ? this.config.MODEL_SMART : this.config.MODEL_FAST);
            const contextualInput = `${contextPrefix}[Roadmap]\n${roadmap}\n\n[Analysis]\n${analysis}\n\n[Request]\n${inp}`;
            
            let code = await this.ai.executeMultiAgentWorkflow(contextualInput, model, this.runtime, this.fsManager);

            this.logThinking("Applying code edits to filesystem via B-Scheme...");
            this.executeAutoFileDrop(code);

            this.logThinking("Updating memory and wiki...");
            const score = this.ai.reward(code, this.runtime);
            this.runtime.lastInput = inp;
            this.runtime.lastOutput = code;
            this.runtime.lastScore = score;
            await this.memory.add("user", inp, this.activeModel);
            await this.memory.add("assistant", code, this.activeModel);
            await this.wikiEngine.extractFacts(inp, code);
            
            return code;
        }, (step) => this.logThinking(step));
    }
}

module.exports = Orchestrator;