// File: ProcessGuard.js
class ProcessGuard {
    /**
     * 掛載系統訊號監聽器，確保強制關閉時完成記憶體落盤
     * @param {Object} memory 記憶體管理實例
     * @param {Object} projectManager 專案管理實例
     * @param {Function} stopSpinnerFn 停止 UI 動畫的回呼函式
     */
    static attach(memory, projectManager, stopSpinnerFn) {
        const safeShutdown = () => {
            if (typeof stopSpinnerFn === 'function') {
                stopSpinnerFn();
            }
            console.log('\n💾 [System Guard] 偵測到中斷訊號，正在強制執行系統狀態與記憶圖譜存盤...');
            try {
                if (memory && typeof memory.save === 'function') {
                    memory.save();
                }
                if (projectManager && typeof projectManager.saveState === 'function') {
                    projectManager.saveState();
                }
                console.log('✅ [System Guard] 所有運行核心存盤完畢，安全退出系統。');
            } catch (e) {
                console.error('❌ [System Guard] 強制緊急存盤失敗:', e.message);
            }
            process.exit(0);
        };
        
        process.on('SIGINT', safeShutdown);
        process.on('SIGTERM', safeShutdown);
    }
}

module.exports = ProcessGuard;