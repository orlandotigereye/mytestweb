// File: TerminalSpinner.js
class TerminalSpinner {
    constructor(ui) {
        this.ui = ui;
        this.spinnerTimer = null;
        this.thinkingLog = [];
    }

    logThinking(step) {
        const entry = `[${new Date().toLocaleTimeString()}] ${step}`;
        this.thinkingLog.push(entry);
        console.log(`${this.ui.colors.gray}${entry}${this.ui.colors.reset}`);
        if (this.thinkingLog.length > 20) {
            this.thinkingLog.shift();
        }
    }

    clearLog() {
        this.thinkingLog = [];
    }

    start(message = "AI 正在全力架構中") {
        this.stop();
        const chars = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"];
        let i = 0;
        process.stdout.write(`\r${this.ui.colors.cyan}${chars[i]} ${message}...${this.ui.colors.reset}`);
        
        this.spinnerTimer = setInterval(() => {
            i = (i + 1) % chars.length;
            process.stdout.write(`\r${this.ui.colors.cyan}${chars[i]} ${message}...${this.ui.colors.reset}`);
        }, 80);
    }

    stop() {
        if (this.spinnerTimer) {
            clearInterval(this.spinnerTimer);
            this.spinnerTimer = null;
            if (process.stdout.clearLine) {
                process.stdout.clearLine(0);
                process.stdout.cursorTo(0);
            } else {
                process.stdout.write('\r\x1b[K');
            }
        }
    }
}

module.exports = TerminalSpinner;