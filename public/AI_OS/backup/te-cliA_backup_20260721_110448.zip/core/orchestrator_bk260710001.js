const path = require("path");
const fs = require("fs");

class Orchestrator {
    constructor(context) {
        this.config = context.config;
        this.ai = context.ai;
        this.memory = context.memory;
        this.fsManager = context.fsManager;
        this.projectManager = context.projectManager;
        this.wikiEngine = context.wikiEngine;
        this.ui = context.ui;
        this.runtime = context.runtime;
        this.activeModel = null;
        this.thinkingLog = [];
        this.spinnerTimer = null;
        
        // 進程守護安全機制 - 註冊全域退出事件，防止極端狀況下記憶與狀態流失
        this.setupProcessGuard();
    }

    /**
     * 動態熱更新讀取意圖字典 (具備 JSON 容錯與預設值防護)
     * 嚴格採用 utf-8 編碼確保跨平台中文字元完整性
     */
    loadIntentDict() {
        const defaultDict = {
            fileMarkers: ["File", "檔案", "Path", "Filename"],
            fallbackTopics: ["九九乘法", "9\\*9", "9x9", "hello", "test", "登入", "login", "程式", "腳本", "網頁", "頁面", "畫面", "小工具", "東西", "刻一個", "幫我"],
            intentVerbs: ["建立", "新增", "修改", "產生", "生成", "寫個", "寫一個", "做個", "做一個", "幫我寫", "幫我生", "弄個", "弄一個", "搞個", "搞一個", "出一個", "刻一個", "生出", "打一個", "隨便寫個", "create", "write", "generate", "output"],
            intentNouns: ["檔", "檔案", "file", "程式", "代碼", "code", "script", "腳本", "網頁", "頁面", "畫面", "組件", "app", "東西", "範例", "功能", "小工具", "\\.[a-zA-Z0-9]+"],
            trivialTasks: ["文字檔", "txt", "readme", "md", "markdown", "任意內容", "隨便寫", "隨意內容", "html", "css", "js", "網頁", "單一頁面", "九九乘法", "9\\*9", "9x9", "登入", "login", "程式", "腳本", "東西", "頁面", "畫面", "刻一個", "弄個", "搞個", "幫我生", "幫我寫", "功能", "小工具"]
        };

        try {
            const dictPath = path.resolve(process.cwd(), "intent_dictionary.json");
            if (fs.existsSync(dictPath)) {
                const content = fs.readFileSync(dictPath, "utf8");
                return JSON.parse(content);
            }
        } catch (e) {
            console.error(`${this.ui.colors.red}[字典載入異常] intent_dictionary.json 讀取或解析失敗: ${e.message}。系統已自動啟用安全預設字典。${this.ui.colors.reset}`);
        }
        return defaultDict;
    }

    /**
     * 掛載系統訊號監聽器，確保強制關閉時完成記憶體落盤
     */
    setupProcessGuard() {
        const safeShutdown = () => {
            this.stopSpinner();
            console.log('\n💾 [System Guard] 偵測到中斷訊號，正在強制執行系統狀態與記憶圖譜存盤...');
            try {
                if (this.memory && typeof this.memory.save === 'function') {
                    this.memory.save();
                }
                if (this.projectManager && typeof this.projectManager.saveState === 'function') {
                    this.projectManager.saveState();
                }
                console.log('✅ [System Guard] 所有運行核心存盤完畢，安全退出系統。');
            } catch (e) {
                console.error('❌ [System Guard] 強制緊急存盤失敗:', e.message);
            }
            process.exit(0);
        };
        process.on('SIGINT', safeShutdown);
        process.on('SIGTERM', safeShutdown);
    }

    logThinking(step) {
        const entry = `[${new Date().toLocaleTimeString()}] ${step}`;
        this.thinkingLog.push(entry);
        console.log(`${this.ui.colors.gray}${entry}${this.ui.colors.reset}`);
        if (this.thinkingLog.length > 20) this.thinkingLog.shift();
    }

    startSpinner(message = "AI 正在全力架構中") {
        this.stopSpinner();
        const chars = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"];
        let i = 0;
        process.stdout.write(`\r${this.ui.colors.cyan}${chars[i]} ${message}...${this.ui.colors.reset}`);
        this.spinnerTimer = setInterval(() => {
            i = (i + 1) % chars.length;
            process.stdout.write(`\r${this.ui.colors.cyan}${chars[i]} ${message}...${this.ui.colors.reset}`);
        }, 80);
    }

    stopSpinner() {
        if (this.spinnerTimer) {
            clearInterval(this.spinnerTimer);
            this.spinnerTimer = null;
            if (process.stdout.clearLine) {
                process.stdout.clearLine(0);
                process.stdout.cursorTo(0);
            } else {
                process.stdout.write('\r\x1b[K');
            }
        }
    }

    executeAutoFileDrop(outputContent, allowFallback = true, originalInput = "") {
        this.logThinking("B-Scheme: 啟動智慧文本掃描，檢索自動建檔標記...");
        let writeCount = 0;
        const workspaceRoot = path.resolve(this.config.WORKSPACE_ROOT || process.cwd());
        
        // 載入最新字典 (熱更新)
        const intentDict = this.loadIntentDict();

        const blocks = this.fsManager.applySearchReplaceBlocks(outputContent);
        if (blocks.length > 0) {
            const edits = this.fsManager.applyEdits(blocks);
            this.logThinking(`B-Scheme: 已成功套用 ${edits} 個 Search-Replace 區塊修改。`);
            writeCount += edits;
        }

        try {
            const markerPattern = intentDict.fileMarkers.join("|");
            const baseRegexSource = /(?:File|檔案|Path|Filename)[:\s]*["']?([a-zA-Z0-9_\-\.\/\\:\*\u4e00-\u9fa5]+)["']?\s*\r?\n```[a-zA-Z0-9\s]*\r?\n([\s\S]*?)```[ \t]*/gi.source;
            const dynamicRegexSource = baseRegexSource.replace("File|檔案|Path|Filename", markerPattern);
            const explicitFileRegex = new RegExp(dynamicRegexSource, "gi");
            
            let match;
            while ((match = explicitFileRegex.exec(outputContent)) !== null) {
                let targetPath = match[1].trim();
                const fileContent = match[2];
                
                targetPath = targetPath.replace(/\*/g, "x");
                const resolvedTarget = path.resolve(workspaceRoot, targetPath);
                
                const relativePath = path.relative(workspaceRoot, resolvedTarget);
                const isInsideSandbox = relativePath && !relativePath.startsWith('..') && !path.isAbsolute(relativePath);
                
                if (!isInsideSandbox && resolvedTarget !== workspaceRoot) {
                    console.error(`${this.ui.colors.red}[B案安全攔截] 偵測到越權路徑嘗試，已拒絕寫入沙箱外部：${targetPath}${this.ui.colors.reset}`);
                    continue;
                }

                try {
                    if (this.config.ATOMIC_WRITE_ENABLED) {
                        const dir = path.dirname(resolvedTarget);
                        if (!fs.existsSync(dir)) {
                            fs.mkdirSync(dir, { recursive: true });
                        }
                        const tmpPath = resolvedTarget + ".tmp";
                        fs.writeFileSync(tmpPath, fileContent, "utf8");
                        fs.renameSync(tmpPath, resolvedTarget);
                        this.logThinking(`B-Scheme [Atomic]: 自動感應並安全無損寫入沙箱區 -> ${resolvedTarget}`);
                    } else {
                        this.fsManager.writeSmartFile(fileContent, resolvedTarget);
                        this.logThinking(`B-Scheme [Standard]: 自動感應並寫入至沙箱區 -> ${resolvedTarget}`);
                    }
                    writeCount++;
                } catch (e) {
                    console.error(`${this.ui.colors.red}[B案寫入失敗] 無法安全寫入 ${resolvedTarget}: ${e.message}${this.ui.colors.reset}`);
                }
            }
        } catch (regexErr) {
            console.error(`${this.ui.colors.red}[Regex編譯失敗] 字典檔 fileMarkers 存在無效的正則語法: ${regexErr.message}${this.ui.colors.reset}`);
        }

        if (writeCount === 0 && allowFallback) {
            const genericRegex = /```([a-zA-Z0-9_\-+]*)\r?\n([\s\S]*?)```[ \t]*/g;
            let m;
            while ((m = genericRegex.exec(outputContent)) !== null) {
                const langTag = m[1].toLowerCase().trim();
                const fallbackContent = m[2];
                
                let ext = "txt";
                if (["js", "javascript", "node"].includes(langTag)) ext = "js";
                else if (["html", "htm"].includes(langTag)) ext = "html";
                else if (["css"].includes(langTag)) ext = "css";
                else if (["json"].includes(langTag)) ext = "json";
                else if (["sh", "bash", "shell"].includes(langTag)) ext = "sh";
                else if (["py", "python"].includes(langTag)) ext = "py";
                else if (["md", "markdown"].includes(langTag)) ext = "md";
                else if (["ts", "typescript"].includes(langTag)) ext = "ts";

                try {
                    const fallbackDir = path.join(workspaceRoot, "Proj");
                    if (!fs.existsSync(fallbackDir)) {
                        fs.mkdirSync(fallbackDir, { recursive: true });
                    }
                    
                    let guessedName = "Proj_Fallback";
                    const titleMatch = originalInput.match(/([a-zA-Z0-9_\u4e00-\u9fa5\*]+)\.(txt|html|css|js|json|md|sh|py|ts)/i);
                    if (titleMatch) {
                        guessedName = titleMatch[1].replace(/\*/g, "x");
                    } else {
                        try {
                            const topicPattern = intentDict.fallbackTopics.join("|");
                            const topicRegex = new RegExp("(" + topicPattern + ")", "i");
                            const topicMatch = originalInput.match(topicRegex);
                            if (topicMatch) guessedName = topicMatch[1].replace(/\*/g, "x");
                        } catch (e) {
                            // 忽略正則錯誤，使用預設值
                        }
                    }
                    
                    const timestamp = Date.now().toString().slice(-4);
                    const fallbackName = `${guessedName}_${timestamp}.${ext}`;
                    const fallbackPath = path.join(fallbackDir, fallbackName);
                    
                    this.fsManager.writeSmartFile(fallbackContent, fallbackPath);
                    this.logThinking(`B-Scheme [Fallback]: 辨識原始意圖 [${guessedName}] 與語系 [${langTag || "plain"}]，智慧落盤 -> ${fallbackPath}`);
                } catch (e) {
                    console.error(`${this.ui.colors.red}[B案後備失敗] 寫入匿名塊發生錯誤: ${e.message}${this.ui.colors.reset}`);
                }
            }
        }
    }

    async cognition(input) {
        this.thinkingLog = []; 
        this.logThinking("Initializing cognition pipeline with advanced expansions...");
        
        const intentDict = this.loadIntentDict();

        let cleanInput = input.trim();
        let forceChat = false;
        let forceCode = false;

        if (/^\/(c|chat)(\s+|$)/i.test(cleanInput)) {
            forceChat = true;
            input = cleanInput.replace(/^\/(c|chat)\s*/i, "");
        } else if (/^\/(f|file)(\s+|$)/i.test(cleanInput)) {
            forceCode = true;
            input = cleanInput.replace(/^\/(f|file)\s*/i, "");
        }

        const relevantFacts = this.wikiEngine.findRelevantFacts(input);
        let contextPrefix = "";
        if (relevantFacts.length > 0) {
            this.logThinking(`Found ${relevantFacts.length} relevant facts in Wiki.`);
            contextPrefix = `[KNOWLEDGE CONTEXT]\n${relevantFacts.join("\n")}\n\n`;
        }

        let bigFileContext = "";
        const pathRegex = /(?:[a-zA-Z]:)?[/\\a-zA-Z0-9_\-.]+\.[a-zA-Z0-9]+/g;
        let pathMatch;
        const scanPaths = new Set();
        while ((pathMatch = pathRegex.exec(input)) !== null) {
            scanPaths.add(pathMatch[0]);
        }
        for (const filePath of scanPaths) {
            try {
                if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
                    const fileLines = fs.readFileSync(filePath, "utf8").split(/\r?\n/);
                    const offsetLimit = this.config.LARGE_FILE_OFFSET_LINE || 3000;
                    
                    if (fileLines.length > offsetLimit) {
                        this.logThinking(`偵測到超大檔案 ${filePath} (${fileLines.length} 行)，啟動自第 ${offsetLimit} 行起的分頁全量載入引擎...`);
                        const slicedContent = fileLines.slice(offsetLimit).join("\n");
                        bigFileContext += `\n\n[LARGE FILE ADDITIONAL CONTEXT (From Line ${offsetLimit} to End)][${filePath}]\n${slicedContent}\n`;
                    }
                }
            } catch (err) {
                // 忽略雜訊
            }
        }

        const enrichedInput = await this.fsManager.detectAndLoadFiles(input, this.ai) + bigFileContext;
        let isCode = this.ai.isCodeRequest(enrichedInput);

        if (forceChat) {
            this.logThinking("Command Prefix Override: Forced Chat/Reasoning request.");
            isCode = false;
        } else if (forceCode) {
            this.logThinking("Command Prefix Override: Forced Development/PlanA request.");
            isCode = true;
        } else {
            try {
                const verbPattern = intentDict.intentVerbs.join("|");
                const nounPattern = intentDict.intentNouns.join("|");
                const fileIntentRegex = new RegExp("(" + verbPattern + ").*(" + nounPattern + ")", "i");
                
                if (!isCode && (fileIntentRegex.test(input) || fileIntentRegex.test(enrichedInput))) {
                    this.logThinking("Intent Override: Detected file operation request. Elevating to Development flow.");
                    isCode = true;
                }
            } catch (e) {
                this.logThinking("Intent Matching skipped due to Regex compilation error in dictionary.");
            }
        }

        if (!isCode) {
            this.logThinking("Identified as Chat/Reasoning request.");
            this.startSpinner("思維模型正在全速演繹中");
            
            let output;
            try {
                const graph = this.ai.planner(enrichedInput);
                const finalInput = contextPrefix + enrichedInput;
                output = await this.ai.executeGraph(finalInput, graph, this.runtime, this.activeModel);
            } finally {
                this.stopSpinner();
            }
            
            this.executeAutoFileDrop(output, true, input);

            this.logThinking("Reasoning complete. Recording to memory.");
            const score = this.ai.reward(output, this.runtime);
            
            this.runtime.lastInput = input;
            this.runtime.lastOutput = output;
            this.runtime.lastScore = score;

            const a = await this.memory.add("user", input, this.activeModel);
            const b = await this.memory.add("assistant", output, this.activeModel);
            this.memory.link(a, b);
            
            const extracted = await this.wikiEngine.extractFacts(input, output);
            if (extracted && extracted.length > 0) {
                console.log(`\n${this.ui.colors.green}💡 [知識庫同步成功] 已為您即時提取並精煉 ${extracted.length} 條核心事實歸檔至智慧圖譜。${this.ui.colors.reset}`);
            }
            
            return output;
        }

        this.logThinking("Identified as Development/PlanA request.");

        let isTrivialTask = false;
        try {
            const trivialPattern = intentDict.trivialTasks.join("|");
            const trivialRegex = new RegExp("(" + trivialPattern + ")", "i");
            isTrivialTask = input.length < 100 && trivialRegex.test(input);
        } catch (e) {
            // 容錯忽略
        }
        
        if (isTrivialTask) {
            this.logThinking("Fast-Track Mode: Simple asset generation detected. Attempting direct rapid execution...");
            try {
                const fastModel = this.config.MODEL_FAST || "gemini-2.5-flash";
                const fastPrompt = `${contextPrefix}${enrichedInput}\n\n【B案格式指令規則】\n請直接給出要寫入的完整程式碼或文本，並在代碼塊正上方精確標註「File: 檔名.副檔名」（例如 File: login.html 或 File: login.py）。必須輸出完整內容，不可省略 any code。`;
                
                this.startSpinner("快速通道極速生成中");
                
                let fastOutput;
                try {
                    const graph = this.ai.planner(fastPrompt);
                    fastOutput = await this.ai.executeGraph(fastPrompt, graph, this.runtime, fastModel);
                } finally {
                    this.stopSpinner();
                }
                
                this.logThinking("Applying Fast-Track generated file to filesystem...");
                this.executeAutoFileDrop(fastOutput, true, input);
                
                await this.memory.add("user", input, fastModel);
                await this.memory.add("assistant", fastOutput, fastModel);
                
                const extracted = await this.wikiEngine.extractFacts(input, fastOutput);
                if (extracted && extracted.length > 0) {
                    console.log(`\n${this.ui.colors.green}💡 [知識庫同步成功] 快速通道已同步提取 ${extracted.length} 條動態知識核心。${this.ui.colors.reset}`);
                }
                
                return fastOutput;
            } catch (fastErr) {
                this.stopSpinner();
                console.error(`${this.ui.colors.red}[快速通道異常] ${fastErr.message}。自動安全降級至標準工程開發流...${this.ui.colors.reset}`);
            }
        }

        let finalInputForPrompt = enrichedInput;
        if (this.config.ENFORCE_B_SCHEME_PROMPT) {
            const bSchemePrompt = `\n\n【B案格式指令規則】\n當你需要建立、修改或覆寫任何檔案程式碼時，請務必在該代碼塊的正上方標註「File: 檔案完整路徑」。\n範例：\nFile: C:\\tmp2\\web\\public\\app.js\n\`\`\`javascript\nconsole.log("hello");\n\`\`\`\n嚴禁使用任何省略號或「其餘相同省略」等縮減字眼，必須完整輸出每一行程式碼以供自動落盤系統辨識。`;
            finalInputForPrompt += bSchemePrompt;
        }

        return await this.projectManager.runStandardFlow(finalInputForPrompt, this.ai, this.fsManager, this.ui, async (inp, analysis, roadmap) => {
            this.logThinking("Executing Multi-Agent Development Workflow...");
            const model = this.activeModel || (inp.length > 100 ? this.config.MODEL_SMART : this.config.MODEL_FAST);
            const contextualInput = `${contextPrefix}[Roadmap]\n${roadmap}\n\n[Analysis]\n${analysis}\n\n[Request]\n${inp}`;
            
            this.startSpinner("多智能體聯邦架構研討與代碼生成中");
            
            let code;
            try {
                code = await this.ai.executeMultiAgentWorkflow(contextualInput, model, this.runtime, this.fsManager);
            } finally {
                this.stopSpinner();
            }
            
            this.logThinking("Applying code edits to filesystem via B-Scheme...");
            this.executeAutoFileDrop(code, true, inp);

            this.logThinking("Updating memory and wiki...");
            const score = this.ai.reward(code, this.runtime);
            this.runtime.lastInput = inp;
            this.runtime.lastOutput = code;
            this.runtime.lastScore = score;
            await this.memory.add("user", inp, this.activeModel);
            await this.memory.add("assistant", code, this.activeModel);
            
            const extracted = await this.wikiEngine.extractFacts(inp, code);
            if (extracted && extracted.length > 0) {
                console.log(`\n${this.ui.colors.green}💡 [知識庫同步成功] 聯邦開發流已成功將 ${extracted.length} 個重構決策寫入 Wiki 圖譜。${this.ui.colors.reset}`);
            }
            
            return code;
        }, (step) => this.logThinking(step));
    }
}

module.exports = Orchestrator;