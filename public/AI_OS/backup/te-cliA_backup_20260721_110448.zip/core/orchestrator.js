const path = require("path");
const fs = require("fs");
const ProcessGuard = require("./ProcessGuard");
const TerminalSpinner = require("./TerminalSpinner");
const logger = require("../logger");

class Orchestrator {
    constructor(context) {
        this.config = context.config;
        this.ai = context.ai;
        this.memory = context.memory;
        this.fsManager = context.fsManager;
        this.projectManager = context.projectManager;
        this.wikiEngine = context.wikiEngine;
        this.ui = context.ui;
        this.runtime = context.runtime;
        this.activeModel = null;
        this.spinner = new TerminalSpinner(this.ui);
        ProcessGuard.attach(this.memory, this.projectManager, () => this.spinner.stop());
    }

    loadIntentDict() {
        const defaultDict = {
            fileMarkers: ["File", "檔案", "Path", "Filename"],
            fallbackTopics: ["九九乘法", "9\\*9", "9x9", "hello", "test", "登入", "login", "程式", "腳本", "網頁", "頁面", "畫面", "小工具", "東西", "刻一個", "幫我"],
            intentVerbs: ["建立", "新增", "修改", "產生", "生成", "寫個", "寫一個", "做個", "做一個", "幫我寫", "幫我生", "弄個", "弄一個", "搞個", "搞一個", "出一個", "刻一個", "生出", "打一個", "隨便寫個", "create", "write", "generate", "output"],
            intentNouns: ["檔", "檔案", "file", "程式", "代碼", "code", "script", "腳本", "網頁", "頁面", "畫面", "組件", "app", "東西", "範例", "功能", "小工具", "\\.[a-zA-Z0-9]+"],
            trivialTasks: ["文字檔", "txt", "readme", "md", "markdown", "任意內容", "隨便寫", "隨意內容", "html", "css", "js", "網頁", "單一頁面", "九九乘法", "9\\*9", "9x9", "登入", "login", "程式", "腳本", "東西", "頁面", "畫面", "刻一個", "弄個", "搞個", "幫我生", "幫我寫", "功能", "小工具"]
        };

        try {
            const dictPath = path.resolve(process.cwd(), "intent_dictionary.json");
            if (fs.existsSync(dictPath)) {
                const content = fs.readFileSync(dictPath, "utf8");
                return JSON.parse(content);
            }
        } catch (e) {
            logger.error({err: e}, "Failed to load intent dictionary, using default");
        }
        return defaultDict;
    }

    executeAutoFileDrop(outputContent, allowFallback = true, originalInput = "") {
        this.spinner.logThinking("B-Scheme: 啟動智慧文本掃描，檢索自動建檔標記...");
        let writeCount = 0;
        const workspaceRoot = path.resolve(this.config.WORKSPACE_ROOT || process.cwd());
        const intentDict = this.loadIntentDict();

        const blocks = this.fsManager.applySearchReplaceBlocks(outputContent);
        if (blocks.length > 0) {
            const edits = this.fsManager.applyEdits(blocks);
            this.spinner.logThinking(`B-Scheme: 已成功套用 ${edits} 個 Search-Replace 區塊修改。`);
            writeCount += edits;
        }

        try {
            const markerPattern = intentDict.fileMarkers.join("|");
            const baseRegexSource = /(?:File|檔案|Path|Filename)[:\s]*["']?([a-zA-Z0-9_\-\.\/\\:\*\u4e00-\u9fa5]+)["']?\s*\r?\n```[a-zA-Z0-9\s]*\r?\n([\s\S]*?)```[ \t]*/gi.source;
            const dynamicRegexSource = baseRegexSource.replace("File|檔案|Path|Filename", markerPattern);
            const explicitFileRegex = new RegExp(dynamicRegexSource, "gi");
            
            let match;
            while ((match = explicitFileRegex.exec(outputContent)) !== null) {
                let targetPath = match[1].trim();
                const fileContent = match[2];
                
                targetPath = targetPath.replace(/\*/g, "x");
                const resolvedTarget = path.resolve(workspaceRoot, targetPath);
                const relativePath = path.relative(workspaceRoot, resolvedTarget);
                const isInsideSandbox = relativePath && !relativePath.startsWith('..') && !path.isAbsolute(relativePath);
                
                if (!isInsideSandbox && resolvedTarget !== workspaceRoot) {
                    logger.warn("Security: blocked path traversal to %s", targetPath);
                    console.error(`${this.ui.colors.red}[B案安全攔截] 偵測到越權路徑嘗試，已拒絕寫入沙箱外部：${targetPath}${this.ui.colors.reset}`);
                    continue;
                }

                try {
                    if (this.config.ATOMIC_WRITE_ENABLED) {
                        const dir = path.dirname(resolvedTarget);
                        if (!fs.existsSync(dir)) {
                            fs.mkdirSync(dir, { recursive: true });
                        }
                        const tmpPath = resolvedTarget + ".tmp";
                        fs.writeFileSync(tmpPath, fileContent, "utf8");
                        fs.renameSync(tmpPath, resolvedTarget);
                        this.spinner.logThinking(`B-Scheme [Atomic]: 自動感應並安全無損寫入沙箱區 -> ${resolvedTarget}`);
                    } else {
                        this.fsManager.writeSmartFile(fileContent, resolvedTarget);
                        this.spinner.logThinking(`B-Scheme [Standard]: 自動感應並寫入至沙箱區 -> ${resolvedTarget}`);
                    }
                    writeCount++;
                } catch (e) {
                    logger.error({err: e}, "B-Scheme write failed: %s", resolvedTarget);
                    console.error(`${this.ui.colors.red}[B案寫入失敗] 無法安全寫入 ${resolvedTarget}: ${e.message}${this.ui.colors.reset}`);
                }
            }
        } catch (regexErr) {
            logger.error({err: regexErr}, "Regex compilation failed");
            console.error(`${this.ui.colors.red}[Regex編譯失敗] 字典檔 fileMarkers 存在無效的正則語法: ${regexErr.message}${this.ui.colors.reset}`);
        }

        if (writeCount === 0 && allowFallback) {
            const genericRegex = /```([a-zA-Z0-9_\-+]*)\r?\n([\s\S]*?)```[ \t]*/g;
            let m;
            while ((m = genericRegex.exec(outputContent)) !== null) {
                const langTag = m[1].toLowerCase().trim();
                const fallbackContent = m[2];
                
                let ext = "txt";
                if (["js", "javascript", "node"].includes(langTag)) ext = "js";
                else if (["html", "htm"].includes(langTag)) ext = "html";
                else if (["css"].includes(langTag)) ext = "css";
                else if (["json"].includes(langTag)) ext = "json";
                else if (["sh", "bash", "shell"].includes(langTag)) ext = "sh";
                else if (["py", "python"].includes(langTag)) ext = "py";
                else if (["md", "markdown"].includes(langTag)) ext = "md";
                else if (["ts", "typescript"].includes(langTag)) ext = "ts";

                try {
                    const fallbackDir = path.join(workspaceRoot, "Proj");
                    if (!fs.existsSync(fallbackDir)) {
                        fs.mkdirSync(fallbackDir, { recursive: true });
                    }
                    
                    let guessedName = "Proj_Fallback";
                    const titleMatch = originalInput.match(/([a-zA-Z0-9_\u4e00-\u9fa5\*]+)\.(txt|html|css|js|json|md|sh|py|ts)/i);
                    if (titleMatch) {
                        guessedName = titleMatch[1].replace(/\*/g, "x");
                    } else {
                        try {
                            const topicPattern = intentDict.fallbackTopics.join("|");
                            const topicRegex = new RegExp("(" + topicPattern + ")", "i");
                            const topicMatch = originalInput.match(topicRegex);
                            if (topicMatch) guessedName = topicMatch[1].replace(/\*/g, "x");
                        } catch (e) {}
                    }
                    
                    const timestamp = Date.now().toString().slice(-4);
                    const fallbackName = `${guessedName}_${timestamp}.${ext}`;
                    const fallbackPath = path.join(fallbackDir, fallbackName);
                    
                    this.fsManager.writeSmartFile(fallbackContent, fallbackPath);
                    this.spinner.logThinking(`B-Scheme [Fallback]: 辨識原始意圖 [${guessedName}] 與語系 [${langTag || "plain"}]，智慧落盤 -> ${fallbackPath}`);
                } catch (e) {
                  if (e.message && e.message.includes("Permission Denied")) {
        logger.warn("B-Scheme skipped: %s", e.message);
        // 這是預期的安全攔截，不需要顯示錯誤
    } else {
        logger.error({err: e}, "B-Scheme fallback failed");
        console.error(`${this.ui.colors.red}[B案後備失敗] 寫入匿名塊發生錯誤: ${e.message}${this.ui.colors.reset}`);
    }
                }
            }
        }
    }

    // ========== 公開入口 ==========
    async cognition(input) {
        this.spinner.clearLog();
        this.spinner.logThinking("Initializing cognition pipeline with advanced expansions...");
        
        const context = await this._prepareContext(input);
        const intent = this._determineIntent(context);
        
        if (intent.mode === 'chat') {
            return await this._executeChat(context);
        }
        
        if (intent.mode === 'fast') {
            return await this._executeFastTrack(context);
        }
        
        return await this._executeStandardFlow(context);
    }

    // ========== 步驟 1-6：準備上下文 ==========
    async _prepareContext(input) {
        const intentDict = this.loadIntentDict();

        let cleanInput = input.trim();
        let forceChat = false;
        let forceCode = false;

        if (/^\/(c|chat)(\s+|$)/i.test(cleanInput)) {
            forceChat = true;
            cleanInput = cleanInput.replace(/^\/(c|chat)\s*/i, "");
        } else if (/^\/(f|file)(\s+|$)/i.test(cleanInput)) {
            forceCode = true;
            cleanInput = cleanInput.replace(/^\/(f|file)\s*/i, "");
        }

        const relevantFacts = this.wikiEngine.findRelevantFacts(input);
        let contextPrefix = "";
        if (relevantFacts.length > 0) {
            this.spinner.logThinking(`Found ${relevantFacts.length} relevant facts in Wiki.`);
            contextPrefix = `[KNOWLEDGE CONTEXT]\n${relevantFacts.join("\n")}\n\n`;
        }

        let bigFileContext = "";
        const pathRegex = /(?:[a-zA-Z]:)?[/\\a-zA-Z0-9_\-.]+\.[a-zA-Z0-9]+/g;
        let pathMatch;
        const scanPaths = new Set();
        while ((pathMatch = pathRegex.exec(input)) !== null) {
            scanPaths.add(pathMatch[0]);
        }
        for (const filePath of scanPaths) {
            try {
                if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
                    const fileLines = fs.readFileSync(filePath, "utf8").split(/\r?\n/);
                    const offsetLimit = this.config.LARGE_FILE_OFFSET_LINE || 3000;
                    
                    if (fileLines.length > offsetLimit) {
                        this.spinner.logThinking(`偵測到超大檔案 ${filePath} (${fileLines.length} 行)，啟動自第 ${offsetLimit} 行起的分頁全量載入引擎...`);
                        const slicedContent = fileLines.slice(offsetLimit).join("\n");
                        bigFileContext += `\n\n[LARGE FILE ADDITIONAL CONTEXT (From Line ${offsetLimit} to End)][${filePath}]\n${slicedContent}\n`;
                    }
                }
            } catch (err) {}
        }

        const enrichedInput = await this.fsManager.detectAndLoadFiles(input, this.ai) + bigFileContext;
        
        return {
            originalInput: input,
            cleanInput: cleanInput,
            enrichedInput: contextPrefix + enrichedInput,
            forceChat,
            forceCode,
            intentDict
        };
    }

    // ========== 步驟 7-8：判斷意圖 ==========
    _determineIntent(context) {
        let isCode = this.ai.isCodeRequest(context.enrichedInput);

        if (context.forceChat) {
            this.spinner.logThinking("Command Prefix Override: Forced Chat/Reasoning request.");
            return { mode: 'chat' };
        }
        
        if (context.forceCode) {
            this.spinner.logThinking("Command Prefix Override: Forced Development/PlanA request.");
            return this._checkFastTrack(context);
        }

        try {
            const verbPattern = context.intentDict.intentVerbs.join("|");
            const nounPattern = context.intentDict.intentNouns.join("|");
            const fileIntentRegex = new RegExp("(" + verbPattern + ").*(" + nounPattern + ")", "i");
            
            if (!isCode && (fileIntentRegex.test(context.originalInput) || fileIntentRegex.test(context.enrichedInput))) {
                this.spinner.logThinking("Intent Override: Detected file operation request. Elevating to Development flow.");
                isCode = true;
            }
        } catch (e) {
            this.spinner.logThinking("Intent Matching skipped due to Regex compilation error in dictionary.");
        }

        if (!isCode) {
            return { mode: 'chat' };
        }

        return this._checkFastTrack(context);
    }

    // ========== 判斷是否快速通道 ==========
    _checkFastTrack(context) {
        try {
            const trivialPattern = context.intentDict.trivialTasks.join("|");
            const trivialRegex = new RegExp("(" + trivialPattern + ")", "i");
            const isTrivial = context.originalInput.length < 100 && trivialRegex.test(context.originalInput);
            
            if (isTrivial) {
                return { mode: 'fast' };
            }
        } catch (e) {}
        
        return { mode: 'standard' };
    }

    // ========== 步驟 9：聊天模式 ==========
    async _executeChat(context) {
        this.spinner.logThinking("Identified as Chat/Reasoning request.");
        this.spinner.start("思維模型正在全速演繹中");
        
        let output;
        try {
            const graph = this.ai.planner(context.enrichedInput);
            const finalInput = context.enrichedInput;
            output = await this.ai.executeGraph(finalInput, graph, this.runtime, this.activeModel);
        } finally {
            this.spinner.stop();
        }
        
        this.executeAutoFileDrop(output, true, context.originalInput);

        this.spinner.logThinking("Reasoning complete. Recording to memory.");
        const score = this.ai.reward(output, this.runtime);
        
        this.runtime.lastInput = context.originalInput;
        this.runtime.lastOutput = output;
        this.runtime.lastScore = score;

        const a = await this.memory.add("user", context.originalInput, this.activeModel);
        const b = await this.memory.add("assistant", output, this.activeModel);
        this.memory.link(a, b);
        
        const extracted = await this.wikiEngine.extractFacts(context.originalInput, output);
        if (extracted && extracted.length > 0) {
            logger.info({facts: extracted.length}, "Wiki facts extracted");
            console.log(`\n${this.ui.colors.green}💡 [知識庫同步成功] 已為您即時提取並精煉 ${extracted.length} 條核心事實歸檔至智慧圖譜。${this.ui.colors.reset}`);
        }
        
        return output;
    }

    // ========== 步驟 10.2：快速通道 ==========
    async _executeFastTrack(context) {
        this.spinner.logThinking("Fast-Track Mode: Simple asset generation detected. Attempting direct rapid execution...");
        try {
            const fastModel = this.config.MODEL_FAST || "gemini-2.5-flash";
            const fastPrompt = `${context.enrichedInput}\n\n【B案格式指令規則】\n請直接給出要寫入的完整程式碼或文本，並在代碼塊正上方精確標註「File: 檔名.副檔名」（例如 File: login.html 或 File: login.py）。必須輸出完整內容，不可省略 any code。`;
            
            this.spinner.start("快速通道極速生成中");
            
            let fastOutput;
            try {
                const graph = this.ai.planner(fastPrompt);
                fastOutput = await this.ai.executeGraph(fastPrompt, graph, this.runtime, fastModel);
            } finally {
                this.spinner.stop();
            }
            
            this.spinner.logThinking("Applying Fast-Track generated file to filesystem...");
            this.executeAutoFileDrop(fastOutput, true, context.originalInput);
            
            await this.memory.add("user", context.originalInput, fastModel);
            await this.memory.add("assistant", fastOutput, fastModel);
            
            const extracted = await this.wikiEngine.extractFacts(context.originalInput, fastOutput);
            if (extracted && extracted.length > 0) {
                logger.info({facts: extracted.length}, "Fast-track wiki synced");
                console.log(`\n${this.ui.colors.green}💡 [知識庫同步成功] 快速通道已同步提取 ${extracted.length} 條動態知識核心。${this.ui.colors.reset}`);
            }
            
            return fastOutput;
        } catch (fastErr) {
            this.spinner.stop();
            logger.error({err: fastErr}, "Fast-track failed, falling back");
            console.error(`${this.ui.colors.red}[快速通道異常] ${fastErr.message}。自動安全降級至標準工程開發流...${this.ui.colors.reset}`);
            return await this._executeStandardFlow(context);
        }
    }

    // ========== 步驟 10.3：標準流程 ==========
    async _executeStandardFlow(context) {
        this.spinner.logThinking("Identified as Development/PlanA request.");

        let finalInputForPrompt = context.enrichedInput;
        if (this.config.ENFORCE_B_SCHEME_PROMPT) {
            finalInputForPrompt += `\n\n【B案格式指令規則】\n當你需要建立、修改或覆寫任何檔案程式碼時，請務必在該代碼塊的正上方標註「File: 檔案完整路徑」。\n範例：\nFile: C:\\tmp2\\web\\public\\app.js\n\`\`\`javascript\nconsole.log("hello");\n\`\`\`\n嚴禁使用任何省略號或「其餘相同省略」等縮減字眼，必須完整輸出每一行程式碼以供自動落盤系統辨識。`;
        }

        return await this.projectManager.runStandardFlow(finalInputForPrompt, this.ai, this.fsManager, this.ui, async (inp, analysis, roadmap) => {
            this.spinner.logThinking("Executing Multi-Agent Development Workflow...");
            const model = this.activeModel || (inp.length > 100 ? this.config.MODEL_SMART : this.config.MODEL_FAST);
            const contextualInput = `[Roadmap]\n${roadmap}\n\n[Analysis]\n${analysis}\n\n[Request]\n${inp}`;
            
            this.spinner.start("多智能體聯邦架構研討與代碼生成中");
            
            let code;
            try {
                code = await this.ai.executeMultiAgentWorkflow(contextualInput, model, this.runtime, this.fsManager);
            } finally {
                this.spinner.stop();
            }
            
            this.spinner.logThinking("Applying code edits to filesystem via B-Scheme...");
            this.executeAutoFileDrop(code, true, inp);

            this.spinner.logThinking("Updating memory and wiki...");
            const score = this.ai.reward(code, this.runtime);
            this.runtime.lastInput = inp;
            this.runtime.lastOutput = code;
            this.runtime.lastScore = score;
            await this.memory.add("user", inp, this.activeModel);
            await this.memory.add("assistant", code, this.activeModel);
            
            const extracted = await this.wikiEngine.extractFacts(inp, code);
            if (extracted && extracted.length > 0) {
                logger.info({facts: extracted.length}, "Standard flow wiki synced");
                console.log(`\n${this.ui.colors.green}💡 [知識庫同步成功] 聯邦開發流已成功將 ${extracted.length} 個重構決策寫入 Wiki 圖譜。${this.ui.colors.reset}`);
            }
            
            return code;
        }, (step) => this.spinner.logThinking(step));
    }
}

module.exports = Orchestrator;