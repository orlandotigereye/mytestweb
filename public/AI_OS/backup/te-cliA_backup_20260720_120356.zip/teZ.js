const readline = require("readline");
const fs = require("fs");
const path = require("path");
const cp = require("child_process");

const logger = require('./logger');
// 過濾環境變數殘留
const originalArgs = process.argv.slice(2);
const envVarPattern = /^[A-Z_]+=.+$/;
const cleanArgs = originalArgs.filter(arg => !envVarPattern.test(arg));
if (cleanArgs.length !== originalArgs.length) {
    const filtered = originalArgs.filter(arg => envVarPattern.test(arg));
    logger.debug("Filtered env var from args: %s", filtered.join(", "));
}

const config = require("./config/config");
const VersionManager = require("./core/version");

const UI = require("./lib/ui_renderer");
const MemorySystem = require("./lib/memory");
const FileSystemManager = require("./lib/file_system");
const AIEngine = require("./lib/ai_engine");
const ProjectManager = require("./core/projectManager");
const NovelEngine = require("./lib/novel_engine");
const WikiEngine = require("./lib/wiki_engine");
const Scheduler = require("./lib/scheduler");
const ExportEngine = require("./lib/export_engine");
const WebPortal = require("./lib/web_portal");
const Orchestrator = require("./core/orchestrator");
const CommandHandler = require("./core/commandHandler");
const DBEngine = require("./lib/db_engine");

const WebSearch = require("./lib/web_search");
const FetchURL = require("./lib/fetch_url");
const ExcelHandler = require("./lib/excel_handler");

let ACTIVE_MODEL = null;
const runtime = {
    start: Date.now(),
    requests: 0,
    rewardTotal: 0,
    rewardHistory: [],
    streamChunks: 0,
    cliQueue: 0,
    lastScore: 0,
    lastInput: "",
    lastOutput: ""
};

const version = new VersionManager(config);
const memory = new MemorySystem(config);
memory.load();

const fsManager = new FileSystemManager(config, version, UI.colors, UI);
const ai = new AIEngine(config, memory, UI, version);
const projectManager = new ProjectManager(config, version);
const novelEngine = new NovelEngine(config, ai, fsManager, UI);
const wikiEngine = new WikiEngine(config, ai, UI);
const exportEngine = new ExportEngine(config, UI);
const dbEngine = new DBEngine(config, ai, UI);
const scheduler = new Scheduler(config, UI, async (cmd) => {
    const output = await orchestrator.cognition(cmd);
    logger.info("Scheduled task completed");
});

const orchestrator = new Orchestrator({ config, ai, memory, fsManager, projectManager, wikiEngine, ui: UI, runtime });
const commandHandler = new CommandHandler({ config, ai, memory, fsManager, projectManager, wikiEngine, ui: UI, runtime, orchestrator, novelEngine, scheduler, version });

const webSearch = new WebSearch();
const fetchURL = new FetchURL();
const excelHandler = new ExcelHandler(ai);

UI.setTerminalTitle("Idle", version.current(), ACTIVE_MODEL, config);
logger.info("AI COGNITIVE OS v5 STARTED (Version: %s)", version.current());

function parseQuotedArgs(str) {
    str = (str || "").trim();
    if (!str) return { path: "", rest: "" };
    let p = "", r = "";
    if (str.startsWith('"') || str.startsWith("'")) {
        const q = str[0];
        const next = str.indexOf(q, 1);
        if (next !== -1) { p = str.substring(1, next); r = str.substring(next + 1).trim(); }
        else p = str.substring(1);
    } else {
        const space = str.indexOf(" ");
        if (space !== -1) { p = str.substring(0, space); r = str.substring(space + 1).trim(); }
        else p = str;
    }
    return { path: p, rest: r };
}

function runSandbox(filePath) {
    return new Promise((resolve) => {
        try {
            if (!fsManager.isPathSafe(filePath)) {
                logger.warn("Sandbox path traversal blocked: %s", filePath);
                return resolve({ success: false, error: "Security Exception: Sandbox traversal blocked." });
            }
            if (path.extname(filePath) !== ".js") return resolve({ success: true, stdout: "Not a JS file." });
            process.stdout.write(`${UI.colors.yellow}⏳ [planA] Running execution test... ${UI.colors.reset}`);
            const child = cp.exec(`node "${filePath}"`, { timeout: 4000 }, (error, stdout, stderr) => {
                if (error) {
                    logger.error({err: error}, "Sandbox execution failed");
                    console.log(`${UI.colors.red}Failed!${UI.colors.reset}`);
                    resolve({ success: false, error: error.message, stderr, stdout });
                } else {
                    logger.info("Sandbox execution success");
                    console.log(`${UI.colors.green}Success!${UI.colors.reset}`);
                    resolve({ success: true, stdout });
                }
            });
            child.on("error", (err) => {
                logger.error({err}, "Sandbox spawn failed");
                console.log(`${UI.colors.red}Failed to spawn!${UI.colors.reset}`);
                resolve({ success: false, error: err.message });
            });
        } catch (err) {
            logger.error({err}, "Unexpected error in runSandbox");
            resolve({ success: false, error: err.message });
        }
    });
}

const projectSubCommands = {
    "init": async (args) => {
        const targetDir = args.trim() || "./phase5-manager";
        const absTarget = path.resolve(config.ROOT, targetDir);

        if (!fsManager.isPathSafe(absTarget)) {
            throw new Error("Cannot initialize project outside workspace sandbox.");
        }
        logger.info("Initializing Phase5 Project in %s", absTarget);
        if (!fs.existsSync(absTarget)) fs.mkdirSync(absTarget, { recursive: true });

        const pkg = {
            name: "phase5-project-manager",
            version: "1.0.0",
            description: "Advanced Glassmorphism Web Kanban & Weekly Report Analyzer",
            main: "p5_web_server.js",
            dependencies: { express: "^4.18.2" }
        };
        fs.writeFileSync(path.join(absTarget, "package.json"), JSON.stringify(pkg, null, 2), "utf8");

        fs.writeFileSync(path.join(absTarget, "p5_kanban.json"), JSON.stringify({
            projectName: "Phase5 Project Workspace",
            tasks: [
                { id: "task-1", title: "Setup Glassmorphism Board", status: "Todo", desc: "Build standard web dashboard" },
                { id: "task-2", title: "Link AI Orchestrator", status: "In Progress", desc: "Bind with OrlandoGPT QA Critic" }
            ]
        }, null, 2), "utf8");

        logger.info("Created package.json & p5_kanban.json in %s", absTarget);
        console.log(`${UI.colors.green}✅ Created package.json & p5_kanban.json databases!${UI.colors.reset}`);
        console.log(`${UI.colors.cyan}👉 Run 'npm install' in ${targetDir} to pull express dashboard server dependencies.${UI.colors.reset}`);
    },

    "open": async (args) => {
        const targetDir = args.trim() || "./phase5-manager";
        const absTarget = path.resolve(config.ROOT, targetDir);

        const serverFile = path.join(absTarget, "p5_web_server.js");
        if (fs.existsSync(serverFile)) {
            logger.info("Starting Phase5 Dashboard Server from %s", absTarget);
            console.log(`${UI.colors.green}🌐 Starting Phase5 Express Dashboard Server...${UI.colors.reset}`);
            const proc = cp.exec(`node "${serverFile}"`, { cwd: absTarget });
            proc.stdout.on("data", data => logger.info("[Web Dashboard] %s", data.trim()));
            proc.stderr.on("data", data => logger.error("[Web Error] %s", data.trim()));
        } else {
            logger.warn("p5_web_server.js not found in %s", targetDir);
            console.log(`${UI.colors.yellow}⚠️ p5_web_server.js not found in ${targetDir}. Please generate/init first.${UI.colors.reset}`);
        }
    },

    "analyze": async (args) => {
        const targetDir = args.trim() || "./phase5-manager";
        const files = fsManager.readFolderRecursive(path.resolve(config.ROOT, targetDir));

        if (files.length === 0) {
            logger.warn("No code files found in %s", targetDir);
            console.log(`${UI.colors.yellow}⚠️ No code files found to analyze in ${targetDir}.${UI.colors.reset}`);
            return;
        }
        logger.info("Analyzing %d files in %s", files.length, targetDir);
        console.log(`\n${UI.colors.cyan}🕵️‍♂️ Scanning and analyzing project files in ${targetDir}...${UI.colors.reset}`);
        await orchestrator.cognition(`Please analyze this directory's overall structure and code quality. Summarize files dynamically:\n\n` +
            files.map(f => `File [${f.relPath}]:\n${f.content.substring(0, 1000)}`).join("\n---\n"));
        await UI.streamFormattedOutput(runtime.lastOutput, runtime.lastScore);
    },

    "roadmap": async (args) => {
        console.log(`\n${UI.colors.cyan}📍 CURRENT ROADMAP:${UI.colors.reset}`);
        console.table(projectManager.roadmap.data.tasks);
    },

    "risk": async (args) => {
        console.log(`\n${UI.colors.red}⚖️ LAST RISK ASSESSMENT:${UI.colors.reset}`);
        console.log("Risk analysis is performed per-request during the Standard Flow.");
    },
};

async function dispatchProject(args) {
    const trimmed = args.trim();
    let matchedSub = null;
    let matchedPrefix = "";
    for (const [name, handler] of Object.entries(projectSubCommands)) {
        if (trimmed.startsWith(name)) {
            if (name.length > matchedPrefix.length) {
                matchedPrefix = name;
                matchedSub = handler;
            }
        }
    }
    if (matchedSub) {
        const subArgs = trimmed.substring(matchedPrefix.length).trim();
        return await matchedSub(subArgs);
    }
    logger.warn("Unknown project command: %s", trimmed);
    console.log(`${UI.colors.yellow}Unknown project command. Try: /project init, /project roadmap, /project analyze, /project open${UI.colors.reset}`);
}

const novelSubCommands = {
    "init": async (args) => {
        const title = args.trim();
        const novel = await novelEngine.init(title);
        logger.info("Novel initialized: %s", title);
        console.log(`\n${UI.colors.green}📖 Novel "${title}" Initialized!${UI.colors.reset}`);
        console.log(novelEngine.getStatus());
    },

    "load": async (args) => {
        const title = args.trim();
        const novel = await novelEngine.load(title);
        if (novel) {
            logger.info("Novel loaded: %s", title);
            console.log(`\n${UI.colors.green}📖 Novel "${title}" Loaded!${UI.colors.reset}`);
            console.log(novelEngine.getStatus());
        } else {
            logger.warn("Novel not found: %s", title);
            console.log(`${UI.colors.red}Novel "${title}" not found.${UI.colors.reset}`);
        }
    },

    "next": async (args) => {
        const prompt = args.trim();
        const result = await novelEngine.writeNextChapter(prompt);
        logger.info("Chapter %d written to %s", result.chapterNum, result.path);
        console.log(`\n${UI.colors.green}✅ Chapter ${result.chapterNum} written to ${result.path}${UI.colors.reset}`);
        await UI.streamFormattedOutput(result.content, 5);
    },

    "status": async (args) => {
        console.log(novelEngine.getStatus());
    },

    "list": async (args) => {
        const novels = novelEngine.listNovels();
        console.log(`\n${UI.colors.cyan}📚 Available Novels:${UI.colors.reset}`);
        novels.forEach(n => console.log(` - ${n}`));
    },
};

async function dispatchNovel(args) {
    const trimmed = args.trim();
    if (novelSubCommands[trimmed]) {
        return await novelSubCommands[trimmed]("");
    }
    let matchedSub = null;
    let matchedPrefix = "";
    for (const [name, handler] of Object.entries(novelSubCommands)) {
        if (trimmed.startsWith(name + " ")) {
            if (name.length > matchedPrefix.length) {
                matchedPrefix = name;
                matchedSub = handler;
            }
        }
    }
    if (matchedSub) {
        const subArgs = trimmed.substring(matchedPrefix.length).trim();
        return await matchedSub(subArgs);
    }
    logger.warn("Unknown novel command: %s", trimmed);
    console.log(`${UI.colors.yellow}Unknown novel command. Try: /novel init <title>, /novel load <title>, /novel next [prompt], /novel status, /novel list${UI.colors.reset}`);
}

const cmd = (name, handler, completer = null) => ({ name, handler, completer });

const commands = {
    "/check": cmd("/check", async (args) => {
        logger.info("System check requested");
        console.log("📋 System Modules: Memory, UI, FS, AI Engine Loaded.");
    }),

    "/runtime": cmd("/runtime", async (args) => {
        logger.info({runtime: {...runtime, activeModel: ACTIVE_MODEL || "Dynamic"}}, "Runtime status");
        console.log("\n🧠 RUNTIME:", { ...runtime, activeModel: ACTIVE_MODEL || "Dynamic" });
    }),

    "/clear": cmd("/clear", async (args) => {
        if (memory && typeof memory.clear === 'function') {
            memory.clear();
        }
        logger.info("Memory cleared");
        console.log(`${UI.colors.green}🧹 當前對話記憶上下文已清除。${UI.colors.reset}`);
    }),

    "/model": cmd("/model", async (args) => {
        const m = args.trim().toLowerCase();
        ACTIVE_MODEL = m === "smart" ? config.MODEL_SMART : (m === "fast" ? config.MODEL_FAST : null);
        orchestrator.activeModel = ACTIVE_MODEL;
        logger.info("Model switched to %s", ACTIVE_MODEL || "Dynamic");
        console.log(`🤖 Model set to: ${ACTIVE_MODEL || "Dynamic"}`);
    }, ["smart", "fast", "dynamic"]),

    "/config": cmd("/config", async (args) => {
        const parts = args.trim().split(" ");
        if (parts.length === 2) {
            config[parts[0]] = parts[1];
            logger.info("Config updated: %s = %s", parts[0], parts[1]);
            console.log(`${UI.colors.green}⚙️ Config updated: ${parts[0]} = ${parts[1]}${UI.colors.reset}`);
        } else {
            logger.warn("Invalid config command: %s", args);
            console.log(`${UI.colors.yellow}Usage: /config <KEY> <VALUE>${UI.colors.reset}`);
        }
    }),

    "/test": cmd("/test", async (args) => {
        const fileToTest = args.trim();
        const absTestPath = path.resolve(config.ROOT, fileToTest);
        logger.info("Running sandbox test: %s", absTestPath);
        const result = await runSandbox(absTestPath);
        if (result.success) {
            console.log(`\n${UI.colors.green}✅ 測試執行成功:\n${result.stdout}${UI.colors.reset}`);
        } else {
            console.log(`\n${UI.colors.red}❌ 測試執行失敗:\n${result.error || result.stderr}${UI.colors.reset}`);
        }
    }),

    "/file": cmd("/file", async (args) => {
        const { path: f, rest: p } = parseQuotedArgs(args);
        logger.info("Reading file: %s", f);
        const content = fsManager.read_file(f);
        await orchestrator.cognition(`[File: ${f}]\n${content}\n\n${p}`);
        await UI.streamFormattedOutput(runtime.lastOutput, runtime.lastScore);
    }),

    "/folder": cmd("/folder", async (args) => {
        const { path: dir, rest: p } = parseQuotedArgs(args);
        const files = fsManager.readFolderRecursive(dir);
        if (files.length === 0) {
            logger.warn("No files found in directory: %s", dir);
            console.log(`${UI.colors.yellow}⚠️ No match files found in directory: ${dir}${UI.colors.reset}`);
            return;
        }
        logger.info("Processing %d files from %s", files.length, dir);
        UI.startSpinner(version.current(), ACTIVE_MODEL, config, "Processing folder files...", 10);

        const processedFiles = await Promise.all(files.map(async (file) => {
            let fileContent = file.content;
            if (fileContent.length > 10000 && ai) {
                logger.info("Summarizing large file: %s (%d chars)", file.relPath, fileContent.length);
                console.log(`\n${UI.colors.yellow}⚠️ File ${file.relPath} is large (${fileContent.length} chars). Summarizing concurrently...${UI.colors.reset}`);
                try {
                    const summary = await ai.summarizeContent(fileContent.substring(0, 15000), config.MODEL_FAST);
                    fileContent = `[SUMMARY: ${summary}]`;
                } catch (e) {
                    logger.error({err: e}, "Summary failed for %s", file.relPath);
                    fileContent = fileContent.substring(0, 5000) + "\n... (Truncated due to summary failure) ...";
                }
            }
            return { relPath: file.relPath, content: fileContent };
        }));

        UI.stopSpinner();

        let folderContext = `[Loaded Directory: ${dir}]\n`;
        for (const file of processedFiles) {
            folderContext += `\n--- File: ${file.relPath} ---\n${file.content}\n`;
        }

        console.log(`${UI.colors.green}ℹ️ Loaded ${files.length} files from directory: ${dir}${UI.colors.reset}`);
        await orchestrator.cognition(`${folderContext}\n\nUser Request: ${p}`);
        await UI.streamFormattedOutput(runtime.lastOutput, runtime.lastScore);
    }),

    "/project": cmd("/project", async (args) => {
        await dispatchProject(args);
    }, ["init", "open", "analyze", "roadmap", "risk"]),

    "/novel": cmd("/novel", async (args) => {
        await dispatchNovel(args);
    }, ["init", "load", "next", "status", "list"]),

    "/schedule": cmd("/schedule", async (args) => {
        const cmd = args.trim();
        const space = cmd.indexOf(" ");
        if (space !== -1) {
            const time = cmd.substring(0, space);
            const taskCmd = cmd.substring(space + 1);
            scheduler.add(time, taskCmd);
            logger.info("Task scheduled: %s -> %s", time, taskCmd);
            console.log(`${UI.colors.green}⏰ Task scheduled for ${time}: ${taskCmd}${UI.colors.reset}`);
        } else {
            logger.warn("Invalid schedule command: %s", cmd);
            console.log(`${UI.colors.yellow}Usage: /schedule <HH:mm | in Xm> <command>${UI.colors.reset}`);
        }
    }),

    "/wiki": cmd("/wiki", async (args) => {
        console.log(wikiEngine.getWikiSummary());
    }),

    "/analyze": cmd("/analyze", async (args) => {
        const file = args.trim();
        logger.info("Analyzing document: %s", file);
        const content = await fsManager.analyzeDocument(file, ai);
        await orchestrator.cognition(`[Document Context: ${file}]\n${content}\n\nPlease analyze this document.`);
        await UI.streamFormattedOutput(runtime.lastOutput, 5);
    }),

    "/export": cmd("/export", async (args) => {
        const cmd = args.trim();
        if (cmd === "novel") {
            if (novelEngine.activeNovel) {
                const exportPath = await exportEngine.exportNovel(novelEngine.activeNovel);
                logger.info("Novel exported to %s", exportPath);
                console.log(`${UI.colors.green}📄 Novel exported to HTML: ${exportPath}${UI.colors.reset}`);
            } else {
                logger.warn("No active novel to export");
                console.log(`${UI.colors.red}No active novel to export.${UI.colors.reset}`);
            }
        } else {
            const exportPath = await exportEngine.exportReport("System Report", runtime.lastOutput);
            logger.info("Report exported to %s", exportPath);
            console.log(`${UI.colors.green}📄 Report exported to HTML: ${exportPath}${UI.colors.reset}`);
        }
    }, ["novel", "report"]),

    "/db": cmd("/db", async (args) => {
        const question = args.trim();
        logger.info("DB query: %s", question);
        const result = await dbEngine.ask(question);
        if (result.error) {
            logger.error("DB Error: %s", result.error);
            console.log(`${UI.colors.red}❌ DB Error: ${result.error}${UI.colors.reset}`);
        } else {
            console.table(result.slice(0, 20));
            console.log(`${UI.colors.green}✅ Found ${result.length} rows.${UI.colors.reset}`);
            runtime.lastOutput = JSON.stringify(result);
        }
    }),

    "/portal": cmd("/portal", async (args) => {
        logger.info("Starting web portal");
        WebPortal.startPortal(config, orchestrator, UI);
    }),

    "/search": cmd("/search", async (args) => {
        const query = args.trim();
        if (!query) {
            logger.warn("Empty search query");
            console.log(`${UI.colors.yellow}Usage: /search <query>${UI.colors.reset}`);
            return;
        }
        try {
            logger.info("Web search: %s", query);
            const results = await webSearch.search(query, { limit: 5 });
            console.log(`\n🔍 搜尋結果：\"${query}\"`);
            results.forEach((r, i) => {
                console.log(`\n${i + 1}. ${r.title}`);
                console.log(`   ${UI.colors.blue}${r.url}${UI.colors.reset}`);
                console.log(`   ${r.snippet.substring(0, 150)}...`);
            });
            const summaryPrompt = `總結以下搜尋結果，提取關鍵資訊：\n\n` +
                results.map(r => `標題：${r.title}\n摘要：${r.snippet}`).join("\n\n");
            const summary = await ai.summarizeContent(summaryPrompt, config.MODEL_FAST);
            console.log(`\n${UI.colors.cyan}📋 AI 總結：${UI.colors.reset}`);
            console.log(summary);
        } catch (e) {
            logger.error({err: e}, "Search failed");
            console.log(`${UI.colors.red}搜尋失敗：${e.message}${UI.colors.reset}`);
        }
    }),

    "/fetch": cmd("/fetch", async (args) => {
        const url = args.trim();
        if (!url) {
            logger.warn("Empty fetch URL");
            console.log(`${UI.colors.yellow}Usage: /fetch <url>${UI.colors.reset}`);
            return;
        }
        try {
            logger.info("Fetching URL: %s", url);
            const page = await fetchURL.fetch(url);
            console.log(`\n📄 ${UI.colors.bold}${page.title}${UI.colors.reset}`);
            console.log(`\n${page.text.substring(0, 3000)}...`);
            console.log(`\n${UI.colors.gray}[共 ${page.length} 字元，已截斷顯示前 3000 字元]${UI.colors.reset}`);
            const prompt = `[Web Page: ${url}]\nTitle: ${page.title}\nContent: ${page.text.substring(0, 10000)}\n\n請分析這個網頁的內容。`;
            await orchestrator.cognition(prompt);
            await UI.streamFormattedOutput(runtime.lastOutput, runtime.lastScore);
        } catch (e) {
            logger.error({err: e}, "Fetch failed");
            console.log(`${UI.colors.red}讀取失敗：${e.message}${UI.colors.reset}`);
        }
    }),

    "/excel": cmd("/excel", async (args) => {
        const { path: filePath, rest: cmd } = parseQuotedArgs(args);
        if (!filePath) {
            logger.warn("Empty excel command");
            console.log(`${UI.colors.yellow}Usage: /excel <file.xlsx> <read|analyze|transform>${UI.colors.reset}`);
            return;
        }
        const subCmd = cmd.trim() || "read";
        try {
            if (subCmd === "read") {
                logger.info("Reading Excel: %s", filePath);
                const data = excelHandler.read(filePath);
                console.log(`\n📊 Excel 內容：`);
                Object.entries(data).forEach(([name, rows]) => {
                    console.log(`\n--- Sheet: ${name} ---`);
                    rows.slice(0, 10).forEach((row, i) => {
                        console.log(`  ${i === 0 ? 'H' : i}: ${JSON.stringify(row)}`);
                    });
                    if (rows.length > 10) console.log(`  ... 還有 ${rows.length - 10} 行`);
                });
            }
            else if (subCmd === "analyze") {
                logger.info("Analyzing Excel: %s", filePath);
                const data = excelHandler.read(filePath);
                const analysis = excelHandler.analyze(data);
                console.log(`\n📈 Excel 分析：`);
                Object.entries(analysis.sheets).forEach(([name, sheet]) => {
                    console.log(`\n--- Sheet: ${name} ---`);
                    console.log(`  行數：${sheet.rowCount}`);
                    console.log(`  欄位：${sheet.headers.join(', ')}`);
                    console.log(`  欄位統計：`);
                    Object.entries(sheet.summary).forEach(([col, stats]) => {
                        console.log(`    ${col}: ${stats.type}, count=${stats.count}, avg=${stats.avg?.toFixed(2) || 'N/A'}`);
                    });
                });
            }
            else if (subCmd === "transform") {
                logger.info("Transforming Excel: %s", filePath);
                const data = excelHandler.read(filePath);
                const transformed = excelHandler.transform(data, [
                    {
                        type: 'addColumn',
                        newHeader: '總額',
                        formula: (row) => {
                            const price = parseFloat(row[2]) || 0;
                            const qty = parseFloat(row[3]) || 0;
                            return price * qty;
                        }
                    }
                ]);
                const outPath = filePath.replace('.xlsx', '_modified.xlsx');
                excelHandler.write(transformed, outPath);
                logger.info("Excel transformed and saved to %s", outPath);
                console.log(`${UI.colors.green}✅ 已儲存改寫後的檔案：${outPath}${UI.colors.reset}`);
            }
            else if (subCmd === "ai") {
                const question = cmd.substring(2).trim() || "分析這份資料的整體趨勢";
                logger.info("AI analyzing Excel: %s, question: %s", filePath, question);
                const result = await excelHandler.aiAnalyze(filePath, question);
                console.log(`\n${UI.colors.cyan}🤖 AI 分析結果：${UI.colors.reset}`);
                console.log(result);
            }
            else {
                logger.warn("Unknown excel command: %s", subCmd);
                console.log(`${UI.colors.yellow}Unknown excel command. Try: read, analyze, transform, ai${UI.colors.reset}`);
            }
        } catch (e) {
            logger.error({err: e}, "Excel processing failed");
            console.log(`${UI.colors.red}Excel 處理失敗：${e.message}${UI.colors.reset}`);
        }
    }, ["read", "analyze", "transform", "ai"]),

    "/help": cmd("/help", async (args) => {
        const c = UI.colors;
        console.log(`\n${c.cyan}${c.bold}🧠 AI COGNITIVE OS v5 - FULL COMMAND GUIDE${c.reset}`);

        console.log(`\n${c.magenta}${c.bold}[ 🛠️ SYSTEM & STATUS ]${c.reset}`);
        console.log(`  ${c.yellow}/check${c.reset}              - 檢查系統模組加載狀態`);
        console.log(`  ${c.yellow}/runtime${c.reset}            - 顯示運行指標、請求次數與獎勵積分`);
        console.log(`  ${c.yellow}/model <type>${c.reset}       - 切換模型 (${c.gray}fast | smart | dynamic${c.reset})`);
        console.log(`  ${c.yellow}/config <key> <val>${c.reset} - 動態調整系統參數`);
        console.log(`  ${c.yellow}/clear${c.reset}              - 清除當前對話記憶`);
        console.log(`  ${c.yellow}exit${c.reset}                - 安全退出系統`);

        console.log(`\n${c.magenta}${c.bold}[ 📂 FILE & DATA ]${c.reset}`);
        console.log(`  ${c.yellow}/file <path> <cmd>${c.reset}  - 讀取特定檔案並執行 AI 指令`);
        console.log(`  ${c.yellow}/folder <dir> <cmd>${c.reset} - 遞迴讀取資料夾內容`);
        console.log(`  ${c.yellow}/analyze <file>${c.reset}     - 針對 PDF/Excel 等非文字檔進行深度分析`);
        console.log(`  ${c.yellow}/test <file>${c.reset}       - 啟動沙箱執行 JS 腳本並檢查錯誤`);

        console.log(`\n${c.magenta}${c.bold}[ 🚀 DEVELOPMENT & PROJECT ]${c.reset}`);
        console.log(`  ${c.yellow}/project init${c.reset}       - 初始化專案管理環境與看板`);
        console.log(`  ${c.yellow}/project roadmap${c.reset}    - 顯示當前開發任務進度表`);
        console.log(`  ${c.yellow}/project analyze${c.reset}    - 掃描專案結構與代碼品質`);
        console.log(`  ${c.yellow}/project open${c.reset}       - 啟動 Express Web 任務看板`);
        console.log(`  ${c.yellow}/project risk${c.reset}       - 查看最近一次改動的風險評估`);

        console.log(`\n${c.magenta}${c.bold}[ 🖋️ NOVEL CREATION ]${c.reset}`);
        console.log(`  ${c.yellow}/novel init <title>${c.reset} - 開始一部新小說，生成大綱與設定`);
        console.log(`  ${c.yellow}/novel next [prompt]${c.reset}- 撰寫下一章節`);
        console.log(`  ${c.yellow}/novel status${c.reset}       - 查看寫作進度`);
        console.log(`  ${c.yellow}/novel list${c.reset}         - 列出本地所有小說作品`);

        console.log(`\n${c.magenta}${c.bold}[ 🔍 WEB TOOLS ]${c.reset}`);
        console.log(`  ${c.yellow}/search <query>${c.reset}     - 網頁搜尋（DuckDuckGo）`);
        console.log(`  ${c.yellow}/fetch <url>${c.reset}        - 讀取網頁內容並分析`);
        console.log(`  ${c.yellow}/excel <file> <cmd>${c.reset} - Excel 讀取/分析/改寫`);

        console.log(`\n${c.magenta}${c.bold}[ 💼 BUSINESS & AUTOMATION ]${c.reset}`);
        console.log(`  ${c.yellow}/schedule <time> <cmd>${c.reset}- 設定定時任務`);
        console.log(`  ${c.yellow}/wiki${c.reset}                - 檢視企業知識百科`);
        console.log(`  ${c.yellow}/export <type>${c.reset}        - 匯出 HTML 報告`);
        console.log(`  ${c.yellow}/portal${c.reset}              - 啟動瀏覽器互動門戶`);

        console.log(`\n${c.cyan}💡 提示: 直接輸入問題即可進行 AI 對話或啟動自動化編碼工作流 (PlanA)。${c.reset}\n`);
    }),

    "exit": cmd("exit", async (args) => {
        logger.info("System exiting");
        process.exit(0);
    }),
};

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    completer: (line) => {
        const allCommands = Object.keys(commands);
        const hits = allCommands.filter(c => c.startsWith(line.trim()));
        return [hits.length ? hits : allCommands, line];
    }
});

const promptUser = () => {
    UI.setTerminalTitle("Idle", version.current(), ACTIVE_MODEL, config);
    rl.setPrompt(`\n${UI.colors.cyan}${UI.colors.bold}You ➔ ${UI.colors.reset}`);
    rl.prompt();
};

async function dispatchCommand(input) {
    const trimmed = input.trim();
    if (!trimmed) return;

    try {
        if (commands[trimmed]) {
            return await commands[trimmed].handler("", { runtime, orchestrator, fsManager, ui: UI });
        }

        let matchedCmd = null;
        let matchedPrefix = "";
        for (const [name, cmdDef] of Object.entries(commands)) {
            if (trimmed.startsWith(name + " ")) {
                if (name.length > matchedPrefix.length) {
                    matchedPrefix = name;
                    matchedCmd = cmdDef;
                }
            }
        }

        if (matchedCmd) {
            const args = trimmed.substring(matchedPrefix.length + 1);
            return await matchedCmd.handler(args, { runtime, orchestrator, fsManager, ui: UI });
        }

        logger.info("AI cognition triggered for: %s", trimmed.substring(0, 50));
        await orchestrator.cognition(trimmed);
        await UI.streamFormattedOutput(runtime.lastOutput, runtime.lastScore);
    } catch (e) {
        logger.error({err: e}, "Command dispatch failed");
        console.error(`${UI.colors.red}Error: ${e.message}${UI.colors.reset}`);
    }
}

rl.on("line", async (line) => {
    runtime.cliQueue++;
    try {
        await dispatchCommand(line);
    } catch (e) {
        logger.error({err: e}, "Command execution failed");
        console.error(`${UI.colors.red}Error: ${e.message}${UI.colors.reset}`);
    }
    promptUser();
});

// ========== 全域錯誤處理與優雅關閉 ==========
process.on("uncaughtException", (err) => {
    logger.fatal({err}, "Uncaught Exception");
    console.error(`${UI.colors.red}💥 Uncaught Exception: ${err.message}${UI.colors.reset}`);
    console.error(err.stack);
    safeShutdown(1);
});

process.on("unhandledRejection", (reason, promise) => {
    logger.fatal({reason}, "Unhandled Rejection");
    console.error(`${UI.colors.red}💥 Unhandled Rejection at: ${promise}${UI.colors.reset}`);
    console.error(reason);
    safeShutdown(1);
});

async function safeShutdown(exitCode = 0) {
    console.log('\n💾 [System Guard] 正在執行優雅關閉與狀態存盤...');
    const shutdownTimeout = setTimeout(() => {
        console.error('⚠️ [System Guard] 存盤超時，強制退出');
        process.exit(exitCode);
    }, 5000);

    try {
        if (memory && typeof memory.save === 'function') {
            await memory.save();
            console.log('✅ Memory saved');
        }
        if (projectManager && typeof projectManager.saveState === 'function') {
            await projectManager.saveState();
            console.log('✅ Project state saved');
        }
        console.log('✅ [System Guard] 所有運行核心存盤完畢，安全退出系統。');
    } catch (e) {
        console.error('❌ [System Guard] 緊急存盤失敗:', e.message);
    } finally {
        clearTimeout(shutdownTimeout);
        rl.close();
        process.exit(exitCode);
    }
}

// 讓 ProcessGuard 也使用我們的 safeShutdown
const ProcessGuard = require("./core/ProcessGuard");
ProcessGuard.attach(memory, projectManager, () => {
    // spinner stop 已由 ProcessGuard 處理，這裡觸發優雅關閉
});

promptUser();