/**
 * AI Cognitive OS v5 - Simple Logger
 * 無外部依賴，完全相容 pino API
 */

const LEVELS = {
    fatal: 60,
    error: 50,
    warn: 40,
    info: 30,
    debug: 20,
    trace: 10
};

const COLORS = {
    fatal: '\x1b[35m',   // magenta
    error: '\x1b[31m',   // red
    warn: '\x1b[33m',    // yellow
    info: '\x1b[36m',    // cyan
    debug: '\x1b[90m',   // gray
    trace: '\x1b[37m',   // white
    reset: '\x1b[0m'
};

const CURRENT_LEVEL = LEVELS[process.env.LOG_LEVEL] || LEVELS.info;

/**
 * 格式化訊息，支援 %s %d %j 等佔位符
 */
function formatMessage(msg, args) {
    if (typeof msg !== 'string') {
        try {
            return JSON.stringify(msg);
        } catch (e) {
            return String(msg);
        }
    }

    let index = 0;
    return msg.replace(/%([sdj%])/g, (match, type) => {
        if (type === '%') return '%';
        if (index >= args.length) return match;
        
        const arg = args[index++];
        switch (type) {
            case 's': return String(arg);
            case 'd': return Number(arg).toString();
            case 'j': 
                try {
                    return JSON.stringify(arg);
                } catch (e) {
                    return '[Circular]';
                }
            default: return match;
        }
    });
}

/**
 * 取得額外資訊（錯誤物件等）
 */
function getExtra(args) {
    if (args.length === 0) return '';
    
    const last = args[args.length - 1];
    if (last && typeof last === 'object') {
        if (last.err instanceof Error) {
            return '\n' + (last.err.stack || last.err.message);
        }
        // 過濾掉已經處理過的佔位符參數
        if (args.length > 1) return '';
        
        // 純物件，格式化輸出
        try {
            return ' ' + JSON.stringify(last);
        } catch (e) {
            return ' [Object]';
        }
    }
    return '';
}

/**
 * 核心日誌函數
 */
function log(level, msg, ...args) {
    if (LEVELS[level] < CURRENT_LEVEL) return;

    const timestamp = new Date().toISOString();
    const color = COLORS[level] || '';
    const reset = COLORS.reset;

    // 分離佔位符參數和額外物件
    const formatArgs = [];
    let extraObj = null;
    
    for (const arg of args) {
        if (extraObj === null && typeof arg === 'object' && !(arg instanceof Error)) {
            extraObj = arg;
        } else {
            formatArgs.push(arg);
        }
    }

    const text = formatMessage(msg, formatArgs);
    const extra = extraObj ? getExtra([extraObj]) : '';

    // 輸出到 console
    console.log(`${color}[${timestamp}] ${level.toUpperCase()}:${reset} ${text}${extra}`);
}

/**
 * 建立子日誌器（相容 pino child）
 */
function createChild(bindings) {
    const prefix = bindings 
        ? `[${Object.entries(bindings).map(([k, v]) => `${k}=${v}`).join(' ')}] ` 
        : '';

    return {
        fatal: (m, ...a) => log('fatal', prefix + m, ...a),
        error: (m, ...a) => log('error', prefix + m, ...a),
        warn:  (m, ...a) => log('warn', prefix + m, ...a),
        info:  (m, ...a) => log('info', prefix + m, ...a),
        debug: (m, ...a) => log('debug', prefix + m, ...a),
        trace: (m, ...a) => log('trace', prefix + m, ...a),
        child: (b) => createChild({ ...bindings, ...b })
    };
}

// 主日誌器
const logger = {
    fatal: (m, ...a) => log('fatal', m, ...a),
    error: (m, ...a) => log('error', m, ...a),
    warn:  (m, ...a) => log('warn', m, ...a),
    info:  (m, ...a) => log('info', m, ...a),
    debug: (m, ...a) => log('debug', m, ...a),
    trace: (m, ...a) => log('trace', m, ...a),
    child: createChild
};

module.exports = logger;