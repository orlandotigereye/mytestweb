using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GlassDetection
{
    /// <summary>
    /// 範例3：玻璃檢測線（狀態機 + 安全監控 + CCD/AOI 整合版）
    /// </summary>
    public class Example3_GlassInspection
    {
        private RobotModule _robot;
        private RobotStateMachine _sm;
        private bool _isGlassOK = true;

        public async Task RunAsync(CancellationToken token = default)
        {
            // 注意：RobotModule 負責管理 IRobotController 與 IIOController 的生命週期
            // 不要在這裡用 using，因為這兩個類別目前未實作 IDisposable
            var robotController = new EsponRobotControl();
            var ioController = new DAQIOCtrl();
            _robot = new RobotModule(robotController, ioController);
            _sm = new RobotStateMachine(_robot);

            try
            {
                _sm.StateChanged += (s, e) =>
                    Console.WriteLine(FormattableString.Invariant($"[UI] 狀態：{e.OldState} → {e.NewState}"));
                _sm.StepChanged += (s, e) =>
                    Console.WriteLine(FormattableString.Invariant($"[UI] 步驟 {e.StepIndex + 1}/{e.TotalSteps}：{e.StepName}"));
                _sm.ErrorOccurred += (s, e) =>
                {
                    Console.WriteLine($"[UI] 異常！{e.Message}");
                    MessageBox.Show($"異常：{e.Message}", "警報");
                };

                Console.WriteLine("===== 範例3：玻璃檢測線 開始 =====");

                if (!_robot.Initialize("192.168.0.1", 5000))
                {
                    MessageBox.Show("連線失敗", "錯誤");
                    return;
                }
                if (!_robot.LoginAndServoOn())
                    return;

                _robot.SetSpeed(ptpSpeed: 65, linearSpeed: 1200, acc: 20, dec: 20, lineAcc: 1400, lineDec: 1400);
                _robot.LoadPositions("Positions_Inspection.ini");

                var sequence = new List<SequenceStep>
                {
                    new SequenceStep("回 Home",          async (ct) => await _robot.GoSafeAsync("Home", token: ct).ConfigureAwait(false)),
                    new SequenceStep("等待位",           async (ct) => await _robot.GoSafeAsync("HoldPoint", token: ct).ConfigureAwait(false)),
                    new SequenceStep("等待玻璃到達",     async (ct) => await _robot.WaitGlassArrivedAsync(0, 10000, ct).ConfigureAwait(false)),
                    new SequenceStep("左側拍照位",       async (ct) => await _robot.GoSafeAsync("LeftTakePicture", token: ct).ConfigureAwait(false)),
                    new SequenceStep("等待穩定",         async (ct) => { await Task.Delay(2500, ct).ConfigureAwait(false); return true; }),
                    new SequenceStep("CCD定位拍照",      async (ct) => await RunCCDLocateAsync(ct).ConfigureAwait(false)),
                    new SequenceStep("玻璃中心",         async (ct) => await _robot.GoSafeAsync("GlassCenter", token: ct).ConfigureAwait(false)),
                    new SequenceStep("吸取高度1",        async (ct) => await _robot.MoveZSafeAsync(318, token: ct).ConfigureAwait(false)),
                    new SequenceStep("吸取高度2",        async (ct) => await _robot.MoveZSafeAsync(305, token: ct).ConfigureAwait(false)),
                    new SequenceStep("開真空",           () => _robot.VacuumOn()),
                    new SequenceStep("等待真空",         async (ct) => await _robot.WaitVacuumAsync(3000, ct).ConfigureAwait(false)),
                    new SequenceStep("提起安全高度",     async (ct) => await _robot.MoveZSafeAsync(530, token: ct).ConfigureAwait(false)),
                    new SequenceStep("經過中間點",       async (ct) => await _robot.GoSafeAsync("Home", token: ct).ConfigureAwait(false)),
                    new SequenceStep("檢測位置1",        async (ct) => await _robot.GoSafeAsync("InspectPos1", token: ct).ConfigureAwait(false)),
                    new SequenceStep("檢測1-左邊緣",     async (ct) => await RunAOIAsync(CCD.Left, ct).ConfigureAwait(false)),
                    new SequenceStep("檢測1-右邊緣",     async (ct) => await RunAOIAsync(CCD.Right, ct).ConfigureAwait(false)),
                    new SequenceStep("檢測位置2",        async (ct) => await _robot.GoSafeAsync("InspectPos2", token: ct).ConfigureAwait(false)),
                    new SequenceStep("檢測2-左邊緣",     async (ct) => await RunAOIAsync(CCD.Left, ct).ConfigureAwait(false)),
                    new SequenceStep("檢測2-右邊緣",     async (ct) => await RunAOIAsync(CCD.Right, ct).ConfigureAwait(false)),
                    new SequenceStep("檢測位置3",        async (ct) => await _robot.GoSafeAsync("InspectPos3", token: ct).ConfigureAwait(false)),
                    new SequenceStep("檢測3-左邊緣",     async (ct) => await RunAOIAsync(CCD.Left, ct).ConfigureAwait(false)),
                    new SequenceStep("檢測3-右邊緣",     async (ct) => await RunAOIAsync(CCD.Right, ct).ConfigureAwait(false)),
                    new SequenceStep("判斷OK/NG",        () => CheckInspectionResult()),
                    new SequenceStep("OK-安全點",        async (ct) => _isGlassOK ? await _robot.GoSafeAsync("OKSafePoint", token: ct).ConfigureAwait(false) : true, isCritical: false),
                    new SequenceStep("OK-輸送帶",        async (ct) => _isGlassOK ? await _robot.GoSafeAsync("OKConveyor", token: ct).ConfigureAwait(false) : true, isCritical: false),
                    new SequenceStep("OK-放置",          async (ct) => _isGlassOK ? await _robot.PlaceSafeAsync("OKConveyor", token: ct).ConfigureAwait(false) : true, isCritical: false),
                    new SequenceStep("OK-回安全點",      async (ct) => _isGlassOK ? await _robot.GoSafeAsync("OKSafePoint", token: ct).ConfigureAwait(false) : true, isCritical: false),
                    new SequenceStep("NG-安全點",        async (ct) => !_isGlassOK ? await _robot.GoSafeAsync("NGSafePoint", token: ct).ConfigureAwait(false) : true, isCritical: false),
                    new SequenceStep("NG-輸送帶",        async (ct) => !_isGlassOK ? await _robot.GoSafeAsync("NGConveyor", token: ct).ConfigureAwait(false) : true, isCritical: false),
                    new SequenceStep("NG-放置",          async (ct) => !_isGlassOK ? await _robot.PlaceSafeAsync("NGConveyor", token: ct).ConfigureAwait(false) : true, isCritical: false),
                    new SequenceStep("NG-回安全點",      async (ct) => !_isGlassOK ? await _robot.GoSafeAsync("NGSafePoint", token: ct).ConfigureAwait(false) : true, isCritical: false),
                    new SequenceStep("回等待位",         async (ct) => await _robot.GoSafeAsync("HoldPoint", token: ct).ConfigureAwait(false)),
                };

                _sm.DefineSequence(sequence);
                _sm.Start();

                Console.WriteLine("檢測線流程已在背景執行，按任意鍵停止...");
                await Task.Run(() => Console.ReadKey(true), token).ConfigureAwait(false);

                _sm.Stop();
            }
            finally
            {
                _sm?.Dispose();
                _robot?.Dispose();
            }
        }

        private async Task<bool> RunCCDLocateAsync(CancellationToken token)
        {
            Console.WriteLine("[CCD] 執行定位拍照...");
            await Task.Delay(500, token).ConfigureAwait(false);
            Console.WriteLine("[CCD] 定位完成");
            return true;
        }

        private async Task<bool> RunAOIAsync(CCD side, CancellationToken token)
        {
            Console.WriteLine(FormattableString.Invariant($"[AOI] 檢測 {side} 邊緣..."));
            await Task.Delay(side == CCD.Left ? 120 : 70, token).ConfigureAwait(false);
            Console.WriteLine(FormattableString.Invariant($"[AOI] {side} 檢測完成"));
            return true;
        }

        private bool CheckInspectionResult()
        {
            Console.WriteLine($"[AOI] 總結果：{(_isGlassOK ? "OK" : "NG")}");
            return true;
        }
    }

    public enum CCD { Left, Right }
}
