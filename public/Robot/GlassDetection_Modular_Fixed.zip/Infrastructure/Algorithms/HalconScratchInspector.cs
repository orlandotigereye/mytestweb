using GlassDetection.Core.Interfaces;
using HalconDotNet;

namespace GlassDetection.Infrastructure.Algorithms
{
    public class HalconScratchInspector : IInspectionAlgorithm
    {
        public string AlgorithmName => "ScratchInspector";
        public void Initialize() { }
        public bool Run(HWindow window, HObject image, string patternName, out bool[] defectFlags)
        {
            defectFlags = new bool[4] { true, true, true, true };
            return true;
        }
    }
}
