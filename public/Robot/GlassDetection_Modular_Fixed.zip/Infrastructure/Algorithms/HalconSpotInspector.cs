using GlassDetection.Core.Interfaces;
using HalconDotNet;

namespace GlassDetection.Infrastructure.Algorithms
{
    public class HalconSpotInspector : IInspectionAlgorithm
    {
        public string AlgorithmName => "SpotInspector";
        public void Initialize() { }
        public bool Run(HWindow window, HObject image, string patternName, out bool[] defectFlags)
        {
            defectFlags = new bool[4] { true, true, true, true };
            return true;
        }
    }
}
