using GlassDetection.Core.Interfaces;

namespace GlassDetection.Infrastructure.Hardware
{
    public class OptLightController : ILightController
    {
        public string Name { get; set; } = "OPT";
        public bool IsConnected { get; private set; }

        public int Connect(string ipAddress)
        {
            IsConnected = true;
            return 0;
        }
        public int Disconnect()
        {
            IsConnected = false;
            return 0;
        }
        public int TurnOnChannel(int channelId, int intensity) { return 0; }
        public int TurnOffChannel(int channelId) { return 0; }
        public int TurnOffAll() { return 0; }
    }
}
