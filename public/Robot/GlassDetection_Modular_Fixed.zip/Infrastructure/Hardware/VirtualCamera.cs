using System;
using GlassDetection.Core.Interfaces;

namespace GlassDetection.Infrastructure.Hardware
{
    public class VirtualCamera : ICamera
    {
        public string DeviceName => "Virtual";
        public bool IsConnected { get; private set; }
        public bool IsGrabbing { get; private set; }

        public int Connect(int deviceIndex) { IsConnected = true; return 0; }
        public int Disconnect() { IsConnected = false; IsGrabbing = false; return 0; }
        public int StartGrabbing() { IsGrabbing = true; return 0; }
        public int StopGrabbing() { IsGrabbing = false; return 0; }
        public int TriggerSoftware() { return 0; }
        public int GetImageBuffer(ref IFrameout frameInfo, int timeoutMs) { return 0; }
        public int FreeImageBuffer(ref IFrameout frameInfo) { return 0; }
        public int SetSoftwareTriggerMode() { return 0; }
        public int PrepareGrab() { return 0; }
        public void Dispose() { Disconnect(); }
    }
}
