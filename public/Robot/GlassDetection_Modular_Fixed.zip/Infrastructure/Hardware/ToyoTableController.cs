using GlassDetection.Core.Interfaces;
using GlassDetection.Core.Models;

namespace GlassDetection.Infrastructure.Hardware
{
    public class ToyoTableController : ITableController
    {
        public bool IsConnected { get; private set; }
        public bool IsHome { get; set; }

        public int Connect(string ip, int port)
        {
            IsConnected = true;
            return 0;
        }
        public int Disconnect()
        {
            IsConnected = false;
            return 0;
        }
        public int HomeMove() { return 0; }
        public int HomeMoveStatus() { IsHome = true; return 0; }
        public int EmgReset() { return 0; }
        public int Speed(int speed) { return 0; }
        public int MoveL(double x, double y, double z, int speed) { return 0; }
        public int GetCurrentPosition(ref RobotPosition position) { return 0; }
        public int CheckStartSignal(ref bool isStart) { isStart = false; return 0; }
    }
}
