using System.IO;
using GlassDetection.Core.Models;
using Newtonsoft.Json;

namespace GlassDetection.Infrastructure.Config
{
    public static class JsonConfigLoader
    {
        public static InspectionRecipe LoadRecipe(string path)
        {
            string json = File.ReadAllText(path);
            return JsonConvert.DeserializeObject<InspectionRecipe>(json);
        }

        public static void SaveRecipe(string path, InspectionRecipe recipe)
        {
            string json = JsonConvert.SerializeObject(recipe, Formatting.Indented);
            File.WriteAllText(path, json);
        }
    }
}
