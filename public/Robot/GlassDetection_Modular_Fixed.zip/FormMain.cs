using System;
using System.Windows.Forms;
using GlassDetection.Core.Enums;
using GlassDetection.Core.Models;
using GlassDetection.Infrastructure.Algorithms;
using GlassDetection.Infrastructure.Hardware;
using GlassDetection.UI;
using HalconDotNet;

namespace GlassDetection
{
    public partial class FormMain : Form
    {
        private MainPresenter _presenter;
        private HWindow _hWindow;

        public FormMain()
        {
            InitializeComponent();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            _hWindow = new HWindow();
            if (picLocation != null)
            {
                _hWindow.OpenWindow(0, 0, picLocation.Width, picLocation.Height, (HTuple)picLocation.Handle, "visible", "");
            }

            ICamera dotCcd = new VirtualCamera();
            ICamera faceCcd = new VirtualCamera();
            ITableController table = new ToyoTableController();
            ILightController ringLight = new OptLightController { Name = "Ring" };
            ILightController backLight = new OptLightController { Name = "Back" };
            IInspectionAlgorithm spotAlgo = new HalconSpotInspector();
            IInspectionAlgorithm faceAlgo = new HalconScratchInspector();

            _presenter = new MainPresenter(this, _hWindow, table, dotCcd, faceCcd, ringLight, backLight, spotAlgo, faceAlgo);
            _presenter.OnLog += msg => lblSysMessage.Text = msg;
            _presenter.OnStateChanged += state => lblSysMessage.Text = state.ToString();
            _presenter.OnResultUpdated += result =>
            {
                lblInferOk.Text = result.OkCount.ToString();
                lblInferNG.Text = result.NgCount.ToString();
                lblSpotsCount.Text = result.SpotsCount.ToString();
                labScratchCount.Text = result.ScratchCount.ToString();
                lblPinHoldCount.Text = result.PinHoldCount.ToString();
                lblParticleCount.Text = result.ParticleCount.ToString();
                lblResult.Text = result.IsOk ? "OK" : "NG";
                lblResult.BackColor = result.IsOk ? System.Drawing.Color.LawnGreen : System.Drawing.Color.Red;
            };
            _presenter.OnError += ex => MessageBox.Show($"Error: {ex.Message}");

            _presenter.LoadRecipeFromFile("Config/recipe_default.json");
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            _presenter?.Start();
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            _presenter?.Stop();
        }

        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            _presenter?.Shutdown();
        }
    }
}
