namespace GlassDetection.Core.Models
{
    public class RobotPosition
    {
        public double X { get; set; }
        public double Y { get; set; }
        public double Z { get; set; }

        public double fX => X;
        public double fY => Y;
        public double fZ => Z;

        public bool Equals(RobotPosition other, double tolerance = 0.01)
        {
            if (other == null) return false;
            return System.Math.Abs(X - other.X) < tolerance &&
                   System.Math.Abs(Y - other.Y) < tolerance &&
                   System.Math.Abs(Z - other.Z) < tolerance;
        }
    }
}
