using System.Collections.Generic;

namespace GlassDetection.Core.Models
{
    /// <summary>
    /// 可參數化的產品檢測配方。取代所有硬編碼 P1~P11 與魔法數字。
    /// </summary>
    public class InspectionRecipe
    {
        public string RecipeId { get; set; } = "default";
        public string ProductName { get; set; } = "Unknown";

        // 安全點 / 進料點
        public RobotPosition InputPosition { get; set; } = new RobotPosition();
        public RobotPosition SafePosition { get; set; } = new RobotPosition();

        // 移動速度
        public int HighSpeed { get; set; } = 30;
        public int LowSpeed { get; set; } = 10;

        // 光源參數
        public int DotCcdBackLightIntensity { get; set; } = 100;
        public int FaceCcdRingLightIntensity { get; set; } = 100;
        public int FaceCcdBackLightIntensity { get; set; } = 100;

        // 檢測點序列（依序執行）
        public List<InspectionPoint> Points { get; set; } = new List<InspectionPoint>();

        // 演算法閾值
        public double ArrivalTolerance { get; set; } = 0.01;
        public double PositionOffsetX { get; set; } = 0.0;
        public double PositionOffsetY { get; set; } = 0.0;
    }

    public class InspectionPoint
    {
        public string PointId { get; set; } = "";
        public RobotPosition Position { get; set; } = new RobotPosition();
        public int Speed { get; set; } = 30;
        public string CameraId { get; set; } = "CCD1";
        public string LightMode { get; set; } = "Ring";
        public string PatternName { get; set; } = "";
        public bool UseDotCcd { get; set; } = false;
        public bool UseFaceCcd { get; set; } = false;
        public bool IsSpotCheck { get; set; } = false;
    }
}
