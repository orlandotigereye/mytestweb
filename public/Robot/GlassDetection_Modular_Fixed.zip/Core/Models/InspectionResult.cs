namespace GlassDetection.Core.Models
{
    public class InspectionResult
    {
        public bool IsOk { get; set; }
        public bool HasSpots { get; set; }
        public bool HasScratch { get; set; }
        public bool HasPinHold { get; set; }
        public bool HasParticle { get; set; }
        public string CurrentPointId { get; set; }
        public int TotalCount { get; set; }
        public int OkCount { get; set; }
        public int NgCount { get; set; }
        public int SpotsCount { get; set; }
        public int ScratchCount { get; set; }
        public int PinHoldCount { get; set; }
        public int ParticleCount { get; set; }
    }
}
