using HalconDotNet;

namespace GlassDetection.Core.Interfaces
{
    public interface IInspectionAlgorithm
    {
        string AlgorithmName { get; }
        void Initialize();
        bool Run(HWindow window, HObject image, string patternName, out bool[] defectFlags);
    }
}
