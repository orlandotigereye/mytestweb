using System;

namespace GlassDetection.Core.Interfaces
{
    public interface ICamera : IDisposable
    {
        string DeviceName { get; }
        bool IsConnected { get; }
        bool IsGrabbing { get; }

        int Connect(int deviceIndex);
        int Disconnect();
        int StartGrabbing();
        int StopGrabbing();
        int TriggerSoftware();
        int GetImageBuffer(ref IFrameout frameInfo, int timeoutMs);
        int FreeImageBuffer(ref IFrameout frameInfo);
        int SetSoftwareTriggerMode();
        int PrepareGrab();
    }

    public interface IFrameout
    {
        int Width { get; }
        int Height { get; }
        IntPtr ImageAddr { get; }
        IFrameout Clone();
    }
}
