using GlassDetection.Core.Models;

namespace GlassDetection.Core.Interfaces
{
    public interface ITableController
    {
        bool IsConnected { get; }
        bool IsHome { get; set; }
        int Connect(string ip, int port);
        int Disconnect();
        int HomeMove();
        int HomeMoveStatus();
        int EmgReset();
        int Speed(int speed);
        int MoveL(double x, double y, double z, int speed);
        int GetCurrentPosition(ref RobotPosition position);
        int CheckStartSignal(ref bool isStart);
    }
}
