namespace GlassDetection.Core.Interfaces
{
    public interface ILightController
    {
        string Name { get; }
        bool IsConnected { get; }
        int Connect(string ipAddress);
        int Disconnect();
        int TurnOnChannel(int channelId, int intensity);
        int TurnOffChannel(int channelId);
        int TurnOffAll();
    }
}
