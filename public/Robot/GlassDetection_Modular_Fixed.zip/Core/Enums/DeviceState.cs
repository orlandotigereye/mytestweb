namespace GlassDetection.Core.Enums
{
    public enum DeviceState
    {
        NON_READY,
        READY,
        ON_GOING,
        STOP,
        WARNNING,
        INPUT_GLASS,
        START_INSPECT
    }

    public enum InferState
    {
        INFER_NON,
        INFER_OK,
        INFER_NG
    }
}
