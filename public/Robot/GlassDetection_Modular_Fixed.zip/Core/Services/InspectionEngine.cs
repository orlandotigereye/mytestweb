using System;
using System.Threading;
using GlassDetection.Core.Enums;
using GlassDetection.Core.Interfaces;
using GlassDetection.Core.Models;
using GlassDetection.Core.Services.StateMachine;
using GlassDetection.Core.Services.StateMachine.States;
using HalconDotNet;

namespace GlassDetection.Core.Services
{
    /// <summary>
    /// 檢測引擎：背景執行緒 + 狀態機驅動。與 UI 完全解耦，透過事件通訊。
    /// </summary>
    public class InspectionEngine : IDisposable
    {
        private readonly ITableController _table;
        private readonly ICamera _dotCcd;
        private readonly ICamera _faceCcd;
        private readonly ILightController _ringLight;
        private readonly ILightController _backLight;
        private readonly IInspectionAlgorithm _spotAlgo;
        private readonly IInspectionAlgorithm _faceAlgo;

        private Thread _worker;
        private CancellationTokenSource _cts;
        private readonly InspectionContext _context;
        private bool _disposed;

        public event EventHandler<InspectionResult> OnResultUpdated;
        public event EventHandler<string> OnLog;
        public event EventHandler<DeviceState> OnStateChanged;
        public event EventHandler<Exception> OnError;

        public bool IsRunning => _worker != null && _worker.IsAlive;
        public InspectionRecipe CurrentRecipe => _context.Recipe;

        public InspectionEngine(
            ITableController table,
            ICamera dotCcd,
            ICamera faceCcd,
            ILightController ringLight,
            ILightController backLight,
            IInspectionAlgorithm spotAlgo,
            IInspectionAlgorithm faceAlgo)
        {
            _table = table ?? throw new ArgumentNullException(nameof(table));
            _dotCcd = dotCcd ?? throw new ArgumentNullException(nameof(dotCcd));
            _faceCcd = faceCcd ?? throw new ArgumentNullException(nameof(faceCcd));
            _ringLight = ringLight ?? throw new ArgumentNullException(nameof(ringLight));
            _backLight = backLight ?? throw new ArgumentNullException(nameof(backLight));
            _spotAlgo = spotAlgo ?? throw new ArgumentNullException(nameof(spotAlgo));
            _faceAlgo = faceAlgo ?? throw new ArgumentNullException(nameof(faceAlgo));

            _context = new InspectionContext
            {
                Table = table,
                DotCcd = dotCcd,
                FaceCcd = faceCcd,
                RingLight = ringLight,
                BackLight = backLight,
                SpotAlgo = spotAlgo,
                FaceAlgo = faceAlgo,
                Result = new InspectionResult()
            };
        }

        public void LoadRecipe(InspectionRecipe recipe)
        {
            if (IsRunning) throw new InvalidOperationException("Cannot change recipe while running.");
            _context.Recipe = recipe ?? throw new ArgumentNullException(nameof(recipe));
        }

        public void SetDisplayWindow(HWindow window)
        {
            _context.DisplayWindow = window;
        }

        public void Start()
        {
            if (IsRunning) return;
            if (_context.Recipe == null) throw new InvalidOperationException("Recipe not loaded.");

            _cts = new CancellationTokenSource();
            _context.CancellationToken = _cts.Token;
            _context.Reset();

            _worker = new Thread(RunLoop)
            {
                IsBackground = true,
                Name = "InspectionWorker"
            };
            _worker.Start();
        }

        public void Stop()
        {
            _cts?.Cancel();
            _worker?.Join(5000);
        }

        private void RunLoop()
        {
            try
            {
                IInspectionState currentState = new InitState();
                while (!_context.CancellationToken.IsCancellationRequested)
                {
                    if (currentState == null) break;

                    OnStateChanged?.Invoke(this, currentState.State);
                    currentState.Execute(_context);

                    // FIX: 觸發結果更新事件
                    if (currentState is CheckResultState)
                    {
                        OnResultUpdated?.Invoke(this, _context.Result);
                    }

                    if (_context.NextState != null)
                    {
                        currentState = _context.NextState;
                        _context.NextState = null;
                    }
                    else
                    {
                        Thread.Sleep(10);
                    }
                }
            }
            catch (OperationCanceledException)
            {
                OnLog?.Invoke(this, "Inspection loop cancelled.");
            }
            catch (Exception ex)
            {
                OnError?.Invoke(this, ex);
            }
            finally
            {
                SafeShutdown();
                OnStateChanged?.Invoke(this, DeviceState.STOP);
            }
        }

        private void SafeShutdown()
        {
            try { _ringLight.TurnOffAll(); } catch { }
            try { _backLight.TurnOffAll(); } catch { }
            try { _dotCcd.StopGrabbing(); } catch { }
            try { _faceCcd.StopGrabbing(); } catch { }
        }

        public void Dispose()
        {
            if (_disposed) return;
            Stop();
            _cts?.Dispose();
            _disposed = true;
            GC.SuppressFinalize(this);
        }
    }
}
