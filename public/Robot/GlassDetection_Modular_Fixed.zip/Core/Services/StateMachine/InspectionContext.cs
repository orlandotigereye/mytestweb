using System.Threading;
using GlassDetection.Core.Interfaces;
using GlassDetection.Core.Models;
using HalconDotNet;

namespace GlassDetection.Core.Services.StateMachine
{
    public class InspectionContext
    {
        public CancellationToken CancellationToken { get; set; }
        public InspectionRecipe Recipe { get; set; }
        public InspectionResult Result { get; set; }
        public IInspectionState NextState { get; set; }

        public ITableController Table { get; set; }
        public ICamera DotCcd { get; set; }
        public ICamera FaceCcd { get; set; }
        public ILightController RingLight { get; set; }
        public ILightController BackLight { get; set; }
        public IInspectionAlgorithm SpotAlgo { get; set; }
        public IInspectionAlgorithm FaceAlgo { get; set; }

        public int CurrentPointIndex { get; set; } = -1;
        public RobotPosition CurrentPosition { get; set; } = new RobotPosition();
        public bool IsDefectFound { get; set; }
        public bool IsSpots { get; set; }
        public bool IsScratch { get; set; }
        public bool IsPinHold { get; set; }
        public bool IsParticle { get; set; }
        public HWindow DisplayWindow { get; set; }

        public void Reset()
        {
            CurrentPointIndex = -1;
            IsDefectFound = false;
            IsSpots = false;
            IsScratch = false;
            IsPinHold = false;
            IsParticle = false;
            NextState = null;
        }
    }
}
