using System;
using System.Threading;
using GlassDetection.Core.Enums;
using GlassDetection.Core.Interfaces;
using GlassDetection.Core.Models;
using HalconDotNet;

namespace GlassDetection.Core.Services.StateMachine.States
{
    /// <summary>
    /// 取代原始碼中 P1~P11 的巨型 if-else。依據 Recipe.Points 依序檢測。
    /// </summary>
    public class InspectSequenceState : IInspectionState
    {
        public DeviceState State => DeviceState.ON_GOING;

        public void Execute(InspectionContext ctx)
        {
            var recipe = ctx.Recipe;
            if (recipe.Points == null || recipe.Points.Count == 0)
            {
                ctx.NextState = new CheckResultState();
                return;
            }

            for (int i = 0; i < recipe.Points.Count; i++)
            {
                if (ctx.CancellationToken.IsCancellationRequested) return;

                var pt = recipe.Points[i];
                ctx.CurrentPointIndex = i;

                // 1. 移動到點位
                ctx.Table.MoveL(pt.Position.X, pt.Position.Y, pt.Position.Z, pt.Speed);
                WaitArrival(ctx, pt.Position, recipe.ArrivalTolerance);

                if (ctx.CancellationToken.IsCancellationRequested) return;

                // 2. 設定光源
                SetLighting(ctx, pt);
                Thread.Sleep(50);

                // 3. 取像與檢測
                if (pt.UseDotCcd)
                    InspectWithCamera(ctx, ctx.DotCcd, pt, isSpot: true);
                else if (pt.UseFaceCcd)
                    InspectWithCamera(ctx, ctx.FaceCcd, pt, isSpot: false);

                if (ctx.CancellationToken.IsCancellationRequested) return;
            }

            ctx.NextState = new CheckResultState();
        }

        private void WaitArrival(InspectionContext ctx, RobotPosition target, double tolerance)
        {
            var pos = new RobotPosition();
            for (int retry = 0; retry < 200; retry++)
            {
                if (ctx.CancellationToken.IsCancellationRequested) return;
                ctx.Table.GetCurrentPosition(ref pos);
                if (pos.Equals(target, tolerance)) return;
                Thread.Sleep(10);
            }
            throw new TimeoutException($"Move arrival timeout: {target.X},{target.Y},{target.Z}");
        }

        private void SetLighting(InspectionContext ctx, InspectionPoint pt)
        {
            ctx.RingLight.TurnOffAll();
            ctx.BackLight.TurnOffAll();

            switch (pt.LightMode)
            {
                case "Ring":
                    ctx.RingLight.TurnOnChannel(0, ctx.Recipe.FaceCcdRingLightIntensity);
                    break;
                case "Back":
                    ctx.BackLight.TurnOnChannel(0, ctx.Recipe.DotCcdBackLightIntensity);
                    break;
                case "Both":
                    ctx.RingLight.TurnOnChannel(0, ctx.Recipe.FaceCcdRingLightIntensity);
                    ctx.BackLight.TurnOnChannel(0, ctx.Recipe.FaceCcdBackLightIntensity);
                    break;
            }
        }

        private void InspectWithCamera(InspectionContext ctx, ICamera camera, InspectionPoint pt, bool isSpot)
        {
            // 由相機實作自行提供 IFrameout 實例
            var frame = camera.CreateFrameout(); // 需於 ICamera 新增此方法，或使用工廠
            // 若無法修改介面，可於各相機實作內部處理，此處示範架構

            camera.TriggerSoftware();
            int ret = camera.GetImageBuffer(ref frame, 1000);
            if (ret != 0) throw new Exception($"GetImageBuffer failed: {ret}");

            HObject hImage = null;
            try
            {
                HOperatorSet.GenImage1Extern(out hImage, "byte", frame.Width, frame.Height, frame.ImageAddr, IntPtr.Zero);
                ctx.Table.GetCurrentPosition(ref ctx.CurrentPosition);

                bool[] flags;
                bool ok = isSpot
                    ? ctx.SpotAlgo.Run(ctx.DisplayWindow, hImage, pt.PatternName, out flags)
                    : ctx.FaceAlgo.Run(ctx.DisplayWindow, hImage, pt.PatternName, out flags);

                if (!ok)
                {
                    ctx.IsDefectFound = true;
                    if (!flags[0]) ctx.IsSpots = true;
                    if (!flags[1]) ctx.IsScratch = true;
                    if (!flags[2]) ctx.IsPinHold = true;
                    if (!flags[3]) ctx.IsParticle = true;
                }
            }
            finally
            {
                hImage?.Dispose();
                camera.FreeImageBuffer(ref frame);
            }
        }
    }
}
