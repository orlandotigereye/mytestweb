using GlassDetection.Core.Enums;

namespace GlassDetection.Core.Services.StateMachine.States
{
    public class MoveToInputState : IInspectionState
    {
        public DeviceState State => DeviceState.INPUT_GLASS;
        public void Execute(InspectionContext ctx)
        {
            var p = ctx.Recipe.InputPosition;
            ctx.Table.MoveL(p.X, p.Y, p.Z, ctx.Recipe.LowSpeed);
            System.Threading.Thread.Sleep(500);
            ctx.NextState = new WaitStartState();
        }
    }
}
