using GlassDetection.Core.Enums;
using System.Threading;

namespace GlassDetection.Core.Services.StateMachine.States
{
    public class WaitStartState : IInspectionState
    {
        public DeviceState State => DeviceState.START_INSPECT;
        public void Execute(InspectionContext ctx)
        {
            bool startSignal = false;
            while (!ctx.CancellationToken.IsCancellationRequested)
            {
                if (ctx.Table.CheckStartSignal(ref startSignal) == 0 && startSignal)
                {
                    ctx.Reset();
                    ctx.DotCcd.StartGrabbing();
                    ctx.FaceCcd.StartGrabbing();
                    ctx.RingLight.TurnOffAll();
                    ctx.BackLight.TurnOffAll();
                    ctx.NextState = new InspectSequenceState();
                    return;
                }
                Thread.Sleep(50);
            }
        }
    }
}
