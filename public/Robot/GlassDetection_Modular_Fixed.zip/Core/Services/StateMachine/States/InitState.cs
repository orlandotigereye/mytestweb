using GlassDetection.Core.Enums;
using GlassDetection.Core.Models;

namespace GlassDetection.Core.Services.StateMachine.States
{
    public class InitState : IInspectionState
    {
        public DeviceState State => DeviceState.NON_READY;
        public void Execute(InspectionContext ctx)
        {
            ctx.Reset();
            ctx.Result = new InspectionResult();
            ctx.NextState = new EmgResetState();
        }
    }
}
