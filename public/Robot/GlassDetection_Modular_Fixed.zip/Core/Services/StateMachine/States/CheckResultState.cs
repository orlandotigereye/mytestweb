using GlassDetection.Core.Enums;

namespace GlassDetection.Core.Services.StateMachine.States
{
    public class CheckResultState : IInspectionState
    {
        public DeviceState State => DeviceState.ON_GOING;
        public void Execute(InspectionContext ctx)
        {
            var r = ctx.Result;
            r.TotalCount++;
            if (ctx.IsDefectFound)
            {
                r.NgCount++;
                if (ctx.IsSpots) r.SpotsCount++;
                if (ctx.IsScratch) r.ScratchCount++;
                if (ctx.IsPinHold) r.PinHoldCount++;
                if (ctx.IsParticle) r.ParticleCount++;
                r.IsOk = false;
            }
            else
            {
                r.OkCount++;
                r.IsOk = true;
            }
            ctx.NextState = new TurnOffLightState();
        }
    }
}
