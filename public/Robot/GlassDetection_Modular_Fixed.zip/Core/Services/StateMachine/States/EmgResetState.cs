using GlassDetection.Core.Enums;

namespace GlassDetection.Core.Services.StateMachine.States
{
    public class EmgResetState : IInspectionState
    {
        public DeviceState State => DeviceState.READY;
        public void Execute(InspectionContext ctx)
        {
            ctx.Table.EmgReset();
            ctx.NextState = new MoveToInputState();
        }
    }
}
