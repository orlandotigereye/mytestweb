using GlassDetection.Core.Enums;
using System.Threading;

namespace GlassDetection.Core.Services.StateMachine.States
{
    public class TurnOffLightState : IInspectionState
    {
        public DeviceState State => DeviceState.ON_GOING;
        public void Execute(InspectionContext ctx)
        {
            ctx.RingLight.TurnOffAll();
            ctx.BackLight.TurnOffAll();
            Thread.Sleep(30);
            ctx.NextState = new MoveToSafeState();
        }
    }
}
