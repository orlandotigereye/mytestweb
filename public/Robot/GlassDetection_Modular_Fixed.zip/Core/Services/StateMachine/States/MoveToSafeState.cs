using GlassDetection.Core.Enums;

namespace GlassDetection.Core.Services.StateMachine.States
{
    public class MoveToSafeState : IInspectionState
    {
        public DeviceState State => DeviceState.READY;
        public void Execute(InspectionContext ctx)
        {
            var p = ctx.Recipe.SafePosition;
            ctx.Table.MoveL(p.X, p.Y, p.Z, ctx.Recipe.HighSpeed);
            ctx.NextState = new MoveToInputState();
        }
    }
}
