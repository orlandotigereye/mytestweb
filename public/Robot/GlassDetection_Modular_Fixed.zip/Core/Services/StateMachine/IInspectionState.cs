using GlassDetection.Core.Enums;

namespace GlassDetection.Core.Services.StateMachine
{
    public interface IInspectionState
    {
        DeviceState State { get; }
        void Execute(InspectionContext context);
    }
}
