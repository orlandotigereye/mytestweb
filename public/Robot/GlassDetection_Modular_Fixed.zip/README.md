# GlassDetection 模組化重構架構（已修正版）

## 修正項目
1. **OnResultUpdated 事件觸發**：於 `InspectionEngine.RunLoop` 中，執行 `CheckResultState` 後自動觸發結果更新事件。
2. **Halcon HObject 安全釋放**：`InspectSequenceState.InspectWithCamera` 改用 `try-finally` 確保 `HObject.Dispose()` 一定執行。
3. **DisplayWindow 正確傳遞**：`MainPresenter.Start()` 呼叫 `_engine.SetDisplayWindow()`，避免 Halcon 畫面為 null。
4. **Newtonsoft.Json 相容性**：`JsonConfigLoader` 改用 `Newtonsoft.Json`，支援 .NET Framework 4.x。
5. **取消檢查補強**：`InspectSequenceState` 於移動到位後、設定光源前、檢測後皆檢查 `CancellationToken`。
6. **多餘 using 清理**：移除未使用的 `System.Numerics`、`System.Threading.Tasks` 等。
7. **空方法刪除**：移除 `InspectionContext.RaiseResultUpdated()` 殭屍程式碼。
8. **Null 防護**：`FormMain` 中 `picLocation` 加入 null 檢查。

## 專案結構
```
GlassDetection_Modular/
├── Core/
│   ├── Interfaces/
│   ├── Models/
│   ├── Enums/
│   └── Services/StateMachine/States/
├── Infrastructure/
│   ├── Hardware/
│   ├── Algorithms/
│   └── Config/
├── UI/
├── Config/recipe_default.json
└── FormMain.cs
```

## 快速開始
1. 於 `Infrastructure/Hardware` 中實作實際 SDK（取消 TODO 註解並引用 DLL）。
2. 修改 `Config/recipe_default.json` 填入實際點位與參數。
3. 於 `FormMain.cs` 選擇硬體實作（`VirtualCamera` / `OptCamera` / `HikCamera`）。
4. 安裝 NuGet 套件：`Newtonsoft.Json`、`HalconDotNet`。
5. 編譯執行。
