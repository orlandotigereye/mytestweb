using System;
using System.Windows.Forms;
using GlassDetection.Core.Enums;
using GlassDetection.Core.Interfaces;
using GlassDetection.Core.Models;
using GlassDetection.Core.Services;
using GlassDetection.Infrastructure.Config;
using HalconDotNet;

namespace GlassDetection.UI
{
    public class MainPresenter
    {
        private readonly InspectionEngine _engine;
        private readonly Form _ui;
        private readonly HWindow _displayWindow;

        public MainPresenter(Form ui, HWindow displayWindow,
            ITableController table, ICamera dotCcd, ICamera faceCcd,
            ILightController ringLight, ILightController backLight,
            IInspectionAlgorithm spotAlgo, IInspectionAlgorithm faceAlgo)
        {
            _ui = ui;
            _displayWindow = displayWindow;
            _engine = new InspectionEngine(table, dotCcd, faceCcd, ringLight, backLight, spotAlgo, faceAlgo);

            _engine.OnLog += (s, msg) => _ui.Invoke(new Action(() => OnLog?.Invoke(msg)));
            _engine.OnStateChanged += (s, st) => _ui.Invoke(new Action(() => OnStateChanged?.Invoke(st)));
            _engine.OnResultUpdated += (s, r) => _ui.Invoke(new Action(() => OnResultUpdated?.Invoke(r)));
            _engine.OnError += (s, ex) => _ui.Invoke(new Action(() => OnError?.Invoke(ex)));
        }

        public event Action<string> OnLog;
        public event Action<DeviceState> OnStateChanged;
        public event Action<InspectionResult> OnResultUpdated;
        public event Action<Exception> OnError;

        public void LoadRecipeFromFile(string path)
        {
            var recipe = JsonConfigLoader.LoadRecipe(path);
            _engine.LoadRecipe(recipe);
        }

        public void Start()
        {
            _engine.SetDisplayWindow(_displayWindow);
            _engine.Start();
        }

        public void Stop() => _engine.Stop();
        public void Shutdown() => _engine.Dispose();
    }
}
