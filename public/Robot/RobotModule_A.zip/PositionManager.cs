using System;
using System.Collections.Generic;
using System.IO;

namespace GlassDetection
{
    /// <summary>
    /// 點位管理器：從 INI 載入所有點位，方便現場修改不用重新編譯
    /// </summary>
    public class PositionManager
    {
        private Dictionary<string, RobotPosition> _positions = new Dictionary<string, RobotPosition>();
        private Dictionary<string, double> _workZs = new Dictionary<string, double>();

        /// <summary>
        /// 從 INI 載入點位
        /// </summary>
        public void LoadFromIni(string iniPath)
        {
            if (!File.Exists(iniPath))
                throw new FileNotFoundException("找不到點位設定檔：" + iniPath);

            string currentName = "";
            var pos = new RobotPosition();
            double workZ = -9999;

            foreach (var raw in File.ReadAllLines(iniPath))
            {
                var line = raw.Trim();
                if (string.IsNullOrEmpty(line) || line.StartsWith(";")) continue;

                if (line.StartsWith("[") && line.EndsWith("]"))
                {
                    SaveCurrent(currentName, pos, workZ);
                    currentName = line.Substring(1, line.Length - 2);
                    pos = new RobotPosition();
                    workZ = -9999;
                }
                else if (line.Contains("="))
                {
                    var kv = line.Split('=');
                    var key = kv[0].Trim().ToUpper();
                    var val = kv[1].Trim();

                    switch (key)
                    {
                        case "X": pos.X = double.Parse(val); break;
                        case "Y": pos.Y = double.Parse(val); break;
                        case "Z": pos.Z = double.Parse(val); break;
                        case "U": pos.U = double.Parse(val); break;
                        case "V": pos.V = double.Parse(val); break;
                        case "W": pos.W = double.Parse(val); break;
                        case "WORKZ": workZ = double.Parse(val); break;
                    }
                }
            }
            SaveCurrent(currentName, pos, workZ);
        }

        private void SaveCurrent(string name, RobotPosition pos, double workZ)
        {
            if (string.IsNullOrEmpty(name)) return;
            _positions[name] = pos;
            if (workZ > -9999) _workZs[name] = workZ;
        }

        public void Add(string name, RobotPosition pos, double workZ = -9999)
        {
            _positions[name] = pos;
            if (workZ > -9999) _workZs[name] = workZ;
        }

        public RobotPosition Get(string name)
        {
            if (!_positions.ContainsKey(name))
                throw new KeyNotFoundException($"未定義的點位：{name}");
            return _positions[name];
        }

        public bool HasWorkZ(string name) => _workZs.ContainsKey(name);
        public double GetWorkZ(string name) => _workZs[name];
    }
}
