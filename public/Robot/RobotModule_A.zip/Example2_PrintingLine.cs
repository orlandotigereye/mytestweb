using System;
using System.Threading;

namespace GlassDetection
{
    /// <summary>
    /// 範例2：印刷線流程
    /// 適用場景：輸送帶取玻璃 → 對位平台 → 印刷機 → 輸送帶放片
    /// 特點：多站點、多段路徑，對應原本 EPSON 腳本邏輯
    /// </summary>
    public class Example2_PrintingLine
    {
        private RobotModule _robot;

        public void Run()
        {
            _robot = new RobotModule();

            if (!_robot.Initialize("192.168.0.1", 5000)) return;
            if (!_robot.LoginAndServoOn()) return;

            _robot.SetSpeed(ptpSpeed: 100, linearSpeed: 100);
            _robot.LoadPositions("Positions_Printing.ini");

            Console.WriteLine("===== 範例2：印刷線流程 開始 =====");

            while (true)
            {
                try
                {
                    MainSequence();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("流程異常：" + ex.Message);
                    Thread.Sleep(2000);
                }
            }
        }

        private void MainSequence()
        {
            // ===== 取玻璃 =====
            _robot.Go("InputWaitHold");        // 輸送帶等待位
            _robot.Go("ToGetGlass");           // 去取得玻璃
            _robot.Pick("ToGetGlass");         // 吸取（自動處理 Z 軸與真空）
            _robot.Go("InputWaitHold");        // 回輸送帶等待位

            // ===== 對位平台 =====
            _robot.Go("sideUpWaitHold");       // 對位平台等待位
            _robot.Go("sideDown");             // 對位平台放入位
            _robot.Place("sideDown");          // 放置玻璃
            _robot.Go("sideUpWaitHold");       // 回對位平台等待位

            // 模擬對位完成後重新吸取（實際可能由另一支手臂或平台動作）
            _robot.Go("sideDown");
            _robot.Pick("sideDown");
            _robot.Go("sideUpWaitHold");

            // ===== 印刷機路徑 =====
            _robot.Go("middlePoint");          // 到印刷機中間點
            _robot.Go("middlePointdw");        // 到印刷機中下點
            _robot.Go("smailPrintwaitup");     // 到小印刷機中待位
            _robot.Go("smallPrintwaitdw");     // 到小印刷機中放片
            _robot.Place("smallPrintwaitdw");  // 放置
            _robot.Go("smailPrintwaitup");     // 回到小印刷機中待位

            // 模擬印刷完成後取回
            _robot.Go("smallPrintwaitdw");
            _robot.Pick("smallPrintwaitdw");
            _robot.Go("smailPrintwaitup");

            // 回程
            _robot.Go("middlePointdw");
            _robot.Go("middlePoint");

            // ===== 放玻璃 =====
            _robot.Go("PutWaitHold");          // 輸送帶放片等待位
            _robot.Go("ToPutGlass");           // 去放下玻璃
            _robot.Place("ToPutGlass");        // 放置玻璃
            _robot.Go("InputWaitHold");        // 回輸送帶等待位，準備下一循環

            Console.WriteLine("完成一循環印刷流程");
        }
    }
}
