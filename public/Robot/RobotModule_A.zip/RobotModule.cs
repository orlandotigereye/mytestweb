using System;
using System.Threading;

namespace GlassDetection
{
    /// <summary>
    /// 機器人高階模組：封裝連線、移動、IO、吸取、放置
    /// 主程式只要呼叫 Go / Pick / Place 即可
    /// </summary>
    public class RobotModule : IDisposable
    {
        private readonly EsponRobotControl _robot;
        private readonly DAQIOCtrl _io;
        private readonly PositionManager _positions;

        // 可調參數
        public int VacuumWaitMs { get; set; } = 800;
        public int BlowTimeMs { get; set; } = 200;
        public int CloseVacuumDelayMs { get; set; } = 50;

        public RobotModule()
        {
            _robot = new EsponRobotControl();
            _io = new DAQIOCtrl();
            _positions = new PositionManager();
        }

        // ==================== 初始化 ====================
        public bool Initialize(string robotIp, int robotPort)
        {
            if (_robot.Connect(robotIp, robotPort) != State.STATE_OK)
            {
                Console.WriteLine("[錯誤] 機器人連線失敗");
                return false;
            }
            if (_io.Connect() != State.STATE_OK)
            {
                Console.WriteLine("[錯誤] IO 連線失敗");
                return false;
            }
            return true;
        }

        public bool LoginAndServoOn()
        {
            if (_robot.Login() != State.STATE_OK) return Fail("Login");
            Thread.Sleep(500);
            if (_robot.Reset() != State.STATE_OK) return Fail("Reset");
            Thread.Sleep(2000);
            if (_robot.ServoOn() != State.STATE_OK) return Fail("ServoOn");
            Thread.Sleep(1000);
            if (_robot.PowerHigh() != State.STATE_OK) return Fail("PowerHigh");
            Thread.Sleep(500);
            return true;
        }

        public void SetSpeed(int ptpSpeed, int linearSpeed, int acc = 20, int dec = 20, int lineAcc = 1400, int lineDec = 1400)
        {
            _robot.Speed(ptpSpeed); Thread.Sleep(200);
            _robot.LineSpeed(linearSpeed); Thread.Sleep(200);
            _robot.Accel(acc, dec); Thread.Sleep(200);
            _robot.AccelS(lineAcc, lineDec); Thread.Sleep(200);
        }

        // ==================== 點位管理 ====================
        public void LoadPositions(string iniPath) => _positions.LoadFromIni(iniPath);
        public void AddPosition(string name, RobotPosition pos, double workZ = -9999) => _positions.Add(name, pos, workZ);

        // ==================== 基本移動 ====================
        public bool Go(string posName)
        {
            var pos = _positions.Get(posName);
            return _robot.MoveByCoordinate(pos) == State.STATE_OK;
        }

        public bool MoveZ(double z)
        {
            var cur = new RobotPosition();
            if (_robot.GetCurrentPosition(ref cur) != State.STATE_OK) return false;
            cur.Z = z;
            return _robot.MoveByCoordinate(cur) == State.STATE_OK;
        }

        public bool GoTeachPoint(string label)
        {
            return _robot.P2PMove(label) == State.STATE_OK;
        }

        // ==================== 高階組合動作 ====================
        public bool Pick(string posName, double? workZ = null)
        {
            double targetZ = workZ ?? (_positions.HasWorkZ(posName) ? _positions.GetWorkZ(posName) : _positions.Get(posName).Z);
            var safe = _positions.Get(posName);

            if (!Go(posName)) return Fail($"移動到 {posName} 失敗");
            if (!MoveZ(targetZ)) return Fail("下降到工作高度失敗");
            if (_io.OpenVacuumPad() != State.STATE_OK) return Fail("開真空失敗");

            Thread.Sleep(VacuumWaitMs);
            if (!WaitVacuum(3000)) return Fail("真空建立失敗");
            if (!MoveZ(safe.Z)) return Fail("上升回安全高度失敗");
            return true;
        }

        public bool Place(string posName, double? workZ = null)
        {
            double targetZ = workZ ?? (_positions.HasWorkZ(posName) ? _positions.GetWorkZ(posName) : _positions.Get(posName).Z);
            var safe = _positions.Get(posName);

            if (!Go(posName)) return Fail($"移動到 {posName} 失敗");
            if (!MoveZ(targetZ)) return Fail("下降到工作高度失敗");
            if (_io.CloseVacuumPad() != State.STATE_OK) return Fail("關真空失敗");
            Thread.Sleep(CloseVacuumDelayMs);
            if (_io.OpenBlow() != State.STATE_OK) return Fail("開吹氣失敗");
            Thread.Sleep(BlowTimeMs);
            if (_io.CloseBlow() != State.STATE_OK) return Fail("關吹氣失敗");
            if (!MoveZ(safe.Z)) return Fail("上升回安全高度失敗");
            return true;
        }

        // ==================== IO 控制 ====================
        public bool VacuumOn() => _io.OpenVacuumPad() == State.STATE_OK;
        public bool VacuumOff() => _io.CloseVacuumPad() == State.STATE_OK;
        public bool BlowOn() => _io.OpenBlow() == State.STATE_OK;
        public bool BlowOff() => _io.CloseBlow() == State.STATE_OK;

        // ==================== 感測器等待 ====================
        public bool WaitVacuum(int timeoutMs = 3000)
        {
            bool ok = false;
            for (int t = 0; t < timeoutMs; t += 100)
            {
                _io.GetVacuumEstablished(ref ok);
                if (ok) return true;
                Thread.Sleep(100);
            }
            return false;
        }

        public bool WaitGlassArrived(int sideIndex, int timeoutMs = 5000)
        {
            bool[] sig = new bool[3];
            for (int t = 0; t < timeoutMs; t += 100)
            {
                _io.GetGlassArrivalSensorSignal(ref sig);
                if (sig[sideIndex]) return true;
                Thread.Sleep(100);
            }
            return false;
        }

        // ==================== 公用 ====================
        public void Wait(int ms) => Thread.Sleep(ms);

        private bool Fail(string msg)
        {
            Console.WriteLine("[錯誤] " + msg);
            return false;
        }

        public void Dispose()
        {
            try { _robot.ServoOff(); Thread.Sleep(1000); } catch { }
            try { _robot.Reset(); Thread.Sleep(1000); } catch { }
            try { _robot.Logout(); } catch { }
            try { _robot.DisConnect(); } catch { }
            try { _io.Disconnect(); } catch { }
        }
    }
}
