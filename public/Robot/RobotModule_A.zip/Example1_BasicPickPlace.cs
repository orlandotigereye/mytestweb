using System;
using System.Threading;

namespace GlassDetection
{
    /// <summary>
    /// 範例1：基本取放流程
    /// 適用場景：單純從 A 點吸取玻璃，放到 B 點
    /// 特點：最簡單、最直覺，適合入門
    /// </summary>
    public class Example1_BasicPickPlace
    {
        private RobotModule _robot;

        public void Run()
        {
            _robot = new RobotModule();

            // 1. 連線與啟動
            if (!_robot.Initialize("192.168.0.1", 5000)) return;
            if (!_robot.LoginAndServoOn()) return;

            // 2. 速度設定
            _robot.SetSpeed(ptpSpeed: 80, linearSpeed: 80);

            // 3. 載入點位
            _robot.LoadPositions("Positions_Basic.ini");

            Console.WriteLine("===== 範例1：基本取放 開始 =====");

            while (true)
            {
                try
                {
                    // 等待玻璃到達（左側感測器）
                    Console.WriteLine("等待玻璃到達...");
                    if (!_robot.WaitGlassArrived(0, 10000))
                    {
                        Console.WriteLine("逾時未檢測到玻璃，繼續等待...");
                        continue;
                    }

                    // 主流程
                    _robot.Go("Home");              // 回安全原點
                    _robot.Go("InputWait");         // 輸送帶等待位
                    _robot.Go("PickPos");           // 吸取位置上方
                    _robot.Pick("PickPos");         // 吸取玻璃（自動處理 Z 軸與真空）
                    _robot.Go("InputWait");         // 回輸送帶等待位

                    _robot.Go("OutputWait");        // 放片區等待位
                    _robot.Go("PlacePos");          // 放置位置上方
                    _robot.Place("PlacePos");       // 放置玻璃（自動處理 Z 軸、關真空、吹氣）
                    _robot.Go("OutputWait");        // 回放片區等待位

                    _robot.Go("Home");              // 回安全原點，準備下一循環
                    Console.WriteLine("完成一循環，等待下一片...");
                    Thread.Sleep(1000);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("流程異常：" + ex.Message);
                    Thread.Sleep(2000);
                }
            }
        }
    }
}
