using System;

namespace GlassDetection
{
    /// <summary>
    /// 機器人六軸座標
    /// </summary>
    public class RobotPosition
    {
        public double X { get; set; }
        public double Y { get; set; }
        public double Z { get; set; }
        public double U { get; set; }
        public double V { get; set; }
        public double W { get; set; }

        public RobotPosition() { }

        public RobotPosition(double x, double y, double z, double u, double v, double w)
        {
            X = x; Y = y; Z = z; U = u; V = v; W = w;
        }

        public override string ToString()
        {
            return $"X:{X:F2} Y:{Y:F2} Z:{Z:F2} U:{U:F2} V:{V:F2} W:{W:F2}";
        }
    }
}
