using System;
using System.Threading;

namespace GlassDetection
{
    /// <summary>
    /// 範例3：玻璃檢測線
    /// 適用場景：取玻璃 → CCD 定位拍照 → 邊緣檢測 → OK/NG 分類
    /// 特點：整合視覺定位與 AOI 檢測，對應原本 GlassDetection 專案
    /// </summary>
    public class Example3_GlassInspection
    {
        private RobotModule _robot;

        public void Run()
        {
            _robot = new RobotModule();

            if (!_robot.Initialize("192.168.0.1", 5000)) return;
            if (!_robot.LoginAndServoOn()) return;

            _robot.SetSpeed(ptpSpeed: 65, linearSpeed: 1200, acc: 20, dec: 20, lineAcc: 1400, lineDec: 1400);
            _robot.LoadPositions("Positions_Inspection.ini");

            Console.WriteLine("===== 範例3：玻璃檢測線 開始 =====");

            while (true)
            {
                try
                {
                    MainSequence();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("流程異常：" + ex.Message);
                    Thread.Sleep(2000);
                }
            }
        }

        private void MainSequence()
        {
            // 1. 回 Home 並等待玻璃到達
            _robot.Go("P0");                   // 安全原點
            _robot.Go("HoldPoint");            // 等待位

            Console.WriteLine("等待玻璃到達左側...");
            if (!_robot.WaitGlassArrived(0, 10000))
            {
                Console.WriteLine("未檢測到玻璃");
                return;
            }

            // 2. 移動到拍照位進行 CCD 定位
            _robot.Go("LeftTakePicture");      // 左側拍照位
            _robot.Wait(2500);                 // 等待穩定
            Console.WriteLine("[CCD] 執行定位拍照...");
            // 此處可呼叫 CCD 定位程式，取得偏移量後更新目標座標
            // _locateGlass.RunHalcon(...);

            // 3. 移動到新的玻璃中心（根據 CCD 結果修正後）
            _robot.Go("GlassCenter");          // 修正後的玻璃中心
            _robot.Go("DrawHeight1");          // 吸取高度1
            _robot.Go("DrawHeight2");          // 吸取高度2
            _robot.VacuumOn();                 // 開真空
            _robot.Wait(800);
            if (!_robot.WaitVacuum(3000))
            {
                Console.WriteLine("[警報] 真空建立失敗");
                return;
            }

            // 4. 提起並移動到檢測區
            _robot.Go("SafeHeight");           // 提起安全高度
            _robot.Go("P0");                   // 經過中間點

            // 5. AOI 檢測第一位置（左邊相機 + 右邊相機各拍一張）
            _robot.Go("InspectPos1");
            Console.WriteLine("[AOI] 檢測位置1 - 左邊緣");
            _robot.Wait(120);
            // _glassChipInspect.RunHalcon(..., CCD.Left);
            Console.WriteLine("[AOI] 檢測位置1 - 右邊緣");
            _robot.Wait(70);
            // _glassChipInspect.RunHalcon(..., CCD.Right);

            // 6. AOI 檢測第二位置
            _robot.Go("InspectPos2");
            Console.WriteLine("[AOI] 檢測位置2 - 左邊緣");
            _robot.Wait(120);
            Console.WriteLine("[AOI] 檢測位置2 - 右邊緣");
            _robot.Wait(70);

            // 7. AOI 檢測第三位置
            _robot.Go("InspectPos3");
            Console.WriteLine("[AOI] 檢測位置3 - 左邊緣");
            _robot.Wait(120);
            Console.WriteLine("[AOI] 檢測位置3 - 右邊緣");
            _robot.Wait(70);

            // 8. 根據檢測結果分類放置
            bool isOK = true; // 實際由 AOI 結果決定

            if (isOK)
            {
                Console.WriteLine("[結果] OK → 放到 OK 輸送帶");
                _robot.Go("OKSafePoint");
                _robot.Go("OKConveyor");
                _robot.Place("OKConveyor");
                _robot.Go("OKSafePoint");
            }
            else
            {
                Console.WriteLine("[結果] NG → 放到 NG 輸送帶");
                _robot.Go("NGSafePoint");
                _robot.Go("NGConveyor");
                _robot.Place("NGConveyor");
                _robot.Go("NGSafePoint");
            }

            // 9. 回到等待位
            _robot.Go("HoldPoint");
            Console.WriteLine("完成一循環檢測流程\n");
        }
    }
}
