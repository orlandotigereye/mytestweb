using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GlassDetection
{
    /// <summary>
    /// 機器人工作站 — 一鍵啟動的封裝入口
    /// 
    /// 異常排除設計：
    ///   1. Initialize 前自動驗證設定，有錯先拋例外（不會連到機器人）
    ///   2. 每個步驟自動寫 Log，出錯時看 Log 就能定位
    ///   3. ErrorOccurred 事件預設彈出 MessageBox，不會靜默失敗
    ///   4. Dispose 確保資源釋放，即使程式崩潰也會嘗試關 Servo
    ///   5. 提供 PreCheck() 方法，上機前自動跑檢查清單
    /// </summary>
    public sealed class RobotWorkstation : IDisposable
    {
        private readonly StationConfig _config;
        private RobotModule _robot;
        private RobotStateMachine _sm;
        private bool _disposed;
        private bool _hasError;

        private EventHandler<StateChangedEventArgs> _stateChanged;
        private EventHandler<StepChangedEventArgs> _stepChanged;
        private EventHandler<SequenceCompletedEventArgs> _sequenceCompleted;
        private EventHandler<ErrorEventArgs> _errorOccurred;

        public RobotModule Robot => _robot;
        public RobotState CurrentState => _sm?.CurrentState ?? RobotState.Idle;
        public int CurrentStep => _sm?.CurrentStep ?? 0;
        public int TotalSteps => _sm?.TotalSteps ?? 0;
        public bool HasError => _hasError;

        public event EventHandler<StateChangedEventArgs> StateChanged
        {
            add => _stateChanged += value;
            remove => _stateChanged -= value;
        }

        public event EventHandler<StepChangedEventArgs> StepChanged
        {
            add => _stepChanged += value;
            remove => _stepChanged -= value;
        }

        public event EventHandler<SequenceCompletedEventArgs> SequenceCompleted
        {
            add => _sequenceCompleted += value;
            remove => _sequenceCompleted -= value;
        }

        public event EventHandler<ErrorEventArgs> ErrorOccurred
        {
            add => _errorOccurred += value;
            remove => _errorOccurred -= value;
        }

        public RobotWorkstation(StationConfig config)
        {
            _config = config ?? throw new ArgumentNullException(nameof(config));
        }

        public bool PreCheck()
        {
            LogHelper.Info("========== 上機前檢查清單 ==========");
            bool ok = true;

            try
            {
                _config.Validate();
                LogHelper.Info("[✓] StationConfig 設定驗證通過");
            }
            catch (Exception ex)
            {
                LogHelper.Error($"[✗] StationConfig 設定錯誤: {ex.Message}");
                ok = false;
            }

            if (!string.IsNullOrEmpty(_config.PositionFile))
            {
                if (File.Exists(_config.PositionFile))
                    LogHelper.Info($"[✓] 點位檔存在: {_config.PositionFile}");
                else
                {
                    LogHelper.Error($"[✗] 點位檔不存在: {_config.PositionFile} — 請確認路徑正確");
                    ok = false;
                }
            }
            else
            {
                LogHelper.Warn("[⚠] 未設定點位檔 (PositionFile 為空)，將使用程式內 AddPosition 設定的點位");
            }

            var robotCtrl = _config.RobotController ?? new EsponRobotControl();
            var ioCtrl = _config.IoController ?? new DAQIOCtrl();
            LogHelper.Info($"[✓] 機器人控制器: {robotCtrl.GetType().Name}");
            LogHelper.Info($"[✓] IO 控制器: {ioCtrl.GetType().Name}");

            if (_config.PtpSpeed > 100)
                LogHelper.Warn($"[⚠] PtpSpeed ({_config.PtpSpeed}) 較高，請確認機台允許此速度");
            if (_config.LinearSpeed > 5000)
                LogHelper.Warn($"[⚠] LinearSpeed ({_config.LinearSpeed}) 較高，請確認機台允許此速度");

            LogHelper.Info($"========== 檢查結果: {(ok ? "通過，可以上機" : "失敗，請修正上述問題")} ==========");
            return ok;
        }

        public void DefineFlow(Action<FlowBuilder> buildAction)
        {
            if (buildAction is null)
                throw new ArgumentNullException(nameof(buildAction));
            if (_robot is null)
                throw new InvalidOperationException("請先呼叫 Initialize() 或 RunAsync()");

            var builder = new FlowBuilder(_robot);
            buildAction(builder);
            _sm.DefineSequence(builder.Build());
            LogHelper.Info($"流程已定義，共 {_sm.TotalSteps} 步");
        }

        public bool Initialize()
        {
            _config.Validate();

            var robotController = _config.RobotController ?? new EsponRobotControl();
            var ioController = _config.IoController ?? new DAQIOCtrl();

            _robot = new RobotModule(robotController, ioController);
            _robot.MoveTimeoutMs = _config.MoveTimeoutMs;
            _robot.VacuumTimeoutMs = _config.VacuumTimeoutMs;
            _robot.PositionTolerance = _config.PositionTolerance;
            _robot.VacuumWaitMs = _config.VacuumWaitMs;
            _robot.BlowTimeMs = _config.BlowTimeMs;
            _robot.CloseVacuumDelayMs = _config.CloseVacuumDelayMs;

            LogHelper.Info($"正在連線機器人 {_config.RobotIp}:{_config.RobotPort}...");
            if (!_robot.Initialize(_config.RobotIp, _config.RobotPort))
            {
                LogHelper.Error("機器人連線失敗！請檢查：1.網路線 2.IP設定 3.控制器電源");
                return false;
            }
            LogHelper.Info("機器人連線成功");

            LogHelper.Info("正在登入並開啟 Servo...");
            if (!_robot.LoginAndServoOn())
            {
                LogHelper.Error("登入/ServoOn 失敗！請檢查：1.控制器模式 2.安全門是否關閉 3.急停是否解除");
                return false;
            }
            LogHelper.Info("登入並 ServoOn 成功");

            _robot.SetSpeed(
                _config.PtpSpeed,
                _config.LinearSpeed,
                _config.Accel,
                _config.Decel,
                _config.LineAccel,
                _config.LineDecel);
            LogHelper.Info($"速度設定: PTP={_config.PtpSpeed}, Linear={_config.LinearSpeed}");

            if (!string.IsNullOrEmpty(_config.PositionFile))
            {
                LogHelper.Info($"載入點位檔: {_config.PositionFile}");
                _robot.LoadPositions(_config.PositionFile);
                LogHelper.Info("點位載入完成");
            }

            _sm = new RobotStateMachine(_robot);
            BindEvents();
            return true;
        }

        public Task RunAsync(CancellationToken token = default)
        {
            if (_robot is null && !Initialize())
                throw new InvalidOperationException("工作站初始化失敗，請查看 Log 排查問題");

            if (_sm.TotalSteps == 0)
                throw new InvalidOperationException("流程未定義，請先呼叫 DefineFlow()");

            LogHelper.Info("========== 流程啟動 ==========");
            _hasError = false;
            _sm.Start();
            return Task.Delay(Timeout.Infinite, token);
        }

        public void Pause() => _sm?.Pause();
        public void Resume() => _sm?.Resume();
        public void Stop() => _sm?.Stop();
        public void RestartFromStep(int stepIndex) => _sm?.RestartFromStep(stepIndex);

        public void Dispose()
        {
            if (_disposed)
                return;
            _disposed = true;
            LogHelper.Info("========== 工作站釋放資源 ==========");
            _sm?.Dispose();
            _robot?.Dispose();
            LogHelper.Info("資源已釋放");
        }

        private void BindEvents()
        {
            if (_sm == null) return;

            _sm.StateChanged += (s, e) =>
            {
                LogHelper.Info($"狀態變更: {e.OldState} → {e.NewState}");
                _stateChanged?.Invoke(s, e);
            };

            _sm.StepChanged += (s, e) =>
            {
                LogHelper.Step(e.StepName, e.StepIndex + 1, e.TotalSteps);
                _stepChanged?.Invoke(s, e);
            };

            _sm.SequenceCompleted += (s, e) =>
            {
                LogHelper.Info("========== 流程完成一循環，自動重跑下一循環 ==========");
                _sequenceCompleted?.Invoke(s, e);
            };

            _sm.ErrorOccurred += (s, e) =>
            {
                _hasError = true;
                var msg = $"步驟 [{e.StepIndex}] '{e.StepName}' 發生錯誤: {e.Message}";
                LogHelper.Error(msg);
                if (e.Exception != null)
                    LogHelper.Error($"例外詳情: {e.Exception}");

                try
                {
                    MessageBox.Show(msg, "機器人異常", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch
                {
                    Console.WriteLine($"[ERROR] {msg}");
                }

                _errorOccurred?.Invoke(s, e);
            };
        }
    }
}
