using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GlassDetection
{
    /// <summary>
    /// 範例3 簡潔版：玻璃檢測線（使用 RobotWorkstation 封裝層）
    /// 
    /// 此版本與 Example3_GlassInspection.cs 功能完全一致，
    /// 但使用 Fluent API 定義流程，程式碼更簡潔、更易維護。
    /// 
    /// 兩種寫法可並存，依專案需求選擇：
    ///   - 原始版：需要精細控制每個 SequenceStep 時使用
    ///   - 簡潔版：快速開發、換專案時使用
    /// </summary>
    public class Example3_GlassInspection_Simple
    {
        private bool _isGlassOK = true;

        public async Task RunAsync(CancellationToken token = default)
        {
            var config = new StationConfig
            {
                RobotIp = "192.168.0.1",
                RobotPort = 5000,
                PositionFile = "Positions_Inspection.ini",
                PtpSpeed = 65,
                LinearSpeed = 1200,
                Accel = 20,
                Decel = 20,
                LineAccel = 1400,
                LineDecel = 1400
            };

            using (var station = new RobotWorkstation(config))
            {
                // 上機前檢查清單
                if (!station.PreCheck())
                {
                    Console.WriteLine("上機前檢查未通過，請修正問題後再試。詳情請查看 RobotLog.txt");
                    Console.WriteLine("按任意鍵結束...");
                    Console.ReadKey(true);
                    return;
                }

                // 綁定事件
                station.StateChanged += (s, e) =>
                    Console.WriteLine(FormattableString.Invariant($"[UI] 狀態：{e.OldState} → {e.NewState}"));
                station.StepChanged += (s, e) =>
                    Console.WriteLine(FormattableString.Invariant($"[UI] 步驟 {e.StepIndex + 1}/{e.TotalSteps}：{e.StepName}"));
                station.ErrorOccurred += (s, e) =>
                {
                    Console.WriteLine($"[UI] 異常！步驟 [{e.StepIndex}] '{e.StepName}': {e.Message}");
                };
                station.SequenceCompleted += (s, e) =>
                {
                    Console.WriteLine($"[UI] 完成第 {e.TotalCycles} 循環");
                };

                // 定義流程（與原始版功能完全一致）
                station.DefineFlow(f =>
                {
                    f.Go(Positions.Home)
                     .Go(Positions.HoldPoint)
                     .WaitGlass(sideIndex: 0, timeoutMs: 10000)
                     .Go(Positions.LeftTakePicture)
                     .Delay(2500)
                     .Do("CCD定位拍照", async ct => await RunCCDLocateAsync(ct))
                     .Go(Positions.GlassCenter)
                     .GoZ(318)
                     .GoZ(305)
                     .VacuumOn()
                     .WaitVacuum(3000)
                     .GoZ(530)
                     .Go(Positions.Home);

                    f.Go(Positions.InspectPos1)
                     .Do("檢測1-左邊緣", async ct => await RunAOIAsync(CCD.Left, ct))
                     .Do("檢測1-右邊緣", async ct => await RunAOIAsync(CCD.Right, ct))
                     .Go(Positions.InspectPos2)
                     .Do("檢測2-左邊緣", async ct => await RunAOIAsync(CCD.Left, ct))
                     .Do("檢測2-右邊緣", async ct => await RunAOIAsync(CCD.Right, ct))
                     .Go(Positions.InspectPos3)
                     .Do("檢測3-左邊緣", async ct => await RunAOIAsync(CCD.Left, ct))
                     .Do("檢測3-右邊緣", async ct => await RunAOIAsync(CCD.Right, ct));

                    f.Do("判斷OK/NG", () => CheckInspectionResult());

                    f.GoIf(Positions.OKSafePoint, () => _isGlassOK, critical: false)
                     .GoIf(Positions.OKConveyor, () => _isGlassOK, critical: false)
                     .PlaceIf(Positions.OKConveyor, () => _isGlassOK, critical: false)
                     .GoIf(Positions.OKSafePoint, () => _isGlassOK, critical: false);

                    f.GoIf(Positions.NGSafePoint, () => !_isGlassOK, critical: false)
                     .GoIf(Positions.NGConveyor, () => !_isGlassOK, critical: false)
                     .PlaceIf(Positions.NGConveyor, () => !_isGlassOK, critical: false)
                     .GoIf(Positions.NGSafePoint, () => !_isGlassOK, critical: false);

                    f.Go(Positions.HoldPoint);
                });

                Console.WriteLine("===== 玻璃檢測線 開始 =====");
                Console.WriteLine("按任意鍵停止...");

                using (var cts = CancellationTokenSource.CreateLinkedTokenSource(token))
                {
                    var keyTask = Task.Run(() => Console.ReadKey(true), token);
                    Task runTask;
                    try
                    {
                        runTask = station.RunAsync(cts.Token);
                    }
                    catch (Exception ex)
                    {
                        LogHelper.Error($"啟動失敗: {ex.Message}");
                        Console.WriteLine($"啟動失敗: {ex.Message}");
                        Console.WriteLine("按任意鍵結束...");
                        Console.ReadKey(true);
                        return;
                    }

                    await keyTask.ConfigureAwait(false);
                    LogHelper.Info("使用者按下按鍵，要求停止...");
                    cts.Cancel();

                    try { await runTask.ConfigureAwait(false); }
                    catch (OperationCanceledException)
                    {
                        LogHelper.Info("流程已正常停止");
                    }
                    catch (Exception ex)
                    {
                        LogHelper.Error($"停止時發生例外: {ex.Message}");
                    }
                }

                Console.WriteLine("===== 已停止 =====");
                Console.WriteLine("詳細 Log 請查看 RobotLog.txt");
            }
        }

        private async Task<bool> RunCCDLocateAsync(CancellationToken token)
        {
            LogHelper.Info("[CCD] 執行定位拍照...");
            await Task.Delay(500, token).ConfigureAwait(false);
            LogHelper.Info("[CCD] 定位完成");
            return true;
        }

        private async Task<bool> RunAOIAsync(CCD side, CancellationToken token)
        {
            LogHelper.Info(FormattableString.Invariant($"[AOI] 檢測 {side} 邊緣..."));
            await Task.Delay(side == CCD.Left ? 120 : 70, token).ConfigureAwait(false);
            LogHelper.Info(FormattableString.Invariant($"[AOI] {side} 檢測完成"));
            return true;
        }

        private bool CheckInspectionResult()
        {
            LogHelper.Info($"[AOI] 總結果：{(_isGlassOK ? "OK" : "NG")}");
            return true;
        }
    }
}
