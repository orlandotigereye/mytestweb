# 機器人工作站 — 完整封裝層（原始功能全保留 + 簡易封裝）

## 檔案結構說明

### 原始檔案（11個，內容完全未改動）

| 檔案 | 說明 |
|------|------|
| `State.cs` | 狀態列舉（STATE_OK / ERROR / TIMEOUT / DISCONNECTED） |
| `RobotPosition.cs` | 六軸座標結構體（readonly struct，含 Equals/GetHashCode） |
| `IRobotController.cs` | 機器人控制器介面 |
| `IIOController.cs` | IO 控制器介面 |
| `EsponRobotControl.cs` | EPSON 機器人控制實作（存根，需替換為真實 API） |
| `DAQIOCtrl.cs` | DAQ IO 控制實作（存根，需替換為真實 API） |
| `PositionManager.cs` | 點位管理器（INI 載入 + 安全檢查 Z/XY/WorkZ） |
| `SafetyMonitor.cs` | 安全監控器（急停 / 真空遺失 / 區域違規） |
| `RobotModule.cs` | 機器人高階模組（連線 / 安全移動 / IO / 吸取 / 放置） |
| `RobotStateMachine.cs` | 狀態機（Idle/Running/Paused/Stopped/Homing/Error） |
| `Example3_GlassInspection.cs` | **原始範例**：玻璃檢測線完整實作 |

### 新增封裝層（5個，不影響原始檔案）

| 檔案 | 說明 |
|------|------|
| `LogHelper.cs` | 簡易日誌（自動寫檔 + Console 輸出） |
| `StationConfig.cs` | 工作站設定集中管理（含 Validate 驗證） |
| `Positions.cs` | 點位名稱常數（避免字串硬編碼） |
| `FlowBuilder.cs` | Fluent API 流程建構器（Go/Pick/Place/Do/Delay...） |
| `RobotWorkstation.cs` | 一鍵啟動入口（含 PreCheck 檢查清單 + 事件 + 錯誤處理） |

### 新增範例（1個）

| 檔案 | 說明 |
|------|------|
| `Example3_GlassInspection_Simple.cs` | **簡潔版範例**：與原始版功能完全一致，但用 Fluent API 撰寫 |

---

## 兩種寫法對照

### 原始寫法（精細控制）

```csharp
var robot = new RobotModule(new EsponRobotControl(), new DAQIOCtrl());
var sm = new RobotStateMachine(robot);
robot.Initialize("192.168.0.1", 5000);
robot.LoginAndServoOn();

var sequence = new List<SequenceStep>
{
    new SequenceStep("回 Home", async (ct) => await robot.GoSafeAsync("Home", token: ct)),
    new SequenceStep("吸取", async (ct) => await robot.PickSafeAsync("PickPos", token: ct)),
    // ... 30 幾行
};
sm.DefineSequence(sequence);
sm.Start();
```

### 簡潔寫法（快速開發）

```csharp
var station = new RobotWorkstation(new StationConfig {
    RobotIp = "192.168.0.1", PositionFile = "Positions.ini"
});

station.PreCheck();  // 上機前檢查

station.DefineFlow(f => {
    f.Go("Home")
     .Pick("PickPos")
     .Place("PlacePos");
});

await station.RunAsync();
```

**兩種寫法可並存**，原始檔案完全不受影響。

---

## 換專案修改清單

1. **StationConfig**：改 IP、點位檔、速度
2. **Positions.cs**：改點位名稱常數
3. **DefineFlow**：改步驟順序與點位
4. **自定義動作**（CCD/AOI）：介面不變，直接複用

---

## 上機前檢查清單

```
□ StationConfig 的 IP、Port、點位檔名是否正確
□ Positions.cs 常數與 INI 檔內的 [Section] 名稱是否一致
□ DefineFlow 裡沒有重複的 Go + Pick / Go + Place
□ 條件分支（GoIf/PickIf/PlaceIf）都設了 critical: false
□ 有 using / Dispose 確保資源釋放
□ CancellationToken 有正確傳入並處理取消例外
□ 事件處理裡有 Invoke 回 UI 執行緒（WinForms）
□ 沒有在 Do() 的 lambda 裡用 .Result / .Wait()
□ 流程無限循環是預期行為（或已在 SequenceCompleted 裡 Stop）
□ RobotLog.txt 有寫入權限
```

---

## 異常排除速查

| 問題 | 排查方向 |
|------|---------|
| PreCheck 失敗 | 看 RobotLog.txt，檢查 IP 格式、點位檔路徑、速度正數 |
| 連線失敗 | Ping IP、檢查網路線、控制器電源 |
| Login/ServoOn 失敗 | 控制器模式 Auto/Remote、安全門、急停 |
| 點位找不到 | Positions.cs 常數與 INI [Section] 名稱一致 |
| 無限循環 | RobotStateMachine 設計為循環，SequenceCompleted 裡 Stop |
| 條件分支錯誤 | 確認狀態變數執行緒安全、判斷步驟在分支之前 |
| UI 卡死 | RunAsync 在背景執行緒、事件裡 Invoke 回 UI |
