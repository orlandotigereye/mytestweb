using System;
using Automation.BDaq;
using PCIE1756_IO_Viewer.Config;

namespace PCIE1756_IO_Viewer.DAQ
{
    public sealed class DAQManager : IDisposable
    {
        private readonly AppConfig _config;
        private readonly InstantDiCtrl _di = new InstantDiCtrl();
        private readonly InstantDoCtrl _do = new InstantDoCtrl();
        private bool _connected;
        private readonly byte[] _diBuffer = new byte[64];
        private readonly byte[] _doBuffer = new byte[64];

        public DAQManager(AppConfig config) { _config = config; }
        public bool IsConnected => _connected;
        public string LastError { get; private set; } = "";

        public bool Connect()
        {
            try
            {
                var device = new DeviceInformation(_config.DeviceDescription);
                _di.SelectedDevice = device;
                var e = _di.LoadProfile(_config.ProfilePath);
                if (e != ErrorCode.Success) { LastError = e.ToString(); return false; }

                if (_config.ReadOutputs)
                {
                    _do.SelectedDevice = new DeviceInformation(_config.DeviceDescription);
                    e = _do.LoadProfile(_config.ProfilePath);
                    if (e != ErrorCode.Success) { LastError = e.ToString(); return false; }
                }
                _connected = true;
                return true;
            }
            catch (Exception ex)
            {
                LastError = ex.Message;
                return false;
            }
        }

        public byte[] ReadAllInputs()
        {
            if (!_connected) throw new InvalidOperationException("DAQ not connected.");
            var e = _di.Read(0, 4, _diBuffer);
            if (e != ErrorCode.Success) throw new InvalidOperationException(e.ToString());
            var result = new byte[4];
            Array.Copy(_diBuffer, result, 4);
            return result;
        }

        public byte[] ReadAllOutputs()
        {
            if (!_connected || !_config.ReadOutputs) return new byte[4];
            var e = _do.Read(0, 4, _doBuffer);
            if (e != ErrorCode.Success) throw new InvalidOperationException(e.ToString());
            var result = new byte[4];
            Array.Copy(_doBuffer, result, 4);
            return result;
        }

        public void Dispose()
        {
            try { _di.Dispose(); } catch { }
            try { _do.Dispose(); } catch { }
            _connected = false;
        }
    }
}
