@echo off
setlocal
if not exist "lib\Automation.BDaq.dll" (
  echo [ERROR] 找不到 lib\Automation.BDaq.dll
  echo 請從已安裝 DAQNavi 的電腦複製 Automation.BDaq.dll 到 lib 資料夾。
  pause
  exit /b 1
)
if not exist "PCIE-1756.xml" (
  echo [ERROR] 找不到 PCIE-1756.xml
  echo 請將目前設備使用的 profile 放到本資料夾。
  pause
  exit /b 1
)
where msbuild >nul 2>nul
if errorlevel 1 (
  echo [ERROR] 找不到 MSBuild。請在 Visual Studio Developer Command Prompt 執行此檔案。
  pause
  exit /b 1
)
msbuild PCIE1756_IO_Viewer.csproj /p:Configuration=Release /p:Platform=AnyCPU
if errorlevel 1 exit /b 1
mkdir Portable 2>nul
xcopy /E /I /Y bin\Release Portable >nul
copy /Y appsettings.json Portable >nul
copy /Y PCIE-1756.xml Portable >nul
copy /Y lib\Automation.BDaq.dll Portable >nul
if exist Portable\PCIE1756_IO_Viewer.exe (
  echo.
  echo Build OK. Portable folder ready.
  echo 請注意：目標電腦仍需安裝研華 DAQNavi/驅動與其原生 Runtime。
)
pause
