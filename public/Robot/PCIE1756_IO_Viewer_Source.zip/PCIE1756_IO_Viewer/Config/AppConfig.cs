using System.Collections.Generic;
using System.IO;
using System.Web.Script.Serialization;

namespace PCIE1756_IO_Viewer.Config
{
    public class AppConfig
    {
        public string DeviceDescription { get; set; } = "PCIE-1756,BID#0";
        public string ProfilePath { get; set; } = "./PCIE-1756.xml";
        public int PollIntervalMs { get; set; } = 100;
        public bool ReadOutputs { get; set; } = true;
        public bool AllowWriteOutputs { get; set; } = false;
        public string CsvLogPath { get; set; } = "./logs/io_changes.csv";
        public Dictionary<string,string> Labels { get; set; } = new Dictionary<string,string>();

        public static AppConfig Load(string path)
        {
            if (!File.Exists(path)) return new AppConfig();
            var json = File.ReadAllText(path);
            var serializer = new JavaScriptSerializer();
            var cfg = serializer.Deserialize<AppConfig>(json);
            return cfg ?? new AppConfig();
        }
    }
}
