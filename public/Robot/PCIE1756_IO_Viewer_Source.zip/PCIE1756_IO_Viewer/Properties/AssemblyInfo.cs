using System.Reflection;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("PCIE1756 I/O Viewer")]
[assembly: AssemblyDescription("Advantech PCIE-1756 read-only I/O monitor")]
[assembly: AssemblyCompany("TigerEye")]
[assembly: AssemblyProduct("PCIE1756_IO_Viewer")]
[assembly: ComVisible(false)]
