using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using PCIE1756_IO_Viewer.Config;
using PCIE1756_IO_Viewer.DAQ;

namespace PCIE1756_IO_Viewer
{
    public class MainForm : Form
    {
        private readonly AppConfig _config;
        private readonly DAQManager _daq;
        private readonly Timer _timer;
        private readonly Label _status = new Label();
        private readonly DataGridView _grid = new DataGridView();
        private readonly Button _btnScan = new Button();
        private readonly Button _btnLog = new Button();
        private readonly CheckBox _chkMonitor = new CheckBox();
        private byte[] _lastDI = new byte[4];
        private byte[] _lastDO = new byte[4];
        private bool _hasLast;
        private readonly List<string> _logBuffer = new List<string>();

        public MainForm()
        {
            Text = "PCIE-1756 I/O Viewer";
            Width = 1180;
            Height = 760;
            StartPosition = FormStartPosition.CenterScreen;
            Font = new Font("Segoe UI", 10F);

            _config = AppConfig.Load(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "appsettings.json"));
            _daq = new DAQManager(_config);

            var top = new Panel { Dock = DockStyle.Top, Height = 60, Padding = new Padding(10) };
            _status.Text = "狀態：未連線";
            _status.AutoSize = true;
            _status.Location = new Point(10, 18);
            top.Controls.Add(_status);

            _btnScan.Text = "立即掃描";
            _btnScan.Width = 110;
            _btnScan.Location = new Point(230, 12);
            _btnScan.Click += (s,e) => Poll(true);
            top.Controls.Add(_btnScan);

            _chkMonitor.Text = "監控 I/O 變化";
            _chkMonitor.AutoSize = true;
            _chkMonitor.Checked = true;
            _chkMonitor.Location = new Point(360, 17);
            top.Controls.Add(_chkMonitor);

            _btnLog.Text = "匯出變化 CSV";
            _btnLog.Width = 130;
            _btnLog.Location = new Point(520, 12);
            _btnLog.Click += (s,e) => ExportLog();
            top.Controls.Add(_btnLog);

            Controls.Add(top);

            _grid.Dock = DockStyle.Fill;
            _grid.ReadOnly = true;
            _grid.AllowUserToAddRows = false;
            _grid.AllowUserToDeleteRows = false;
            _grid.AutoGenerateColumns = false;
            _grid.RowHeadersVisible = false;
            _grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText="類型", Width=70 });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText="I/O", Width=80 });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText="Port", Width=60 });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText="Bit", Width=60 });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText="狀態", Width=90 });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText="標籤 / 用途", AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText="最後變化", Width=170 });
            Controls.Add(_grid);

            _timer = new Timer { Interval = Math.Max(50, _config.PollIntervalMs) };
            _timer.Tick += (s,e) => Poll(false);
            _timer.Start();
            FormClosing += (s,e) => { _timer.Stop(); _daq.Dispose(); };
        }

        private void Poll(bool manual)
        {
            if (!_daq.IsConnected && !_daq.Connect())
            {
                _status.Text = "狀態：連線失敗 - " + _daq.LastError;
                return;
            }
            try
            {
                var di = _daq.ReadAllInputs();
                var output = _config.ReadOutputs ? _daq.ReadAllOutputs() : new byte[4];
                _status.Text = "狀態：CONNECTED    Device=" + _config.DeviceDescription + "    Poll=" + _config.PollIntervalMs + "ms";
                Render(di, output);
            }
            catch (Exception ex)
            {
                _status.Text = "狀態：讀取失敗 - " + ex.Message;
            }
        }

        private void Render(byte[] di, byte[] output)
        {
            _grid.Rows.Clear();
            for (int i=0;i<32;i++)
            {
                int port=i/8, bit=i%8;
                bool on=(di[port] & (1<<bit)) != 0;
                string key="DI"+i.ToString("00");
                DateTime? changed = null;
                if (_hasLast && ((di[port] ^ _lastDI[port]) & (1<<bit)) != 0)
                {
                    changed=DateTime.Now;
                    if (_chkMonitor.Checked) AddLog(key, !on, on);
                }
                int row=_grid.Rows.Add("DI",key,port,bit,on?"ON":"OFF",LabelFor(key),changed.HasValue?changed.Value.ToString("HH:mm:ss.fff"):"");
                _grid.Rows[row].Cells[4].Style.BackColor=on?Color.LightGreen:Color.Gainsboro;
            }
            for (int i=0;i<32;i++)
            {
                int port=i/8, bit=i%8;
                bool on=(output[port] & (1<<bit)) != 0;
                string key="DO"+i.ToString("00");
                DateTime? changed = null;
                if (_hasLast && ((output[port] ^ _lastDO[port]) & (1<<bit)) != 0)
                {
                    changed=DateTime.Now;
                    if (_chkMonitor.Checked) AddLog(key, !on, on);
                }
                int row=_grid.Rows.Add("DO",key,port,bit,on?"ON":"OFF",LabelFor(key),changed.HasValue?changed.Value.ToString("HH:mm:ss.fff"):"");
                _grid.Rows[row].Cells[4].Style.BackColor=on?Color.LightYellow:Color.Gainsboro;
            }
            Array.Copy(di,_lastDI,4);
            Array.Copy(output,_lastDO,4);
            _hasLast=true;
        }

        private string LabelFor(string io)
        {
            if (_config.Labels != null && _config.Labels.TryGetValue(io,out var s)) return s;
            return "未設定 / 未命名";
        }

        private void AddLog(string io,bool oldValue,bool newValue)
        {
            _logBuffer.Add(string.Format("{0:yyyy-MM-dd HH:mm:ss.fff},{1},{2},{3}",DateTime.Now,io,oldValue?"ON":"OFF",newValue?"ON":"OFF"));
            if (_logBuffer.Count>10000) _logBuffer.RemoveAt(0);
        }

        private void ExportLog()
        {
            string path=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"logs");
            Directory.CreateDirectory(path);
            string file=Path.Combine(path,"io_changes_"+DateTime.Now.ToString("yyyyMMdd_HHmmss")+".csv");
            var sb=new StringBuilder("Time,IO,Old,New\r\n");
            foreach(var line in _logBuffer) sb.AppendLine(line);
            File.WriteAllText(file,sb.ToString(),Encoding.UTF8);
            MessageBox.Show("已匯出：\r\n"+file,"完成",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }
    }
}
