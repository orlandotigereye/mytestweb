# PCIE1756_IO_Viewer

獨立的 PCIE-1756 I/O 監看工具，依目前 DAQServer 程式使用的 Automation.BDaq / DAQNavi API 撰寫。

## 目前版本安全原則
- 讀取 DI00~DI31。
- 讀取 DO00~DO31 的目前狀態。
- 預設 `AllowWriteOutputs=false`，程式沒有任何 DO 寫入功能。
- 監控 OFF→ON / ON→OFF 變化並可匯出 CSV。
- I/O 標籤放在 `appsettings.json`，不需要重新編譯即可修改名稱。

## 建置
1. 在有 DAQNavi 的 Windows 電腦安裝 Visual Studio / Build Tools。
2. 將目前設備使用的 `PCIE-1756.xml` 放到專案根目錄。
3. 將 `Automation.BDaq.dll` 放到 `lib\Automation.BDaq.dll`。
4. 用 Visual Studio Developer Command Prompt 執行 `build.bat`。
5. `Portable` 資料夾就是部署資料夾。

## 跨電腦使用的限制
PCIE-1756 是實體 PCIe DAQ 卡，因此不是「任何沒有這張卡的電腦都能讀 I/O」。目標電腦必須具備：
- PCIE-1756 硬體
- 研華 DAQNavi / 驅動與其必要 Runtime
- 對應的 `PCIE-1756.xml`
- 對應版本的 Automation.BDaq runtime

本工具本身不會修改原本 DAQServer 的程式或 I/O 狀態。

## 目前已知標籤
標籤依使用者提供的 DAQServer 原始程式整理：
DI00 OK輸送帶允許
DI01 NG輸送帶允許
DI02 左側玻璃到達
DI03 右側玻璃到達
DI04 真空確認
DI08~DI10 CV1 Machine No
DI16~DI18 CV2 Machine No
DO00 真空
DO01 吹氣
DO02 綠燈
DO03 黃燈
DO04 紅燈
DO05 蜂鳴器
DO06 Robot動作中
DO07 Robot動作完成
DO10~DO12 CV1 Machine No
DO18~DO20 CV2 Machine No

未標示的 I/O 顯示為「未設定 / 未命名」，不代表它一定是物理上空的。
