using System;
using System.Threading;
using System.Threading.Tasks;

namespace GlassDetection
{
    /// <summary>
    /// 機器人高階模組：封裝連線、安全移動、IO、吸取、放置
    /// </summary>
    public sealed class RobotModule : IDisposable
    {
        private readonly IRobotController _robot;
        private readonly IIOController _io;
        private readonly PositionManager _positions;
        private SafetyMonitor _safety;
        private bool _disposed;

        public int VacuumWaitMs { get; set; } = 800;
        public int BlowTimeMs { get; set; } = 200;
        public int CloseVacuumDelayMs { get; set; } = 50;
        public double PositionTolerance { get; set; } = 0.5;
        public int MoveTimeoutMs { get; set; } = 30000;
        public int VacuumTimeoutMs { get; set; } = 3000;

        public bool IsEStopOn => _safety?.IsEStopOn ?? false;
        public bool IsConnected => _robot?.IsConnected ?? false;

        public RobotModule(IRobotController robot, IIOController io)
        {
            _robot = robot ?? throw new ArgumentNullException(nameof(robot));
            _io = io ?? throw new ArgumentNullException(nameof(io));
            _positions = new PositionManager();
        }

        public bool Initialize(string robotIp, int robotPort)
        {
            if (_robot.Connect(robotIp, robotPort) != State.STATE_OK)
                return false;

            if (_io.Connect() != State.STATE_OK)
            {
                // IO 連線失敗時，斷開已連線的機器人，避免資源洩漏
                _robot.DisConnect();
                return false;
            }

            _safety = new SafetyMonitor(_robot, _io);
            _safety.EStopTriggered += OnEStopTriggered;
            _safety.VacuumLost += OnVacuumLost;
            _safety.ZoneViolation += OnZoneViolation;
            _safety.Start();
            return true;
        }

        public bool LoginAndServoOn()
        {
            if (_robot.Login() != State.STATE_OK) return false;
            Thread.Sleep(500);
            if (_robot.Reset() != State.STATE_OK) return false;
            Thread.Sleep(2000);
            if (_robot.ServoOn() != State.STATE_OK) return false;
            Thread.Sleep(1000);
            if (_robot.PowerHigh() != State.STATE_OK) return false;
            Thread.Sleep(500);
            return true;
        }

        public void SetSpeed(int ptpSpeed, int linearSpeed, int acc = 20, int dec = 20, int lineAcc = 1400, int lineDec = 1400)
        {
            _robot.Speed(ptpSpeed); Thread.Sleep(200);
            _robot.LineSpeed(linearSpeed); Thread.Sleep(200);
            _robot.Accel(acc, dec); Thread.Sleep(200);
            _robot.AccelS(lineAcc, lineDec); Thread.Sleep(200);
        }

        public void LoadPositions(string iniPath) => _positions.LoadFromIni(iniPath);
        public void AddPosition(string name, RobotPosition pos, double workZ = -9999) => _positions.Add(name, pos, workZ);

        public async Task<bool> GoSafeAsync(string posName, int? timeoutMs = null, CancellationToken token = default)
        {
            if (IsEStopOn)
                return false;
            if (!_positions.TryGet(posName, out var pos))
                return false;

            if (_robot.MoveByCoordinate(pos) != State.STATE_OK)
                return false;

            return await WaitArrivalAsync(pos, timeoutMs ?? MoveTimeoutMs, token).ConfigureAwait(false);
        }

        public async Task<bool> MoveZSafeAsync(double z, int? timeoutMs = null, CancellationToken token = default)
        {
            if (IsEStopOn)
                return false;
            if (_robot.GetCurrentPosition(out var cur) != State.STATE_OK)
                return false;

            var target = new RobotPosition(cur.X, cur.Y, z, cur.U, cur.V, cur.W);
            if (_robot.MoveByCoordinate(target) != State.STATE_OK)
                return false;

            return await WaitArrivalAsync(target, timeoutMs ?? MoveTimeoutMs, token).ConfigureAwait(false);
        }

        public async Task<bool> GoTeachPointSafeAsync(string label, int? timeoutMs = null, CancellationToken token = default)
        {
            if (IsEStopOn)
                return false;
            if (_robot.P2PMove(label) != State.STATE_OK)
                return false;

            return await WaitMotionCompleteAsync(timeoutMs ?? MoveTimeoutMs, token).ConfigureAwait(false);
        }

        public async Task<bool> PickSafeAsync(string posName, double? workZ = null, CancellationToken token = default)
        {
            if (IsEStopOn)
                return false;
            if (!_positions.TryGet(posName, out var safe))
                return false;

            double targetZ = workZ ?? (_positions.HasWorkZ(posName) ? _positions.GetWorkZ(posName) : safe.Z);

            if (!await GoSafeAsync(posName, token: token).ConfigureAwait(false))
                return false;
            if (!await MoveZSafeAsync(targetZ, token: token).ConfigureAwait(false))
                return false;

            if (_io.GetVacuumEstablished(out var vacNow) == State.STATE_OK && vacNow)
            {
                _io.CloseVacuumPad();
                await Task.Delay(100, token).ConfigureAwait(false);
            }

            if (_io.OpenVacuumPad() != State.STATE_OK)
                return false;

            await Task.Delay(VacuumWaitMs, token).ConfigureAwait(false);

            if (!await WaitVacuumAsync(VacuumTimeoutMs, token).ConfigureAwait(false))
                return false;

            if (!await MoveZSafeAsync(safe.Z, token: token).ConfigureAwait(false))
                return false;

            return true;
        }

        public async Task<bool> PlaceSafeAsync(string posName, double? workZ = null, CancellationToken token = default)
        {
            if (IsEStopOn)
                return false;
            if (!_positions.TryGet(posName, out var safe))
                return false;

            double targetZ = workZ ?? (_positions.HasWorkZ(posName) ? _positions.GetWorkZ(posName) : safe.Z);

            if (!await GoSafeAsync(posName, token: token).ConfigureAwait(false))
                return false;
            if (!await MoveZSafeAsync(targetZ, token: token).ConfigureAwait(false))
                return false;

            if (_io.GetVacuumEstablished(out var vacNow) == State.STATE_OK && !vacNow)
            {
                // 真空未建立，可能掉片，依現場需求決定是否中斷
            }

            if (_io.CloseVacuumPad() != State.STATE_OK)
                return false;
            await Task.Delay(CloseVacuumDelayMs, token).ConfigureAwait(false);

            if (_io.OpenBlow() != State.STATE_OK)
                return false;
            await Task.Delay(BlowTimeMs, token).ConfigureAwait(false);
            if (_io.CloseBlow() != State.STATE_OK)
                return false;

            if (!await MoveZSafeAsync(safe.Z, token: token).ConfigureAwait(false))
                return false;

            return true;
        }

        public bool VacuumOn() => _io.OpenVacuumPad() == State.STATE_OK;
        public bool VacuumOff() => _io.CloseVacuumPad() == State.STATE_OK;
        public bool BlowOn() => _io.OpenBlow() == State.STATE_OK;
        public bool BlowOff() => _io.CloseBlow() == State.STATE_OK;

        public async Task<bool> WaitVacuumAsync(int timeoutMs, CancellationToken token = default)
        {
            for (int t = 0; t < timeoutMs; t += 100)
            {
                if (IsEStopOn)
                    return false;
                if (_io.GetVacuumEstablished(out var ok) == State.STATE_OK && ok)
                    return true;
                await Task.Delay(100, token).ConfigureAwait(false);
            }
            return false;
        }

        public async Task<bool> WaitGlassArrivedAsync(int sideIndex, int timeoutMs = 5000, CancellationToken token = default)
        {
            if (_io.GetGlassArrivalSensorSignal(out var sig) != State.STATE_OK)
                return false;
            if (sideIndex < 0 || sideIndex >= sig.Length)
                throw new ArgumentOutOfRangeException(nameof(sideIndex));

            for (int t = 0; t < timeoutMs; t += 100)
            {
                if (_io.GetGlassArrivalSensorSignal(out sig) == State.STATE_OK && sig[sideIndex])
                    return true;
                await Task.Delay(100, token).ConfigureAwait(false);
            }
            return false;
        }

        private async Task<bool> WaitArrivalAsync(RobotPosition target, int timeoutMs, CancellationToken token)
        {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            while (sw.ElapsedMilliseconds < timeoutMs)
            {
                if (IsEStopOn)
                    return false;
                if (_robot.GetCurrentPosition(out var cur) == State.STATE_OK && IsPositionMatch(cur, target))
                    return true;
                await Task.Delay(50, token).ConfigureAwait(false);
            }
            return false;
        }

        private async Task<bool> WaitMotionCompleteAsync(int timeoutMs, CancellationToken token)
        {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            RobotPosition lastPos = default;
            int stableCount = 0;

            while (sw.ElapsedMilliseconds < timeoutMs)
            {
                if (IsEStopOn)
                    return false;
                if (_robot.GetCurrentPosition(out var cur) == State.STATE_OK)
                {
                    if (stableCount > 0 && IsPositionMatch(cur, lastPos, 0.01))
                    {
                        stableCount++;
                        if (stableCount > 10)
                            return true;
                    }
                    else
                    {
                        stableCount = 1;
                    }
                    lastPos = cur;
                }
                await Task.Delay(50, token).ConfigureAwait(false);
            }
            return false;
        }

        private static bool IsPositionMatch(RobotPosition a, RobotPosition b, double tolerance = 0.5)
        {
            return Math.Abs(a.X - b.X) < tolerance &&
                   Math.Abs(a.Y - b.Y) < tolerance &&
                   Math.Abs(a.Z - b.Z) < tolerance &&
                   Math.Abs(a.U - b.U) < tolerance &&
                   Math.Abs(a.V - b.V) < tolerance &&
                   Math.Abs(a.W - b.W) < tolerance;
        }

        private void OnEStopTriggered(object sender, EStopEventArgs e) { }
        private void OnVacuumLost(object sender, VacuumLostEventArgs e) { }
        private void OnZoneViolation(object sender, ZoneViolationEventArgs e) { }

        public void Dispose()
        {
            if (_disposed)
                return;
            _disposed = true;

            _safety?.Dispose();
            try { _robot.ServoOff(); Thread.Sleep(1000); } catch { }
            try { _robot.Reset(); Thread.Sleep(1000); } catch { }
            try { _robot.Logout(); } catch { }
            try { _robot.DisConnect(); } catch { }
            try { _io.Disconnect(); } catch { }
            _positions?.Dispose();
        }
    }
}
