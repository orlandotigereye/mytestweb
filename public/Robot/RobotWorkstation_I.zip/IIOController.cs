namespace GlassDetection
{
    public interface IIOController
    {
        bool IsConnected { get; }
        State Connect();
        State Disconnect();
        State OpenVacuumPad();
        State CloseVacuumPad();
        State OpenBlow();
        State CloseBlow();
        State GetVacuumEstablished(out bool isEstablished);
        State GetGlassArrivalSensorSignal(out bool[] signals);
    }
}
