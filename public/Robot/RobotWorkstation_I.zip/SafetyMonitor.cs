using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

namespace GlassDetection
{
    /// <summary>
    /// 安全監控器：背景持續監控急停、真空、區域限制
    /// </summary>
    public sealed class SafetyMonitor : IDisposable
    {
        private readonly IRobotController _robot;
        private readonly IIOController _io;
        private readonly CancellationTokenSource _cts = new CancellationTokenSource();
        private Task _monitorTask;
        private bool _disposed;

        public event EventHandler<EStopEventArgs> EStopTriggered;
        public event EventHandler<VacuumLostEventArgs> VacuumLost;
        public event EventHandler<ZoneViolationEventArgs> ZoneViolation;

        public bool IsEStopOn { get; private set; }

        public SafetyMonitor(IRobotController robot, IIOController io)
        {
            _robot = robot ?? throw new ArgumentNullException(nameof(robot));
            _io = io ?? throw new ArgumentNullException(nameof(io));
        }

        public void Start()
        {
            if (_monitorTask != null)
                return;
            _monitorTask = Task.Run(() => MonitorLoopAsync(_cts.Token));
        }

        public void Stop()
        {
            _cts.Cancel();
            try { _monitorTask?.Wait(TimeSpan.FromSeconds(2)); } catch { }
        }

        private async Task MonitorLoopAsync(CancellationToken token)
        {
            bool lastEStop = false;
            bool lastVacuum = false;

            while (!token.IsCancellationRequested)
            {
                try
                {
                    if (_robot.GetEmergency(out var estop) == State.STATE_OK)
                    {
                        if (estop && !lastEStop)
                        {
                            IsEStopOn = true;
                            EStopTriggered?.Invoke(this, new EStopEventArgs { IsPressed = true });
                        }
                        else if (!estop && lastEStop)
                        {
                            IsEStopOn = false;
                            EStopTriggered?.Invoke(this, new EStopEventArgs { IsPressed = false });
                        }
                        lastEStop = estop;
                    }

                    if (_io.GetVacuumEstablished(out var vacuum) == State.STATE_OK)
                    {
                        if (!vacuum && lastVacuum)
                            VacuumLost?.Invoke(this, new VacuumLostEventArgs());
                        lastVacuum = vacuum;
                    }

                    if (_robot.GetCurrentPosition(out var cur) == State.STATE_OK)
                    {
                        if (cur.Z < 50 && (Math.Abs(cur.X) > 1500 || Math.Abs(cur.Y) > 1500))
                        {
                            ZoneViolation?.Invoke(this, new ZoneViolationEventArgs
                            {
                                Message = "低高度大範圍移動",
                                CurrentPosition = cur
                            });
                        }
                    }
                }
                catch (OperationCanceledException)
                {
                    break;
                }
                catch (Exception ex)
                {
                    // 【修正】監控異常不應中斷循環，但須記錄以便排查
                    Debug.WriteLine($"[SafetyMonitor] 監控異常: {ex.Message}");
                }

                try
                {
                    await Task.Delay(50, token).ConfigureAwait(false);
                }
                catch (OperationCanceledException)
                {
                    break;
                }
            }
        }

        public void Dispose()
        {
            if (_disposed)
                return;
            _disposed = true;
            Stop();
            _cts.Dispose();
        }
    }

    public class EStopEventArgs : EventArgs
    {
        public bool IsPressed { get; set; }
    }

    public class VacuumLostEventArgs : EventArgs
    {
        public DateTime Time { get; set; } = DateTime.Now;
    }

    public class ZoneViolationEventArgs : EventArgs
    {
        public string Message { get; set; }
        public RobotPosition CurrentPosition { get; set; }
    }
}
