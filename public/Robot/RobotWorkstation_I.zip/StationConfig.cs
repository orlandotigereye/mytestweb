using System;
using System.Net;

namespace GlassDetection
{
    /// <summary>
    /// 工作站設定 — 集中管理連線、速度、點位等參數
    /// 換專案時通常只需要改這個檔案（或從 JSON 載入）
    /// </summary>
    public class StationConfig
    {
        public string RobotIp { get; set; } = "192.168.0.1";
        public int RobotPort { get; set; } = 5000;
        public string PositionFile { get; set; } = "";

        public int PtpSpeed { get; set; } = 50;
        public int LinearSpeed { get; set; } = 1000;
        public int Accel { get; set; } = 20;
        public int Decel { get; set; } = 20;
        public int LineAccel { get; set; } = 1400;
        public int LineDecel { get; set; } = 1400;

        public int MoveTimeoutMs { get; set; } = 30000;
        public int VacuumTimeoutMs { get; set; } = 3000;
        public double PositionTolerance { get; set; } = 0.5;
        public int VacuumWaitMs { get; set; } = 800;
        public int BlowTimeMs { get; set; } = 200;
        public int CloseVacuumDelayMs { get; set; } = 50;

        public IRobotController RobotController { get; set; }
        public IIOController IoController { get; set; }

        public void Validate()
        {
            var errors = "";
            if (string.IsNullOrWhiteSpace(RobotIp))
                errors += "• RobotIp 未設定
";
            else if (!IPAddress.TryParse(RobotIp, out _))
                errors += $"• RobotIp '{RobotIp}' 不是有效的 IP 位址
";
            if (RobotPort <= 0 || RobotPort > 65535)
                errors += $"• RobotPort {RobotPort} 超出範圍 (1~65535)
";
            if (PtpSpeed <= 0)
                errors += $"• PtpSpeed ({PtpSpeed}) 必須 > 0
";
            if (LinearSpeed <= 0)
                errors += $"• LinearSpeed ({LinearSpeed}) 必須 > 0
";
            if (Accel <= 0 || Decel <= 0)
                errors += $"• Accel/Decel 必須 > 0
";
            if (MoveTimeoutMs < 1000)
                errors += $"• MoveTimeoutMs ({MoveTimeoutMs}) 建議至少 1000ms
";
            if (PositionTolerance <= 0)
                errors += $"• PositionTolerance ({PositionTolerance}) 必須 > 0
";
            if (!string.IsNullOrEmpty(errors))
                throw new InvalidOperationException($"[設定驗證失敗] 請檢查 StationConfig：
{errors}");
        }
    }
}
