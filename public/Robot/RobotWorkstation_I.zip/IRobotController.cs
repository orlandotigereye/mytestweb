namespace GlassDetection
{
    public interface IRobotController
    {
        bool IsConnected { get; }
        State Connect(string ip, int port);
        State DisConnect();
        State Login();
        State Logout();
        State Reset();
        State ServoOn();
        State ServoOff();
        State PowerHigh();
        State Speed(int ptpSpeed);
        State LineSpeed(int linearSpeed);
        State Accel(int acc, int dec);
        State AccelS(int lineAcc, int lineDec);
        State MoveByCoordinate(RobotPosition position);
        State P2PMove(string label);
        State GetCurrentPosition(out RobotPosition position);
        State GetEmergency(out bool isPressed);
    }
}
