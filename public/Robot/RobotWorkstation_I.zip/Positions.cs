namespace GlassDetection
{
    /// <summary>
    /// 點位名稱常數 — 避免字串硬編碼，改名時只需改這裡
    /// 換專案時把這裡的常數改成新專案的點位名稱即可
    /// </summary>
    public static class Positions
    {
        public const string Home = "Home";
        public const string HoldPoint = "HoldPoint";
        public const string LeftTakePicture = "LeftTakePicture";
        public const string GlassCenter = "GlassCenter";
        public const string InspectPos1 = "InspectPos1";
        public const string InspectPos2 = "InspectPos2";
        public const string InspectPos3 = "InspectPos3";
        public const string OKSafePoint = "OKSafePoint";
        public const string OKConveyor = "OKConveyor";
        public const string NGSafePoint = "NGSafePoint";
        public const string NGConveyor = "NGConveyor";
    }
}
