using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace GlassDetection
{
    /// <summary>
    /// 流程建構器 — 用 Fluent API 宣告式定義機器人流程
    /// </summary>
    public class FlowBuilder
    {
        private readonly RobotModule _robot;
        private readonly List<SequenceStep> _steps = new List<SequenceStep>();
        private int _stepCounter = 0;

        public FlowBuilder(RobotModule robot)
        {
            _robot = robot ?? throw new ArgumentNullException(nameof(robot));
        }

        public FlowBuilder Go(string positionName, bool critical = true)
        {
            if (string.IsNullOrWhiteSpace(positionName))
                throw new ArgumentException("點位名稱不可為空", nameof(positionName));
            return Add($"移動至 {positionName}",
                ct => WrapAsync($"Go({positionName})", c => _robot.GoSafeAsync(positionName, token: c), ct),
                critical);
        }

        public FlowBuilder GoIf(string positionName, Func<bool> condition, bool critical = false)
        {
            if (string.IsNullOrWhiteSpace(positionName))
                throw new ArgumentException("點位名稱不可為空", nameof(positionName));
            if (condition is null)
                throw new ArgumentNullException(nameof(condition));
            return Add($"[條件]移動至 {positionName}",
                async ct => condition() ? await WrapAsync($"GoIf({positionName})", c => _robot.GoSafeAsync(positionName, token: c), ct).ConfigureAwait(false) : true,
                critical);
        }

        public FlowBuilder GoZ(double z, bool critical = true)
            => Add($"Z 軸移至 {z:F1}",
                ct => WrapAsync($"GoZ({z})", c => _robot.MoveZSafeAsync(z, token: c), ct),
                critical);

        public FlowBuilder GoTeach(string label, bool critical = true)
        {
            if (string.IsNullOrWhiteSpace(label))
                throw new ArgumentException("教導點標籤不可為空", nameof(label));
            return Add($"教導點 {label}",
                ct => WrapAsync($"GoTeach({label})", c => _robot.GoTeachPointSafeAsync(label, token: c), ct),
                critical);
        }

        public FlowBuilder Pick(string positionName, double? workZ = null, bool critical = true)
        {
            if (string.IsNullOrWhiteSpace(positionName))
                throw new ArgumentException("點位名稱不可為空", nameof(positionName));
            return Add($"吸取 {positionName}",
                ct => WrapAsync($"Pick({positionName})", c => _robot.PickSafeAsync(positionName, workZ, token: c), ct),
                critical);
        }

        public FlowBuilder PickIf(string positionName, Func<bool> condition, double? workZ = null, bool critical = false)
        {
            if (string.IsNullOrWhiteSpace(positionName))
                throw new ArgumentException("點位名稱不可為空", nameof(positionName));
            if (condition is null)
                throw new ArgumentNullException(nameof(condition));
            return Add($"[條件]吸取 {positionName}",
                async ct => condition() ? await WrapAsync($"PickIf({positionName})", c => _robot.PickSafeAsync(positionName, workZ, token: c), ct).ConfigureAwait(false) : true,
                critical);
        }

        public FlowBuilder Place(string positionName, double? workZ = null, bool critical = true)
        {
            if (string.IsNullOrWhiteSpace(positionName))
                throw new ArgumentException("點位名稱不可為空", nameof(positionName));
            return Add($"放置 {positionName}",
                ct => WrapAsync($"Place({positionName})", c => _robot.PlaceSafeAsync(positionName, workZ, token: c), ct),
                critical);
        }

        public FlowBuilder PlaceIf(string positionName, Func<bool> condition, double? workZ = null, bool critical = false)
        {
            if (string.IsNullOrWhiteSpace(positionName))
                throw new ArgumentException("點位名稱不可為空", nameof(positionName));
            if (condition is null)
                throw new ArgumentNullException(nameof(condition));
            return Add($"[條件]放置 {positionName}",
                async ct => condition() ? await WrapAsync($"PlaceIf({positionName})", c => _robot.PlaceSafeAsync(positionName, workZ, token: c), ct).ConfigureAwait(false) : true,
                critical);
        }

        public FlowBuilder VacuumOn(bool critical = true)
            => Add("開真空", () => WrapSync("VacuumOn", () => _robot.VacuumOn()), critical);

        public FlowBuilder VacuumOff(bool critical = true)
            => Add("關真空", () => WrapSync("VacuumOff", () => _robot.VacuumOff()), critical);

        public FlowBuilder BlowOn(bool critical = true)
            => Add("開吹氣", () => WrapSync("BlowOn", () => _robot.BlowOn()), critical);

        public FlowBuilder BlowOff(bool critical = true)
            => Add("關吹氣", () => WrapSync("BlowOff", () => _robot.BlowOff()), critical);

        public FlowBuilder WaitVacuum(int timeoutMs, bool critical = true)
            => Add($"等待真空 {timeoutMs}ms",
                ct => WrapAsync($"WaitVacuum({timeoutMs})", c => _robot.WaitVacuumAsync(timeoutMs, c), ct),
                critical);

        public FlowBuilder WaitGlass(int sideIndex, int timeoutMs, bool critical = true)
            => Add($"等待玻璃到達[{sideIndex}]",
                ct => WrapAsync($"WaitGlass({sideIndex},{timeoutMs})", c => _robot.WaitGlassArrivedAsync(sideIndex, timeoutMs, c), ct),
                critical);

        public FlowBuilder Delay(int milliseconds, bool critical = false)
        {
            if (milliseconds < 0)
                throw new ArgumentException("延遲時間不可為負數", nameof(milliseconds));
            return Add($"等待 {milliseconds}ms",
                async ct => { await Task.Delay(milliseconds, ct).ConfigureAwait(false); return true; },
                critical);
        }

        public FlowBuilder Do(string name, Func<bool> action, bool critical = true)
        {
            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentException("步驟名稱不可為空", nameof(name));
            if (action is null)
                throw new ArgumentNullException(nameof(action));
            return Add(name, () => WrapSync(name, action), critical);
        }

        public FlowBuilder Do(string name, Func<CancellationToken, Task<bool>> action, bool critical = true)
        {
            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentException("步驟名稱不可為空", nameof(name));
            if (action is null)
                throw new ArgumentNullException(nameof(action));
            return Add(name, ct => WrapAsync(name, action, ct), critical);
        }

        public FlowBuilder DoIf(string name, Func<bool> condition, Func<bool> action, bool critical = false)
        {
            if (condition is null) throw new ArgumentNullException(nameof(condition));
            if (action is null) throw new ArgumentNullException(nameof(action));
            return Add($"[條件]{name}", () => condition() ? WrapSync(name, action) : true, critical);
        }

        public FlowBuilder DoIf(string name, Func<bool> condition, Func<CancellationToken, Task<bool>> action, bool critical = false)
        {
            if (condition is null) throw new ArgumentNullException(nameof(condition));
            if (action is null) throw new ArgumentNullException(nameof(action));
            return Add($"[條件]{name}", async ct => condition() ? await WrapAsync(name, action, ct).ConfigureAwait(false) : true, critical);
        }

        private bool WrapSync(string name, Func<bool> action)
        {
            try
            {
                LogHelper.Debug($"開始: {name}");
                var result = action();
                LogHelper.Debug($"結束: {name} => {(result ? "成功" : "失敗")}");
                return result;
            }
            catch (Exception ex)
            {
                LogHelper.Error($"步驟 '{name}' 發生例外: {ex.Message}");
                throw;
            }
        }

        private async Task<bool> WrapAsync(string name, Func<CancellationToken, Task<bool>> action, CancellationToken token)
        {
            try
            {
                LogHelper.Debug($"開始: {name}");
                var result = await action(token).ConfigureAwait(false);
                LogHelper.Debug($"結束: {name} => {(result ? "成功" : "失敗")}");
                return result;
            }
            catch (OperationCanceledException)
            {
                LogHelper.Warn($"步驟 '{name}' 被取消");
                throw;
            }
            catch (Exception ex)
            {
                LogHelper.Error($"步驟 '{name}' 發生例外: {ex.Message}");
                throw;
            }
        }

        private FlowBuilder Add(string name, Func<bool> action, bool critical)
        {
            _stepCounter++;
            _steps.Add(new SequenceStep($"{_stepCounter:D2}. {name}", action, critical));
            return this;
        }

        private FlowBuilder Add(string name, Func<CancellationToken, Task<bool>> action, bool critical)
        {
            _stepCounter++;
            _steps.Add(new SequenceStep($"{_stepCounter:D2}. {name}", action, critical));
            return this;
        }

        internal IReadOnlyList<SequenceStep> Build() => _steps.AsReadOnly();
    }
}
