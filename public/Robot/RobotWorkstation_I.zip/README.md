# 機器人工作站 — 完整封裝層（原始功能全保留 + 簡易封裝 + Bug 修正）

## 本次修正內容

| 檔案 | 修正項目 |
|------|---------|
| `RobotStateMachine.cs` | Stop() 等待時間延長至 30 秒並循環檢查；RestartFromStep() 確保 Task 完全結束後再 Start；RunLoopAsync 流程完成後的 delay 加入 OCE 處理 |
| `SafetyMonitor.cs` | catch 塊加入 `Debug.WriteLine` 記錄異常，避免靜默吞掉問題 |
| `RobotWorkstation.cs` | PreCheck() 改用反射取型別名稱，避免建立臨時控制器實例造成副作用 |
| `Example3_GlassInspection.cs` | CCD enum 移至獨立檔案 `Enums.cs`，避免與簡潔版重複定義 |
| `Example3_GlassInspection_Simple.cs` | 引用 `Enums.cs` 中的 CCD enum |
| `Enums.cs` | 【新增】CCD enum 獨立檔案，供所有範例共用 |

---

## 檔案結構（共 18 個檔案）

### 原始檔案（11個，內容完全保留）

| 檔案 | 說明 |
|------|------|
| `State.cs` | 狀態列舉 |
| `RobotPosition.cs` | 六軸座標結構體 |
| `IRobotController.cs` | 機器人控制器介面 |
| `IIOController.cs` | IO 控制器介面 |
| `EsponRobotControl.cs` | EPSON 存根實作 |
| `DAQIOCtrl.cs` | DAQ 存根實作 |
| `PositionManager.cs` | 點位管理（INI 載入 + 安全檢查） |
| `SafetyMonitor.cs` | 安全監控（急停/真空/區域） |
| `RobotModule.cs` | 高階模組（移動/吸取/放置） |
| `RobotStateMachine.cs` | 狀態機（Idle/Running/Error...） |
| `Example3_GlassInspection.cs` | 原始範例（31 步驟） |

### 新增封裝層（6個）

| 檔案 | 說明 |
|------|------|
| `Enums.cs` | CCD enum 獨立檔案 |
| `LogHelper.cs` | 自動日誌 |
| `StationConfig.cs` | 設定集中管理 + 驗證 |
| `Positions.cs` | 點位名稱常數 |
| `FlowBuilder.cs` | Fluent API |
| `RobotWorkstation.cs` | 一鍵啟動 + PreCheck |

### 新增範例與文件（1個）

| 檔案 | 說明 |
|------|------|
| `Example3_GlassInspection_Simple.cs` | 簡潔版範例 |
| `README.md` | 本文件 |

---

## 快速開始

```csharp
var station = new RobotWorkstation(new StationConfig {
    RobotIp = "192.168.0.1", PositionFile = "Positions.ini"
});

if (!station.PreCheck()) return;  // 上機前檢查

station.DefineFlow(f => {
    f.Go("Home").Pick("PickPos").Place("PlacePos");
});

await station.RunAsync();
```

---

## 上機前檢查清單

```
□ StationConfig 的 IP、Port、點位檔名是否正確
□ Positions.cs 常數與 INI 檔內的 [Section] 名稱是否一致
□ DefineFlow 裡沒有重複的 Go + Pick / Go + Place
□ 條件分支（GoIf/PickIf/PlaceIf）都設了 critical: false
□ 有 using / Dispose 確保資源釋放
□ CancellationToken 有正確傳入並處理取消例外
□ 事件處理裡有 Invoke 回 UI 執行緒（WinForms）
□ 沒有在 Do() 的 lambda 裡用 .Result / .Wait()
□ 流程無限循環是預期行為（或已在 SequenceCompleted 裡 Stop）
□ RobotLog.txt 有寫入權限
```
