namespace GlassDetection
{
    /// <summary>
    /// EPSON 機器人控制實作 — 存根版本
    /// 【使用者須修改】將 State.STATE_OK 改為實際的 EPSON RC+ API 呼叫
    /// </summary>
    public class EsponRobotControl : IRobotController
    {
        public bool IsConnected { get; private set; }

        public State Connect(string ip, int port)
        {
            IsConnected = true;
            return State.STATE_OK;
        }

        public State DisConnect()
        {
            IsConnected = false;
            return State.STATE_OK;
        }

        public State Login() => State.STATE_OK;
        public State Logout() => State.STATE_OK;
        public State Reset() => State.STATE_OK;
        public State ServoOn() => State.STATE_OK;
        public State ServoOff() => State.STATE_OK;
        public State PowerHigh() => State.STATE_OK;
        public State Speed(int ptpSpeed) => State.STATE_OK;
        public State LineSpeed(int linearSpeed) => State.STATE_OK;
        public State Accel(int acc, int dec) => State.STATE_OK;
        public State AccelS(int lineAcc, int lineDec) => State.STATE_OK;
        public State MoveByCoordinate(RobotPosition position) => State.STATE_OK;
        public State P2PMove(string label) => State.STATE_OK;

        public State GetCurrentPosition(out RobotPosition position)
        {
            position = new RobotPosition(0, 0, 0, 0, 0, 0);
            return State.STATE_OK;
        }

        public State GetEmergency(out bool isPressed)
        {
            isPressed = false;
            return State.STATE_OK;
        }
    }
}
