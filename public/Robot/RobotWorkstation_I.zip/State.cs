namespace GlassDetection
{
    public enum State
    {
        STATE_OK = 0,
        STATE_ERROR = 1,
        STATE_TIMEOUT = 2,
        STATE_DISCONNECTED = 3
    }
}
