namespace GlassDetection
{
    /// <summary>
    /// CCD 側邊列舉 — 獨立檔案，供所有範例共用
    /// </summary>
    public enum CCD { Left, Right }
}
