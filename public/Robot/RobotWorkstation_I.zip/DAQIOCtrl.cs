namespace GlassDetection
{
    /// <summary>
    /// DAQ IO 控制實作 — 存根版本
    /// 【使用者須修改】將 State.STATE_OK 改為實際的 DAQ 卡 API 呼叫
    /// </summary>
    public class DAQIOCtrl : IIOController
    {
        public bool IsConnected { get; private set; }

        public State Connect()
        {
            IsConnected = true;
            return State.STATE_OK;
        }

        public State Disconnect()
        {
            IsConnected = false;
            return State.STATE_OK;
        }

        public State OpenVacuumPad() => State.STATE_OK;
        public State CloseVacuumPad() => State.STATE_OK;
        public State OpenBlow() => State.STATE_OK;
        public State CloseBlow() => State.STATE_OK;

        public State GetVacuumEstablished(out bool isEstablished)
        {
            isEstablished = true;
            return State.STATE_OK;
        }

        public State GetGlassArrivalSensorSignal(out bool[] signals)
        {
            signals = new bool[3];
            return State.STATE_OK;
        }
    }
}
