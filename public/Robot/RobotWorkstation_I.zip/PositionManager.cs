using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace GlassDetection
{
    /// <summary>
    /// 點位管理器：從 INI 載入所有點位，並進行安全檢查
    /// </summary>
    public sealed class PositionManager : IDisposable
    {
        private readonly Dictionary<string, RobotPosition> _positions = new Dictionary<string, RobotPosition>();
        private readonly Dictionary<string, double> _workZs = new Dictionary<string, double>();
        private readonly object _sync = new object();
        private bool _disposed;

        public double MinZ { get; set; } = 0;
        public double MaxZ { get; set; } = 1000;
        public double MaxXY { get; set; } = 2000;

        public IReadOnlyDictionary<string, RobotPosition> Positions
        {
            get
            {
                lock (_sync) { return new Dictionary<string, RobotPosition>(_positions); }
            }
        }

        public void LoadFromIni(string iniPath)
        {
            if (iniPath is null)
                throw new ArgumentNullException(nameof(iniPath));
            if (!File.Exists(iniPath))
                throw new FileNotFoundException("找不到點位設定檔", iniPath);

            lock (_sync)
            {
                _positions.Clear();
                _workZs.Clear();

                string currentName = string.Empty;
                double x = 0, y = 0, z = 0, u = 0, v = 0, w = 0;
                double workZ = -9999;
                bool hasData = false;

                foreach (var raw in File.ReadAllLines(iniPath))
                {
                    var line = raw.Trim();
                    if (string.IsNullOrWhiteSpace(line) || line.StartsWith(";"))
                        continue;

                    if (line.StartsWith("[") && line.EndsWith("]"))
                    {
                        if (hasData && !string.IsNullOrEmpty(currentName))
                            SavePosition(currentName, new RobotPosition(x, y, z, u, v, w), workZ);

                        currentName = line.Substring(1, line.Length - 2).Trim();
                        x = y = z = u = v = w = 0;
                        workZ = -9999;
                        hasData = false;
                    }
                    else if (line.Contains("="))
                    {
                        var idx = line.IndexOf('=');
                        var key = line.Substring(0, idx).Trim();
                        var val = line.Substring(idx + 1).Trim();

                        if (string.Equals(key, "X", StringComparison.OrdinalIgnoreCase))
                        { x = double.Parse(val, CultureInfo.InvariantCulture); hasData = true; }
                        else if (string.Equals(key, "Y", StringComparison.OrdinalIgnoreCase))
                        { y = double.Parse(val, CultureInfo.InvariantCulture); hasData = true; }
                        else if (string.Equals(key, "Z", StringComparison.OrdinalIgnoreCase))
                        { z = double.Parse(val, CultureInfo.InvariantCulture); hasData = true; }
                        else if (string.Equals(key, "U", StringComparison.OrdinalIgnoreCase))
                        { u = double.Parse(val, CultureInfo.InvariantCulture); hasData = true; }
                        else if (string.Equals(key, "V", StringComparison.OrdinalIgnoreCase))
                        { v = double.Parse(val, CultureInfo.InvariantCulture); hasData = true; }
                        else if (string.Equals(key, "W", StringComparison.OrdinalIgnoreCase))
                        { w = double.Parse(val, CultureInfo.InvariantCulture); hasData = true; }
                        else if (string.Equals(key, "WORKZ", StringComparison.OrdinalIgnoreCase))
                        { workZ = double.Parse(val, CultureInfo.InvariantCulture); hasData = true; }
                    }
                }

                if (hasData && !string.IsNullOrEmpty(currentName))
                    SavePosition(currentName, new RobotPosition(x, y, z, u, v, w), workZ);
            }
        }

        private void SavePosition(string name, RobotPosition pos, double workZ)
        {
            if (pos.Z < MinZ)
                throw new ArgumentException(
                    FormattableString.Invariant($"[安全警告] {name} 的 Z={pos.Z:F1} 低於安全下限 {MinZ:F1}！"));
            if (pos.Z > MaxZ)
                throw new ArgumentException(
                    FormattableString.Invariant($"[安全警告] {name} 的 Z={pos.Z:F1} 超過安全上限 {MaxZ:F1}！"));
            if (Math.Abs(pos.X) > MaxXY || Math.Abs(pos.Y) > MaxXY)
                throw new ArgumentException($"[安全警告] {name} 的 XY 超出行程限制！");
            if (workZ > -9999 && workZ > pos.Z)
                throw new ArgumentException(
                    FormattableString.Invariant($"[安全警告] {name} 的工作高度 WorkZ={workZ:F1} 高於安全高度 Z={pos.Z:F1}！"));

            _positions[name] = pos;
            if (workZ > -9999)
                _workZs[name] = workZ;
        }

        public void Add(string name, RobotPosition pos, double workZ = -9999)
        {
            if (name is null)
                throw new ArgumentNullException(nameof(name));
            lock (_sync)
            {
                SavePosition(name, pos, workZ);
            }
        }

        public RobotPosition Get(string name)
        {
            if (name is null)
                throw new ArgumentNullException(nameof(name));
            lock (_sync)
            {
                if (!_positions.TryGetValue(name, out var pos))
                    throw new KeyNotFoundException($"未定義的點位：{name}");
                return pos;
            }
        }

        public bool TryGet(string name, out RobotPosition position)
        {
            if (name is null)
            {
                position = default;
                return false;
            }
            lock (_sync)
            {
                return _positions.TryGetValue(name, out position);
            }
        }

        public bool HasWorkZ(string name)
        {
            if (name is null)
                return false;
            lock (_sync)
            {
                return _workZs.ContainsKey(name);
            }
        }

        public double GetWorkZ(string name)
        {
            if (name is null)
                throw new ArgumentNullException(nameof(name));
            lock (_sync)
            {
                if (!_workZs.TryGetValue(name, out var z))
                    throw new KeyNotFoundException($"點位 {name} 未定義 WorkZ");
                return z;
            }
        }

        public void Dispose()
        {
            if (_disposed)
                return;
            _disposed = true;
            lock (_sync)
            {
                _positions.Clear();
                _workZs.Clear();
            }
        }
    }
}
