using System;

namespace GlassDetection
{
    /// <summary>
    /// 機器人六軸座標 — readonly struct 確保不可變性與值語義
    /// </summary>
    public readonly struct RobotPosition : IEquatable<RobotPosition>
    {
        public double X { get; }
        public double Y { get; }
        public double Z { get; }
        public double U { get; }
        public double V { get; }
        public double W { get; }

        public RobotPosition(double x, double y, double z, double u, double v, double w)
        {
            X = x; Y = y; Z = z; U = u; V = v; W = w;
        }

        public bool Equals(RobotPosition other)
        {
            return X == other.X && Y == other.Y && Z == other.Z
                && U == other.U && V == other.V && W == other.W;
        }

        public override bool Equals(object obj) => obj is RobotPosition other && Equals(other);

        public override int GetHashCode()
        {
            unchecked
            {
                int hash = 17;
                hash = hash * 31 + X.GetHashCode();
                hash = hash * 31 + Y.GetHashCode();
                hash = hash * 31 + Z.GetHashCode();
                hash = hash * 31 + U.GetHashCode();
                hash = hash * 31 + V.GetHashCode();
                hash = hash * 31 + W.GetHashCode();
                return hash;
            }
        }

        public override string ToString() =>
            FormattableString.Invariant($"X:{X:F2} Y:{Y:F2} Z:{Z:F2} U:{U:F2} V:{V:F2} W:{W:F2}");

        public static bool operator ==(RobotPosition left, RobotPosition right) => left.Equals(right);
        public static bool operator !=(RobotPosition left, RobotPosition right) => !left.Equals(right);
    }
}
