using System;
using System.IO;

namespace GlassDetection
{
    /// <summary>
    /// 簡易日誌幫手 — 自動寫入檔案 + 輸出到 Console
    /// 新接手的人可以直接看 Log 排查問題
    /// </summary>
    public static class LogHelper
    {
        private static readonly object _lock = new object();
        private static string _logPath = "RobotLog.txt";
        private static bool _consoleOutput = true;

        public static string LogPath
        {
            get => _logPath;
            set
            {
                _logPath = value;
                try { File.WriteAllText(_logPath, $"===== 日誌開始 {DateTime.Now:yyyy-MM-dd HH:mm:ss} =====
"); }
                catch { }
            }
        }

        public static bool ConsoleOutput { get => _consoleOutput; set => _consoleOutput = value; }

        public static void Info(string msg)  => Write("[INFO]", msg);
        public static void Warn(string msg)  => Write("[WARN]", msg);
        public static void Error(string msg) => Write("[ERROR]", msg);
        public static void Debug(string msg) => Write("[DEBUG]", msg);
        public static void Step(string name, int idx, int total) => Write("[STEP]", $"({idx}/{total}) {name}");

        private static void Write(string level, string msg)
        {
            var line = $"{DateTime.Now:HH:mm:ss.fff} {level} {msg}";
            lock (_lock)
            {
                if (_consoleOutput) Console.WriteLine(line);
                try { File.AppendAllText(_logPath, line + "
"); }
                catch { }
            }
        }
    }
}
