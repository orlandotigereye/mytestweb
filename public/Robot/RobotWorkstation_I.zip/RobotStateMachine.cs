using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

namespace GlassDetection
{
    /// <summary>
    /// 機器人狀態機：管理整個生產流程的狀態轉換
    /// </summary>
    public sealed class RobotStateMachine : IDisposable
    {
        private readonly RobotModule _robot;
        private readonly object _stateSync = new object();
        private RobotState _state = RobotState.Idle;
        private int _currentStep = 0;
        private IReadOnlyList<SequenceStep> _sequence = Array.Empty<SequenceStep>();
        private CancellationTokenSource _cts;
        private Task _runTask;
        private bool _disposed;

        public RobotState CurrentState
        {
            get { lock (_stateSync) { return _state; } }
        }

        public int CurrentStep
        {
            get { lock (_stateSync) { return _currentStep; } }
        }

        public int TotalSteps
        {
            get { lock (_stateSync) { return _sequence.Count; } }
        }

        public event EventHandler<StateChangedEventArgs> StateChanged;
        public event EventHandler<StepChangedEventArgs> StepChanged;
        public event EventHandler<SequenceCompletedEventArgs> SequenceCompleted;
        public event EventHandler<ErrorEventArgs> ErrorOccurred;

        public RobotStateMachine(RobotModule robot)
        {
            _robot = robot ?? throw new ArgumentNullException(nameof(robot));
        }

        public void DefineSequence(IEnumerable<SequenceStep> steps)
        {
            if (steps is null)
                throw new ArgumentNullException(nameof(steps));

            var list = new List<SequenceStep>(steps);
            lock (_stateSync)
            {
                _sequence = list.AsReadOnly();
            }
        }

        public void Start()
        {
            lock (_stateSync)
            {
                if (_runTask != null && !_runTask.IsCompleted)
                    return;
                if (_sequence.Count == 0)
                    throw new InvalidOperationException("流程未定義，無法啟動");

                _cts = new CancellationTokenSource();
                _currentStep = 0;
                ChangeStateLocked(RobotState.Running);
                _runTask = Task.Run(() => RunLoopAsync(_cts.Token));
            }
        }

        public void Pause()
        {
            lock (_stateSync)
            {
                if (_state != RobotState.Running)
                    return;
                ChangeStateLocked(RobotState.Paused);
            }
        }

        public void Resume()
        {
            lock (_stateSync)
            {
                if (_state != RobotState.Paused)
                    return;
                ChangeStateLocked(RobotState.Running);
            }
        }

        /// <summary>
        /// 停止流程。先取消 CTS，再等待 Task 完成（最長 30 秒），避免死鎖。
        /// </summary>
        public void Stop()
        {
            _cts?.Cancel();

            // 【修正】延長等待時間至 30 秒（與 MoveTimeoutMs 一致），並循環檢查
            var sw = Stopwatch.StartNew();
            while (_runTask != null && !_runTask.IsCompleted && sw.ElapsedMilliseconds < 30000)
            {
                try { _runTask?.Wait(100); } catch { }
            }

            if (_runTask != null && !_runTask.IsCompleted)
            {
                Debug.WriteLine("[RobotStateMachine] Warning: Stop() 超時，背景 Task 可能仍在執行");
            }

            lock (_stateSync)
            {
                if (_state != RobotState.Idle && _state != RobotState.Stopped && _state != RobotState.Error)
                    ChangeStateLocked(RobotState.Stopped);
            }
        }

        public async Task<bool> ResetToHomeAsync(CancellationToken token = default)
        {
            ChangeState(RobotState.Homing);
            try
            {
                await _robot.MoveZSafeAsync(700, token: token).ConfigureAwait(false);
                await _robot.GoSafeAsync("Home", token: token).ConfigureAwait(false);
                lock (_stateSync) { _currentStep = 0; }
                ChangeState(RobotState.Idle);
                return true;
            }
            catch (Exception ex)
            {
                ChangeState(RobotState.Error);
                ErrorOccurred?.Invoke(this, new ErrorEventArgs
                {
                    Message = $"復歸失敗：{ex.Message}",
                    Exception = ex
                });
                return false;
            }
        }

        /// <summary>
        /// 從指定步驟重新開始。先驗證索引，再 Stop，等待 Task 完全結束後才 Start。
        /// 避免 RestartFromStep 的 lock 與 Stop 內部的 Wait 形成死鎖。
        /// </summary>
        public void RestartFromStep(int stepIndex)
        {
            lock (_stateSync)
            {
                if (stepIndex < 0 || stepIndex >= _sequence.Count)
                    throw new ArgumentOutOfRangeException(nameof(stepIndex));
            }

            Stop();

            // 【修正】確保背景 Task 完全結束後再 Start
            var sw = Stopwatch.StartNew();
            while (_runTask != null && !_runTask.IsCompleted && sw.ElapsedMilliseconds < 30000)
            {
                Thread.Sleep(50);
            }

            lock (_stateSync) { _currentStep = stepIndex; }
            Start();
        }

        private async Task RunLoopAsync(CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                RobotState state;
                int stepIndex;
                SequenceStep step;
                int totalSteps;

                lock (_stateSync)
                {
                    state = _state;
                    stepIndex = _currentStep;
                    totalSteps = _sequence.Count;
                    step = stepIndex < totalSteps ? _sequence[stepIndex] : null;
                }

                if (state == RobotState.Paused)
                {
                    await Task.Delay(100, token).ConfigureAwait(false);
                    continue;
                }
                if (state != RobotState.Running)
                    break;

                if (step is null)
                {
                    SequenceCompleted?.Invoke(this, new SequenceCompletedEventArgs { TotalCycles = 1 });
                    lock (_stateSync) { _currentStep = 0; }
                    // 【修正】流程完成後的 delay 也需處理取消例外
                    try
                    {
                        await Task.Delay(500, token).ConfigureAwait(false);
                    }
                    catch (OperationCanceledException)
                    {
                        break;
                    }
                    continue;
                }

                StepChanged?.Invoke(this, new StepChangedEventArgs
                {
                    StepIndex = stepIndex,
                    StepName = step.Name,
                    TotalSteps = totalSteps
                });

                try
                {
                    bool result = await step.ExecuteAsync(token).ConfigureAwait(false);

                    if (!result && step.IsCritical)
                    {
                        ChangeState(RobotState.Error);
                        ErrorOccurred?.Invoke(this, new ErrorEventArgs
                        {
                            StepIndex = stepIndex,
                            StepName = step.Name,
                            Message = $"關鍵步驟失敗：{step.Name}"
                        });
                        break;
                    }

                    lock (_stateSync) { _currentStep++; }
                }
                catch (OperationCanceledException)
                {
                    break;
                }
                catch (Exception ex)
                {
                    ChangeState(RobotState.Error);
                    ErrorOccurred?.Invoke(this, new ErrorEventArgs
                    {
                        StepIndex = stepIndex,
                        StepName = step.Name,
                        Message = ex.Message,
                        Exception = ex
                    });
                    break;
                }

                await Task.Delay(10, token).ConfigureAwait(false);
            }

            // 清理：在 lock 內設置狀態，但 _cts 在 lock 外釋放
            lock (_stateSync)
            {
                if (_state != RobotState.Error && _state != RobotState.Stopped)
                    _state = RobotState.Idle;
                _runTask = null;
            }
            _cts?.Dispose();
            _cts = null;
        }

        /// <summary>
        /// 狀態變更 — 呼叫方已持有 _stateSync lock 時使用
        /// </summary>
        private void ChangeStateLocked(RobotState newState)
        {
            var oldState = _state;
            _state = newState;
            StateChanged?.Invoke(this, new StateChangedEventArgs
            {
                OldState = oldState,
                NewState = newState
            });
        }

        /// <summary>
        /// 狀態變更 — 呼叫方未持有 lock 時使用
        /// </summary>
        private void ChangeState(RobotState newState)
        {
            RobotState oldState;
            lock (_stateSync)
            {
                oldState = _state;
                _state = newState;
            }
            StateChanged?.Invoke(this, new StateChangedEventArgs
            {
                OldState = oldState,
                NewState = newState
            });
        }

        public void Dispose()
        {
            if (_disposed)
                return;
            _disposed = true;
            Stop();
        }
    }

    public enum RobotState
    {
        Idle,
        Running,
        Paused,
        Stopped,
        Homing,
        Error
    }

    public sealed class SequenceStep
    {
        public string Name { get; }
        public bool IsCritical { get; }
        private readonly Func<CancellationToken, Task<bool>> _asyncAction;
        private readonly Func<bool> _syncAction;

        public SequenceStep(string name, Func<bool> action, bool isCritical = true)
        {
            Name = name ?? throw new ArgumentNullException(nameof(name));
            _syncAction = action ?? throw new ArgumentNullException(nameof(action));
            IsCritical = isCritical;
        }

        public SequenceStep(string name, Func<CancellationToken, Task<bool>> asyncAction, bool isCritical = true)
        {
            Name = name ?? throw new ArgumentNullException(nameof(name));
            _asyncAction = asyncAction ?? throw new ArgumentNullException(nameof(asyncAction));
            IsCritical = isCritical;
        }

        public Task<bool> ExecuteAsync(CancellationToken token)
        {
            if (_asyncAction != null)
                return _asyncAction(token);
            return Task.FromResult(_syncAction());
        }
    }

    public class StateChangedEventArgs : EventArgs
    {
        public RobotState OldState { get; set; }
        public RobotState NewState { get; set; }
    }

    public class StepChangedEventArgs : EventArgs
    {
        public int StepIndex { get; set; }
        public string StepName { get; set; }
        public int TotalSteps { get; set; }
    }

    public class SequenceCompletedEventArgs : EventArgs
    {
        public int TotalCycles { get; set; }
    }

    public class ErrorEventArgs : EventArgs
    {
        public int StepIndex { get; set; }
        public string StepName { get; set; }
        public string Message { get; set; }
        public Exception Exception { get; set; }
    }
}
