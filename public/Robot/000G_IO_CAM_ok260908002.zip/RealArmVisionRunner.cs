using System;
using System.IO;
using System.Reflection;
using System.Xml;
using System.Windows.Forms;
using HalconDotNet;
using EpsonRunner;

namespace GlassDetection
{
    public class RealArmVisionRunner : IVisionRunner
    {
        public HTuple hv_ExpDefaultWinHandle;

        private HTuple hv_ModelID = new HTuple();
        private HTuple hv_HomMat2D = new HTuple();
        private HObject ho_ModelContours;

        private ProductModel _config;

        private double _imageGlassUpperLeftCornerCol = 0.0;
        private double _imageGlassUpperLeftCornerRow = 0.0;
        private double _imageGlassLowerRightCornerCol = 0.0;
        private double _imageGlassLowerRightCornerRow = 0.0;
        private double _imageGlassPhi = 0.0;

        private bool _bResult = false;
        private bool _disposed = false;

        public double GlassCenterX { get; set; }
        public double GlassCenterY { get; set; }
        public double A_Offset { get; set; }

        public double RobotCenterX { get; set; }
        public double RobotCenterY { get; set; }
        public double RobotCenterU { get; set; }
        public double RobotCenterV { get; set; }
        public double RobotCenterW { get; set; }

        static RealArmVisionRunner()
        {
            AppDomain.CurrentDomain.AssemblyResolve += OnResolveAssembly;
        }

        public RealArmVisionRunner()
        {
            HOperatorSet.GenEmptyObj(out ho_ModelContours);
        }

        public static void LoadHalconAssemblyFromXml(string xmlPath)
        {
            if (!File.Exists(xmlPath)) return;

            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(xmlPath);

                XmlNode halconPathNode = doc.SelectSingleNode("//HalconDllPath");
                string halconDllPath = halconPathNode != null ? halconPathNode.InnerText.Trim() : "";

                if (!string.IsNullOrEmpty(halconDllPath) && File.Exists(halconDllPath))
                {
                    string dir = Path.GetDirectoryName(halconDllPath);
                    if (!string.IsNullOrEmpty(dir) && Directory.Exists(dir))
                    {
                        s_customDllDirectory = dir;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("[警告] 解析 XML HalconDllPath 失敗: " + ex.Message);
            }
        }

        private static string s_customDllDirectory = null;

        private static Assembly OnResolveAssembly(object sender, ResolveEventArgs args)
        {
            string assemblyName = new AssemblyName(args.Name).Name;
            if (assemblyName.Equals("halcondotnet", StringComparison.OrdinalIgnoreCase))
            {
                if (!string.IsNullOrEmpty(s_customDllDirectory))
                {
                    string targetPath = Path.Combine(s_customDllDirectory, "halcondotnet.dll");
                    if (File.Exists(targetPath))
                    {
                        return Assembly.LoadFrom(targetPath);
                    }
                }
            }
            return null;
        }

        public void InitHalcon(string xmlPath, string activeModel)
        {
            try
            {
                LoadHalconAssemblyFromXml(xmlPath);

                XmlDocument doc = new XmlDocument();
                if (File.Exists(xmlPath))
                {
                    doc.Load(xmlPath);
                    _config = ProductModel.LoadFromXml(doc, activeModel);
                }
                else
                {
                    _config = new ProductModel();
                }

                InitMatchModule(_config.PatternImage);
            }
            catch (Exception ex)
            {
                Console.WriteLine("[錯誤] InitHalcon 執行失敗: " + ex.Message);
            }
        }

        public void InitHalcon()
        {
            InitHalcon("EpsonConfig.xml", "Glass_310x320");
        }

        private void InitMatchModule(string recipePatternFilename)
        {
            HObject ho_Image = null;
            HObject ho_ModelRegion = null;
            HObject ho_TemplateImage = null;

            try
            {
                HOperatorSet.GenEmptyObj(out ho_Image);
                HOperatorSet.GenEmptyObj(out ho_ModelRegion);
                HOperatorSet.GenEmptyObj(out ho_TemplateImage);

                string fullPath = Path.Combine(Application.StartupPath, recipePatternFilename);
                if (!File.Exists(fullPath)) return;

                HOperatorSet.ReadImage(out ho_Image, fullPath);
                HOperatorSet.GenRectangle1(out ho_ModelRegion, _config.RoiRow1, _config.RoiCol1, _config.RoiRow2, _config.RoiCol2);
                HOperatorSet.ReduceDomain(ho_Image, ho_ModelRegion, out ho_TemplateImage);

                if (hv_ModelID != null && hv_ModelID.Length > 0)
                {
                    hv_ModelID.Dispose();
                }
                HOperatorSet.CreateGenericShapeModel(out hv_ModelID);
                HOperatorSet.SetGenericShapeModelParam(hv_ModelID, "iso_scale_max", _config.IsoScaleMax);
                HOperatorSet.SetGenericShapeModelParam(hv_ModelID, "iso_scale_min", _config.IsoScaleMin);
                HOperatorSet.TrainGenericShapeModel(ho_TemplateImage, hv_ModelID);
            }
            catch (Exception ex)
            {
                Console.WriteLine("[錯誤] InitMatchModule 失敗: " + ex.Message);
            }
            finally
            {
                if (ho_Image != null) ho_Image.Dispose();
                if (ho_ModelRegion != null) ho_ModelRegion.Dispose();
                if (ho_TemplateImage != null) ho_TemplateImage.Dispose();
            }
        }

        public bool RunVisionSimulated(double simRobotX, double simRobotY, double simRobotU)
        {
            RobotCenterX = simRobotX;
            RobotCenterY = simRobotY;
            RobotCenterU = simRobotU;

            GlassCenterX = simRobotX;
            GlassCenterY = simRobotY;
            A_Offset = 0.0;
            return true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (hv_ModelID != null && hv_ModelID.Length > 0) hv_ModelID.Dispose();
                if (ho_ModelContours != null && ho_ModelContours.IsInitialized()) ho_ModelContours.Dispose();
                if (hv_HomMat2D != null && hv_HomMat2D.Length > 0) hv_HomMat2D.Dispose();
                _disposed = true;
            }
        }

        ~RealArmVisionRunner()
        {
            Dispose(false);
        }
    }
}