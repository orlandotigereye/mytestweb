using System;
using System.IO;
using System.Xml;
using System.Threading;
using System.Reflection;
using System.Collections.Generic;

namespace EpsonRunner {
    public enum WorkMode {
        SIMULATION = 1,
        DRY_RUN = 2,
        PRODUCTION = 3
    }

    class Program {
        private static readonly object _robotLock = new object();

        private static Type t; 
        private static object r; 

        private static MethodInfo cmdM = null;
        private static MethodInfo gX = null; 
        private static MethodInfo gY = null; 
        private static MethodInfo gZ = null;

        private static Dictionary<string, MethodInfo> _methodCache = new Dictionary<string, MethodInfo>();
        private static Dictionary<string, PropertyInfo> _propertyCache = new Dictionary<string, PropertyInfo>();

        private static WorkMode currentWorkMode = WorkMode.PRODUCTION;
        private static double safeZOffset = 0.0;
        private static ProductModel currentProduct = null;

        #region 安全 XML 工具函式
        private static int GetXmlInt(XmlDocument doc, string xpath, int defaultValue, int min, int max) {
            XmlNode node = doc.SelectSingleNode(xpath);
            int val = 0;
            if (node != null && int.TryParse(node.InnerText.Trim(), out val)) {
                return Math.Max(min, Math.Min(max, val));
            }
            return defaultValue;
        }

        private static int GetXmlInt(XmlDocument doc, string xpath, int defaultValue) {
            return GetXmlInt(doc, xpath, defaultValue, int.MinValue, int.MaxValue);
        }

        private static string GetXmlString(XmlDocument doc, string xpath, string defaultValue) {
            XmlNode node = doc.SelectSingleNode(xpath);
            if (node != null && !string.IsNullOrEmpty(node.InnerText)) {
                return node.InnerText.Trim();
            }
            return defaultValue;
        }

        private static bool GetXmlBool(XmlDocument doc, string xpath, bool defaultValue) {
            XmlNode node = doc.SelectSingleNode(xpath);
            bool val = false;
            if (node != null && bool.TryParse(node.InnerText.Trim(), out val)) {
                return val;
            }
            return defaultValue;
        }

        private static string ResolvePath(string baseDir, string path) {
            if (string.IsNullOrEmpty(path)) return string.Empty;
            if (Path.IsPathRooted(path)) return path;
            if (string.IsNullOrEmpty(baseDir)) return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, path);
            
            string resolvedBase = Path.IsPathRooted(baseDir) 
                ? baseDir 
                : Path.Combine(AppDomain.CurrentDomain.BaseDirectory, baseDir);
            return Path.Combine(resolvedBase, path);
        }
        #endregion

        #region 反射與防護機制
        private static void FastSetP(string name, object val) {
            if (t == null || r == null) return;
            try {
                PropertyInfo p = null;
                if (!_propertyCache.TryGetValue(name, out p)) {
                    p = t.GetProperty(name);
                    _propertyCache[name] = p;
                }
                if (p != null) {
                    p.SetValue(r, val, null);
                    return;
                }

                string key = name + "_" + val.GetType().FullName;
                MethodInfo m = null;
                if (!_methodCache.TryGetValue(key, out m)) {
                    m = t.GetMethod(name, new Type[] { val.GetType() });
                    _methodCache[key] = m;
                }
                if (m != null) m.Invoke(r, new object[] { val });
            } catch (Exception ex) {
                string msg = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                if (msg.Contains("2342")) {
                    Console.WriteLine("   [⚠️ 2342 屬性防護] 忽略遠端輸出位元設定屬性: " + name);
                } else {
                    Console.WriteLine("[快取反射錯誤 - SetP]: " + msg);
                }
            }
        }

        private static void FastInvokeM(string name, params object[] args) {
            if (t == null || r == null) return;
            try {
                string key = name;
                if (args != null && args.Length > 0) {
                    key += "_" + args.Length;
                    for (int i = 0; i < args.Length; i++) key += "_" + args[i].GetType().FullName;
                }

                MethodInfo m = null;
                if (!_methodCache.TryGetValue(key, out m)) {
                    if (args != null && args.Length > 0) {
                        Type[] ts = new Type[args.Length];
                        for (int i = 0; i < args.Length; i++) ts[i] = args[i].GetType();
                        m = t.GetMethod(name, ts);
                    } else {
                        m = t.GetMethod(name);
                    }
                    _methodCache[key] = m;
                }

                if (m != null) m.Invoke(r, args);
            } catch (Exception ex) {
                Exception actualEx = ex.InnerException != null ? ex.InnerException : ex;
                if (actualEx.Message.Contains("2342")) {
                    string timeTag = "[" + DateTime.Now.ToString("HH:mm:ss.fff") + "]";
                    Console.WriteLine("   " + timeTag + " [⚠️ 2342 防禦成功] 攔截系統遠端位元寫入衝突 (" + name + ")，流程繼續執行。");
                    return;
                }
                throw actualEx;
            }
        }

        private static double NormalizeAngle(double angle) {
            while (angle > 180.0) angle -= 360.0;
            while (angle < -180.0) angle += 360.0;
            return angle;
        }

        private static void SafeExecuteCommand(string command) {
            if (cmdM == null || r == null) return;
            try {
                cmdM.Invoke(r, new object[] { command });
            } catch (Exception ex) {
                Exception actualEx = ex.InnerException != null ? ex.InnerException : ex;
                if (actualEx.Message.Contains("2342")) {
                    string timeTag = "[" + DateTime.Now.ToString("HH:mm:ss.fff") + "]";
                    Console.WriteLine("   " + timeTag + " [⚠️ 2342 點位/IO防護] 攔截指令: " + command + " (該位元已被系統宣告為 Remote Output)");
                } else {
                    throw actualEx;
                }
            }
        }

        private static void SafeSetPoint(string pointName, double x, double y, double z, double u) {
            lock (_robotLock) {
                if (cmdM == null) return;

                double safeU = NormalizeAngle(u);
                string setPointCmd = string.Format("{0} = XY({1:F3}, {2:F3}, {3:F3}, {4:F3})", pointName, x, y, z, safeU);

                try {
                    SafeExecuteCommand(setPointCmd);
                } 
                catch (Exception) {
                    try {
                        string timeTag = "[" + DateTime.Now.ToString("HH:mm:ss.fff") + "]";
                        Console.WriteLine("   " + timeTag + " [⚠️ 點位防錯] 動態建立全域點位: [" + pointName + "]");
                        SafeExecuteCommand("Global Pres " + pointName);
                        SafeExecuteCommand(setPointCmd);
                        Console.WriteLine("   " + timeTag + " [成功] 點位 [" + pointName + "] 設定完成！");
                    } 
                    catch (Exception ex) {
                        string timeTag = "[" + DateTime.Now.ToString("HH:mm:ss.fff") + "]";
                        Console.WriteLine("   " + timeTag + " [❌ 點位失敗] 無法建立 [" + pointName + "]: " + ex.Message);
                    }
                }
            }
        }

        private static void ExecPt(string mode, string pt) {
            lock (_robotLock) {
                string timeTag = "[" + DateTime.Now.ToString("HH:mm:ss.fff") + "]";
                
                if (currentWorkMode == WorkMode.SIMULATION && r == null) {
                    Console.WriteLine("   " + timeTag + " [💻 虛擬手臂] 指令: " + mode + " ➔ 點位: " + pt + " (安全 Z 偏移: +" + safeZOffset + "mm)");
                    return;
                }

                Console.WriteLine("   " + timeTag + " [🤖 實體手臂] 執行 " + mode + " ➔ 點位: " + pt);

                try { 
                    FastInvokeM(mode, pt); 
                }
                catch (Exception ex) {
                    string errMsg = ex.Message;
                    Console.WriteLine("   " + timeTag + " [💥 運動中斷](" + pt + "): " + errMsg);

                    if (errMsg.Contains("Point") || errMsg.Contains("exist") || errMsg.Contains("4000")) {
                        try {
                            string cleanPointName = pt.Split(' ')[0].Trim();
                            Console.WriteLine("   " + timeTag + " [自動修復] 自動宣告全域點位: " + cleanPointName);
                            SafeExecuteCommand("Global Pres " + cleanPointName);
                            FastInvokeM(mode, pt);
                        } catch {
                            try { FastInvokeM("Reset"); } catch { }
                        }
                    } else {
                        try { FastInvokeM("Reset"); } catch { }
                    }
                }
            }
        }
        #endregion

        #region Home Return 安全復歸
        private static void ExecuteHomeReturn() {
            Console.WriteLine("\n=========================================================");
            Console.WriteLine("   [🔄 Home Return] 開始執行急停/半途停機安全復歸流程...");
            Console.WriteLine("=========================================================");

            lock (_robotLock) {
                string timeTag = "[" + DateTime.Now.ToString("HH:mm:ss.fff") + "]";

                bool hasMaterial = IOManager.IsVacuumOn();
                if (hasMaterial) {
                    Console.WriteLine("   " + timeTag + " [⚠️ 警告] 偵測到夾具上有殘留玻璃/材料！");
                    Console.WriteLine("   " + timeTag + " [安全策略] 執行垂直高點退場，防止水平碰撞...");
                } else {
                    Console.WriteLine("   " + timeTag + " [資訊] 夾具無帶料，執行標準復歸位...");
                }

                Console.WriteLine("   " + timeTag + " [步驟 1/3] 強制抬升 Z 軸至頂點 (Z=0 Safe)");
                if (cmdM != null) {
                    try { SafeExecuteCommand("LimZ 0"); } catch { }
                    ExecPt("Move", "Here :Z(0)");
                } else {
                    Console.WriteLine("   " + timeTag + " [💻 虛擬手臂] 垂直抬升至 Z(0)");
                }

                Console.WriteLine("   " + timeTag + " [步驟 2/3] 平移至 safe WaitingPoint");
                ExecPt("Go", "WaitingPoint");

                if (hasMaterial) {
                    Console.WriteLine("   " + timeTag + " [步驟 3/3] 執行破 vacuum 釋放物件...");
                    IOManager.SendCommand("CLOSE_VACUUM");
                } else {
                    Console.WriteLine("   " + timeTag + " [步驟 3/3] 系統狀態復位完成。");
                }

                Console.WriteLine("\n[成功] Home Return 復歸完成！機台已恢復安全初始狀態。\n");
            }
        }
        #endregion

        #region 控制權搶占
        private static bool TryAcquireControllerPermission(Assembly assembly) {
            if (r == null || t == null) return false;
            try {
                try {
                    PropertyInfo modeProp = t.GetProperty("OperationMode");
                    if (modeProp != null) {
                        Type enumType = assembly.GetType("RCAPINet.SpelOperationMode") ?? assembly.GetType("SpelNetLib60.SpelOperationMode");
                        if (enumType != null) {
                            modeProp.SetValue(r, Enum.Parse(enumType, "Program"), null);
                            Console.WriteLine("[成功] 已將 EPSON 控制器切換至: Program 模式");
                        }
                    }
                } catch { }

                MethodInfo enableM = t.GetMethod("EnableThisController");
                if (enableM != null) {
                    enableM.Invoke(r, null);
                    Console.WriteLine("[OK] 成功取得 EPSON 控制器主控制權 (EnableThisController)！");
                    return true;
                } else {
                    PropertyInfo enableP = t.GetProperty("EnableThisController");
                    if (enableP != null) {
                        enableP.SetValue(r, true, null);
                        Console.WriteLine("[OK] 成功變更控制權屬性 (EnableThisController = true)！");
                        return true;
                    }
                }
            } catch (Exception ex) {
                string msg = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                Console.WriteLine("[⚠️ 控制權搶占提示]: " + msg);
            }
            return false;
        }
        #endregion

        static void Main(string[] args) {
            while (true) {
                Console.WriteLine("=========================================================");
                Console.WriteLine("   EPSON C8 模組化生產生產控制系統 (實體手臂運動修復版)");
                Console.WriteLine("=========================================================");

                string configPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "EpsonConfig.xml");
                if (!File.Exists(configPath)) {
                    configPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Configuration.xml");
                }

                XmlDocument doc = new XmlDocument();
                bool isConfigLoaded = false;
                if (File.Exists(configPath)) {
                    try {
                        doc.Load(configPath);
                        isConfigLoaded = true;
                    } catch (Exception ex) {
                        Console.WriteLine("[警告] XML 載入失敗: " + ex.Message);
                    }
                } else {
                    Console.WriteLine("[資訊] 未檢測到 XML 設定檔，使用預設模擬模式運行");
                }

                string activeModel = isConfigLoaded ? GetXmlString(doc, "//ActiveProductModel", "Glass_U717") : "Glass_U717";
                
                if (isConfigLoaded) {
                    try {
                        currentProduct = ProductModel.LoadFromXml(doc, activeModel);
                    } catch {
                        currentProduct = new ProductModel { ModelName = activeModel, Description = "標準流程", PickZOffset = 0.0, SimObjectName = "Glass" };
                    }
                } else {
                    currentProduct = new ProductModel { ModelName = "Default", Description = "預設模擬流程", PickZOffset = 0.0, SimObjectName = "Glass" };
                }

                Console.WriteLine("---------------------------------------------------------");
                Console.WriteLine("當前激活產品尺寸: [" + currentProduct.ModelName + "]");
                Console.WriteLine("選擇運行模式:");
                Console.WriteLine("  1 ➔ 實體手臂驅動測試 (單獨手臂 / 實機運轉)");
                Console.WriteLine("  2 ➔ 純 I/O 模擬 / 空運轉 (略過手臂點位)");
                Console.WriteLine("  3 ➔ 正式混合全自動生產 (手臂 + 實體 I/O)");
                Console.WriteLine("  4 ➔ 實體手臂 + 實體視覺 (視覺即時抓片模式)");
                Console.WriteLine("  H ➔ Home Return (一鍵安全復歸/急停退場)");
                Console.Write("👉 請選擇 (1, 2, 3, 4, H 或 Q 離開): ");		

                string inputMode = Console.ReadLine();
                if (inputMode != null && inputMode.ToUpper() == "Q") break;
				
                if (inputMode == "4") {
                    GlassDetection.RealArmVisionRunner visionRunner = new GlassDetection.RealArmVisionRunner();
                    visionRunner.InitHalcon(configPath, currentProduct.ModelName);
                    Console.WriteLine("[OK] 實體視覺即時定位模組初始化完成 (產品: " + currentProduct.ModelName + ")");
                    Console.WriteLine("按任意鍵返回主選單...");
                    Console.ReadKey();
                    continue;
                }

                if (inputMode != null && inputMode.ToUpper() == "H") {
                    ExecuteHomeReturn();
                    continue;
                }

                bool useRealDaqSetting = false;
                if (inputMode == "1") {
                    currentWorkMode = WorkMode.PRODUCTION;
                    useRealDaqSetting = false;
                } else if (inputMode == "2") {
                    currentWorkMode = WorkMode.SIMULATION;
                    useRealDaqSetting = false;
                } else if (inputMode == "3") {
                    currentWorkMode = WorkMode.PRODUCTION;
                    useRealDaqSetting = isConfigLoaded && GetXmlBool(doc, "//UseRealDAQ", true);
                } else {
                    currentWorkMode = WorkMode.PRODUCTION;
                    useRealDaqSetting = false;
                }

                safeZOffset = (currentWorkMode == WorkMode.PRODUCTION) ? currentProduct.PickZOffset : (50.0 + currentProduct.PickZOffset);

                Console.WriteLine("\n[系統啟動] 當前手臂模式: [" + currentWorkMode + "] | 產品: [" + currentProduct.ModelName + "]\n");

                string dllDirectory = isConfigLoaded ? GetXmlString(doc, "//DllDirectory", "") : "";
                string rawDllPath = isConfigLoaded ? GetXmlString(doc, "//DllPath", GetXmlString(doc, "//RobotConfig/DllPath", "RCAPINet.dll")) : "RCAPINet.dll";
                string dllPath = ResolvePath(dllDirectory, rawDllPath);

                string projectPath = isConfigLoaded ? GetXmlString(doc, "//ProjectPath", GetXmlString(doc, "//RobotConfig/ProjectPath", "")) : "";
                int connNum = isConfigLoaded ? GetXmlInt(doc, "//ConnectionNumber", GetXmlInt(doc, "//RobotConfig/ConnectionNumber", 8)) : 8; 
                int robotNum = isConfigLoaded ? GetXmlInt(doc, "//RobotNumber", GetXmlInt(doc, "//RobotConfig/RobotNumber", 1)) : 1;
                int speed = isConfigLoaded ? GetXmlInt(doc, "//Speed", GetXmlInt(doc, "//RobotConfig/Speed", 100, 1, 100), 1, 100) : 100; 
                int speedS = isConfigLoaded ? GetXmlInt(doc, "//SpeedS", GetXmlInt(doc, "//RobotConfig/SpeedS", 800, 1, 2000), 1, 2000) : 800;
                int accelS = isConfigLoaded ? GetXmlInt(doc, "//AccelS", GetXmlInt(doc, "//RobotConfig/AccelS", 5000, 1, 10000), 1, 10000) : 5000; 
                int totalCycles = isConfigLoaded ? GetXmlInt(doc, "//TotalCycles", GetXmlInt(doc, "//RobotConfig/TotalCycles", 1, 1, 99999), 1, 99999) : 1;

                string daqIP = isConfigLoaded ? GetXmlString(doc, "//DaqServerIP", GetXmlString(doc, "//DaqConfig/DaqServerIP", "127.0.0.1")) : "127.0.0.1"; 
                int daqPort = isConfigLoaded ? GetXmlInt(doc, "//DaqServerPort", GetXmlInt(doc, "//DaqConfig/DaqServerPort", 5000)) : 5000;
                string deviceDesc = isConfigLoaded ? GetXmlString(doc, "//DeviceDescription", GetXmlString(doc, "//DaqConfig/DeviceDescription", "")) : ""; 

                string rawProfilePath = isConfigLoaded ? GetXmlString(doc, "//ProfilePath", GetXmlString(doc, "//DaqConfig/ProfilePath", "")) : "";
                string profilePath = ResolvePath(dllDirectory, rawProfilePath);

                string rawDaqDllPath = isConfigLoaded ? GetXmlString(doc, "//DaqDllPath", GetXmlString(doc, "//DaqConfig/DaqDllPath", "")) : "";
                string daqDllPath = ResolvePath(dllDirectory, rawDaqDllPath);

                string rawBioDaqDllPath = isConfigLoaded ? GetXmlString(doc, "//BioDaqDllPath", GetXmlString(doc, "//DaqConfig/BioDaqDllPath", "")) : "";
                string bioDaqDllPath = ResolvePath(dllDirectory, rawBioDaqDllPath);

                string rawDaqDesignDllPath = isConfigLoaded ? GetXmlString(doc, "//DaqDesignDllPath", GetXmlString(doc, "//DaqConfig/DaqDesignDllPath", "")) : "";
                string daqDesignDllPath = ResolvePath(dllDirectory, rawDaqDesignDllPath);

                IOManager.UseRealDaq = useRealDaqSetting;

                List<string[]> motionScript = new List<string[]>();
                if (isConfigLoaded) {
                    XmlNodeList steps = doc.SelectNodes("//Script/Step");
                    if (steps != null && steps.Count > 0) {
                        foreach (XmlNode node in steps) {
                            string line = node.InnerText.Trim(); 
                            int idx = line.IndexOf(',');
                            if (idx > 0) motionScript.Add(new string[] { line.Substring(0, idx).Trim(), line.Substring(idx + 1).Trim() });
                            else motionScript.Add(new string[] { line.Trim(), "" });
                        }
                    }
                }
                
                if (motionScript.Count == 0) {
                    motionScript.Add(new string[] { "VISION", "" });
                    motionScript.Add(new string[] { "GO", "P_TARGET" });
                    motionScript.Add(new string[] { "IO", "OPEN_VACUUM" });
                    motionScript.Add(new string[] { "GO", "WaitingPoint" });
                    motionScript.Add(new string[] { "IO", "CLOSE_VACUUM" });
                }

                IOManager.Initialize(daqIP, daqPort, daqDllPath, bioDaqDllPath, daqDesignDllPath, deviceDesc, profilePath);

                if (File.Exists(dllPath)) {
                    try {
                        Assembly assembly = Assembly.LoadFrom(dllPath); 
                        t = assembly.GetType("RCAPINet.Spel") ?? assembly.GetType("RCAPINet.Robot") ?? assembly.GetType("Epson.RobotCompactAPI.Robot");

                        if (t != null) {
                            r = Activator.CreateInstance(t); 
                            
                            FastSetP("Project", projectPath); 
                            FastSetP("ProjectFile", projectPath); 
                            FastSetP("Connection", connNum); 
                            FastSetP("ConnectionNumber", connNum);
                            
                            MethodInfo initM = t.GetMethod("Initialize") ?? t.GetMethod("Connect");
                            if (initM != null) initM.Invoke(r, null);

                            TryAcquireControllerPermission(assembly);

                            FastSetP("EnableEvent", true); 
                            cmdM = t.GetMethod("ExecuteCommand", new Type[] { typeof(string) });
                            
                            bool motorSuccess = false;
                            for (int attempt = 1; attempt <= 3; attempt++) {
                                try {
                                    TryAcquireControllerPermission(assembly);

                                    if (cmdM != null) {
                                        SafeExecuteCommand("Reset");
                                        SafeExecuteCommand("Motor On");
                                        try { SafeExecuteCommand("CP On"); } catch { }
                                    } else {
                                        FastSetP("MotorOn", true);
                                    }

                                    motorSuccess = true;
                                    Console.WriteLine("[OK] 手臂馬達激磁成功 (Motor On)！");
                                    break;
                                } catch (Exception ex) {
                                    string innerMsg = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                                    Console.WriteLine("[⚠️ 嘗試 " + attempt + "/3] 馬達啟動中... 訊息: " + innerMsg);
                                    Thread.Sleep(800);
                                }
                            }

                            if (!motorSuccess) {
                                Console.WriteLine("\n[🚨 錯誤 1028 排除指引]");
                                Console.WriteLine("1. 請關閉 EPSON RC+ 軟體中的 Control Panel (控制面板)");
                                Console.WriteLine("2. 若有實體教導盒 (TP)，請確認鑰匙開關已切換至 AUTO 模式\n");
                            }

                            FastSetP("PowerHigh", true); 
                            FastSetP("Speed", speed); 
                            FastSetP("SpeedS", speedS);
                            
                            if (cmdM != null) {
                                try { SafeExecuteCommand("AccelS " + accelS + ", " + accelS); } catch { }
                            }
                            
                            FastSetP("RobotNumber", robotNum); 
                            FastSetP("Robot", robotNum);
                            
                            gX = t.GetMethod("GetPointX", new Type[] { typeof(string) }); 
                            gY = t.GetMethod("GetPointY", new Type[] { typeof(string) }); 
                            gZ = t.GetMethod("GetPointZ", new Type[] { typeof(string) });
                        } else {
                            Console.WriteLine("[資訊] 未發現指定 API 型態，執行純軟體模擬運行。");
                        }
                    } catch (Exception ex) {
                        Console.WriteLine("[提示] API 載入提醒: " + ex.Message);
                    }
                } else {
                    Console.WriteLine("[資訊] 未找到硬體 DLL 檔 (" + dllPath + ")，切換至純虛擬模式。");
                }

                Console.WriteLine("\n[開始執行] 產品: " + currentProduct.ModelName + " | 共 " + totalCycles + " 循環...");

                bool isErrorOccurred = false;

                for (int i = 1; i <= totalCycles; i++) {
                    if (isErrorOccurred) break;
                    Console.WriteLine("-> 正在執行第 " + i + "/" + totalCycles + " 次生產循環...");

                    for (int s = 0; s < motionScript.Count; s++) {
                        string[] currentStep = motionScript[s];
                        string cmdType = currentStep[0].ToUpper(); 
                        string cmdParam = currentStep[1];

                        if (cmdType == "VISION") {
                            VisionResult vRes = VisionManager.ExecuteGlassDetection(currentWorkMode, currentProduct, daqIP, daqPort);
                            if (vRes.IsSuccess) {
                                double targetZ = (currentWorkMode == WorkMode.PRODUCTION) ? 0.0 : safeZOffset;
                                SafeSetPoint("P_TARGET", vRes.RobotTargetX, vRes.RobotTargetY, targetZ, vRes.RobotTargetU);
                            } else {
                                Console.WriteLine("\n[🚨 系統中斷] 視覺定位失敗，觸發產線警報！");
                                IOManager.SendCommand("SET_ALARM_LIGHT,RED_ON_BUZZER_ON");
                                isErrorOccurred = true;
                                break;
                            }
                        }
                        else if (cmdType == "IO") {
                            if (cmdParam.StartsWith("SET_ROBOT_MOTION") || 
                                cmdParam.StartsWith("SET_RUNNING_LIGHT") || 
                                cmdParam.StartsWith("SET_IDLE_LIGHT") || 
                                cmdParam.StartsWith("SET_WARNING")) {
                                string timeTag = "[" + DateTime.Now.ToString("HH:mm:ss.fff") + "]";
                                Console.WriteLine("   " + timeTag + " [ℹ️ 系統位元跳過] 遠端指示位元 [" + cmdParam + "] 已由控制器系統自動託管。");
                            }
                            else {
                                if (cmdM != null && currentWorkMode != WorkMode.PRODUCTION) {
                                    lock (_robotLock) {
                                        if (cmdParam == "OPEN_VACUUM") {
                                            string attachCmd = string.Format("On 1; SimObject_SetParent \"{0}\", \"Robot1.Tool0\"", currentProduct.SimObjectName);
                                            SafeExecuteCommand(attachCmd);
                                        }
                                        else if (cmdParam == "CLOSE_VACUUM") {
                                            string detachCmd = string.Format("Off 1; On 2; Wait 0.05; Off 2; SimObject_SetParent \"{0}\", \"World\"", currentProduct.SimObjectName);
                                            SafeExecuteCommand(detachCmd);
                                        }
                                    }
                                }
                                IOManager.SendCommand(cmdParam);
                            }
                        }
                        else if (cmdType == "GO") {
                            ExecPt("Go", cmdParam);
                        }
                        else if (cmdType == "MOVE") {
                            ExecPt("Move", cmdParam);
                        }
                        else if (cmdType == "MOVEFLAT") {
                            if (gX != null && gY != null && gZ != null) {
                                try { 
                                    double tx = (double)gX.Invoke(r, new object[] { cmdParam });
                                    double ty = (double)gY.Invoke(r, new object[] { cmdParam });
                                    double tz = (double)gZ.Invoke(r, new object[] { cmdParam }) + safeZOffset;
                                    ExecPt("Move", string.Format("XY({0}, {1}, {2}, 0)", tx, ty, tz));
                                } catch { 
                                    ExecPt("Move", cmdParam);
                                }
                            } else {
                                ExecPt("Move", cmdParam);
                            }
                        }
                        else { 
                            ExecPt(cmdType, cmdParam); 
                        }
                    }
                }

                if (isErrorOccurred) {
                    Console.WriteLine("\n[提示] 系統異常，請排除後輸入 'H' 進行 Home Return 復歸。\n");
                } else {
                    Console.WriteLine("\n[循環完成] 正在復位與安全收尾...");
                }

                if (r != null && t != null) { 
                    try { FastSetP("MotorOn", false); } catch { } 
                }
                IOManager.Close();
                Console.WriteLine("[完成] 3 秒後返回主選單...\n");
                Thread.Sleep(3000);
            }
        }
    }
}