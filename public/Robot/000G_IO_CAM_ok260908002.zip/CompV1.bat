@echo off
:: 切換命令提示字元編碼為 UTF-8 (CP65001)
chcp 65001 > nul

set OUT_DIR=c:\Users\user\Downloads
set SRC_DIR=c:\Users\user\Downloads\01C.Robot\0D.TestProgram\OnlyFileTest\000G_IO_CAM
set DLL_DIR=c:\Users\user\Downloads\01C.Robot\0D.TestProgram\OnlyFileTest\DLL_New

:: 1. 執行 C# 編譯
C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe /target:exe /platform:x64 /optimize+ /r:"%DLL_DIR%\halcondotnet.dll" /r:"%DLL_DIR%\RCAPINet.dll" /r:"%DLL_DIR%\Automation.BDaq4.dll" /out:"%OUT_DIR%\EpsonController.exe" "%SRC_DIR%\Program.cs" "%SRC_DIR%\ProductModel.cs" "%SRC_DIR%\VisionManager.cs" "%SRC_DIR%\IOManager.cs" "%SRC_DIR%\RealArmVisionRunner_2.cs" "%SRC_DIR%\VisionRunner.cs"

:: 2. 自動將執行所需之完整相依 DLL 檔複製至 EXE 同一目錄
copy /Y "%DLL_DIR%\halcondotnet.dll" "%OUT_DIR%\"
copy /Y "%DLL_DIR%\RCAPINet.dll" "%OUT_DIR%\"
copy /Y "%DLL_DIR%\Automation.BDaq4.dll" "%OUT_DIR%\"
copy /Y "%DLL_DIR%\Automation.BDaq4.Design.dll" "%OUT_DIR%\"
copy /Y "%DLL_DIR%\biodaq.dll" "%OUT_DIR%\"

echo =========================================
echo 編譯與部署完成！
echo =========================================
pause