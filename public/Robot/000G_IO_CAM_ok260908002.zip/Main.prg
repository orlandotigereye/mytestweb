' =========================================================
' EPSON RC+ SPEL+ 通用核心程式碼 (全模式通用)
' =========================================================
Global Pres P_TARGET, PrinterToOV07

Function main
    Xq 2, SimIO_Service ' 啟動背景 Task 2 執行虛擬 I/O 狀態輪詢
    Motor On
    Power High
    Speed 100
    Accel 100, 100
Funct

' ---------------------------------------------------------
' 通用 3D 動態物件掛載 (由 C# 傳送物件名稱 SimGlass)
' ---------------------------------------------------------
Function AttachObject(objName$ As String)
    On 1 ' 開啟真空 Sw(1)
    SimObject_SetParent objName$, "Robot1.Tool0"
Funct

' ---------------------------------------------------------
' 通用 3D 動態物件釋放
' ---------------------------------------------------------
Function DetachObject(objName$ As String)
    Off 1 ' 關閉真空 Sw(1)
    On 2  ' 開啟吹氣 Sw(2)
    Wait 0.05
    Off 2 ' 關閉吹氣 Sw(2)
    SimObject_SetParent objName$, "World"
Funct

' ---------------------------------------------------------
' 背景 I/O 模擬與狀態反饋
' ---------------------------------------------------------
Function SimIO_Service
    Do
        If Sw(1) = On Then
            Wait 0.1
            On 10 ' 模擬 DI(10) 真空建立 OK 訊號
        Else
            Off 10
        EndIf
        Wait 0.02
    Loop
Funct