using System;
using System.IO;
using System.Xml;

namespace EpsonRunner
{
    public class ProductModel
    {
        public string ModelName { get; set; }
        public string Description { get; set; }
        public string PatternImage { get; set; }
        public string SimObjectName { get; set; }

        public double RoiRow1 { get; set; }
        public double RoiCol1 { get; set; }
        public double RoiRow2 { get; set; }
        public double RoiCol2 { get; set; }

        public double IsoScaleMin { get; set; }
        public double IsoScaleMax { get; set; }

        public double DistanceRobot2Camera { get; set; }
        public double ImageCenterCol { get; set; }
        public double ImageCenterRow { get; set; }

        public double PixelWSize { get; set; }
        public double PixelLSize { get; set; }

        public double NotRotatedGlassCenterX { get; set; }
        public double NotRotatedGlassCenterY { get; set; }

        public double PickZOffset { get; set; }
        public double CameraOffsetX { get; set; }
        public double CameraOffsetY { get; set; }
        public double CameraOffsetU { get; set; }

        public ProductModel()
        {
            ModelName = "Default";
            Description = "Default Model";
            PatternImage = "Pattern.bmp";
            SimObjectName = "";

            RoiRow1 = 0;
            RoiCol1 = 0;
            RoiRow2 = 100;
            RoiCol2 = 100;

            IsoScaleMin = 0.9;
            IsoScaleMax = 1.1;

            DistanceRobot2Camera = 0.0;
            ImageCenterCol = 0.0;
            ImageCenterRow = 0.0;

            PixelWSize = 1.0;
            PixelLSize = 1.0;

            NotRotatedGlassCenterX = 0.0;
            NotRotatedGlassCenterY = 0.0;

            PickZOffset = 0.0;
            CameraOffsetX = 0.0;
            CameraOffsetY = 0.0;
            CameraOffsetU = 0.0;
        }

        public static ProductModel LoadFromXml(XmlDocument doc, string modelName)
        {
            ProductModel model = new ProductModel();
            model.ModelName = modelName;

            if (doc == null) return model;

            // 嘗試尋找對應 ModelName 的節點，若無則抓第一個 ProductModel 或 Root
            string xpath = string.Format("//ProductModel[@name='{0}']", modelName);
            XmlNode modelNode = doc.SelectSingleNode(xpath);

            if (modelNode == null)
            {
                modelNode = doc.SelectSingleNode("//ProductModel");
            }

            if (modelNode == null)
            {
                modelNode = doc.DocumentElement;
            }

            if (modelNode != null)
            {
                model.Description = GetNodeText(modelNode, "Description", "Default Description");
                model.PatternImage = GetNodeText(modelNode, "PatternImage", "Pattern.bmp");
                model.SimObjectName = GetNodeText(modelNode, "SimObjectName", "");

                model.RoiRow1 = GetNodeDouble(modelNode, "RoiRow1", 100.0);
                model.RoiCol1 = GetNodeDouble(modelNode, "RoiCol1", 100.0);
                model.RoiRow2 = GetNodeDouble(modelNode, "RoiRow2", 500.0);
                model.RoiCol2 = GetNodeDouble(modelNode, "RoiCol2", 500.0);

                model.IsoScaleMin = GetNodeDouble(modelNode, "IsoScaleMin", 0.98);
                model.IsoScaleMax = GetNodeDouble(modelNode, "IsoScaleMax", 1.01);

                model.DistanceRobot2Camera = GetNodeDouble(modelNode, "DistanceRobot2Camera", 356.0);
                model.ImageCenterCol = GetNodeDouble(modelNode, "ImageCenterCol", 1224.0);
                model.ImageCenterRow = GetNodeDouble(modelNode, "ImageCenterRow", 1024.0);

                model.PixelWSize = GetNodeDouble(modelNode, "PixelWSize", 0.0674);
                model.PixelLSize = GetNodeDouble(modelNode, "PixelLSize", 0.0604);

                model.NotRotatedGlassCenterX = GetNodeDouble(modelNode, "NotRotatedGlassCenterX", 0.0);
                model.NotRotatedGlassCenterY = GetNodeDouble(modelNode, "NotRotatedGlassCenterY", 0.0);

                model.PickZOffset = GetNodeDouble(modelNode, "PickZOffset", 0.0);
                model.CameraOffsetX = GetNodeDouble(modelNode, "CameraOffsetX", 0.0);
                model.CameraOffsetY = GetNodeDouble(modelNode, "CameraOffsetY", 0.0);
                model.CameraOffsetU = GetNodeDouble(modelNode, "CameraOffsetU", 0.0);
            }

            return model;
        }

        public static ProductModel LoadFromXmlFile(string xmlPath, string modelName)
        {
            if (!File.Exists(xmlPath))
            {
                Console.WriteLine("[警告] XML 檔案不存在: " + xmlPath);
                return new ProductModel { ModelName = modelName };
            }

            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(xmlPath);
                return LoadFromXml(doc, modelName);
            }
            catch (Exception ex)
            {
                Console.WriteLine("[錯誤] 讀取 XML 失敗: " + ex.Message);
                return new ProductModel { ModelName = modelName };
            }
        }

        private static string GetNodeText(XmlNode parentNode, string nodeName, string defaultValue)
        {
            if (parentNode == null) return defaultValue;
            XmlNode node = parentNode.SelectSingleNode(nodeName);
            if (node != null && !string.IsNullOrEmpty(node.InnerText))
            {
                return node.InnerText.Trim();
            }
            return defaultValue;
        }

        private static double GetNodeDouble(XmlNode parentNode, string nodeName, double defaultValue)
        {
            if (parentNode == null) return defaultValue;
            XmlNode node = parentNode.SelectSingleNode(nodeName);
            if (node != null && !string.IsNullOrEmpty(node.InnerText))
            {
                double val;
                if (double.TryParse(node.InnerText.Trim(), out val))
                {
                    return val;
                }
            }
            return defaultValue;
        }
    }
}