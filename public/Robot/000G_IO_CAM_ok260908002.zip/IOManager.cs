using System;
using System.IO;
using System.Text;
using System.Net.Sockets;
using System.Threading;
using System.Reflection;
using System.Runtime.InteropServices;

namespace EpsonRunner {
    public static class IOManager {
        public static bool UseRealDaq = false; 
        public static bool IsCommFault = false; 
        
        private static TcpClient ioClient; 
        private static NetworkStream ioStream;
        private static object daqDoCtrl; 
        private static object daqDiCtrl; 
        private static bool isDaqLoaded = false;
        
        private static MethodInfo diReadMethod = null;
        private static object[] diReadArgs = null;
        private static readonly object _ioLock = new object();

        private static string cachedIP = "127.0.0.1";
        private static int cachedPort = 5000;
        private static bool simulatedVacuumState = false;

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool SetDllDirectory(string lpPathName);

        private static string GetTimeTag() {
            return "[" + DateTime.Now.ToString("HH:mm:ss.fff") + "]";
        }

        public static void Initialize(string daqIP, int daqPort, string daqDllPath, string bioDaqDllPath, string daqDesignDllPath, string deviceDesc, string profilePath) {
            cachedIP = daqIP; 
            cachedPort = daqPort;
            IsCommFault = false; 
            
            Console.WriteLine("========== DAQ 硬體連線診斷 ==========");
            if (!UseRealDaq) {
                Console.WriteLine(GetTimeTag() + " [提示] 當前為 SIMULATION / 虛擬模式，研華實體卡跳過不載入。");
                Console.WriteLine("========================================\n");
                return;
            }

            if (File.Exists(daqDllPath)) {
                try {
                    if (File.Exists(bioDaqDllPath)) {
                        string bioDir = Path.GetDirectoryName(bioDaqDllPath);
                        if (!string.IsNullOrEmpty(bioDir)) SetDllDirectory(bioDir);
                    }
                    Assembly assembly = Assembly.LoadFrom(daqDllPath);
                    Type doType = assembly.GetType("Automation.BDaq.InstantDoCtrl");
                    Type diType = assembly.GetType("Automation.BDaq.InstantDiCtrl");
                    Type devInfoType = assembly.GetType("Automation.BDaq.DeviceInformation");

                    if (doType != null && diType != null && devInfoType != null) {
                        daqDoCtrl = Activator.CreateInstance(doType); 
                        daqDiCtrl = Activator.CreateInstance(diType);
                        GC.SuppressFinalize(daqDoCtrl); 
                        GC.SuppressFinalize(daqDiCtrl);
                        object devInfo = Activator.CreateInstance(devInfoType, new object[] { deviceDesc });
                        doType.GetProperty("SelectedDevice").SetValue(daqDoCtrl, devInfo, null);
                        diType.GetProperty("SelectedDevice").SetValue(daqDiCtrl, devInfo, null);
                        doType.GetMethod("LoadProfile", new Type[] { typeof(string) }).Invoke(daqDoCtrl, new object[] { profilePath });
                        diType.GetMethod("LoadProfile", new Type[] { typeof(string) }).Invoke(daqDiCtrl, new object[] { profilePath });
                        
                        diReadMethod = diType.GetMethod("Read", new Type[] { typeof(int), typeof(byte).MakeByRefType() });
                        diReadArgs = new object[] { 0, (byte)0 };

                        isDaqLoaded = true; 
                        Console.WriteLine(GetTimeTag() + " [成功] 研華實體 I/O 卡驅動加載成功！");
                    }
                } catch (Exception ex) { 
                    Console.WriteLine(GetTimeTag() + " [提示] 此處需要你提供資料 / 實體卡元件載入說明: " + ex.Message); 
                }
            } else {
                Console.WriteLine(GetTimeTag() + " [提示] 此處需要你提供資料: 找不到 DAQ DLL 檔案 " + daqDllPath);
            }
            Console.WriteLine("========================================\n");

            if (!ConnectSocketWithRetry()) {
                IsCommFault = true;
            }
        }

        private static bool ConnectSocketWithRetry() {
            if (ioClient != null) { try { ioClient.Close(); } catch { } }
            
            for (int retry = 1; retry <= 3; retry++) {
                try {
                    Console.Write(GetTimeTag() + " [網路] 嘗試建立 DAQ 連線 (第 " + retry + "/3 次)...");
                    ioClient = new TcpClient();
                    
                    ioClient.SendTimeout = 300;
                    ioClient.ReceiveTimeout = 300;
                    ioClient.NoDelay = true;

                    IAsyncResult result = ioClient.BeginConnect(cachedIP, cachedPort, null, null);
                    if (result.AsyncWaitHandle.WaitOne(500) && ioClient.Connected) {
                        ioStream = ioClient.GetStream();
                        ioStream.ReadTimeout = 300;
                        ioStream.WriteTimeout = 300;
                        Console.WriteLine(" 成功！");
                        return true;
                    }
                    Console.WriteLine(" 失敗");
                } catch { 
                    Console.WriteLine(" 拒絕"); 
                }
                if (retry < 3) Thread.Sleep(100); 
            }
            
            Console.WriteLine(GetTimeTag() + " [❌ 通訊錯誤] 連續 3 次連線失敗！");
            return false;
        }

        public static void SendCommand(string ioCmd) {
            if (ioCmd == "OPEN_VACUUM") simulatedVacuumState = true;
            else if (ioCmd == "CLOSE_VACUUM") simulatedVacuumState = false;

            if (!UseRealDaq) { 
                if (ioCmd.StartsWith("SET_ALARM_LIGHT")) {
                    Console.WriteLine("   " + GetTimeTag() + " [🚨 警報 I/O 觸發] 指令 ➔ " + ioCmd);
                } else {
                    Console.WriteLine("   " + GetTimeTag() + " [💻 虛擬 I/O 動作] 指令 ➔ " + ioCmd); 
                }
                return; 
            }

            if (IsCommFault) return;

            lock (_ioLock) {
                if (ioClient == null || !ioClient.Connected || ioStream == null) {
                    if (!ConnectSocketWithRetry()) {
                        IsCommFault = true; 
                        return;
                    }
                }

                try {
                    byte[] data = Encoding.ASCII.GetBytes(ioCmd + "\r\n"); 
                    ioStream.Write(data, 0, data.Length);

                    if (ioStream.DataAvailable) {
                        byte[] buffer = new byte[256]; 
                        int bytes = ioStream.Read(buffer, 0, buffer.Length);
                        string response = Encoding.ASCII.GetString(buffer, 0, bytes).Trim();
                        Console.WriteLine("   " + GetTimeTag() + " [🔌 實體 I/O 回應] 指令: " + ioCmd + " ➔ 狀態: " + response);
                    } else {
                        Console.WriteLine("   " + GetTimeTag() + " [🔌 實體 I/O 發送] 指令: " + ioCmd);
                    }
                } 
                catch (Exception ex) { 
                    Console.WriteLine("   " + GetTimeTag() + " [💥 通訊例外] 發送突發中斷: " + ex.Message);
                    try { if (ioClient != null) ioClient.Close(); } catch { }
                }
            }
        }

        public static bool IsVacuumOn() {
            if (UseRealDaq && isDaqLoaded && daqDiCtrl != null && diReadMethod != null) {
                try {
                    lock (_ioLock) {
                        diReadArgs[0] = 0;
                        diReadArgs[1] = (byte)0;
                        diReadMethod.Invoke(daqDiCtrl, diReadArgs);
                        byte portData = (byte)diReadArgs[1];
                        return (portData & 0x01) != 0;
                    }
                } catch { }
            }
            return simulatedVacuumState;
        }

        public static void Close() {
            try {
                if (ioStream != null) ioStream.Close(); 
                if (ioClient != null) ioClient.Close();
                if (isDaqLoaded && daqDoCtrl != null) {
                    daqDoCtrl.GetType().GetMethod("Dispose").Invoke(daqDoCtrl, null); 
                    daqDiCtrl.GetType().GetMethod("Dispose").Invoke(daqDiCtrl, null);
                }
            } catch { }
            finally { 
                try { SetDllDirectory(null); } catch { } 
            }
        }
    }
}