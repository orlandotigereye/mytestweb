using System;

namespace GlassDetection
{
    public interface IVisionRunner : IDisposable
    {
        double GlassCenterX { get; set; }
        double GlassCenterY { get; set; }
        double A_Offset { get; set; }

        double RobotCenterX { get; set; }
        double RobotCenterY { get; set; }
        double RobotCenterU { get; set; }
        double RobotCenterV { get; set; }
        double RobotCenterW { get; set; }

        void InitHalcon(string xmlPath, string activeModel);
        void InitHalcon();
        bool RunVisionSimulated(double simRobotX, double simRobotY, double simRobotU);
    }

    public class VirtualVisionRunner : IVisionRunner
    {
        public double GlassCenterX { get; set; }
        public double GlassCenterY { get; set; }
        public double A_Offset { get; set; }

        public double RobotCenterX { get; set; }
        public double RobotCenterY { get; set; }
        public double RobotCenterU { get; set; }
        public double RobotCenterV { get; set; }
        public double RobotCenterW { get; set; }

        private bool _disposed = false;

        public void InitHalcon(string xmlPath, string activeModel)
        {
            Console.WriteLine("[虛擬視覺] 初始化成功（使用模擬模式，免 HALCON 授權）。");
        }

        public void InitHalcon()
        {
            InitHalcon("EpsonConfig.xml", "Glass_310x320");
        }

        public bool RunVisionSimulated(double simRobotX, double simRobotY, double simRobotU)
        {
            RobotCenterX = simRobotX;
            RobotCenterY = simRobotY;
            RobotCenterU = simRobotU;

            // 模擬定位成功，加上微小誤差測試
            Random rnd = new Random();
            double mockOffsetX = (rnd.NextDouble() - 0.5) * 0.2; // +-0.1mm
            double mockOffsetY = (rnd.NextDouble() - 0.5) * 0.2;
            double mockOffsetA = (rnd.NextDouble() - 0.5) * 0.1; // +-0.05 deg

            GlassCenterX = simRobotX + mockOffsetX;
            GlassCenterY = simRobotY + mockOffsetY;
            A_Offset = mockOffsetA;

            Console.WriteLine(string.Format("[虛擬視覺] 模擬定位成功 -> X:{0:F3}, Y:{1:F3}, Angle:{2:F3}", GlassCenterX, GlassCenterY, A_Offset));
            return true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                _disposed = true;
            }
        }
    }
}