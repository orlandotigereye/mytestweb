using System;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Xml;
using GlassDetection;

namespace EpsonRunner
{
    public class VisionResult
    {
        public bool IsSuccess { get; set; }
        public double RobotTargetX { get; set; }
        public double RobotTargetY { get; set; }
        public double RobotTargetU { get; set; }
        public string ErrorMessage { get; set; }

        public VisionResult()
        {
            IsSuccess = false;
            RobotTargetX = 0.0;
            RobotTargetY = 0.0;
            RobotTargetU = 0.0;
            ErrorMessage = string.Empty;
        }
    }

    public static class VisionManager
    {
        private const int VISION_TIMEOUT_MS = 3000;

        private static TcpClient clientPersistent = null;
        private static NetworkStream streamPersistent = null;
        private static readonly object _visionLock = new object();
        private static string lastConnectedIp = "";
        private static int lastConnectedPort = 0;

        private static string GetTimeTag()
        {
            return "[" + DateTime.Now.ToString("HH:mm:ss.fff") + "]";
        }

        public static IVisionRunner CreateVisionRunner(string xmlPath)
        {
            bool useVirtual = true;

            if (File.Exists(xmlPath))
            {
                try
                {
                    XmlDocument doc = new XmlDocument();
                    doc.Load(xmlPath);
                    XmlNode node = doc.SelectSingleNode("//UseVirtualVision");
                    if (node != null && !string.IsNullOrEmpty(node.InnerText))
                    {
                        bool.TryParse(node.InnerText.Trim(), out useVirtual);
                    }
                }
                catch
                {
                    useVirtual = true;
                }
            }

            if (useVirtual)
            {
                Console.WriteLine("[系統資訊] 目前設定為【虛擬視覺模式】(不需 HALCON 授權)");
                return new VirtualVisionRunner();
            }
            else
            {
                Console.WriteLine("[系統資訊] 目前設定為【實體 HALCON 視覺模式】");
                return new RealArmVisionRunner();
            }
        }

        public static VisionResult ExecuteGlassDetection(WorkMode mode, ProductModel product, string cameraIp, int cameraPort)
        {
            string timeTag = GetTimeTag();
            Console.WriteLine("    " + timeTag + " [📷 視覺定位] 開始進行產品 [" + product.ModelName + "] 視覺定位取像...");

            VisionResult result = new VisionResult();

            if (mode == WorkMode.SIMULATION || mode == WorkMode.DRY_RUN)
            {
                Thread.Sleep(200);

                double rawX = 150.0;
                double rawY = 300.0;
                double rawU = 1.5;

                result.RobotTargetX = rawX + product.CameraOffsetX;
                result.RobotTargetY = rawY + product.CameraOffsetY;
                result.RobotTargetU = rawU + product.CameraOffsetU;
                result.IsSuccess = true;

                Console.WriteLine("    " + timeTag + " [📷 視覺成功] 計算目標手臂點位 ➔ X:" + result.RobotTargetX.ToString("F3") +
                                  " Y:" + result.RobotTargetY.ToString("F3") + " U:" + result.RobotTargetU.ToString("F3") + "°");
                return result;
            }

            lock (_visionLock)
            {
                try
                {
                    EnsurePersistentConnection(cameraIp, cameraPort);

                    while (streamPersistent.DataAvailable)
                    {
                        streamPersistent.ReadByte();
                    }

                    byte[] cmd = Encoding.ASCII.GetBytes("CMD_TRIG_LOCATE\r\n");
                    streamPersistent.Write(cmd, 0, cmd.Length);

                    string response = ReadLineWithTimeout(streamPersistent, VISION_TIMEOUT_MS);

                    if (string.IsNullOrEmpty(response))
                    {
                        throw new TimeoutException("相機回應超時或回傳空字串！");
                    }

                    string[] parts = response.Trim().Split(',');

                    double rx = 0;
                    double ry = 0;
                    double ru = 0;

                    if (parts.Length >= 3 &&
                        double.TryParse(parts[0], out rx) &&
                        double.TryParse(parts[1], out ry) &&
                        double.TryParse(parts[2], out ru))
                    {
                        result.RobotTargetX = rx + product.CameraOffsetX;
                        result.RobotTargetY = ry + product.CameraOffsetY;
                        result.RobotTargetU = ru + product.CameraOffsetU;
                        result.IsSuccess = true;

                        Console.WriteLine("    " + timeTag + " [📷 視覺成功] 計算目標手臂點位 ➔ X:" + result.RobotTargetX.ToString("F3") +
                                          " Y:" + result.RobotTargetY.ToString("F3") + " U:" + result.RobotTargetU.ToString("F3") + "°");
                    }
                    else
                    {
                        result.IsSuccess = false;
                        result.ErrorMessage = "相機回傳資料格式不符: " + response;
                    }
                }
                catch (Exception ex)
                {
                    result.IsSuccess = false;
                    result.ErrorMessage = "視覺定位異常/超時: " + ex.Message;
                    Console.WriteLine("    " + timeTag + " [💥 視覺超時/失敗] " + result.ErrorMessage);
                    CloseConnection();
                }
            }

            return result;
        }

        private static void EnsurePersistentConnection(string ip, int port)
        {
            if (clientPersistent != null && clientPersistent.Connected && lastConnectedIp == ip && lastConnectedPort == port)
            {
                return;
            }

            CloseConnection();

            clientPersistent = new TcpClient();
            clientPersistent.NoDelay = true;
            clientPersistent.SendTimeout = VISION_TIMEOUT_MS;
            clientPersistent.ReceiveTimeout = VISION_TIMEOUT_MS;

            IAsyncResult connectResult = clientPersistent.BeginConnect(ip, port, null, null);
            if (!connectResult.AsyncWaitHandle.WaitOne(VISION_TIMEOUT_MS))
            {
                CloseConnection();
                throw new TimeoutException("相機 TCP 連線超時 (" + VISION_TIMEOUT_MS + "ms)！");
            }

            clientPersistent.EndConnect(connectResult);
            streamPersistent = clientPersistent.GetStream();
            lastConnectedIp = ip;
            lastConnectedPort = port;
        }

        private static string ReadLineWithTimeout(NetworkStream stream, int timeoutMs)
        {
            StringBuilder sb = new StringBuilder();
            byte[] buffer = new byte[1];
            int elapsedTime = 0;
            int checkInterval = 10;

            while (elapsedTime < timeoutMs)
            {
                if (stream.DataAvailable)
                {
                    int bytesRead = stream.Read(buffer, 0, 1);
                    if (bytesRead > 0)
                    {
                        char c = (char)buffer[0];
                        if (c == '\n') break;
                        if (c != '\r') sb.Append(c);
                    }
                }
                else
                {
                    Thread.Sleep(checkInterval);
                    elapsedTime += checkInterval;
                }
            }

            return sb.ToString();
        }

        public static void CloseConnection()
        {
            try
            {
                if (streamPersistent != null)
                {
                    streamPersistent.Close();
                }
                if (clientPersistent != null)
                {
                    clientPersistent.Close();
                }
            }
            catch { }
            finally
            {
                streamPersistent = null;
                clientPersistent = null;
            }
        }
    }
}