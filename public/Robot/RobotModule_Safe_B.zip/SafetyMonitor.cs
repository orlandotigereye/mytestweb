using System;
using System.Threading;
using log4net;

namespace GlassDetection
{
    /// <summary>
    /// 安全監控器：背景執行緒持續監控急停、真空、區域限制
    /// </summary>
    public class SafetyMonitor : IDisposable
    {
        private static readonly ILog s_logger = LogManager.GetLogger(typeof(SafetyMonitor));
        private readonly EsponRobotControl _robot;
        private readonly DAQIOCtrl _io;
        private Thread _monitorThread;
        private bool _isRunning = false;
        private bool _isDisposed = false;

        // 事件
        public event EventHandler<EStopEventArgs> EStopTriggered;
        public event EventHandler<VacuumLostEventArgs> VacuumLost;
        public event EventHandler<ZoneViolationEventArgs> ZoneViolation;

        public bool IsEStopOn { get; private set; } = false;
        public bool IsMonitoring { get { lock (this) { return _isRunning; } } }

        public SafetyMonitor(EsponRobotControl robot, DAQIOCtrl io)
        {
            _robot = robot;
            _io = io;
        }

        public void Start()
        {
            lock (this)
            {
                if (_isRunning) return;
                _isRunning = true;
            }
            _monitorThread = new Thread(MonitorLoop)
            {
                IsBackground = true,
                Name = "SafetyMonitor",
                Priority = ThreadPriority.Highest
            };
            _monitorThread.Start();
            s_logger.Info("[SafetyMonitor] 安全監控已啟動");
        }

        public void Stop()
        {
            lock (this)
            {
                _isRunning = false;
            }
            _monitorThread?.Join(1000);
            s_logger.Info("[SafetyMonitor] 安全監控已停止");
        }

        private void MonitorLoop()
        {
            bool lastEStop = false;
            bool lastVacuum = false;
            RobotPosition lastPos = new RobotPosition();

            while (true)
            {
                lock (this) { if (!_isRunning || _isDisposed) break; }

                try
                {
                    // 1. 急停監控
                    bool estop = false;
                    if (_robot.GetEmergency(ref estop) == State.STATE_OK)
                    {
                        if (estop && !lastEStop)
                        {
                            IsEStopOn = true;
                            s_logger.Fatal("[急停] 急停按鈕被觸發！！");
                            EStopTriggered?.Invoke(this, new EStopEventArgs { IsPressed = true });
                        }
                        else if (!estop && lastEStop)
                        {
                            IsEStopOn = false;
                            s_logger.Info("[急停] 急停已解除");
                            EStopTriggered?.Invoke(this, new EStopEventArgs { IsPressed = false });
                        }
                        lastEStop = estop;
                    }

                    // 2. 真空流失監控（僅在移動中）
                    bool vacuum = false;
                    if (_io.GetVacuumEstablished(ref vacuum) == State.STATE_OK)
                    {
                        if (!vacuum && lastVacuum)
                        {
                            s_logger.Error("[真空] 真空訊號流失！可能掉片！");
                            VacuumLost?.Invoke(this, new VacuumLostEventArgs());
                        }
                        lastVacuum = vacuum;
                    }

                    // 3. 區域限制監控（簡易版）
                    var cur = new RobotPosition();
                    if (_robot.GetCurrentPosition(ref cur) == State.STATE_OK)
                    {
                        if (cur.Z < 50 && (Math.Abs(cur.X) > 1500 || Math.Abs(cur.Y) > 1500))
                        {
                            s_logger.Fatal($"[區域] 低高度大範圍移動！Z={cur.Z:F1} XY=({cur.X:F1},{cur.Y:F1})");
                            ZoneViolation?.Invoke(this, new ZoneViolationEventArgs 
                            { 
                                Message = "低高度大範圍移動",
                                CurrentPosition = cur 
                            });
                        }
                        lastPos = cur;
                    }
                }
                catch (Exception ex)
                {
                    s_logger.Error("[SafetyMonitor] 監控異常：" + ex.Message);
                }

                Thread.Sleep(50); // 20Hz 監控頻率
            }
        }

        public void Dispose()
        {
            lock (this)
            {
                _isDisposed = true;
                _isRunning = false;
            }
            Stop();
        }
    }

    public class EStopEventArgs : EventArgs
    {
        public bool IsPressed { get; set; }
    }

    public class VacuumLostEventArgs : EventArgs
    {
        public DateTime Time { get; set; } = DateTime.Now;
    }

    public class ZoneViolationEventArgs : EventArgs
    {
        public string Message { get; set; }
        public RobotPosition CurrentPosition { get; set; }
    }
}
