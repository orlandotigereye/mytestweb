using System;
using System.Collections.Generic;
using System.IO;

namespace GlassDetection
{
    /// <summary>
    /// 點位管理器：從 INI 載入所有點位，並進行安全檢查
    /// </summary>
    public class PositionManager
    {
        private Dictionary<string, RobotPosition> _positions = new Dictionary<string, RobotPosition>();
        private Dictionary<string, double> _workZs = new Dictionary<string, double>();

        // 安全限制（可根據機台調整）
        public double MinZ { get; set; } = 0;       // Z軸最低安全高度
        public double MaxZ { get; set; } = 1000;    // Z軸最高安全高度
        public double MaxXY { get; set; } = 2000;   // XY最大行程

        public void LoadFromIni(string iniPath)
        {
            if (!File.Exists(iniPath))
                throw new FileNotFoundException("找不到點位設定檔：" + iniPath);

            string currentName = "";
            var pos = new RobotPosition();
            double workZ = -9999;

            foreach (var raw in File.ReadAllLines(iniPath))
            {
                var line = raw.Trim();
                if (string.IsNullOrEmpty(line) || line.StartsWith(";")) continue;

                if (line.StartsWith("[") && line.EndsWith("]"))
                {
                    SaveCurrent(currentName, pos, workZ);
                    currentName = line.Substring(1, line.Length - 2);
                    pos = new RobotPosition();
                    workZ = -9999;
                }
                else if (line.Contains("="))
                {
                    var kv = line.Split('=');
                    var key = kv[0].Trim().ToUpper();
                    var val = kv[1].Trim();

                    switch (key)
                    {
                        case "X": pos.X = double.Parse(val); break;
                        case "Y": pos.Y = double.Parse(val); break;
                        case "Z": pos.Z = double.Parse(val); break;
                        case "U": pos.U = double.Parse(val); break;
                        case "V": pos.V = double.Parse(val); break;
                        case "W": pos.W = double.Parse(val); break;
                        case "WORKZ": workZ = double.Parse(val); break;
                    }
                }
            }
            SaveCurrent(currentName, pos, workZ);
        }

        private void SaveCurrent(string name, RobotPosition pos, double workZ)
        {
            if (string.IsNullOrEmpty(name)) return;

            // 安全檢查
            if (pos.Z < MinZ)
                throw new ArgumentException($"[安全警告] {name} 的 Z={pos.Z:F1} 低於安全下限 {MinZ:F1}！");
            if (pos.Z > MaxZ)
                throw new ArgumentException($"[安全警告] {name} 的 Z={pos.Z:F1} 超過安全上限 {MaxZ:F1}！");
            if (Math.Abs(pos.X) > MaxXY || Math.Abs(pos.Y) > MaxXY)
                throw new ArgumentException($"[安全警告] {name} 的 XY 超出行程限制！");
            if (workZ > -9999 && workZ > pos.Z)
                throw new ArgumentException($"[安全警告] {name} 的工作高度 WorkZ={workZ:F1} 高於安全高度 Z={pos.Z:F1}！");

            _positions[name] = pos;
            if (workZ > -9999) _workZs[name] = workZ;
        }

        public void Add(string name, RobotPosition pos, double workZ = -9999)
        {
            SaveCurrent(name, pos, workZ);
        }

        public RobotPosition Get(string name)
        {
            if (!_positions.ContainsKey(name))
                throw new KeyNotFoundException($"未定義的點位：{name}");
            return _positions[name];
        }

        public bool HasWorkZ(string name) => _workZs.ContainsKey(name);
        public double GetWorkZ(string name) => _workZs[name];
    }
}
