using System;
using System.Collections.Generic;
using System.Windows.Forms;
using log4net;

namespace GlassDetection
{
    /// <summary>
    /// 範例2：印刷線流程（狀態機 + 安全監控版）
    /// 適用場景：輸送帶取玻璃 → 對位平台 → 印刷機 → 輸送帶放片
    /// 特點：多站點、多段路徑，對應原本 EPSON 腳本邏輯
    /// 
    /// 【一般人要改的地方】
    /// 1. 改 IP 位址
    /// 2. 改速度數字
    /// 3. 改 .ini 檔名
    /// 4. 改 DefineSequence() 裡的點位名稱和順序
    /// </summary>
    public class Example2_PrintingLine
    {
        private static readonly ILog s_logger = LogManager.GetLogger(typeof(Example2_PrintingLine));
        private RobotModule _robot;
        private RobotStateMachine _sm;

        public void Run()
        {
            _robot = new RobotModule();
            _sm = new RobotStateMachine(_robot);

            _sm.StateChanged += (s, e) => 
                s_logger.Info($"[UI] 狀態：{e.OldState} → {e.NewState}");
            _sm.StepChanged += (s, e) => 
                s_logger.Info($"[UI] 步驟 {e.StepIndex + 1}/{e.TotalSteps}：{e.StepName}");
            _sm.ErrorOccurred += (s, e) => 
            {
                s_logger.Fatal($"[UI] 異常！{e.Message}");
                MessageBox.Show($"異常：{e.Message}\n步驟：{e.StepName}", "警報");
            };

            s_logger.Info("===== 範例2：印刷線流程 開始 =====");

            if (!_robot.Initialize("192.168.0.1", 5000))
            {
                MessageBox.Show("連線失敗", "錯誤");
                return;
            }
            if (!_robot.LoginAndServoOn()) return;

            _robot.SetSpeed(ptpSpeed: 100, linearSpeed: 100);
            _robot.LoadPositions("Positions_Printing.ini");

            // 【這裡是一般人要改的地方】
            var sequence = new List<SequenceStep>
            {
                // ===== 取玻璃 =====
                new SequenceStep("回 Home",            () => _robot.GoSafe("Home")),
                new SequenceStep("輸送帶等待位",      () => _robot.GoSafe("InputWaitHold")),
                new SequenceStep("去取得玻璃",        () => _robot.GoSafe("ToGetGlass")),
                new SequenceStep("吸取玻璃",          () => _robot.PickSafe("ToGetGlass")),
                new SequenceStep("回輸送帶等待位",    () => _robot.GoSafe("InputWaitHold")),

                // ===== 對位平台 =====
                new SequenceStep("對位平台等待位",    () => _robot.GoSafe("sideUpWaitHold")),
                new SequenceStep("對位平台放入位",    () => _robot.GoSafe("sideDown")),
                new SequenceStep("放置玻璃",          () => _robot.PlaceSafe("sideDown")),
                new SequenceStep("回對位平台等待位",  () => _robot.GoSafe("sideUpWaitHold")),

                // 模擬對位完成後重新吸取
                new SequenceStep("回到對位平台",      () => _robot.GoSafe("sideDown")),
                new SequenceStep("重新吸取",          () => _robot.PickSafe("sideDown")),
                new SequenceStep("回對位平台等待位",  () => _robot.GoSafe("sideUpWaitHold")),

                // ===== 印刷機路徑 =====
                new SequenceStep("印刷機中間點",      () => _robot.GoSafe("middlePoint")),
                new SequenceStep("印刷機中下點",      () => _robot.GoSafe("middlePointdw")),
                new SequenceStep("小印刷機待位",      () => _robot.GoSafe("smailPrintwaitup")),
                new SequenceStep("小印刷機放片位",    () => _robot.GoSafe("smallPrintwaitdw")),
                new SequenceStep("小印刷機放置",      () => _robot.PlaceSafe("smallPrintwaitdw")),
                new SequenceStep("回小印刷機待位",    () => _robot.GoSafe("smailPrintwaitup")),

                // 模擬印刷完成後取回
                new SequenceStep("回小印刷機放片位",  () => _robot.GoSafe("smallPrintwaitdw")),
                new SequenceStep("取回玻璃",          () => _robot.PickSafe("smallPrintwaitdw")),
                new SequenceStep("回小印刷機待位",    () => _robot.GoSafe("smailPrintwaitup")),

                // 回程
                new SequenceStep("回印刷機中下點",    () => _robot.GoSafe("middlePointdw")),
                new SequenceStep("回印刷機中間點",    () => _robot.GoSafe("middlePoint")),

                // ===== 放玻璃 =====
                new SequenceStep("放片區等待位",      () => _robot.GoSafe("PutWaitHold")),
                new SequenceStep("去放下玻璃",        () => _robot.GoSafe("ToPutGlass")),
                new SequenceStep("放置玻璃",          () => _robot.PlaceSafe("ToPutGlass")),
                new SequenceStep("回輸送帶等待位",    () => _robot.GoSafe("InputWaitHold")),
            };

            _sm.DefineSequence(sequence);
            _sm.Start();

            s_logger.Info("印刷線流程已在背景執行...");
            Console.ReadKey();
            _sm.Stop();
        }
    }
}
