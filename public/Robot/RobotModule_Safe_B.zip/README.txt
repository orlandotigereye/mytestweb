============================================================
RobotModule 安全版 v2.0
狀態機 + 到位確認 + 急停監控 + log4net
============================================================

本壓縮檔是「安全修正版」，解決了第一版的以下問題：
  ✓ Go() 不確認到位 → GoSafe() 會等待到位確認
  ✓ 沒有急停監控 → SafetyMonitor 背景執行緒 20Hz 監控
  ✓ 異常後繼續執行 → 狀態機自動進入 Error 狀態
  ✓ 缺少 log4net → 所有動作都有詳細 Log
  ✓ 無暫停/續跑 → StateMachine 支援 Pause/Resume
  ✓ 無復歸機制 → ResetToHome() 一鍵回 Home
  ✓ 無掉片偵測 → 移動中背景監控真空
  ✓ 點位無安全檢查 → PositionManager 載入時驗證 Z 值

============================================================
檔案說明
============================================================

【核心模組】（5個 .cs，所有範例共用）
  RobotPosition.cs      - 六軸座標結構
  PositionManager.cs    - INI 載入 + 安全檢查（Z值、行程限制）
  SafetyMonitor.cs      - 背景安全監控（急停/真空/區域）
  RobotModule.cs        - 高階機器人模組（GoSafe/PickSafe/PlaceSafe）
  RobotStateMachine.cs  - 狀態機核心（Pause/Resume/Error處理）

【範例1：基本取放】
  Example1_BasicPickPlace.cs   - 主程式
  Positions_Basic.ini          - 點位設定檔

【範例2：印刷線流程】
  Example2_PrintingLine.cs     - 主程式
  Positions_Printing.ini       - 點位設定檔

【範例3：玻璃檢測線】
  Example3_GlassInspection.cs  - 主程式
  Positions_Inspection.ini     - 點位設定檔

============================================================
使用方法
============================================================

1. 將「核心模組」5個 .cs 加入你的 GlassDetection 專案
2. 確認專案已引用 log4net（NuGet: Install-Package log4net）
3. 在 App.config 加入 log4net 設定（範例見下方）
4. 選擇一個範例，將其 .cs 與對應 .ini 加入專案
5. 修改 .ini 裡的 X/Y/Z/U/V/W 數值
6. 編譯執行

============================================================
一般人要改的地方（只有這些！）
============================================================

【改 IP 位址】
  _robot.Initialize("192.168.0.1", 5000);
  → 改成你的機器人 IP

【改速度】
  _robot.SetSpeed(ptpSpeed: 80, linearSpeed: 80);
  → 改數字即可

【改點位名稱和順序】
  在 DefineSequence() 裡：
    new SequenceStep("步驟名稱", () => _robot.GoSafe("點位名稱")),
  → 改 "點位名稱" 和順序即可

【改 .ini 檔名】
  _robot.LoadPositions("Positions_Basic.ini");
  → 改成你的 INI 檔名

【改 INI 裡的座標】
  用記事本開啟 .ini，改 X/Y/Z/U/V/W 數值

============================================================
主程式語法對照表
============================================================

C# 安全版寫法              對應 EPSON RC+ 語法
─────────────────────────────────────────────────────────
_robot.GoSafe("P0");       Go P0 + 等待到位 + 急停檢查
_robot.PickSafe("Pos");    Go Pos + 下降 + 開真空 + 等真空 + 上升
_robot.PlaceSafe("Pos");   Go Pos + 下降 + 關真空 + 吹氣 + 上升
_robot.MoveZSafe(500);     只改 Z 軸 + 等待到位
_sm.Start();               啟動流程（背景執行）
_sm.Pause();               暫停流程
_sm.Resume();              繼續流程
_sm.ResetToHome();         急停復歸：回 Home

============================================================
log4net App.config 設定範例
============================================================

<?xml version="1.0" encoding="utf-8"?>
<configuration>
  <configSections>
    <section name="log4net" type="log4net.Config.Log4NetConfigurationSectionHandler, log4net"/>
  </configSections>
  <log4net>
    <appender name="FileAppender" type="log4net.Appender.RollingFileAppender">
      <file value="Logs\RobotLog_"/>
      <appendToFile value="true"/>
      <rollingStyle value="Date"/>
      <datePattern value="yyyyMMdd'.log'"/>
      <layout type="log4net.Layout.PatternLayout">
        <conversionPattern value="%date [%thread] %-5level %logger - %message%newline"/>
      </layout>
    </appender>
    <root>
      <level value="DEBUG"/>
      <appender-ref ref="FileAppender"/>
    </root>
  </log4net>
</configuration>

並在 Program.cs 加入：
  [assembly: log4net.Config.XmlConfigurator(Watch = true)]

============================================================
安全功能說明
============================================================

1. 到位確認：GoSafe() 會持續查詢目前位置，與目標比對，
   在容差內（預設 0.5mm）才回傳成功。

2. 急停監控：SafetyMonitor 以 20Hz 頻率背景監控急停訊號，
   一旦觸發，所有移動命令立即停止，狀態機進入 Error。

3. 真空流失偵測：移動過程中若真空訊號消失，會記錄 Error Log。

4. 區域限制：低高度（Z<50）時不允許大範圍 XY 移動，防止撞機。

5. 點位安全檢查：載入 INI 時自動檢查：
   - Z 不可為負值
   - WorkZ 必須低於安全高度 Z
   - XY 不可超過行程限制

6. 狀態機保護：
   - 關鍵步驟失敗 → 進入 Error，停止流程
   - 非關鍵步驟失敗 → 記錄警告，繼續執行
   - 支援 Pause/Resume/ResetToHome

============================================================
