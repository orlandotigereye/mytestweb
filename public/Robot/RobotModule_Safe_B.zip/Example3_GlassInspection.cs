using System;
using System.Collections.Generic;
using System.Windows.Forms;
using log4net;

namespace GlassDetection
{
    /// <summary>
    /// 範例3：玻璃檢測線（狀態機 + 安全監控 + CCD/AOI 整合版）
    /// 適用場景：取玻璃 → CCD 定位拍照 → 邊緣檢測 → OK/NG 分類
    /// 特點：整合視覺定位與 AOI 檢測，對應原本 GlassDetection 專案
    /// 
    /// 【一般人要改的地方】
    /// 1. 改 IP 位址
    /// 2. 改速度數字
    /// 3. 改 .ini 檔名
    /// 4. 改 DefineSequence() 裡的點位名稱和順序
    /// 5. 改 IsGlassOK 的判斷邏輯（連接你的 AOI 演算法）
    /// </summary>
    public class Example3_GlassInspection
    {
        private static readonly ILog s_logger = LogManager.GetLogger(typeof(Example3_GlassInspection));
        private RobotModule _robot;
        private RobotStateMachine _sm;
        private bool _isGlassOK = true;  // AOI 檢測結果，實際由演算法決定

        public void Run()
        {
            _robot = new RobotModule();
            _sm = new RobotStateMachine(_robot);

            _sm.StateChanged += (s, e) => 
                s_logger.Info($"[UI] 狀態：{e.OldState} → {e.NewState}");
            _sm.StepChanged += (s, e) => 
                s_logger.Info($"[UI] 步驟 {e.StepIndex + 1}/{e.TotalSteps}：{e.StepName}");
            _sm.ErrorOccurred += (s, e) => 
            {
                s_logger.Fatal($"[UI] 異常！{e.Message}");
                MessageBox.Show($"異常：{e.Message}", "警報");
            };

            s_logger.Info("===== 範例3：玻璃檢測線 開始 =====");

            if (!_robot.Initialize("192.168.0.1", 5000))
            {
                MessageBox.Show("連線失敗", "錯誤");
                return;
            }
            if (!_robot.LoginAndServoOn()) return;

            _robot.SetSpeed(ptpSpeed: 65, linearSpeed: 1200, acc: 20, dec: 20, lineAcc: 1400, lineDec: 1400);
            _robot.LoadPositions("Positions_Inspection.ini");

            // 【這裡是一般人要改的地方】
            var sequence = new List<SequenceStep>
            {
                // 1. 回 Home 並等待玻璃到達
                new SequenceStep("回 Home",          () => _robot.GoSafe("Home")),
                new SequenceStep("等待位",           () => _robot.GoSafe("HoldPoint")),

                // 2. 等待玻璃到達（左側感測器）
                new SequenceStep("等待玻璃到達",     () => _robot.WaitGlassArrived(0, 10000)),

                // 3. 移動到拍照位進行 CCD 定位
                new SequenceStep("左側拍照位",       () => _robot.GoSafe("LeftTakePicture")),
                new SequenceStep("等待穩定",         () => { _robot.Wait(2500); return true; }),
                new SequenceStep("CCD定位拍照",      () => RunCCDLocate()),

                // 4. 移動到修正後的玻璃中心
                new SequenceStep("玻璃中心",         () => _robot.GoSafe("GlassCenter")),
                new SequenceStep("吸取高度1",        () => _robot.MoveZSafe(318)),
                new SequenceStep("吸取高度2",        () => _robot.MoveZSafe(305)),
                new SequenceStep("開真空",           () => _robot.VacuumOn()),
                new SequenceStep("等待真空",         () => _robot.WaitVacuum(3000)),

                // 5. 提起並移動到檢測區
                new SequenceStep("提起安全高度",     () => _robot.MoveZSafe(530)),
                new SequenceStep("經過中間點",       () => _robot.GoSafe("Home")),

                // 6. AOI 檢測第一位置
                new SequenceStep("檢測位置1",        () => _robot.GoSafe("InspectPos1")),
                new SequenceStep("檢測1-左邊緣",     () => RunAOI(CCD.Left)),
                new SequenceStep("檢測1-右邊緣",     () => RunAOI(CCD.Right)),

                // 7. AOI 檢測第二位置
                new SequenceStep("檢測位置2",        () => _robot.GoSafe("InspectPos2")),
                new SequenceStep("檢測2-左邊緣",     () => RunAOI(CCD.Left)),
                new SequenceStep("檢測2-右邊緣",     () => RunAOI(CCD.Right)),

                // 8. AOI 檢測第三位置
                new SequenceStep("檢測位置3",        () => _robot.GoSafe("InspectPos3")),
                new SequenceStep("檢測3-左邊緣",     () => RunAOI(CCD.Left)),
                new SequenceStep("檢測3-右邊緣",     () => RunAOI(CCD.Right)),

                // 9. 根據檢測結果分類放置
                new SequenceStep("判斷OK/NG",        () => CheckInspectionResult()),
                new SequenceStep("OK-安全點",        () => _isGlassOK ? _robot.GoSafe("OKSafePoint") : true, isCritical: false),
                new SequenceStep("OK-輸送帶",        () => _isGlassOK ? _robot.GoSafe("OKConveyor") : true, isCritical: false),
                new SequenceStep("OK-放置",          () => _isGlassOK ? _robot.PlaceSafe("OKConveyor") : true, isCritical: false),
                new SequenceStep("OK-回安全點",      () => _isGlassOK ? _robot.GoSafe("OKSafePoint") : true, isCritical: false),
                new SequenceStep("NG-安全點",        () => !_isGlassOK ? _robot.GoSafe("NGSafePoint") : true, isCritical: false),
                new SequenceStep("NG-輸送帶",        () => !_isGlassOK ? _robot.GoSafe("NGConveyor") : true, isCritical: false),
                new SequenceStep("NG-放置",          () => !_isGlassOK ? _robot.PlaceSafe("NGConveyor") : true, isCritical: false),
                new SequenceStep("NG-回安全點",      () => !_isGlassOK ? _robot.GoSafe("NGSafePoint") : true, isCritical: false),

                // 10. 回到等待位
                new SequenceStep("回等待位",         () => _robot.GoSafe("HoldPoint")),
            };

            _sm.DefineSequence(sequence);
            _sm.Start();

            s_logger.Info("檢測線流程已在背景執行...");
            Console.ReadKey();
            _sm.Stop();
        }

        /// <summary>執行 CCD 定位（請在此整合你的 Halcon 演算法）</summary>
        private bool RunCCDLocate()
        {
            s_logger.Info("[CCD] 執行定位拍照...");
            // 實際整合：
            // HObject image;
            // _camera.GetImageBuffer(...);
            // _locateGlass.RunHalcon(_window, image);
            // _glassCenterPosition.X = _locateGlass.GlassCenterX;
            // ...
            _robot.Wait(500); // 模擬拍照時間
            s_logger.Info("[CCD] 定位完成");
            return true;
        }

        /// <summary>執行 AOI 檢測（請在此整合你的 Halcon 演算法）</summary>
        private bool RunAOI(CCD side)
        {
            s_logger.Info($"[AOI] 檢測 {side} 邊緣...");
            // 實際整合：
            // _glassChipInspect.RunHalcon(_window, image, side);
            // if (!result) _isGlassOK = false;
            _robot.Wait(side == CCD.Left ? 120 : 70);
            s_logger.Info($"[AOI] {side} 檢測完成");
            return true;
        }

        /// <summary>檢查 AOI 總結果</summary>
        private bool CheckInspectionResult()
        {
            s_logger.Info($"[AOI] 總結果：{(_isGlassOK ? "OK" : "NG")}");
            // 實際應根據前面三次 AOI 結果綜合判斷
            return true;
        }
    }

    // AOI 側邊定義（與原始專案一致）
    public enum CCD { Left, Right }
}
