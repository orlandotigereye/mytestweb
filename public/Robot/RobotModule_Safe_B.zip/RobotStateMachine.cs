using System;
using System.Collections.Generic;
using System.Threading;
using log4net;

namespace GlassDetection
{
    /// <summary>
    /// 機器人狀態機：管理整個生產流程的狀態轉換
    /// 異常時自動進入 Error 狀態，可選擇復歸或回 Home
    /// </summary>
    public class RobotStateMachine
    {
        private static readonly ILog s_logger = LogManager.GetLogger(typeof(RobotStateMachine));
        private RobotModule _robot;
        private RobotState _state = RobotState.Idle;
        private int _currentStep = 0;
        private List<SequenceStep> _sequence = new List<SequenceStep>();
        private bool _isPaused = false;
        private bool _isRunning = false;
        private Thread _runThread;

        public RobotState CurrentState => _state;
        public int CurrentStep => _currentStep;
        public bool IsPaused => _isPaused;
        public bool IsRunning => _isRunning;
        public int TotalSteps => _sequence.Count;

        // 事件
        public event EventHandler<StateChangedEventArgs> StateChanged;
        public event EventHandler<StepChangedEventArgs> StepChanged;
        public event EventHandler<SequenceCompletedEventArgs> SequenceCompleted;
        public event EventHandler<ErrorEventArgs> ErrorOccurred;

        public RobotStateMachine(RobotModule robot)
        {
            _robot = robot;
        }

        /// <summary>
        /// 定義流程步驟。一般人只要改這裡的順序和點位名稱！
        /// </summary>
        public void DefineSequence(List<SequenceStep> steps)
        {
            _sequence = steps ?? new List<SequenceStep>();
            s_logger.Info($"[狀態機] 流程已定義，共 {steps.Count} 步");
        }

        /// <summary>啟動流程（在背景執行緒執行）</summary>
        public void Start()
        {
            if (_isRunning) return;
            if (_sequence.Count == 0)
            {
                s_logger.Error("[狀態機] 流程未定義，無法啟動");
                return;
            }

            _isRunning = true;
            _isPaused = false;
            _currentStep = 0;
            ChangeState(RobotState.Running);

            _runThread = new Thread(RunLoop)
            {
                IsBackground = true,
                Name = "StateMachine"
            };
            _runThread.Start();
            s_logger.Info("[狀態機] 流程已啟動");
        }

        /// <summary>暫停流程</summary>
        public void Pause()
        {
            if (!_isRunning) return;
            _isPaused = true;
            ChangeState(RobotState.Paused);
            s_logger.Info("[狀態機] 流程已暫停");
        }

        /// <summary>繼續流程</summary>
        public void Resume()
        {
            if (!_isRunning || !_isPaused) return;
            _isPaused = false;
            ChangeState(RobotState.Running);
            s_logger.Info("[狀態機] 流程已繼續");
        }

        /// <summary>停止流程</summary>
        public void Stop()
        {
            _isRunning = false;
            _isPaused = false;
            ChangeState(RobotState.Stopped);
            s_logger.Info("[狀態機] 流程已停止");
        }

        /// <summary>急停後復歸：回 Home 並回到 Idle</summary>
        public bool ResetToHome()
        {
            s_logger.Info("[狀態機] 執行復歸...");
            ChangeState(RobotState.Homing);

            try
            {
                // 先回安全高度
                _robot.MoveZSafe(700);
                // 回 Home
                _robot.GoSafe("Home");
                _currentStep = 0;
                ChangeState(RobotState.Idle);
                s_logger.Info("[狀態機] 復歸完成");
                return true;
            }
            catch (Exception ex)
            {
                s_logger.Error("[狀態機] 復歸失敗：" + ex.Message);
                ChangeState(RobotState.Error);
                return false;
            }
        }

        /// <summary>從指定步驟重新開始（斷電續跑用）</summary>
        public void RestartFromStep(int stepIndex)
        {
            if (stepIndex < 0 || stepIndex >= _sequence.Count)
            {
                s_logger.Error($"[狀態機] 步驟索引 {stepIndex} 超出範圍");
                return;
            }
            _currentStep = stepIndex;
            s_logger.Info($"[狀態機] 將從第 {stepIndex + 1} 步重新開始");
            Start();
        }

        private void RunLoop()
        {
            while (_isRunning)
            {
                if (_isPaused)
                {
                    Thread.Sleep(100);
                    continue;
                }

                if (_currentStep >= _sequence.Count)
                {
                    // 流程完成
                    s_logger.Info("[狀態機] 流程全部完成");
                    SequenceCompleted?.Invoke(this, new SequenceCompletedEventArgs { TotalCycles = 1 });
                    _currentStep = 0; // 自動循環
                    Thread.Sleep(500);
                    continue;
                }

                var step = _sequence[_currentStep];
                StepChanged?.Invoke(this, new StepChangedEventArgs
                {
                    StepIndex = _currentStep,
                    StepName = step.Name,
                    TotalSteps = _sequence.Count
                });

                try
                {
                    s_logger.Info($"[狀態機] 執行步驟 [{_currentStep + 1}/{_sequence.Count}] {step.Name}");
                    bool result = step.Action();

                    if (!result)
                    {
                        // 步驟失敗
                        s_logger.Error($"[狀態機] 步驟失敗：{step.Name}");
                        if (step.IsCritical)
                        {
                            // 關鍵步驟失敗 → 進入 Error
                            ChangeState(RobotState.Error);
                            ErrorOccurred?.Invoke(this, new ErrorEventArgs
                            {
                                StepIndex = _currentStep,
                                StepName = step.Name,
                                Message = $"關鍵步驟失敗：{step.Name}"
                            });
                            _isRunning = false;
                            break;
                        }
                        else
                        {
                            // 非關鍵步驟失敗 → 記錄警告但繼續
                            s_logger.Warn($"[狀態機] 非關鍵步驟失敗，繼續執行：{step.Name}");
                        }
                    }

                    _currentStep++;
                }
                catch (Exception ex)
                {
                    s_logger.Fatal($"[狀態機] 步驟異常：{step.Name} - {ex.Message}");
                    ChangeState(RobotState.Error);
                    ErrorOccurred?.Invoke(this, new ErrorEventArgs
                    {
                        StepIndex = _currentStep,
                        StepName = step.Name,
                        Message = ex.Message,
                        Exception = ex
                    });
                    _isRunning = false;
                    break;
                }

                Thread.Sleep(10);
            }

            if (_state != RobotState.Error)
            {
                ChangeState(RobotState.Idle);
            }
        }

        private void ChangeState(RobotState newState)
        {
            var oldState = _state;
            _state = newState;
            s_logger.Info($"[狀態機] 狀態變更：{oldState} → {newState}");
            StateChanged?.Invoke(this, new StateChangedEventArgs
            {
                OldState = oldState,
                NewState = newState
            });
        }
    }

    // ==================== 資料結構 ====================

    public enum RobotState
    {
        Idle,       // 待命
        Running,    // 執行中
        Paused,     // 暫停
        Stopped,    // 已停止
        Homing,     // 復歸中
        Error       // 異常
    }

    public class SequenceStep
    {
        /// <summary>步驟名稱（顯示用）</summary>
        public string Name { get; set; }
        /// <summary>執行動作，回傳 true=成功, false=失敗</summary>
        public Func<bool> Action { get; set; }
        /// <summary>是否為關鍵步驟（失敗會進入 Error）</summary>
        public bool IsCritical { get; set; } = true;

        public SequenceStep(string name, Func<bool> action, bool isCritical = true)
        {
            Name = name;
            Action = action;
            IsCritical = isCritical;
        }
    }

    public class StateChangedEventArgs : EventArgs
    {
        public RobotState OldState { get; set; }
        public RobotState NewState { get; set; }
    }

    public class StepChangedEventArgs : EventArgs
    {
        public int StepIndex { get; set; }
        public string StepName { get; set; }
        public int TotalSteps { get; set; }
    }

    public class SequenceCompletedEventArgs : EventArgs
    {
        public int TotalCycles { get; set; }
    }

    public class ErrorEventArgs : EventArgs
    {
        public int StepIndex { get; set; }
        public string StepName { get; set; }
        public string Message { get; set; }
        public Exception Exception { get; set; }
    }
}
