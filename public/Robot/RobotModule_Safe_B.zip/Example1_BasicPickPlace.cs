using System;
using System.Collections.Generic;
using System.Windows.Forms;
using log4net;

namespace GlassDetection
{
    /// <summary>
    /// 範例1：基本取放流程（狀態機 + 安全監控版）
    /// 適用場景：單純從 A 點吸取玻璃，放到 B 點
    /// 特點：最簡單、最安全，適合入門
    /// 
    /// 【一般人要改的地方】
    /// 1. 改 IP 位址
    /// 2. 改速度數字
    /// 3. 改 .ini 檔名
    /// 4. 改 DefineSequence() 裡的點位名稱和順序
    /// </summary>
    public class Example1_BasicPickPlace
    {
        private static readonly ILog s_logger = LogManager.GetLogger(typeof(Example1_BasicPickPlace));
        private RobotModule _robot;
        private RobotStateMachine _sm;

        public void Run()
        {
            _robot = new RobotModule();
            _sm = new RobotStateMachine(_robot);

            // 訂閱事件（可選，用於 UI 顯示）
            _sm.StateChanged += (s, e) => 
                s_logger.Info($"[UI] 狀態變更：{e.OldState} → {e.NewState}");
            _sm.StepChanged += (s, e) => 
                s_logger.Info($"[UI] 步驟 {e.StepIndex + 1}/{e.TotalSteps}：{e.StepName}");
            _sm.ErrorOccurred += (s, e) => 
                s_logger.Fatal($"[UI] 異常！步驟 {e.StepName}：{e.Message}");

            // ========== 1. 連線與啟動 ==========
            s_logger.Info("===== 範例1：基本取放 開始 =====");
            if (!_robot.Initialize("192.168.0.1", 5000)) 
            {
                MessageBox.Show("連線失敗，請檢查網路與機器人電源", "錯誤");
                return;
            }
            if (!_robot.LoginAndServoOn()) return;

            // ========== 2. 速度設定 ==========
            _robot.SetSpeed(ptpSpeed: 80, linearSpeed: 80);

            // ========== 3. 載入點位 ==========
            _robot.LoadPositions("Positions_Basic.ini");

            // ========== 4. 定義流程 ==========
            // 【這裡是一般人要改的地方】
            // 只要改 GoSafe("點位名稱") 和 PickSafe/PlaceSafe 的順序即可
            var sequence = new List<SequenceStep>
            {
                new SequenceStep("回 Home",       () => _robot.GoSafe("Home")),
                new SequenceStep("輸送帶等待位",   () => _robot.GoSafe("InputWait")),
                new SequenceStep("移動到吸取位",   () => _robot.GoSafe("PickPos")),
                new SequenceStep("吸取玻璃",      () => _robot.PickSafe("PickPos")),
                new SequenceStep("回輸送帶等待位", () => _robot.GoSafe("InputWait")),
                new SequenceStep("放片區等待位",   () => _robot.GoSafe("OutputWait")),
                new SequenceStep("移動到放置位",   () => _robot.GoSafe("PlacePos")),
                new SequenceStep("放置玻璃",      () => _robot.PlaceSafe("PlacePos")),
                new SequenceStep("回放片區等待位", () => _robot.GoSafe("OutputWait")),
                new SequenceStep("回 Home",       () => _robot.GoSafe("Home")),
            };

            _sm.DefineSequence(sequence);

            // ========== 5. 啟動流程（背景執行）==========
            _sm.Start();

            // 主執行緒保持運作，實際 UI 程式可用 Timer 監控狀態
            s_logger.Info("流程已在背景執行，按任意鍵停止...");
            Console.ReadKey();
            _sm.Stop();
        }
    }
}
