# Model Rigging Checklist for Automation | 自動化錄影模型綁定檢核表

Follow these tips to ensure your model looks perfect when using the **Live2D Portfolio Master**.
遵循這些建議，確保您的模型在使用 **Live2D 作品集大師** 時呈現完美效果。

---

## 1. Parameter Naming | 參數命名規範
- [ ] **Standard IDs**: Use official Live2D parameter IDs (e.g., `ParamAngleX`, `ParamEyeBallY`).
- [ ] **官方 ID**：使用官方標準參數 ID（如 `ParamAngleX`）。
- [ ] **Consistency**: Ensure left/right naming follows the `L`/`R` suffix standard for smooth mirroring.
- [ ] **一致性**：確保左右命名遵循 `L`/`R` 字尾標準，以實現順暢的鏡像動作。

---

## 2. Physics Optimization | 物理效果優化
- [ ] **Stable FPS**: Set your physics to calculate at **60 FPS** in the Cubism Editor, even though we record at 12 FPS.
- [ ] **穩定幀率**：即使我們以 12 FPS 錄製，請在 Cubism 編輯器中將物理運算設為 **60 FPS**。
- [ ] **Damping & Friction**: Increase damping slightly to prevent "jitter" during slow-motion capture.
- [ ] **阻尼與摩擦力**：稍微增加阻尼，以防止在慢動作擷取時出現「抖動」。

---

## 3. Expressions & Motions | 表情與動作設定
- [ ] **Named Expressions**: Use clear names for `.exp3.json` files (e.g., `angry`, `joy`, `blush`).
- [ ] **命名表情**：為 `.exp3.json` 檔案使用清晰的名稱（如 `angry`, `joy`, `blush`）。
- [ ] **Transition Time**: Set expression transition time to **0.5s** for a natural look.
- [ ] **轉場時間**：將表情轉場時間設為 **0.5秒**，外觀會最自然。

---

## 4. Texture Atlas | 紋理圖集
- [ ] **Resolution**: Keep the texture atlas under **4096x4096px** for browser compatibility.
- [ ] **解析度**：為了瀏覽器相容性，紋理圖集請保持在 **4096x4096px** 以內。
- [ ] **Bleeding**: Ensure enough padding between parts to avoid white edges during high-res recording.
- [ ] **溢色處理**：確保部件之間有足夠間距，避免在高解析度錄影時出現白邊。

---

## 🚀 Pro Tip | 專家建議
Test your model in the **L09 Template** early in the rigging process to see how the automated camera handles your character's height and width.

-----

*Created by Project Assistant on 2026-01-06*
