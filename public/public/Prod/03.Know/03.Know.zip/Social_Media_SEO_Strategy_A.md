# Social Media SEO & Discovery Strategy | 社群媒體 SEO 與發現策略

How to make your videos show up when people search for Live2D solutions.
如何讓您的影片在人們搜尋 Live2D 解決方案時出現。

---

## 🔍 1. High-Value Keywords | 高價值關鍵字
Include these in your Video Titles and the first 2 lines of your description.
將這些關鍵字放入影片標題與描述的前兩行。

**Primary Keywords (核心詞)**:
- Live2D Recording (Live2D 錄影)
- VTuber Showcase (VTuber 展示影片)
- Auto-record Live2D (自動錄製 Live2D)
- Smooth Physics Showcase (平滑物理效果展示)

**Problem Keywords (問題詞)**:
- Fix Live2D lag (修復 Live2D 卡頓)
- OBS lag Live2D (OBS 錄製 Live2D 延遲)
- Fast Live2D portfolio (快速製作 Live2D 作品集)

---

## 📝 2. Description Template (YouTube/TikTok) | 描述模板
Use this structure to help the algorithm understand your video.
使用此結構幫助演算法理解您的影片。

"Struggling with **Live2D recording lag**? In this video, I show you how to **auto-record Live2D showcases** using a simple Google Sheet script. 

This method ensures **smooth physics** and a clean, UI-free view for your **VTuber portfolio**. 

✅ Download the tool: [Gumroad Link]
✅ Rigging Checklist: [Link to Bento.me]

#Live2D #VTuberAssets #Live2DRigging"

---

## 🖼️ 3. Meta-Data & Alt-Text | 標籤與替代文字
- **Alt-Text (IG/X)**: Always add a description to your images.
- **Example**: "A smooth Live2D character animation recorded automatically using the Portfolio Master tool."
- **行動**：為圖片加入替代文字，描述影片內容以增加搜尋權重。

---

## 🚀 Pro Tip | 專家建議
The first 48 hours are crucial. When you post a YouTube video, use the "First Comment" to link to your Bento.me page and pin it. This drives traffic while boosting the video's engagement score.

-----

*Created by Project Assistant on 2026-01-06*
