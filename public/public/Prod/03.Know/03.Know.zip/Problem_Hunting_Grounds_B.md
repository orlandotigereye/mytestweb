# Where to Find People's Problems?

## 1. Reddit: The World's Hub for Frustrations
Search in these specific subreddits:
- **r/VTuber**: Where creators hang out. They often rant about long production times.
- **r/Live2D**: A technical hub where people ask "Why is my recording failing?"
- **r/SideHustle**: A place to see how others are trying to make money and what tools they need.

## 2. YouTube: The Educational Goldmine
Find the top "Live2D Tutorial" videos.
- **The Comments are Key**: People often post their failures or difficulties in the comments section. 
- If someone says, "I wish there was an easier way," that is a direct invitation for your product.

## 3. Twitter (X): The Rant Platform
Use the search bar with these tags:
- `#Live2D` + "tedious"
- `#VTuber` + "recording issue"
- Search for the word "exhausting" or "annoying" next to Live2D keywords.

## 4. Key Takeaway: Don't Just Browse, Engage
- When you find a problem, don't just take a note. 
- **Reply**. A helpful comment is the most powerful "ad" you can ever create.
- Say: "I had the same problem, so I built this tool to automate it. Want to try it?"

-----

# 去哪裡找別人的問題？

## 1. Reddit：全球最大的痛苦聚集地
在這些特定的討論區搜尋：
- **r/VTuber**：創作者聚集地。他們經常抱怨製作時間太長。
- **r/Live2D**：技術中心，人們會在這裡問：「為什麼我的錄影失敗了？」
- **r/SideHustle**：看看別人如何嘗試賺錢以及他們需要什麼工具。

## 2. YouTube：教學影片的金礦
尋找排名靠前的 "Live2D Tutorial" 影片。
- **評論是關鍵**：人們經常在評論區發布他們的失敗或遇到的困難。
- 如果有人說：「我希望有更簡單的方法」，那這就是對你產品的直接邀請。

## 3. Twitter (X)：抱怨平台
使用搜尋列搭配這些標籤：
- `#Live2D` + "tedious" (乏味)
- `#VTuber` + "recording issue" (錄影問題)
- 在 Live2D 關鍵字旁邊搜尋 "exhausting" (精疲力竭) 或 "annoying" (煩人) 等詞彙。

## 4. 核心重點：不要只是看，要參與互動
- 當你發現問題時，不要只是做筆記。
- **回覆**。一條有幫助的評論是你所能創造的最強大的「廣告」。
- 試著說：「我也遇到過同樣的問題，所以我做了一個工具來自動化。你想試試看嗎？」
