# Lead Magnet Creation Guide | 誘餌產品製作指南

How to build a massive Email list by giving away "Free Value."
如何透過贈送「免費價值」來建立龐大的 Email 清單。

---

## 🎁 1. What is a Lead Magnet? | 什麼是誘餌產品？
It is a free gift you offer in exchange for an Email. It must solve a **specific, small problem** quickly.
這是一個用來換取 Email 的免費禮物。它必須能快速解決一個**具體的、微小的問題**。

---

## 🎁 2. Top 3 Ideas for your Project | 三大誘餌產品提案

### A. The "Instant Setup" Mini-Course
- **What**: A 3-minute screen recording showing exactly how to set up the Portfolio Master.
- **Why**: Removes the "it looks complicated" fear.
- **提案**：「快速設定」微課程。一段 3 分鐘的螢幕錄影，展示如何設定工具。

### B. The "5 Pro Scenes" Background Pack
- **What**: A zip file of 5 high-quality, 4K backgrounds optimized for Live2D models.
- **Why**: Artists always need beautiful backgrounds for their showcases.
- **提案**：「5 款專業場景」背景包。針對 Live2D 優化的高品質背景圖。

### C. The "Perfect Script" Library
- **What**: 10 pre-written Google Sheet lines for different vibes (Happy, Cool, Tsundere).
- **Why**: Saves the user from having to think of what to write for their first test.
- **提案**：「完美劇本」庫。包含 10 組針對不同個性的預設台詞。

---

## 🚀 3. How to Deliver it | 如何交付
1. **Gumroad**: List it as a "$0" product.
2. **Bento.me**: Add a large button: "Get the Free Background Pack 📥".
3. **Action**: After they download, your **Email Nurture Sequence** starts automatically.

---

## 💡 Pro Tip | 專家建議
The best lead magnet is the one that makes your paid product look like the "next natural step." (例如：送了背景包，使用者自然會想用你的工具來錄影)。

-----

*Created by Project Assistant on 2026-01-06*
