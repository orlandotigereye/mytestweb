# Google Sheets Scripting Guide | Google 表格劇本編寫指南

This guide explains how to format your Google Sheet so the **Live2D Auto-Recorder** can read it correctly.
本指南說明如何格式化您的 Google 表格，以便 **Live2D 自動錄影機器人** 能正確讀取。

---

## 1. Sheet Setup | 表格設定
1. **Create a new Sheet**: Use Google Sheets. (建立新表格)
2. **First Row (Headers)**: The first row is ignored. You can use it for labels like "Role," "Text," etc. (第一列標題會被忽略)
3. **Privacy**: Ensure the sheet is set to **"Anyone with the link can view"**. (確保設定為「知道連結的人均可查看」)

---

## 2. Column Format | 欄位格式

### For Solo Mode (K09 / L09) | 單人模式
| Column A (Role) | Column B (Text) |
| :--- | :--- |
| Character | Hello everyone! Welcome to my channel. |
| Character | Today, I want to show you something cool. |

### For Duo Mode (F版 / C版) | 雙人模式
| Column A (Role) | Column B (Text) | Column C (Background) |
| :--- | :--- | :--- |
| Left | Hey, look at that! | gold |
| Right | What is it? | dusk |
| Left | It's an automated script! | night |

**Note**: In Duo mode, the system checks if the word "Right" or "右" is in Column A to decide which character speaks.
**註**：在雙人模式中，系統會檢查 A 欄位是否包含 "Right" 或 "右" 來決定哪位角色說話。

---

## 3. Background Keywords | 背景關鍵字
You can change the background by typing these in **Column C**:
您可以透過在 **C 欄位** 輸入以下內容來切換背景：
- `gold` (Default | 預設)
- `day` (Bright Cafe | 明亮咖啡廳)
- `dusk` (Evening | 傍晚)
- `night` (Late Night | 深夜)
- `[URL]` (You can also paste a direct image link! | 也可以直接貼上圖片網址)

---

## 🚀 Pro Tip | 專家建議
Keep your lines short (under 30 words) for the best TTS (text-to-speech) results and smooth character movements.
台詞請保持簡短（30 字以內），以獲得最佳語音效果與順暢的角色動作。

-----

*Created by Project Assistant on 2026-01-06*
