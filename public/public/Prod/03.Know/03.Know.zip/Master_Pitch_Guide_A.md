# Master Pitch & Social Media Bios | 核心推銷語與社群簡介

## 1. The Master Pitch | 一句話核心推銷語
**English**: "I help Live2D artists automate their portfolio showcases so they can stop manual recording and focus on their art."
**Chinese**: 「我幫助 Live2D 藝術家自動化其作品集展示影片，讓他們能告別手動錄影並專注於藝術創作。」

---

## 2. Instagram Bio Template | IG 簡介模板
- **Header**: Live2D Automation Specialist 🤖
- **Body**: 
  - Save 2+ hours on every showcase video. ⏳
  - perfectly smooth movements via Google Sheets. ✨
  - Get the Portfolio Master template below! 👇
- **Link**: [Your Bento.me/Linktree URL]

---

## 3. X (Twitter) Bio Template | X 簡介模板
Live2D Rigger & Automation Dev. I built the "Portfolio Master" to end the headache of manual recording. Automate your showcases with scripts. Download the free tool below! ⬇️ #Live2D #VTuberAssets

---

## 4. Reddit Profile Description | Reddit 個人介紹模板
Live2D automation enthusiast. Creator of the "Live2D Portfolio Master" tool. Here to help artists record smoother showcases without the OBS lag. Check out my free resources!

---

## 🚀 Why consistency matters | 為什麼一致性很重要
When you use the same message across all platforms, you build a **"Brand"**. People will start to recognize you as "The Automation Guy" in the Live2D community.

-----

*Created by Project Assistant on 2026-01-06*
