# Partner Demo Script & Video Guide | 合作夥伴演示腳本與影片指南

Give this to your partners to help them create high-converting promotional videos.
將此指南提供給合作夥伴，協助他們製作高轉化率的推廣影片。

---

## 🎬 1. The Video Structure | 影片結構建議
Partners should keep it short (15-30s) and focus on the "Magic."
合作夥伴應保持短片精悍，並專注於「神奇之處」。

- **The Intro (0-5s)**: "Look how I recorded this rigger showcase without moving my mouse!"
- **The Process (5-15s)**: A quick screen recording showing the Google Sheet script side-by-side with the model acting.
- **The Result (15-25s)**: Close-up of smooth physics and clean view.
- **The CTA (25-30s)**: "Get this automation tool at the link in my bio!"

---

## 📝 2. Word-for-Word Script | 推薦逐字稿
"Hey everyone! I’m using a new tool called **Live2D Portfolio Master** to record my latest rigging showcases. 🤖 

I just write my lines in a Google Sheet, and the model performs everything automatically. It saves me so much time and makes the physics look perfectly smooth. 

If you want to automate your recordings too, check the link in my bio. You can get the base version for **FREE**!"

---

## 📸 3. Key Features to Highlight | 重點展示功能
- **Scripted Movements**: Mention that it's automated via Google Sheets. (強調劇本自動化)
- **High Quality**: Mention the lag-free 12 FPS recording method. (強調無卡頓高畫質)
- **Clean UI**: Show the "L09" template result with no buttons. (展示純淨視角)

---

## 🚀 Pro Tip for Partners | 專家建議
Tell your partners to use their own models for the demo! People want to see how it works on *their* rigging style.

-----

*Created by Project Assistant on 2026-01-06*
