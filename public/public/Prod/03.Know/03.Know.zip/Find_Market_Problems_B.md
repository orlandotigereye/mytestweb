# How to Identify Others' Problems?

## 1. Where to Look?
**Reddit Search Keywords**
Visit subreddits like `r/VTuber` or `r/Live2D` and search for these phrases:
- "How do I..."
- "Tired of..."
- "Too long / Takes too much time"
- "Help with recording"

**YouTube Comment Sections**
Find popular tutorials about Live2D. Look at the "Newest First" comments. 
- What are people struggling with? 
- Which step are they complaining is "too annoying"?

## 2. Common "Pain Point" Examples
Based on market observation, your audience usually has these frustrations:
- **Efficiency**: "Recording a 1-minute clip takes me 2 hours!"
- **Complexity**: "I can't figure out the settings in OBS or other recording software."
- **Hardware**: "My PC lags when I try to run the model and record at the same time."

## 3. Your Action Plan
- **Ask the Community**: Post a question like "What is the most frustrating part of your Live2D workflow?"
- **Offer Specific Help**: When someone mentions a struggle, reply with how your tool solves that specific issue.
- **Observe Competitors**: Read reviews of other Live2D tools. The 1-star to 3-star reviews are where the "unmet needs" are hidden.

-----

# 如何找出別人的問題？

## 1. 去哪裡找？
**Reddit 搜尋關鍵字**
造訪 `r/VTuber` 或 `r/Live2D` 等討論區，並搜尋以下詞彙：
- "我要怎麼..." (How do I...)
- "厭倦了..." (Tired of...)
- "太長了 / 太花時間" (Too long / Takes too much time)
- "錄影求助" (Help with recording)

**YouTube 評論區**
尋找關於 Live2D 的熱門教學。查看「從新到舊」的評論。
- 人們在哪些地方遇到困難？
- 他們抱怨哪個步驟「太煩人」？

## 2. 常見的「痛點」範例
根據市場觀察，你的受眾通常有這些煩惱：
- **效率問題**：「錄製 1 分鐘的短片竟然花了我 2 小時！」
- **複雜度問題**：「我搞不懂 OBS 或其他錄影軟體的設定。」
- **硬體問題**：「當我嘗試同時運行模型和錄影時，我的電腦會變得很慢。」

## 3. 你的行動方案
- **詢問社群**：發布一個問題，例如：「在你的 Live2D 工作流程中，最讓你感到挫折的部分是什麼？」
- **提供具體協助**：當有人提到困難時，回覆你的工具如何解決那個具體問題。
- **觀察競爭對手**：閱讀其他 Live2D 工具的評論。那些 1 星到 3 星的評論通常隱藏著「未被滿足的需求」。
