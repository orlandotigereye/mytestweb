# Bundle & Upsell Strategy | 組合包與增售策略

How to increase your revenue per customer using logical product groupings.
如何透過邏輯性的產品組合來增加每位客戶的平均貢獻營收。

---

## 📦 1. The Tiered Bundles | 組合包分階

### **Starter Pack (The Entry)**
- **Contents**: Solo Recording Script + L09 Template.
- **Price**: $0+ (Free/Pay what you want).
- **入門包**：單人錄製腳本 + L09 模板。價格 $0+。

### **Pro Creator Bundle (The Best Seller)**
- **Contents**: Starter Pack + **Duo Recording Script** + **Rigging Checklist**.
- **Price**: $29 (Save 20% vs buying separately).
- **專業創作者包**：入門包 + 雙人錄製腳本 + 綁定檢核表。價格 $29（比單買省 20%）。

### **Studio Elite Suite (The Premium)**
- **Contents**: Pro Bundle + **Custom Background Pack** + **Lead Magnet Library**.
- **Price**: $49.
- **工作室精英套件**：專業包 + 自定義背景包 + 誘餌產品庫。價格 $49。

---

## 📈 2. The "Order Bump" Strategy | 「訂單加購」策略
On Gumroad, add a small checkbox at the checkout page.
在 Gumroad 結帳頁面新增一個小勾選框。
- **Offer**: "Add the 4K Background Pack for only $5 (Normally $15)."
- **提議**：以 5 美元加購 4K 背景包（原價 15 美元）。
- **Why**: High conversion rate because the price is low enough to be an "impulse buy."

---

## 📈 3. The "Post-Purchase" Upsell | 「售後」增售
24 hours after a customer buys the Pro Bundle, send an automated email.
在客戶購買專業包 24 小時後，發送自動郵件。
- **Offer**: "Need a custom setup? Get $20 off my **Custom Showcase Service** if you book in the next 48 hours."
- **提議**：提供「客製化展示服務」的限時折價優惠。

---

## 🚀 Pro Tip | 專家建議
Always name your bundles after the "Goal" of the user (e.g., "The Pro Rigger Bundle"). This makes them feel that buying the bundle is the "professional" choice.

-----

*Created by Project Assistant on 2026-01-06*
