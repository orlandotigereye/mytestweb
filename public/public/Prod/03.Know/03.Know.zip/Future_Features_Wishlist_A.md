# Future Feature Wishlist (Version 2.0) | 未來功能願望清單

Use this list to organize ideas for future updates and paid expansion packs.
使用此清單整理未來更新與付費擴充包的想法。

---

## 1. Technical Enhancements | 技術增強
- **Automated Voice Cloning**: Integrate with AI voice tools so characters can speak in specific cloned voices.
- **自動語音克隆**：整合 AI 語音工具，讓角色能以特定的克隆聲音說話。
- **Real-time Interaction**: A mode that allows users to type and have the character respond and record instantly.
- **即時互動**：允許使用者輸入文字後，角色立即回應並錄製的模式。
- **Automatic Subtitle Hardcoding**: Use FFmpeg to bake the subtitles directly into the video file.
- **自動字幕硬編碼**：使用 FFmpeg 直接將字幕嵌入影片檔案中。

---

## 2. User Experience (UX) | 使用者體驗
- **GUI for Scripting**: Build a simple web interface to write scripts instead of using Google Sheets.
- **劇本圖形介面**：建立一個簡單的網頁介面來編寫劇本，取代 Google 表格。
- **Preview Window**: A small window to see the character's reaction before starting the full recording.
- **預覽視窗**：在開始完整錄製前，先查看角色反應的小視窗。

---

## 3. Marketing & Integration | 行銷與整合
- **Unity/Unreal Integration**: Tools to export the recorded animations directly into game engines.
- **Unity/Unreal 整合**：將錄製的動畫直接匯入遊戲引擎的工具。
- **Custom Scene Presets**: Premade scene settings for different vibes (Horror, Cyberpunk, Slice of Life).
- **自定義場景預設**：針對不同氛圍（恐怖、賽博龐克、日常）的預設場景設定。

---

## 🚀 Priority for Next Update | 下次更新優先項目
1. Automatic MP4 renaming based on the character name.
2. Background music integration.

-----

*Created by Project Assistant on 2026-01-06*
