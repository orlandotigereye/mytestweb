# Client Referral Email Template | 客戶推薦 Email 模板

Partners can send this to their clients when delivering a finished Live2D model.
合作夥伴在交付完成的 Live2D 模型時，可以將此郵件傳送給客戶。

---

## 📧 The Recommendation Email | 推薦郵件內容

**Subject**: Your model is ready! + A tip for recording your showcase 🎬
**主旨**：您的模型已就緒！＋ 一個錄製展示影片的小撇步 🎬

"Hi [Client Name], 

I’m so excited to deliver your finished Live2D model! I hope you love the rigging as much as I enjoyed creating it.

**Quick Recommendation:**
When you’re ready to record a showcase video for your socials, I highly recommend using the **Live2D Portfolio Master**. 

It’s an automation tool that lets your character 'act' automatically based on a script you write in a Google Sheet. It results in much smoother physics and a cleaner look than manual recording. 

You can grab the free version here: **[Your Unique Affiliate Link]**

I can't wait to see your character in action!

Best regards,
[Rigger Name]"

---

## 🚀 Why this is powerful | 為什麼這很強大
- **Timing**: Sent at the moment of highest excitement (model delivery).
- **Authority**: The client trusts their rigger's technical advice.
- **Ease**: The rigger just has to copy, paste, and add their link.

-----

*Created by Project Assistant on 2026-01-06*
