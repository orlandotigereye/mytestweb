# Social Media Profile Final Copy | 社群媒體個人簡介定案文案

Use these exact strings to set up your profiles today.
請直接複製這些文字來設定您今天的個人檔案。

---

## 📸 Instagram Bio (The Professional Rigger Look)
**Name**: Live2D Automation Robot 🤖
**Bio**:
End the headache of manual recording. ⏳
Auto-record smooth showcases via Google Sheets. ✨
Optimized physics. Zero lag. 💎
Download the FREE Portfolio Master below! 👇
**Link**: [Your Bento.me/Gumroad Link]

---

## 🧡 Reddit Profile (The Helpful Community Creator)
**Display Name**: Live2D Auto-Recorder
**About**:
I build automation tools to help Live2D artists save time. Creator of the "Portfolio Master" (Scripted recording via Google Sheets). Here to share resources and help riggers look professional! 🚀

---

## 🐦 X (Twitter) Profile (The Tech-Wizard Rigger)
**Name**: [Your Name] | Live2D Automation
**Bio**: 
Helping riggers record perfect showcases without the OBS lag. 🤖 Scripted movements via Google Sheets. Get the free L09 template here! ⬇️ #Live2D #VTuberAssets

---

## 🚀 Pro Tip | 專家建議
Use a high-quality profile picture (your best Live2D model) and keep it the same across all three platforms. This creates "Brand Recognition."

-----

*Created by Project Assistant on 2026-01-06*
