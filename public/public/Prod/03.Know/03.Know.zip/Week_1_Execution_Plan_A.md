# Week 1: Execution Micro-Plan | 第一週：執行微計畫

Use this checklist to bridge the gap between strategy and your daily habit.
使用此清單來銜接策略與每日習慣。

---

## 📅 Day 1: Setup & Launch | 設定與發布
- [ ] Finalize Gumroad product listing ($0+).
- [ ] Create Bento.me profile and link it in IG/X bios.
- [ ] Run `record_live2d_Final_Pro_D.js` to get your first demo file.

## 📅 Day 2: First Public Appearance | 首次公開亮相
- [ ] Post the demo video on X (Twitter) using Hook #4.
- [ ] Create your first IG Reel using the same video and Hook #1.

## 📅 Day 3: Reddit Engagement | Reddit 互動
- [ ] Search `r/Live2D` for "Showcase" or "Help".
- [ ] Leave 3 "Complimentary Expert" comments.

## 📅 Day 4: Deep Content | 深度內容
- [ ] Post Hook #9 (The Freebie) on X and IG.
- [ ] Direct people to your Bento.me link.

## 📅 Day 5: B2B Research | 夥伴研究
- [ ] Find 5 professional riggers on X with 1k+ followers.
- [ ] Follow them and engage with their latest posts (Like/Reply).

## 📅 Day 6: The Pitch | 主動提案
- [ ] Send the **Partner Outreach Script** to the 2 most active riggers from yesterday.
- [ ] Offer them the free Pro version.

## 📅 Day 7: Analysis & Planning | 分析與規劃
- [ ] Review your `Outreach_Tracker_A.md`.
- [ ] Check Gumroad for any downloads/ratings.
- [ ] Plan Week 2 based on what got the most clicks!

-----

*Created by Project Assistant on 2026-01-06*
