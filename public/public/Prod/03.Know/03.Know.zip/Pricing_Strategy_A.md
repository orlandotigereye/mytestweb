# Pricing and Tiering Strategy | 定價與階梯策略

## 1. Tier 1: The "Hook" (Free / $0+)
**Goal: Maximum Reach and Lead Generation**
- **What's included**:
  - Basic Solo Recording Script (Pro B).
  - Standard Portfolio Template (L09).
  - Simple Setup Guide.
- **Why**: This lowers the barrier to entry and gets your tool into the hands of as many artists as possible.

## 2. Tier 2: The "Pro Showcase" ($15 - $25)
**Goal: Monetizing High-End Artists**
- **What's included**:
  - **Duo Recording Script (Pro I)**: Most artists want interaction, and this is a premium feature.
  - **Custom Background Package**: A curated set of 4K anime-style backgrounds for their showcases.
  - **Advanced Physics Optimization**: Special settings for extra-smooth hair/clothing movement.

## 3. Tier 3: The "Custom Concierge" ($50+)
**Goal: High-Ticket Service**
- **What's included**:
  - **One-on-One Setup**: You help them set up their specific model and Google Sheet for a perfect recording.
  - **Custom HTML Layout**: A unique stage design tailored to their specific character's aesthetic.

---

## 🚀 Future Roadmap | 未來發展藍圖
**Phase 1 (Now)**: Gain 50 free users and collect 5 testimonials.
**第一階段 (現在)**：獲得 50 名免費使用者並收集 5 份心得回饋。

**Phase 2 (Month 2)**: Launch the "Duo Expansion Pack" on Gumroad for $19.
**第二階段 (第 2 個月)**：在 Gumroad 以 19 美元價格發布「雙主播擴充包」。

**Phase 3 (Month 4)**: Offer "Showcase-as-a-Service" where you record the videos for them.
**第三階段 (第 4 個月)**：提供「展示影片代錄服務」。

-----

*Created by Project Assistant on 2026-01-06*
