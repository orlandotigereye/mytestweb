# 去哪裡找別人的問題？ | Where to Find People's Problems?

## 1. Reddit：全球最大的痛苦交換中心 | Reddit: Global Pain Exchange
去以下這些討論區（Subreddits）搜尋關鍵字：
Search keywords in these subreddits:
- **r/VTuber**：創作者最多的地方，常有人抱怨製作流程太長。
- **r/VTuber**: The largest creator hub; many complain about long workflows.
- **r/Live2D**：技術討論區，大家會在這裡求救「為什麼錄出來會這樣」。
- **r/Live2D**: Technical hub; people ask for help with recording issues.
- **r/VirtualYoutubers**：討論軟體與設備的好地方。
- **r/VirtualYoutubers**: A good place for software and gear discussions.

---

## 2. YouTube：教學影片的留言區 | YouTube: Tutorial Comments
搜尋「Live2D Tutorial」或「VTuber Recording」，找點閱率最高的影片。
Search for "Live2D Tutorial" or "VTuber Recording" and find high-view videos.
- **看留言**：點選「依序排列：最新內容」。
- **Check Comments**: Sort by "Newest first."
- **找「？」**：很多人會問「這個步驟有沒有更簡單的方法？」這就是你的機會。
- **Look for "?"**: Many ask, "Is there an easier way for this step?" That's your chance.

---

## 3. Twitter (X)：創作者的碎碎念 | Twitter (X): Creator Rants
使用推特的搜尋功能，搭配這些標籤（Hashtags）：
Use X's search with these hashtags:
- `#Live2D`
- `#VTuberDev`
- `#VTuberEN` / `#VTuberTW`
- **搜尋指令**：輸入 `Live2D "too long"` 或 `Live2D "annoying"`。
- **Search Query**: Type `Live2D "too long"` or `Live2D "annoying"`.

---

## 4. 繁體中文市場：在地社群 | Traditional Chinese Market
如果你想做台灣或香港市場，去這裡：
If you want to target Taiwan or Hong Kong markets, go here:
- **巴哈姆特 (Bahamut)**：搜尋「Live2D」或「VTuber」版。
- **Bahamut**: Search the Live2D or VTuber boards.
- **Facebook 社團**：加入「VTuber 交流」或「Live2D 討論區」。
- **Facebook Groups**: Join "VTuber Exchange" or "Live2D Discussion" groups.

---

## 5. 實戰建議 | Practical Advice
**不要只看，要記錄 | Don't just watch, record**
建立一個筆記，記錄你看到的常見問題。例如：
Keep a note of common issues you see, such as:
1. "My computer is too slow to record" (電腦太慢跑不動)
2. "Setting up OBS is a headache" (設定錄影軟體好頭痛)
3. "I want to record two people together" (我想錄雙人對話)

**這就是你的廣告詞 | This is your ad copy**
當你在 IG 或 Reddit 發文時，直接用他們的抱怨當標題：
When posting on IG or Reddit, use their rants as your headline:
- "Tired of spending 2 hours just to record a 1-minute clip?"
- (厭倦了只為了錄一分鐘影片就要花兩小時嗎？)

---
*Created by Project Assistant on 2026-01-06*
