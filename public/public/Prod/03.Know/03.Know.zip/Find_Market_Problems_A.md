# 如何找出別人的問題？ | How to Identify Others' Problems?

## 1. 去哪裡找？ | Where to Look?
**Reddit 搜尋關鍵字 | Search Keywords on Reddit**
去 `r/VTuber` 或 `r/Live2D` 搜尋這些詞：
Go to `r/VTuber` or `r/Live2D` and search for these terms:
- "How do I..." (我要怎麼...)
- "Tired of..." (厭倦了...)
- "Too long" (太久、太花時間)
- "Help" (救命、求救)
- "Impossible" (不可能、沒辦法)

**YouTube 評論區 | YouTube Comment Sections**
找那些教 Live2D 或錄影的熱門影片，看下面的留言。
Find popular videos teaching Live2D or recording and read the comments.
大家在問什麼？大家在抱怨什麼步驟很煩？
What are they asking? What steps are they complaining about?

---

## 2. 常見的「痛點」範例 | Common Pain Point Examples
根據我的觀察，你的受眾通常有這些煩惱：
Based on my observations, your audience usually has these struggles:
- **時間不夠**：「錄製 1 分鐘的對話竟然要花我 1 小時！」
- **Time Shortage**: "Recording a 1-minute dialogue takes me a whole hour!"
- **技術太難**：「我不會用複雜的錄影軟體設定。」
- **Technical Difficulty**: "I don't know how to set up complex recording software."
- **電腦太爛**：「我的電腦一邊跑 Live2D 一邊錄影就會當機。」
- **Hardware Limitations**: "My computer crashes when running Live2D and recording at the same time."

---

## 3. 你的行動方案 | Your Action Plan
**第一步：模仿問題 | Step 1: Mimic the Question**
在社群媒體上發問：「大家在錄製 Live2D 影片時，最討厭哪個步驟？」
Ask on social media: "What is the most annoying part of recording Live2D videos?"
這會讓別人主動告訴你他們的痛苦。
This will make people tell you their pain points directly.

**第二步：對號入座 | Step 2: Match the Solution**
如果有人說「錄影好累」，你就回覆：「我最近做了一個自動錄影工具，好像可以幫到你。」
If someone says "recording is exhausting," reply: "I recently made an auto-recording tool that might help you."

**第三步：觀察競爭對手 | Step 3: Observe Competitors**
看別人的產品評論，差評（1-3顆星）通常就是未被滿足的需求。
Read competitors' product reviews; low ratings (1-3 stars) are usually unmet needs.

---

## 4. 關鍵心法 | Key Mindset
**先聽、再看、最後才說。**
**Listen first, observe second, and speak last.**
當你了解大家的煩惱，你的介紹文案自然就會吸引人，因為你在幫他們解決問題。
Once you understand their struggles, your copy will naturally attract them because you are solving their problems.

---
*Created by Project Assistant on 2026-01-06*
