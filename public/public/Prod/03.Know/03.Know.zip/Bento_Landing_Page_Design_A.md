# Bento.me Landing Page Design | Bento.me 落地頁面設計指南

Use this layout to create a professional "Link-in-Bio" that converts visitors into users.
使用此佈局建立一個專業的個人簡介連結，將訪客轉化為使用者。

---

## 🎨 Layout Map | 佈局圖

### 1. The Hero Section (Top) | 頂部核心區
- **Avatar**: Use a high-quality character icon or your brand logo. (高品質頭像)
- **Title**: "Live2D Automation Specialist 🤖" (標題)
- **Description**: "Helping artists create perfect showcases in half the time." (簡介)

### 2. The Main Action (Large Tile) | 主要行動區 (大磁磚)
- **Link**: Your Gumroad "Portfolio Master" ($0+) product.
- **Visual**: A GIF or video of the automated recording in action.
- **Text**: "Download Portfolio Master (FREE) 📥"
- **行動**：連結至 Gumroad 免費產品，配上自動錄影的動態預覽。

### 3. Proof & Education (Small Tiles) | 證明與教育區 (小磁磚)
- **Video Tile**: Link to your first Demo Reel. (連結至首支演示短片)
- **Tutorial Tile**: "How it works: 5-Minute Guide." (5 分鐘操作指南)
- **Rigging Tile**: "Rigging Checklist for Pros." (綁定優化檢核表)

### 4. Contact & Socials (Bottom) | 聯繫與社群 (底部)
- **Icons**: Links to your Instagram, X (Twitter), and Reddit profile.
- **Button**: "Custom Showcase Service (DM for Inquiry)."
- **行動**：社群媒體圖示連結與「客製化服務」洽詢按鈕。

---

## 💡 Conversion Tips | 轉化小撇步
- **Color**: Use your brand color (#fbbf24) for the main download button.
- **Trust**: If you get a positive comment on Reddit, take a screenshot and add it as a small image tile.
- **簡潔**：首頁只放最重要的資訊，不要讓訪客感到困惑。

-----

*Created by Project Assistant on 2026-01-06*
