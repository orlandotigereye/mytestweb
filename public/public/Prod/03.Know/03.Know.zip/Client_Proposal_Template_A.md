# Custom Showcase Service: Client Proposal | 客製化展示服務：客戶提案

Use this template when a client asks for a custom setup or high-end recording service.
當客戶要求客製化設定或高端錄影服務時，請使用此模板。

---

## 📅 Project Title: [Client Name] Custom Showcase
**Service Level**: Premium Automation & Recording

---

## 1. Project Goal | 專案目標
To create a perfectly smooth, high-resolution automated showcase for the model "[Model Name]," ensuring that every rigging detail and physics element is captured with professional quality.
為模型「[模型名稱]」建立一個完美平滑、高解析度的自動化展示影片，確保每一個綁定細節與物理元件都以專業品質被捕捉。

---

## 2. Scope of Work | 服務範圍
- **Custom HTML Environment**: Tailored background and layout to match the character's aesthetic. (客製化網頁環境)
- **Advanced Scripting**: Up to 3 minutes of synchronized dialogue and expression triggers. (進階劇本編寫)
- **Physics Optimization**: Fine-tuning of damping and damping for the most realistic movement. (物理效果優化)
- **High-Res Master**: Delivery of a 4K, 60fps-interpolated MP4 file. (高解析度成品交付)

---

## 3. Timeline | 專案時程
- **Setup**: 2 Days (Environment & Scripting)
- **Review**: 1 Day (First draft delivery & feedback)
- **Final Delivery**: 1 Day after feedback.

---

## 4. Investment | 投資金額
**Total Project Fee**: $[Amount, e.g., $149]
- *Deposit*: 50% to start the project.
- *Final Payment*: 50% upon delivery of the watermarked preview.

---

## 5. Next Steps | 下一步
If you’re ready to proceed, please confirm this proposal and I will send the deposit invoice. I look forward to bringing "[Model Name]" to life!
如果您準備好開始，請確認此提案，我將發送訂金發票。期待讓「[模型名稱]」活靈活現！

-----

*Created by Project Assistant on 2026-01-06*
