# Testimonial & Feedback Request | 見證與回饋邀請模板

Use this to collect social proof from your users and service clients.
使用此模板向使用者與服務客戶收集社群信任證據。

---

## 📧 Scenario 1: For Free Users (Gumroad) | 針對免費使用者
**Subject**: How is the Live2D Portfolio Master working for you? 😊
**主旨**：Live2D 作品集大師用起來還順手嗎？ 😊

"Hi [Name], 

I noticed you downloaded the **Live2D Portfolio Master** a few days ago. I’d love to know: did you manage to record your first automated showcase?

I’m on a mission to save artists time, and your feedback helps me make the tool even better. If you have 30 seconds, could you reply with one thing you liked about it?

If you’re happy for me to share your feedback (and your social handle) as a featured artist, just let me know!

Best,
[Your Name]"

---

## 📧 Scenario 2: For Custom Service Clients | 針對服務客戶
**Subject**: Quick question about your custom showcase project 🎬
**主旨**：關於您的客製化展示專案的一個小提問 🎬

"Hi [Name],

It was a pleasure working on the custom showcase for [Model Name]! 

I’m currently updating my portfolio and would love to feature our collaboration. Would you mind providing a short 'shout-out' or testimonial about the automation quality?

**Example**: 'The automated movements are so much smoother than what I could do manually. Saved me hours of editing!'

I’ll be sure to link back to your profile so more people can see your amazing art!

Cheers,
[Your Name]"

---

## 🚀 Why this works | 為什麼這有效
- **Win-Win**: You offer to link back to their profile, giving them free exposure.
- **Low Friction**: You provide an example of what they could say.
- **Personal**: It feels like a 1-on-1 conversation, not a mass email.

-----

*Created by Project Assistant on 2026-01-06*
