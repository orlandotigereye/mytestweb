# Customer Referral & Reward Strategy | 客戶推薦與獎勵策略

Turn your happy customers into your most effective sales force.
將滿意的客戶轉化為您最有效的銷售力量。

---

## 🎁 1. The "Free User" Incentive | 針對免費使用者的獎勵
**Goal**: Get them to share your tool on social media.
**目標**：讓他們在社群媒體上分享您的工具。

- **Offer**: "Share a video you recorded with our tool on X or IG, tag us, and get the **Pro Background Pack** for free!"
- **提議**：「在 X 或 IG 分享您用我們工具錄製的影片並標記我們，即可免費獲得『專業背景包』！」
- **Why**: This creates a flood of **User Generated Content (UGC)** which acts as powerful social proof.

---

## 🎁 2. The "Paid User" Referral | 針對付費使用者的推薦
**Goal**: Reward them for bringing new paying customers.
**目標**：獎勵他們帶來新的付費客戶。

- **Offer**: "Refer a friend who buys the Pro Bundle, and you both get a **$10 credit** or a custom expression script for free."
- **提議**：「推薦一位朋友購買專業包，您與朋友皆可獲得 10 美元抵用金或免費獲贈一個客製化表情腳本。」
- **Setup**: Use Gumroad's "Affiliate" feature to automate this tracking.

---

## 🎁 3. The "Artist Spotlight" Program | 「藝術家聚光燈」計畫
- **Action**: Every month, select one user who shared a great video and feature them on your landing page and social media.
- **行動**：每月選出一位分享優秀影片的使用者，並在您的落地頁面與社群媒體上進行專題介紹。
- **Benefit**: People love exposure. This encourages them to use your tool more creatively and share it with their followers.

---

## 🚀 How to Implement | 如何執行
1. **Gumroad Receipt**: Add a line in your digital receipt: "Love the tool? Share your results and get a bonus!"
2. **Email Sequence**: Include the referral offer in **Email #2** of your nurture sequence.
3. **Discord**: Create a `#✨-showcase-rewards` channel where users post their links to claim prizes.

---

## 💡 Pro Tip | 專家建議
A recommendation from a friend is 10x more powerful than any ad you will ever run. Focus on making the referral process "fun" rather than just "transactional."

-----

*Created by Project Assistant on 2026-01-06*
