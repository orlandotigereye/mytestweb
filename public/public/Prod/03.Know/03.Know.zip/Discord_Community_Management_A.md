# Discord Community Management Guide | Discord 社群管理與設定指南

Building your own server is the best way to turn users into loyal fans.
建立自己的伺服器是將使用者轉化為忠實粉絲的最佳方式。

---

## 🏗️ 1. Server Structure (Channels) | 頻道架構
Organize your server logically to keep discussions focused.
邏輯化地組織頻道，讓討論保持專注。

- **#📢-announcements**: Official updates and new version releases. (官方更新)
- **#✨-showcase**: A place for users to post videos they recorded with your tool. (成果展示)
- **#🆘-technical-support**: Where users can ask questions about setup. (技術支援)
- **#💡-feature-requests**: Collect ideas for Version 2.0. (功能建議)
- **#☕-general-chat**: Casual VTuber and Live2D talk. (閒聊區)

---

## 🏗️ 2. User Roles | 身分組設定
Assign roles to give people a sense of belonging.
分配身分組以增加成員的歸屬感。

- **Owner**: You.
- **Pro User**: For anyone who has purchased a paid tier. (付費使用者)
- **Beta Tester**: Loyal free users who help test new features. (測試員)
- **Artist/Rigger**: To identify their professional background. (專業身分)

---

## 🏗️ 3. Engagement Strategies | 互動策略
- **Weekly Showcase**: Every Friday, pick the best user video and feature it.
- **每週之星**：每週五挑選一個最優秀的使用者影片進行表揚。
- **Direct Feedback**: Ask "Which background should I add next?" Use polls.
- **直接回饋**：使用投票功能詢問：「下次該新增哪種背景？」

---

## 🏗️ 4. Rules & Safety | 規則與安全
- No spamming links.
- Be respectful to artists of all levels.
- Report any technical bugs in the designated channel.

---

## 🚀 Pro Tip | 專家建議
Use a bot like **MEE6** or **Carl-bot** to automate the "Welcome Message" when new people join. Link your Discord in your Gumroad "Success" message so people join immediately after downloading.

-----

*Created by Project Assistant on 2026-01-06*
