# Daily Growth Routine | 每日成長規律

A simple 45-minute daily plan to grow your second income project.
一套簡單的 45 分鐘每日計畫，用來發展您的第二收入專案。

---

## 🕒 Morning: The "Bait" (15 Minutes) | 早晨：佈餌
- **Action**: Post one content piece (IG Reel or X post) using a headline from the **Content Hook Library**.
- **行動**：從「內容勾子庫」挑選一個標題，發布一個內容作品（IG Reel 或 X 貼文）。
- **Why**: This starts the algorithm working for you while you are busy with other things.

---

## 🕒 Lunch/Break: The "Search" (15 Minutes) | 午休：搜尋
- **Action**: Search Reddit (`r/Live2D`, `r/VTuber`) for 3 specific questions or showcases.
- **行動**：在 Reddit 搜尋 3 個具體的問題或作品展示。
- **Why**: This keeps you updated on the latest pain points and identifies potential customers.

---

## 🕒 Evening: The "Engagement" (15 Minutes) | 晚上：互動
- **Action**: Leave 3 "Complimentary Expert" comments on the posts you found earlier.
- **行動**：在稍早找到的貼文中留下 3 則「讚賞式專家」評論。
- **Action**: Log your actions in the `Outreach_Tracker_A.md`.
- **行動**：在「開發追蹤表」中記錄您的行動。
- **Why**: Direct interaction is the fastest way to get your first response and download.

---

## 🚀 Weekend: The "Level Up" (1 Hour) | 週末：升級
- **Action**: Review your Tracker. Which platform got the most clicks?
- **行動**：回顧您的追蹤表。哪個平台獲得最多點擊？
- **Action**: Update the `Product_Update_Log_A.md` with any new ideas or bug fixes.
- **行動**：將任何新想法或修復更新到「產品維護日誌」中。

-----

*Created by Project Assistant on 2026-01-06*
