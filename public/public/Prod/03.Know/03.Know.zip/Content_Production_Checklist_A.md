# High-Impact Content Production Checklist | 高影響力內容製作檢核表

Use this checklist before every post to ensure maximum quality and engagement.
在每次發文前使用此檢核表，確保最高品質與互動率。

---

## 🎬 1. Visual Standards | 畫面標準
- [ ] **High Resolution**: Video exported at 1080p or 4K. (高解析度輸出)
- [ ] **Clean Stage**: Using **L09 Template** with zero UI/mouse cursor visible. (純淨舞台，無介面雜物)
- [ ] **Fluid Physics**: Hair and clothing movement looks smooth (recorded at 12 FPS). (平滑的物理效果)
- [ ] **The "Hook" Text**: Catchy headline visible in the center for the first 3 seconds. (前 3 秒螢幕中央有吸引人的標題)

---

## 🎵 2. Audio & Scripting | 音訊與劇本
- [ ] **Trending Music**: Using a popular VTuber/Anime track (low volume if TTS is used). (使用熱門音樂)
- [ ] **Clear TTS**: The voice-over is easy to understand and matches the character. (語音清晰且契合角色)
- [ ] **Pacing**: Cuts are fast (every 2-3 seconds) to maintain attention. (節奏快速，每 2-3 秒有畫面變動)

---

## 🎨 3. Branding & CTAs | 品牌與行動呼籲
- [ ] **Signature Color**: Using **Success Gold (#fbbf24)** for key text/subtitles. (使用標誌性金黃色)
- [ ] **The "What's Next"**: Ending with a clear "Link in bio" or "Download for free." (明確的結尾引導)
- [ ] **Bento Link**: Ensure your landing page URL is actually in your bio! (確保個人簡介裡真的有連結)

---

## 🔍 4. Discovery (SEO) | 發現與優化
- [ ] **Hashtags**: Using a mix of broad (#VTuber) and niche (#Live2DRigging) tags. (混合使用大眾與小眾標籤)
- [ ] **Alt-Text**: Added image descriptions for screen readers and search weight. (加入圖片替代文字)
- [ ] **Thumbnail**: A custom cover image with high-contrast text. (自定義高對比文字封面)

---

## 🚀 Pro Tip | 專家建議
Batch-produce your content! Spend 1 hour on Sunday recording 5 different scripts. This makes your **Daily Growth Routine** much easier during the week.

-----

*Created by Project Assistant on 2026-01-06*
