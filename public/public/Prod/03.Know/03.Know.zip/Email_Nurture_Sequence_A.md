# Email Nurture Sequence | Email 經營序列 (3 封)

These emails should be set up in your Gumroad "Workflows" or your email marketing tool.
這些郵件應在您的 Gumroad「工作流」或 Email 行銷工具中設定。

---

## 📧 Email 1: The "Quick Win" (Sent immediately after download)
**Subject**: One quick tip for your first automated recording 🎬
**主旨**：關於您的第一次自動錄影的一個小技巧 🎬

"Hi [Name], 

By now, you should have the **Live2D Portfolio Master** in your hands. I want to make sure you get a win today!

**Quick Tip**: When you record your first video, try using the **L09 Clean Template**. It’s designed to hide all the buttons so you can post the video directly to social media as a professional showcase.

Did the script run smoothly for you? Just hit reply and let me know—I read every email!

Cheers,
[Your Name]"

---

## 📧 Email 2: The "Expert Insight" (Sent 3 days later)
**Subject**: How to make your Live2D physics look like a professional animation ✨
**主旨**：如何讓您的 Live2D 物理效果看起來像專業動畫 ✨

"Hi [Name],

One of the biggest problems with recording Live2D is **laggy physics**. Most people try to record at 60 FPS while their computer is struggling.

**The Secret**: Our tool records at a stable 12 FPS and then uses FFmpeg to process it. This ensures that every strand of hair and every piece of clothing moves perfectly smooth, regardless of how fast your computer is.

If you haven't recorded a video yet, try it today and notice the difference in the hair physics!

Best,
[Your Name]"

---

## 📧 Email 3: The "Soft Pitch" (Sent 7 days later)
**Subject**: Want to record two characters talking automatically? 🎭
**主旨**：想自動錄製兩位角色的對話嗎？ 🎭

"Hi [Name],

I hope you’ve been enjoying the Portfolio Master! 

Many artists have asked me: 'Can I record a duo showcase where two models interact?'

The answer is **Yes!** I’ve built a **Duo Pro Expansion Pack** that handles synchronized dialogue, background switching, and advanced physics for two models at once.

If you’re ready to take your showcases to the next level, you can check out the Pro version here: **[Link to Paid Gumroad Product]**

As a thanks for being an early user, use code **EARLYBIRD** for 20% off.

Happy creating,
[Your Name]"

-----

*Created by Project Assistant on 2026-01-06*
