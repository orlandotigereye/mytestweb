# Social Media Crisis & Comment Management | 社群媒體危機與評論管理指南

Use these strategies to maintain a professional image and handle difficult public interactions.
使用這些策略來維持專業形象，並處理困難的公開互動。

---

## 🛡️ 1. The "Technical Fail" Comment | 處理「技術失效」評論
**Comment**: "This tool is broken! It didn't record anything for me."
**回覆思路**：不要防衛，展現解決問題的誠意。

**Response**: "Oh no! I'm so sorry to hear that. I want to make sure this works perfectly for you. It might be a quick path setting issue—could you please DM me or check the `Product_FAQ_A.md`? I'd love to help you fix it right away!"
**中文回覆**：「喔不！我很遺憾聽到這個消息。我想確保它能為您完美運作。這可能只是路徑設定的小問題——可以請您私訊我，或是查看 `Product_FAQ_A.md` 嗎？我很樂意立即協助您修復！」

---

## 🛡️ 2. The "AI/Automation" Debate | 處理「AI/自動化」爭議
**Comment**: "Automation is killing art! Real riggers don't need this."
**回覆思路**：強調工具是「輔助」而非「取代」。

**Response**: "I completely agree that nothing replaces the soul of an artist! I built this specifically to handle the *boring, repetitive* mouse-clicking part of recording, so riggers like you can spend more time on the actual 'Magic' (the art and rigging). It's a tool to show off your hard work in the best possible light!"
**中文回覆**：「我完全同意，沒有任何東西可以取代藝術家的靈魂！我開發這個工具是專門為了處理錄影中那些『無聊、重複』的點擊動作，讓像您這樣的綁定師能把更多時間花在真正的『魔法』（藝術與綁定）上。這是一個讓您的辛勤成果以最佳光彩呈現的工具！」

---

## 🛡️ 3. The "Troll" or "Spam" Comment | 處理「酸民」或「垃圾訊息」
**Comment**: (Random insults or unrelated links)
**回覆思路**：保持優雅，或是直接無視。

**Action**: If it's pure hate, **hide or delete** the comment. If it's a minor troll, reply with a simple: "Thanks for the feedback! Happy creating!" and move on. Do not argue.
**行動**：如果是純粹的惡意攻擊，直接**隱藏或刪除**。如果是輕微的酸言酸語，簡單回覆：「謝謝您的回饋！祝您創作愉快！」然後跳過。不要與之爭論。

---

## 🚀 Pro Tip | 專家建議
Always wait 5 minutes before replying to a negative comment. Never reply when you are angry. Your brand's reputation is built on how you handle the 1% of difficult people.

-----

*Created by Project Assistant on 2026-01-06*
