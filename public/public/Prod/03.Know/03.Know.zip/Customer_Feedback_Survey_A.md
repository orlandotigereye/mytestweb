# Customer Feedback & Innovation Survey | 客戶回饋與創新調查問卷

Use these questions to understand your users and plan Version 2.0.
使用這些問題來了解您的使用者，並規劃 2.0 版本。

---

## 📝 1. The "Experience" Question | 使用體驗
**Question**: "On a scale of 1-10, how much time did the Portfolio Master save you on your last recording?"
**問題**：以 1 到 10 分為標準，作品集大師在您上次錄影中節省了多少時間？
- **Why**: This gives you a concrete number for your marketing copy (e.g., "Saves users an average of 8/10 time").

---

## 📝 2. The "Pain Point" Question | 挖掘痛點
**Question**: "What was the most frustrating part of using the script or the Google Sheet setup?"
**問題**：在執行腳本或設定 Google 表格時，最讓您感到沮喪的部分是什麼？
- **Why**: Identifies the biggest "friction points" you need to fix in the next update.

---

## 📝 3. The "Future" Question | 未來展望
**Question**: "If I could add ONE new feature to the Pro version tomorrow, what would it be?"
**問題**：如果我明天能為專業版新增「一項」功能，您希望是什麼？
- **Why**: Directly sources ideas for your Version 2.0 Feature Wishlist.

---

## 📝 4. The "Value" Question | 價值評估
**Question**: "Would you recommend this tool to a fellow artist? Why or why not?"
**問題**：您會向其他藝術家推薦這個工具嗎？為什麼？
- **Why**: The answers here are perfect snippets for your **Testimonials & Social Proof**.

---

## 🚀 How to Send | 如何發送
- **Method 1**: Link to a Google Form in your **Email Sequence (Email #2)**.
- **Method 2**: Post it in your Discord `#💡-feature-requests` channel.
- **Incentive**: Offer a "Free Custom Background" to anyone who completes the survey. (提供小禮物以增加填答率)

-----

*Created by Project Assistant on 2026-01-06*
