# Content Creation Workflow | 內容製作工作流 (從錄製到發布)

Follow these steps to turn your raw recording into a high-impact social media post.
遵循這些步驟，將原始錄影轉化為高影響力的社群媒體貼文。

---

## 🎥 Step 1: Technical Recording | 第一步：技術錄製
1. Open your Google Sheet and write the script.
2. Run the command: `node public/note_js/record_live2d_Final_Pro_D.js`.
3. Wait for the MP4 to be generated in the `public/linve2D/` folder.

---

## ✂️ Step 2: Quick Editing (Mobile/PC) | 第二步：快速剪輯
Don't over-edit! Keep it raw and authentic.
不要過度剪輯！保持原始且真實的感覺。
- **Tool**: **CapCut** (Mobile) or **Adobe Premiere Rush**.
- **Action**: 
  - Crop to **9:16** for Reels/Shorts. (裁切成 9:16)
  - Add **Trending Music** from the IG/TikTok library. (加上熱門音樂)
  - Add **Subtitles** using the auto-caption feature if your script is long. (使用自動字幕功能)

---

## 📤 Step 3: Platform Upload | 第三步：平台上傳
### **Instagram Reels**
- **Settings**: Turn on "Upload at Highest Quality" in your IG settings. (開啟「高畫質上傳」設定)
- **Cover**: Select a frame where the character looks best. (選擇角色最美的一幀作為封面)
- **Caption**: Use the copy from our **Social Profile Final Copy**.

### **Reddit (r/Live2D)**
- **Method**: Upload the MP4 directly to the Reddit post.
- **Context**: Mention that it was recorded with an automated script to spark curiosity. (提到這是用自動化腳本錄製的，以引發好奇心)

---

## ⏱️ Total Time Estimate | 預估總耗時
- **Recording**: 2 Minutes.
- **Editing**: 5 Minutes.
- **Posting**: 3 Minutes.
- **Total**: **10 Minutes per post!**

-----

*Created by Project Assistant on 2026-01-06*
