# Competitor Analysis & Market Positioning | 競爭分析與市場定位

## 1. The Current Alternatives | 現有替代方案
- **VTube Studio Built-in Recorder**: Exports `.motion3.json` files. Good for making animations but bad for making social media videos. Requires users to still record with OBS if they want an MP4.
- **OBS + Spout2**: The "Standard" method. High quality but very complex to set up. Requires a lot of manual work to trigger expressions while recording.

## 2. Your "Unfair Advantage" | 您的獨特優勢
- **Browser-Based (Puppeteer)**: No need for high-end GPUs or OBS.
- **Google Sheets Automation**: The only tool that lets you "script" the performance beforehand. This is your biggest selling point.
- **Zero UI Mode (L09)**: Instantly provides a clean, professional look that usually takes hours to edit in Premiere or After Effects.

## 3. Positioning Your Product | 產品定位建議
Don't call it a "Live2D tool." Call it a **"Portfolio Marketing Automation Tool."**
- **Target Audience**: Model artists (Riggers) who need to make showcases for their clients.
- **Value Proposition**: "Save 2 hours per showcase video and make your models look 10x more professional."

## 4. Competitive Pricing Strategy | 競爭定價策略
Since there is no direct "Automated Scripting" tool on Booth.pm or Gumroad, you can define the market price.
- **Starter**: $0 (The Hook).
- **Pro Bundle**: $19 - $29 (The Income).
- **Custom Integration**: $99+ (The Service).

-----

*Created by Project Assistant on 2026-01-06*
