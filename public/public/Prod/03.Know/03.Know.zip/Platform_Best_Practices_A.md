# Platform Best Practices | 平台最佳實踐指南

## 1. Reddit: The "Expert Helper" Strategy
**Don't**: Create a new post saying "Buy my tool at [Link]." You will be ignored or banned.
**Do**: Search for questions. When you find one, write a long, helpful reply (at least 3-4 sentences) and mention your tool as a "free resource I built to solve this."

**Best Subreddits**:
- `r/VTuber`: Use the "Resource" or "Discussion" flair.
- `r/Live2D`: Use the "Showcase" or "Tutorial" flair.

---

## 2. Instagram: The "Hook-Value-CTA" Framework
Every Reel or Post should follow this structure to keep people watching:
1. **Hook (0-3s)**: A bold statement. "How I stopped wasting 2 hours on recording."
2. **Value (3-12s)**: Show the tool in action. Use fast cuts and trending VTuber music.
3. **CTA (12-15s)**: Tell them exactly what to do. "Comment 'AUTO' for the link!" (Directing them to DMs is better for the algorithm than a link in the caption).

---

## 3. Twitter (X): The "Networking" Strategy
**Don't**: Just tweet into the void.
**Do**: Quote-tweet (Retweet with comment) popular model artists. 
- Example: "This rigging is insane! If you ever need to record a clean showcase for this model without manual clicks, I've got a free automation tool that might help!"

---

## 4. Key Metrics to Watch | 關鍵數據指標
- **Reddit**: Karma points and Upvotes (Shows you are trusted).
- **IG**: Saves and Shares (Shows your tool is actually useful).
- **X**: Profile visits (Shows people are curious about who you are).

-----

*Created by Project Assistant on 2026-01-06*
