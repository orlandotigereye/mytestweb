# Product FAQ | 產品常見問題

## 1. Is this tool safe to run? | 這個工具執行起來安全嗎？
**English**: Yes. It runs locally on your computer using Puppeteer (a tool by Google). It does not send your model files to any external server.
**Chinese**: 是的。它使用 Puppeteer（Google 開發的工具）在您的電腦本地執行。它不會將您的模型檔案傳送到任何外部伺服器。

---

## 2. Do I need to know how to code? | 我需要懂寫程式嗎？
**English**: No! You only need to copy and paste a single command into your terminal (the "black window"). Everything else is handled by the script.
**Chinese**: 不需要！您只需要將一行指令複製並貼上到終端機（那個「小黑窗」）即可。其他所有事情都由腳本自動處理。

---

## 3. Why is this better than OBS? | 為什麼這比 OBS 更好？
**English**: OBS recording requires a powerful GPU and manual mouse clicks to trigger expressions. Our tool is lightweight (browser-based) and automates every movement using a script, resulting in a cleaner, smoother "Portfolio" look.
**Chinese**: OBS 錄製需要強大的顯卡，且必須手動點擊滑鼠來觸發表情。我們的工具非常輕量（基於瀏覽器），並透過劇本自動化每個動作，產出的作品集畫面更純淨、更順暢。

---

## 4. Does it work on Mac? | Mac 電腦可以使用嗎？
**English**: Currently, the paths are optimized for Windows. However, it can run on Mac with a simple change to the Chrome application path in the script.
**Chinese**: 目前的路徑設定是針對 Windows 優化的。不過，只需在腳本中修改 Chrome 應用程式的路徑，它也可以在 Mac 上執行。

---

## 5. How do I use my own model? | 我要如何使用我自己的模型？
**English**: The free version includes standard models for testing. To use your own, you simply replace the `AVATARS` URL in the HTML file with the path to your own model files.
**Chinese**: 免費版包含標準模型供測試。要使用您自己的模型，只需將 HTML 檔案中 `AVATARS` 的網址替換為您自己模型檔案的路徑即可。

---

## 6. How do I change the speech speed? | 我要如何更改說話速度？
**English**: You can adjust the `ut.rate` value in the script. `0.6` is the optimized "slow" speed for the 12 FPS recording mode.
**Chinese**: 您可以調整腳本中的 `ut.rate` 數值。對於 12 FPS 的錄影模式，`0.6` 是優化過的「慢速」設定。

-----

*Created by Project Assistant on 2026-01-06*
