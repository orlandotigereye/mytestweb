# Customer Service & Objection Handling | 客戶服務與疑慮處理指南

Use these responses to handle common doubts and close more sales.
使用這些回覆來處理常見疑慮並增加銷售轉化。

---

## 1. Objection: "Is it safe to run a script on my PC?"
**疑慮：「在我的電腦上跑腳本安全嗎？」**

**English Response**: "I completely understand! The tool uses Puppeteer, an industry-standard library by Google. It runs entirely on your local machine and never sends your model files anywhere. You can even check the source code yourself if you’re tech-savvy—everything is transparent!"
**中文回覆**：「我完全理解！這個工具使用的是 Puppeteer，這是 Google 開發的業界標準庫。它完全在您的本地機器上執行，絕不會將您的模型檔案傳送到任何地方。如果您懂技術，甚至可以直接查看原始碼——一切都是透明的！」

---

## 2. Objection: "The Pro version is too expensive."
**疑慮：「專業版太貴了。」**

**English Response**: "Think of it this way: if this tool saves you just 2 hours on every showcase video, it pays for itself in the very first use. For a professional artist, your time is worth much more than the cost of the script. It’s an investment in your productivity!"
**中文回覆**：「您可以這樣想：如果這個工具在每一支展示影片中幫您節省 2 小時，那麼第一次使用就已經回本了。對於專業藝術家來說，您的時間價值遠高於這個腳本的成本。這是對您生產力的一項投資！」

---

## 3. Objection: "It looks too complicated to set up."
**疑慮：「看起來設定好複雜。」**

**English Response**: "It’s actually much simpler than it looks! You just fill in your lines in a Google Sheet and paste one command. I’ve included a 5-minute 'Quick Start' guide that walks you through every step. If you get stuck, I’m always here to help!"
**中文回覆**：「其實它比看起來簡單得多！您只需要在 Google 表格填寫台詞並貼上一行指令。我附帶了一份 5 分鐘『快速入門』指南，會帶領您完成每個步驟。如果您卡住了，我隨時都在這裡提供協助！」

---

## 4. Objection: "Does it support 60 FPS recording?"
**疑慮：「它支援 60 FPS 錄製嗎？」**

**English Response**: "Our unique method records at a super-stable 12 FPS to ensure the highest quality physics rendering without lag, and then outputs a smooth video. This actually results in a 'cleaner' look for showcases than most 60 FPS screen recordings that suffer from frame drops."
**中文回覆**：「我們獨特的方法是以極其穩定的 12 FPS 進行錄製，以確保在不卡頓的情況下實現最高品質的物理效果渲染，然後產出流暢的影片。比起大多數會掉幀的 60 FPS 螢幕錄影，這反而能為作品集帶來更『純淨』的視覺效果。」

-----

*Created by Project Assistant on 2026-01-06*
