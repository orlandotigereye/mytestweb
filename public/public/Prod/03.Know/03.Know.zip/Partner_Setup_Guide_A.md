# Quick-Start Guide for Partners | 合作夥伴快速入門指南

Test your model in our automation system in under 2 minutes.
在 2 分鐘內於我們的自動化系統中測試您的模型。

---

## 🚀 Step 1: Open the HTML | 第一步：開啟網頁
Open the `LiveOnly260304L09.html` file in your browser. (直接在瀏覽器中開啟 L09 檔案)

## 🚀 Step 2: Link Your Model | 第二步：連結您的模型
1. Open the `.html` file in a text editor (Notepad++ or VS Code).
2. Find the `AVATARS` constant.
3. Paste the URL or local path to your `.model3.json` file.
   - **Example**: `"my_model": "file://C:/models/my_character.model.json"`

## 🚀 Step 3: Run the Script | 第三步：執行指令
1. Paste your Google Sheet ID into the UI. (貼上您的 Google 表格 ID)
2. Open your terminal and run: (在終端機執行)
   `node public/note_js/record_live2d_Final_Pro_D.js`

---

## 🎬 Result | 預期結果
The character will perform your script automatically, and a high-quality MP4 will be saved to your folder.
角色將自動執行您的劇本，且一段高品質的 MP4 影片將儲存至您的資料夾。

**Need Help?** DM us anytime! We want to make your showcases look perfect.

-----

*Created by Project Assistant on 2026-01-06*
