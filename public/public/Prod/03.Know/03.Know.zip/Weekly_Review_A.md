# Weekly Review & Reflection | 每週回顧與反思表

Fill this out every Sunday to stay focused and motivated.
每週日填寫此表，保持專注與動力。

---

## 📊 1. The Numbers | 數據指標
- **Outreach Messages Sent (本週聯繫數)**: 
- **New Free Downloads (本週免費下載數)**: 
- **Total Revenue Earned (本週總收入)**: $
- **Best Platform (表現最佳平台)**: (Reddit / IG / X?)

---

## 🧠 2. The Reflection | 深度反思
- **What worked best this week? (本週最成功的行動是什麼？)**
  
- **What was the biggest challenge? (本週最大的挑戰是什麼？)**
  
- **What is one thing I will STOP doing next week? (下週我要停止做哪件事？)**
  

---

## 🎯 3. Next Week's Goal | 下週目標
- **Main Objective (核心目標)**: 
- **One "Big Action" (一個重要行動)**: 

---

## 💡 Mindset Check | 心態檢查
How am I feeling about this project right now? (1 = Tired, 10 = High Energy)
我現在對這個專案的感覺如何？（1 = 疲憊，10 = 充滿活力）

-----

*Created by Project Assistant on 2026-01-06*
