# Japanese Market Entry Strategy | 日本市場進入策略

How to scale your tool in the birthplace of Live2D.
如何在 Live2D 的發源地擴大您的工具影響力。

---

## 🇯🇵 1. The Primary Platform: Booth.pm | 核心平台
In Japan, **Booth.pm** is much more popular than Gumroad for VTuber assets.
在日本，針對 VTuber 資產，**Booth.pm** 比 Gumroad 受歡迎得多。
- **Action**: Create a Booth.pm shop. (建立 Booth 商店)
- **Action**: List your Portfolio Master as a "Free Download" (0 JPY).
- **行動**：將作品集大師上架為「免費下載」（0 日圓）。

---

## 🇯🇵 2. Language & Localization | 語言與在地化
You don't need to be fluent. Use these standard phrases for your Booth listing and X (Twitter) posts.
您不需要精通日文。在 Booth 描述與 X 貼文中可以使用這些標準語句。

- **Tool Name**: Live2Dオートキャプチャ (Live2D Auto-Capture)
- **Hook**: "録画の手間をゼロに。" (Reduce recording effort to zero.)
- **Description**: "GoogleスプレッドシートでLive2Dモデルを自動制御。滑らかなショーケース動画を1クリックで作成！" (Control Live2D via Google Sheets. Create smooth showcases in 1-click!)

---

## 🇯🇵 3. Visual Aesthetics | 視覺美學
- **Cleanliness**: Japanese users love clean, white backgrounds with high-resolution characters.
- **Vertical Orientation**: Most Japanese creators watch on mobile. Ensure your demo videos are **9:16**.
- **風格**：偏好乾淨的白色背景與高解析度角色。確保展示影片為 **9:16** 比例。

---

## 🇯🇵 4. Outreach on X (Twitter JP) | X 平台開發
The Japanese Live2D community is extremely active on X.
- **Hashtags**: Use `#Live2D` and `#VTuber準備中` (VTuber in preparation).
- **Strategy**: Follow Japanese riggers and "Like" their showcases. When they follow back, send a very polite DM in Japanese (I can provide a script for this).

---

## 🚀 Pro Tip | 專家建議
Use DeepL for high-quality translation. Japanese creators appreciate politeness above all else. Always start your DMs with "突然の連絡失礼いたします" (Apologies for the sudden contact).

-----

*Created by Project Assistant on 2026-01-06*
