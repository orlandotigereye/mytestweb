# Partner Information Deck | 合作夥伴資訊手冊

**Product**: Live2D Portfolio Master (Automated Recording Suite)
**Target**: Professional Riggers & Live2D Artists

---

## 1. The Problem | 解決什麼問題？
Recording high-quality showcases is time-consuming and often results in laggy, clunky movements. Most artists spend 1-2 hours just to record a 1-minute clip.
錄製高品質的展示影片非常耗時，且經常導致卡頓、不自然的動作。大多數藝術家光是錄製一分鐘的短片就要花上 1 到 2 小時。

---

## 2. Our Solution | 我們的解決方案
A browser-based automation tool that records models via Google Sheets.
一個基於瀏覽器、透過 Google 表格進行錄影的自動化工具。
- **Auto-Animation**: The model acts automatically based on a script. (自動演戲)
- **Lag-Free**: Stabilized 12 FPS capture for perfect physics. (無卡頓捕捉)
- **Zero-UI**: Clean, professional output ready for IG/X. (純淨輸出)

---

## 3. Why Partner with Us? | 為什麼與我們合作？
- **Add Value to Clients**: Give your clients a better way to show off the model you rigged for them. (為客戶增值)
- **Passive Income**: Earn a **40% commission** on every sale generated through your link. (被動收入：40% 分潤)
- **Free License**: Get the Full Pro version for free for your own portfolio. (免費授權)

---

## 4. How it Works | 如何運作
1. **Join**: We set you up as an affiliate on Gumroad. (加入分潤系統)
2. **Promote**: You use the tool for your own showcases and share your unique link. (進行推廣)
3. **Earn**: Every time a client or follower buys the Pro version, you get paid automatically. (獲得收益)

---

## 5. Get Started | 立即開始
Reply to this message with "PARTNER" and let’s set up your custom affiliate link!
回覆 "PARTNER" 給我們，讓我們為您設定專屬的分潤連結！

-----

*Created by Project Assistant on 2026-01-06*
