# Collaborative Marketing & Partnership Strategy | 合作行銷與夥伴關係策略

## 1. Why Partner with Riggers? | 為什麼要與綁定師合作？
Riggers are the "gatekeepers." Every time they finish a model, their client asks: "How do I record a showcase?" If the rigger recommends your tool, you get an instant, high-trust lead.
綁定師是「守門人」。每當他們完成一個模型，客戶都會問：「我要如何錄製展示影片？」如果綁定師推薦了您的工具，您就能立即獲得一個高品質、高信任度的潛在客戶。

---

## 2. The "Free Pro" Offer | 「免費專業版」提案
Reach out to mid-tier riggers (1k - 5k followers) and offer them the **Pro Bundle ($29 value)** for free. 
聯繫中階綁定師（1千至 5千追蹤者），並免費提供價值 29 美元的「專業版組合包」。
- **The Deal**: They use it to record their own showcases and mention "Recorded with [Your Tool Name]" in their caption.
- **交易內容**：他們使用該工具錄製自己的作品展示，並在說明欄標註「使用 [您的工具名稱] 錄製」。

---

## 3. Affiliate Marketing (Gumroad) | 分潤行銷
Use Gumroad's built-in affiliate system.
使用 Gumroad 內建的分潤系統。
- **Offer**: Give riggers 30% - 50% commission for every sale they generate through their link.
- **提議**：為他們透過連結促成的每一筆銷售提供 30% - 50% 的佣金。
- **Why**: This incentivizes them to actively promote your tool to every single client.

---

## 4. Partner Outreach Script | 合作開發腳本
"Hi [Rigger Name], I love your rigging style! I noticed that recording high-quality showcases is a pain for many artists. I built an automation tool that records models via Google Sheets—it makes the physics super smooth. I'd love to give you the Pro version for free to use for your own portfolio. If you like it, we could even set up an affiliate link so you can earn a commission when your clients use it. Interested?"

---

## 🚀 Action Step | 行動步驟
Find 5 riggers on Twitter/X today who frequently post showcases and send them this message.

-----

*Created by Project Assistant on 2026-01-06*
