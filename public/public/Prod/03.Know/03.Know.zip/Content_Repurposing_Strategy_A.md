# Content Repurposing Strategy | 內容多用途化策略

Turn 1 recording into 5+ pieces of high-impact content.
將 1 段錄影轉化為 5 件以上的高影響力內容。

---

## 📽️ The Core Asset: 1-Minute Automated Recording
Record a high-quality showcase using **Script Pro D**. This is your "Master Video."
使用 **Script Pro D** 錄製一段高品質展示。這是您的「大師影片」。

---

## 🚀 Repurposing Map | 內容轉化地圖

### 1. Instagram Reels (Vertical)
- **Edit**: Crop to 9:16, add trending VTuber music.
- **Hook**: Use Hook #1 ("Recording used to take hours...").
- **行動**：裁切為 9:16，加上熱門 VTuber 音樂，並使用勾子標題 #1。

### 2. X (Twitter) Native Video
- **Edit**: Keep the original 16:9 or 1:1 ratio.
- **Caption**: Focus on the technical smoothness. Tag #Live2D #Rigging.
- **行動**：保持原比例發布，強調技術上的平滑感，並標註相關標籤。

### 3. Reddit Showcase (r/Live2D)
- **Edit**: Post the full "Master Video" with a "How I did it" caption.
- **Body**: Include a screenshot of your Google Sheet script to show the "Automation."
- **行動**：發布完整影片並配上「我如何達成」的說明，附上 Google 表格截圖以展示「自動化」。

### 4. Discord Resource Share
- **Edit**: Create a 5-second GIF of the smoothest hair/physics part.
- **Message**: "Made a tool to automate this. Smoothest physics I've ever recorded!"
- **行動**：製作一段 5 秒的物理效果精華 GIF，分享到資源頻道並強調這是自動錄製的成果。

### 5. Notion/Blog Case Study
- **Edit**: Use the video as a header for a "Behind the Scenes" post.
- **Goal**: Build long-term authority by explaining the Puppeteer/Browser tech.
- **行動**：將影片作為「幕後花絮」文章的標題影片，透過解釋技術原理建立長期權威。

---

## 📈 The 1:5 Rule | 1:5 原則
Never post just once. For every minute you spend recording, spend 5 minutes distributing that content across all your channels.

-----

*Created by Project Assistant on 2026-01-06*
