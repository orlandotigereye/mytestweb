# 打造第二收入的實戰策略 | Practical Strategy for Building a Second Income

## 1. 現狀診斷：為什麼沒人理你？ | Diagnosis: Why No Response?
**IG 的問題：過於靜態或缺乏吸引力 | IG Issues: Too static or low hook**
- 演算法現在偏好 **Reels (短影音)**。如果你只發圖片，觸及率會很低。
- Reels algorithm favors short videos. Static images get very low reach now.

**Reddit 的問題：被視為廣告 | Reddit Issues: Seen as an Ad**
- Reddit 非常排斥直接的廣告。如果你只是貼連結，會被封鎖或無視。
- Reddit hates direct ads. Posting only links leads to bans or being ignored.

---

## 2. 轉型策略：從「推銷」變「解決問題」 | Strategy: From Selling to Solving
**找到一個痛點 | Find a Pain Point**
- 不要賣「產品」，要賣「解決方案」。例如：不是賣 Live2D 工具，是賣「讓 VTuber 每天省下 2 小時的方法」。
- Don't sell "products"; sell "solutions." E.g., not "Live2D tool," but "How to save 2 hours daily for VTubers."

**建立信任感 | Build Trust**
- 在 Reddit 上，先去別人的問題下提供有價值的建議，不要放連結。等累積了聲望 (Karma)，別人才會看你的個人簡介。
- On Reddit, provide valuable advice first without links. Build Karma so people check your profile naturally.

---

## 3. 具體執行步驟 | Specific Action Steps

### 第一步：內容優化 (IG) | Step 1: Content Optimization (IG)
- **製作 7-15 秒的 Reels**：展示 Live2D 自動錄影的成果，配上流行的音樂。
- Create 7-15s Reels: Show the Live2D auto-recording results with trending music.
- **標題要吸睛**：例如「當我發現不用自己錄影時...」。
- Use catchy hooks: e.g., "When I realized I didn't have to record manually..."

### 第二步：社群滲透 (Reddit) | Step 2: Community Infiltration (Reddit)
- **搜尋關鍵字**：到 `r/VTuber`, `r/Live2D`, `r/SideHustle` 搜尋別人的困擾。
- Search Keywords: Look for struggles in subreddits like `r/VTuber` or `r/SideHustle`.
- **真心回覆**：回覆 10 個人的問題，第 11 個才提到你有一個工具可以幫忙。
- Genuine Replies: Reply to 10 people's questions; mention your tool only on the 11th.

### 第三步：產品落地 (Gumroad/Notion) | Step 3: Product Landing (Gumroad/Notion)
- **提供免費試用版**：先給一個超簡單的免費模板，換取對方的 Email。
- Offer a Free Sample: Give away a simple template in exchange for their Email.
- **建立名單**：有了 Email，你才能進行後續的行銷，而不是每天等演算法垂憐。
- Build a List: With Emails, you can market directly instead of waiting for algorithms.

---

## 4. 目標：第一筆收入 (The Goal: First Income)
- **不要追求多，先追求 1**。只要有 1 個人願意付錢，就代表這個商業模式可行。
- Don't aim for many; aim for 1. If 1 person pays, the business model is validated.

---
*Created by Project Assistant on 2026-01-06*
