# Hashtag & Keyword Strategy | 社群媒體標籤與關鍵字策略

Use these sets to maximize the organic reach of your IG Reels, X posts, and Reddit threads.
使用這些組合來極大化您的 IG Reels、X 貼文與 Reddit 討論串的自然觸及率。

---

## 📸 Instagram Reels: The "Mixed" Strategy | IG 策略
Copy and paste these groups depending on your post type. (建議混合使用大眾與小眾標籤)

**Set A: General VTuber (大眾標籤)**
`#VTuber #Live2D #VTuberEN #VTuberTW #AnimeArt #DigitalArt`

**Set B: Technical & Tools (小眾/工具標籤)**
`#Live2DShowcase #Live2DRigging #VTuberAssets #StreamerTools #IndieDev`

**Set C: Your Brand (品牌標籤)**
`#PortfolioMaster #AutoRecord #AutomationRobot`

---

## 🐦 X (Twitter): The "Trending" Strategy | X 策略
X is all about what’s happening NOW. Use only 2-3 high-impact tags.

- **Primary Tags**: `#Live2D #VTuber #VTuberAssets`
- **Artist Tags**: `#Live2DCommissions #Live2DModel`
- **The "Rigger" Tag**: `#Live2DRigging` (This is where your target customers hang out!)

---

## 🔍 Reddit: The "Lead Finder" Keywords | Reddit 搜尋關鍵字
Use these in the Reddit search bar to find people who need your help:
在 Reddit 搜尋列輸入這些詞，尋找需要協助的人：
- `Live2D "recording"`
- `Live2D "tedious"`
- `Live2D "smooth"`
- `"record" showcase`
- `"obs" lag Live2D`

---

## 🚀 Pro Tip | 專家建議
On Instagram, hide your hashtags in the **first comment** instead of the caption to keep your post looking clean and professional.

-----

*Created by Project Assistant on 2026-01-06*
