# First Demo Video Script | 第一支演示影片腳本 (Reel/TikTok/Shorts)

**Format**: 10-15 Seconds, Fast-paced.
**格式**：10-15 秒，節奏快速。

---

## 🎬 Visual & Audio Plan | 畫面與音訊計畫

- **0-3s (The Hook)**: 
  - **Visual**: A close-up of a Live2D model looking bored or "frozen."
  - **Text on Screen**: "Stop manually recording your showcases. 🛑"
  - **Audio**: Fast, high-energy anime beat.
  - **行動**：Live2D 模型看起來很無聊或「凍結」的特寫。螢幕文字：「停止手動錄製展示影片。🛑」音訊：快速、高能量的動漫節奏。

- **3-8s (The Magic)**:
  - **Visual**: Transition to the character moving perfectly (use **L09 template**). Show your hands in the frame (real or recorded) away from the keyboard.
  - **Text on Screen**: "100% Automated via Google Sheets. ✨"
  - **Audio**: Transition to a smoother, "magical" sound effect.
  - **行動**：切換到角色完美移動的畫面（使用 L09 模板）。展示你的雙手遠離鍵盤。螢幕文字：「透過 Google 表格 100% 自動化。✨」音訊：切換到更順滑、「魔幻」的音效。

- **8-12s (The Result)**:
  - **Visual**: Show the hair/clothing physics flowing smoothly in slow motion.
  - **Text on Screen**: "No Lag. Perfect Physics. 💎"
  - **行動**：展示頭髮/衣服物理效果在慢動作下順滑流動。螢幕文字：「不卡頓。完美物理效果。💎」

- **12-15s (The CTA)**:
  - **Visual**: Show the Gumroad page ($0+). 
  - **Text on Screen**: "Get the FREE template in bio! 📥"
  - **Audio**: "Ding!" sound effect at the end.
  - **行動**：展示 Gumroad 頁面 ($0+)。螢幕文字：「在個人簡介獲取免費模板！📥」音訊：結尾一聲 "叮！"。

---

## 📝 Caption Copy | 貼文說明文字
**English**:
"Say goodbye to manual mouse-clicking! 🤖 I built an automation tool that lets your Live2D models act on their own via Google Sheets. Perfect for smooth portfolio showcases. Download the base template for FREE at the link in my bio! 🚀 #Live2D #VTuber #VTuberAssets #Automation"

**Chinese**:
「告別手動點擊滑鼠！🤖 我做了一個自動化工具，讓你的 Live2D 模型能透過 Google 表格自動演戲。非常適合製作平滑的作品集展示。點擊個人簡介連結免費下載基礎模板！🚀 #Live2D #VTuber #自動化 #創作工具」

-----

*Created by Project Assistant on 2026-01-06*
