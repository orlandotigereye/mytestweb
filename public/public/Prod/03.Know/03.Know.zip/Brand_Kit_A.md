# Social Media Brand Kit | 社群媒體品牌視覺組

Use this guide to ensure your profiles and content look professional and consistent.
使用此指南確保您的個人檔案與內容看起來專業且一致。

---

## 🎨 1. Color Palette | 標準色調
**Primary: Success Gold (核心金)**
- **HEX**: `#fbbf24` (Tailwind Amber-400)
- **Use**: Buttons, Hook text, key highlights.

**Secondary: Deep Slate (質感深)**
- **HEX**: `#0f172a` (Tailwind Slate-900)
- **Use**: Backgrounds for text, professional headers.

**Accent: VTuber Pink (活力粉)**
- **HEX**: `#f472b6` (Tailwind Pink-400)
- **Use**: Secondary highlights, "kawaii" elements to appeal to the anime community.

---

## ✍️ 2. Typography | 字體建議
**English (Body & Headlines)**: 
- **Inter** or **Montserrat** (Modern, tech-focused, easy to read on mobile).

**Chinese (Body & Headlines)**: 
- **Noto Sans TC** (Clean, professional, and standard across all devices).

---

## 🗣️ 3. Tone of Voice | 品牌語氣
- **Key Attributes**: Expert, Helpful, Efficient, Minimalist.
- **The "Vibe"**: You are the "Tech Wizard" who solves the boring manual work so artists can focus on their "Magic" (Art).
- **Example**: Instead of saying "I sell code," say "I give you back your time."

---

## 🖼️ 4. Visual Style | 視覺風格
- **Screenshots**: High-resolution, clean backgrounds only.
- **Videos**: Fast-paced (Reels style), use "Before & After" transitions.
- **UI**: Always hide toolbars and cursors in final demo videos.

---

## 🚀 Action Step | 行動步驟
Update your **Bento.me** profile colors to match the Success Gold (#fbbf24) today.

-----

*Created by Project Assistant on 2026-01-06*
