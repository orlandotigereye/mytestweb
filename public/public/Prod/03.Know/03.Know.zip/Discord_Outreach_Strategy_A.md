# Discord Community Outreach Strategy | Discord 社群開發策略

## 1. Where to Find Servers | 去哪裡找伺服器
Search on **Disboard.org** or **DiscordMe** for these tags:
在 Disboard 或 DiscordMe 搜尋這些標籤：
- `Live2D`
- `VTuber Assets`
- `VTuber Help`
- `Art Resources`

---

## 2. The "Community Member" Approach | 「社群成員」切入法
**Rule #1**: Read the rules! Most servers have a specific channel for self-promotion. (遵守規範：大多數伺服器有專門的自我推薦頻道)
**Rule #2**: Don't DM people without asking first. (不要在沒詢問的情況下私訊別人)

### **Channel: #resources or #tools-and-scripts**
"Hey everyone! I’ve been working on a way to automate Live2D portfolio showcases because I found manual recording to be super tedious. I made a script that reads from a Google Sheet and records the character automatically (clean view, no UI). 

I'm giving the base template away for free to get some feedback from other artists. If you record showcases often, feel free to grab it here: [Gumroad Link]"

---

## 3. The "Expert Help" Approach | 「專家協助」切入法
Look in `#help` or `#questions` channels. If someone asks: *"How do I make my recording look smoother?"* or *"My PC lags when recording,"* use this:

"I had the same lag issues with OBS. I ended up building a browser-based recorder using Puppeteer—it's much lighter on the CPU and automates the movements. You're welcome to try my free version if you want to see if it fixes the lag for you!"

---

## 4. Building Your Own Server | 建立自己的伺服器
Once you get your first 10-20 users, create a **"Live2D Automation Support"** server.
- **Benefit**: You can collect feedback directly.
- **Benefit**: You can announce "Pro" paid versions to your most loyal users first.

-----

*Created by Project Assistant on 2026-01-06*
