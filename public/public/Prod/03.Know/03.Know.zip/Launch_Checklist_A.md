# Live2D Business Launch Checklist | 事業發布檢核表

Follow these 5 steps to go live today.
遵循這 5 個步驟，今天就正式上線。

---

## ✅ Step 1: Finalize Gumroad Listing | 完備 Gumroad 頁面
- [ ] Create a product named "Live2D Portfolio Master".
- [ ] Set price to **$0+**.
- [ ] Upload the `LiveOnly260304L09.html` and `record_live2d_Final_Pro_D.js` as the "Pro D" package.
- [ ] Include the `Live2D_Recording_Instructions_A.txt` as the guide.

---

## ✅ Step 2: Set Up Landing Page | 設定落地頁面
- [ ] Create a **Bento.me** or **Linktree** profile.
- [ ] Add your Gumroad link as the main button.
- [ ] Put this link in your Instagram and X (Twitter) bio.

---

## ✅ Step 3: Record Your First Demo | 錄製第一段展示
- [ ] Run `node public/note_js/record_live2d_Final_Pro_D.js`.
- [ ] Take that MP4 file and post it as an IG Reel or X video.
- [ ] **Caption Hook**: "POV: Recording a Live2D showcase without moving my hands. 🤖✨"

---

## ✅ Step 4: First Reddit Outreach | 第一次 Reddit 開發
- [ ] Go to `r/Live2D`.
- [ ] Find a recent "Showcase" or "Help" post.
- [ ] Use the **"Complimentary Expert"** script to leave a helpful comment.

---

## ✅ Step 5: Start the Tracker | 啟動追蹤表
- [ ] Open `Outreach_Tracker_A.md`.
- [ ] Log your first outreach attempt.
- [ ] Commitment: Contact **3 artists** per day for the next 7 days.

---

## 🚀 YOU ARE READY! | 您已準備就緒！
You have the product, the strategy, and the tools. Now, let the world see what you've built.

-----

*Created by Project Assistant on 2026-01-06*
